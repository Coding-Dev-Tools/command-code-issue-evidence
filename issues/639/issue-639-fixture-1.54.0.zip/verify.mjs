import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
const dir=process.argv[2]?path.resolve(process.argv[2]):path.dirname(fileURLToPath(import.meta.url));const read=n=>JSON.parse(fs.readFileSync(path.join(dir,n),'utf8'));const data={windows:read('windows-results.json'),linux:read('linux-tmpfs-results.json')};
function verify(data){for(const[platform,x]of Object.entries(data)){
 assert.equal(x.failure,null);assert.equal(x.rows.length,15);assert.equal(x.bundleSha256,'0de512d28b0a66708fbb0e367443ad7f9f9d4e8eda62a76563f1493b997dd61d');
 const r=n=>x.rows.find(y=>y.name===n),errno=platform==='windows'?'ENOENT':'ENAMETOOLONG';
 for(const name of ['long-six','long-retry','ascii256-six','preamble-no-heading','valid-then-long']){assert.equal(r(name).error.code,errno);assert.equal(r(name).files['taste.md'],r(name).rootBefore);}
 assert.equal(r('long-five').error,null);assert.equal(r('long-five').files['taste.md'],r('long-five').rootBefore);
 assert.equal(r('ascii255-six').error,null);assert.equal(r('unicode260bytes-six').error?.code??null,platform==='windows'?null:errno);
 assert.equal(r('preamble-no-heading').categories[0].learningCount,6);assert.ok(r('preamble-no-heading').categories[0].name.startsWith('- '));
 assert.ok(r('short-six').files['workflow/taste.md'].includes('SHORT_5'));assert.deepEqual(r('short-repeat').files,r('short-six').files);
 const recovery=r('renamed-recovery').files['recovered/taste.md'];for(let i=0;i<6;i++)assert.ok(recovery.includes(`SIX_${i}`));
 const coll=r('slug-collision');assert.ok(!JSON.stringify(coll.files).includes('FIRST_0'));assert.ok(coll.files['workflow-a/taste.md'].includes('SECOND_5'));assert.equal((coll.files['taste.md'].match(/See \[/g)??[]).length,2);
 const mixed=r('mixed-recovery');for(let i=0;i<6;i++){assert.ok(mixed.files['workflow/taste.md'].includes(`VALID_${i}`));assert.ok(mixed.files['shortcategory/taste.md'].includes(`INVALID_${i}`));}
}}
verify(data);const mutations=[x=>x.linux.rows.find(r=>r.name==='long-six').error.code='ENOENT',x=>x.windows.rows.find(r=>r.name==='long-six').files['taste.md']='',x=>x.windows.rows.find(r=>r.name==='renamed-recovery').files['recovered/taste.md']='SIX_5',x=>x.linux.rows.find(r=>r.name==='slug-collision').files['workflow-a/taste.md']+='FIRST_0',x=>x.linux.rows.find(r=>r.name==='preamble-no-heading').categories[0].learningCount=5,x=>x.windows.failure={message:'unexpected'}];for(const mutate of mutations){const bad=structuredClone(data);mutate(bad);assert.throws(()=>verify(bad));}
const result={ok:true,negativeMutationsRejected:mutations.length,scope:'Independent retained-content, errno, recovery, collision and failure checks; no new product execution.'};fs.writeFileSync(path.join(dir,'verification.json'),JSON.stringify(result,null,2)+'\n');console.log(result);
