import fs from 'node:fs';import fsp from 'node:fs/promises';import path from 'node:path';import os from 'node:os';import vm from 'node:vm';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
const expected='0de512d28b0a66708fbb0e367443ad7f9f9d4e8eda62a76563f1493b997dd61d';
if(!process.argv[2])throw Error('Usage: node repro.mjs PATH_TO_command-code_dist_cli.mjs OUTPUT_DIRECTORY');
const bundle=fs.readFileSync(path.resolve(process.argv[2])),sha=createHash('sha256').update(bundle).digest('hex');assert.equal(sha,expected);
const source=bundle.toString(),a=source.indexOf('function parseCategories('),b=source.indexOf('function emitLearningSignals(',a);assert.ok(a>=0&&b>a);
const ctx=vm.createContext({});vm.runInContext(source.slice(a,b),ctx);
const base=path.resolve(process.argv[3]??'.');fs.mkdirSync(base,{recursive:true});const out=fs.mkdtempSync(path.join(base,'taste639-')),rows=[];
const section=(name,count,prefix,heading=true)=>(heading?'# ':'')+name+'\n'+Array.from({length:count},(_,i)=>`- ${prefix}_${i}. Confidence: 0.90`).join('\n')+'\n';
const runtime={fs:{exists:async({path:p})=>fsp.access(p).then(()=>true,()=>false),read:async({path:p})=>fsp.readFile(p,'utf8'),mkdir:async({path:p})=>fsp.mkdir(p,{recursive:true}),write:async({path:p,content})=>fsp.writeFile(p,content)}};
async function filesUnder(dir){const result={};async function visit(d){for(const f of await fsp.readdir(d,{withFileTypes:true})){const p=path.join(d,f.name);if(f.isDirectory())await visit(p);else result[path.relative(dir,p).replaceAll('\\','/')]=await fsp.readFile(p,'utf8');}}await visit(dir);return result;}
async function invoke(name,input,{dir,expectedError=false}={}){
 dir??=path.join(out,name);await fsp.mkdir(dir,{recursive:true});if(input!==null)await fsp.writeFile(path.join(dir,'taste.md'),input);
 const before=await fsp.readFile(path.join(dir,'taste.md'),'utf8'),notices=[];let error=null;
 try{await ctx.reorganizeIfNeeded({runtime,dir,emit:e=>notices.push(e)});}catch(e){error={name:e.name,code:e.code,syscall:e.syscall};}
 const files=await filesUnder(dir),after=files['taste.md'],row={name,categories:ctx.parseCategories(before).map(x=>({name:x.name,learningCount:x.learningCount,utf8Bytes:Buffer.byteLength(x.name)})),error,rootUnchanged:before===after,rootBefore:before,files,notices};rows.push(row);
 assert.equal(!!error,expectedError,name+' error');return {row,dir};
}
let failure=null;
try{
 const long='preference-'+ 'a'.repeat(280);
 const healthy=await invoke('short-six',section('workflow',6,'SHORT'));assert.ok(healthy.row.files['workflow/taste.md']);assert.ok(healthy.row.files['taste.md'].includes('See ['));
 const repeat=await invoke('short-repeat',null,{dir:healthy.dir});assert.deepEqual(repeat.row.files,healthy.row.files);
 const five=await invoke('long-five',section(long,5,'FIVE'));assert.equal(five.row.rootUnchanged,true);
 const six=await invoke('long-six',section(long,6,'SIX'),{expectedError:true});assert.equal(six.row.rootUnchanged,true);assert.equal(Object.keys(six.row.files).length,1);
 const retry=await invoke('long-retry',null,{dir:six.dir,expectedError:true});assert.deepEqual(retry.row.files,six.row.files);
 const recovery=await invoke('renamed-recovery',six.row.rootBefore.replace('# '+long+'\n','# recovered\n'),{dir:six.dir});assert.ok(recovery.row.files['recovered/taste.md'].includes('SIX_5'));assert.equal(recovery.row.error,null);
 await invoke('ascii255-six',section('x'.repeat(255),6,'A255'));
 await invoke('ascii256-six',section('x'.repeat(256),6,'A256'),{expectedError:true});
 await invoke('unicode260bytes-six',section('é'.repeat(130),6,'UNICODE'),{expectedError:process.platform!=='win32'});
 const noHeading='- '+ 'preference'.repeat(31)+'. Confidence: 0.90';
 const malformed=await invoke('preamble-no-heading',noHeading+'\n'+Array.from({length:5},(_,i)=>`- PREAMBLE_${i}. Confidence: 0.90`).join('\n')+'\n',{expectedError:true});assert.equal(malformed.row.categories[0].learningCount,6);assert.ok(malformed.row.categories[0].name.startsWith('- '));
 const noCount=await invoke('unrecognized-confidence',section(long,6,'NOCOUNT').replaceAll('Confidence:','confidence:'));assert.equal(noCount.row.rootUnchanged,true);
 const nested=await invoke('nested-name',section('nested/category',6,'NESTED'));assert.ok(nested.row.files['nested/category/taste.md']);
 const collision=await invoke('slug-collision',section('Workflow A',6,'FIRST')+section('workflow-a',6,'SECOND'));
 assert.ok(!JSON.stringify(collision.row.files).includes('FIRST_0'));assert.ok(collision.row.files['workflow-a/taste.md'].includes('SECOND_5'));
 const mixed=await invoke('valid-then-long',section('workflow',6,'VALID')+section(long,6,'INVALID'),{expectedError:true});assert.equal(mixed.row.rootUnchanged,true);assert.ok(mixed.row.files['workflow/taste.md'].includes('VALID_5'));
 const fixed=await invoke('mixed-recovery',mixed.row.rootBefore.replace('# '+long+'\n','# shortcategory\n'),{dir:mixed.dir});assert.ok(fixed.row.files['shortcategory/taste.md'].includes('INVALID_5'));assert.ok(fixed.row.files['workflow/taste.md'].includes('VALID_5'));
}catch(e){failure={message:e.message,stack:e.stack};}
const result={version:'1.54.0',bundleSha256:sha,node:process.version,platform:process.platform,osRelease:os.release(),scope:'Exact unmodified extracted parseCategories/reorganizeIfNeeded; actual filesystem adapters. Seeded text, no CLI/model session. Linux container is not macOS. No claim about original generated taste.md.',extraction:{start:a,end:b,sha256:createHash('sha256').update(source.slice(a,b)).digest('hex')},rows,failure};fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({out,rows:rows.map(r=>({name:r.name,error:r.error,rootUnchanged:r.rootUnchanged,fileCount:Object.keys(r.files).length})),failure}));if(failure)process.exitCode=1;
