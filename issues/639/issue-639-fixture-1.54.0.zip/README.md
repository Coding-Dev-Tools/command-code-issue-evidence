# Issue 639 fixture

Exact extracted parseCategories/reorganizeIfNeeded from Command Code 1.54.0 with actual filesystem adapters. Fifteen cases were run on Windows/Node 24.15.0 and on Linux tmpfs/Node 22.23.2. No full CLI learning session, real model or original macOS session was run.

Extract this packet in a fresh writable directory, then:

```sh
npm pack command-code@1.54.0
tar -xf command-code-1.54.0.tgz
node repro.mjs package/dist/cli.mjs runs
node verify.mjs
```

Package acquisition uses the registry; the experiment itself is offline and requires only Node built-ins and the acquired cli.mjs. The bundle SHA256 is checked before extraction. Every invocation creates a fresh taste639-* directory. Nothing in an existing real Taste directory is read or changed.

The cases cover five/six learnings, 255/256 ASCII characters, UTF-8 byte length, malformed preamble categories, lowercased/hyphenated collisions, a nested category, repeated errors, naming recovery and a valid category before a failing one. Results retain complete synthetic before/after bytes and category metadata. Naming recovery edits the seeded header, not production code. Root preservation in mkdir failures does not establish universal failure atomicity. The collision demonstrates actual loss from the resulting synthetic file set but is not alleged to be the original incident.

Linux primary results used tmpfs in a network-disabled, read-only Docker container; exact image/Node provenance is recorded. An earlier Linux run used a Windows-backed bind mount and is excluded from the primary native-filesystem comparison. Linux errno reproduction is not a macOS reproduction.

`verify.mjs` checks retained Windows/Linux results, complete learning markers, errors, root preservation, collision behavior and six corruptions. It does not run product code or automatically choose new outputs. Fresh replay asserts expected current behavior and writes separate results. Change these expected-failure assertions to the agreed acceptance behavior when testing a fix.

No product bundle, private project, real Taste content, credential or public submission is included. The ZIP contains this runnable fixture and the retained observations.
