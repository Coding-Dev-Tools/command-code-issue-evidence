import fs from 'node:fs';
import vm from 'node:vm';
import crypto from 'node:crypto';

const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const escaped = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Extract only the published model canonicalizer, its literal data, and the
// published deferral predicate. Nothing is imported from the product runtime.
export function loadDeferredModelSupport(bundlePath) {
  const bytes = fs.readFileSync(bundlePath);
  const source = bytes.toString('utf8');
  const ranges = [];
  function range(name, start, end) {
    if (start < 0 || end <= start) throw new Error(`Missing source: ${name}`);
    const code = source.slice(start, end);
    const entry = { name, startUtf16: start, endUtf16: end,
      startByte: Buffer.byteLength(source.slice(0, start)),
      endByte: Buffer.byteLength(source.slice(0, end)), sha256: hash(code), code };
    ranges.push(entry);
    return code;
  }
  function functionSource(name) {
    const first = `function ${name}(`;
    const start = source.indexOf(first);
    if (start < 0) throw new Error(`Missing function ${name}`);
    const next = /(?:async )?function [A-Za-z_$]/g;
    next.lastIndex = start + first.length;
    const match = next.exec(source);
    if (!match) throw new Error(`Missing end of ${name}`);
    return range(name, start, match.index);
  }
  function constant(name, initializerPattern) {
    const expression = new RegExp(`\\b${escaped(name)}=${initializerPattern}`, 'g');
    const match = expression.exec(source);
    if (!match) throw new Error(`Missing literal initializer for ${name}`);
    if (expression.exec(source)) throw new Error(`Ambiguous initializer for ${name}`);
    return range(name, match.index, match.index + match[0].length);
  }
  const definitions = ['findKnownById', 'tryResolveCanonical',
    'canonicalizeModelId', 'supportsDeferredTools'].map(functionSource);
  const names = {
    knownIds: definitions[0].match(/for\(const \w+ of (\w+)\)/)?.[1],
    aliases: definitions[1].match(/findKnownById\(\((\w+)\[/)?.[1],
    dateSuffix: definitions[2].match(/\.replace\((\w+),""\)/)?.[1],
    deferredExceptions: definitions[3].match(/return!(\w+)\.has/)?.[1],
  };
  if (Object.values(names).some(name => !name)) throw new Error('Unrecognized canonicalizer shape');
  const known = constant(names.knownIds, 'new Set\\(\\[[\\s\\S]*?\\]\\)');
  const exceptions = constant(names.deferredExceptions, 'new Set\\(\\[[\\s\\S]*?\\]\\)');
  const aliases = constant(names.aliases, '\\{[^}]*\\}');
  const suffix = constant(names.dateSuffix, '/(?:\\\\.|[^/\\r\\n])*/[dgimsuvy]*');
  // Published known-ID sets contain a string-valued alias such as `dr`.
  // Copy its original literal initializer too, rather than inventing a value.
  const dependencies = new Set();
  for (const declaration of [known, exceptions]) {
    const contents = declaration.slice(declaration.indexOf('[') + 1, declaration.lastIndexOf(']'));
    const withoutStrings = contents.replace(/"(?:\\.|[^"\\])*"/g, '');
    for (const name of withoutStrings.match(/[A-Za-z_$][\w$]*/g) ?? []) dependencies.add(name);
  }
  const literals = [...dependencies].map(name => constant(name, '"(?:\\\\.|[^"\\\\])*"'));
  const initializerSource = `var ${[...literals, known, exceptions, aliases, suffix].join(',')};`;
  const functionCode = definitions.join('\n');
  const context = vm.createContext({});
  vm.runInContext(initializerSource + '\n' + functionCode, context,
    { filename: 'exact-published-deferred-model-support.js' });
  return {
    supportsDeferredTools: model => context.supportsDeferredTools(model),
    canonicalizeModelId: model => context.canonicalizeModelId({ model }),
    initializerSource,
    functionSource: functionCode,
    metadata: { bundleSHA256: hash(bytes), names,
      ranges: ranges.map(({ code, ...entry }) => entry) },
  };
}
