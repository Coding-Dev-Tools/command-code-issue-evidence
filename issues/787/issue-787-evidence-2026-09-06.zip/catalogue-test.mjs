// Exact published-component test. No model inference or external network.
// Usage: node catalogue-test.mjs OLD_CLI_MJS NEW_CLI_MJS [OUTPUT_DIRECTORY]
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { loadDeferredModelSupport } from './disclosure-review/deferred-model-support.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const [oldArg, newArg, outArg] = process.argv.slice(2);
assert(oldArg && newArg, 'Supply published 1.40.0 and installed 1.49.1 cli.mjs paths');
const out = path.resolve(outArg ?? path.join(here, 'component-output'));
fs.mkdirSync(out, { recursive: true });
const hash = x => crypto.createHash('sha256').update(x).digest('hex');
let assertions = 0;
const check = (a, b, message) => { assert.deepEqual(a, b, message); assertions++; };
const installedRoot = path.dirname(path.dirname(path.resolve(newArg)));
const requireInstalled = createRequire(path.resolve(newArg));
const serializerPath = path.join(installedRoot, 'node_modules/@ai-sdk/openai-compatible/dist/internal/index.js');
const { prepareTools } = requireInstalled(serializerPath);
const sdkVersion = JSON.parse(fs.readFileSync(path.join(installedRoot, 'node_modules/@ai-sdk/openai-compatible/package.json'))).version;

function extractContext(bundle, version) {
  const source = fs.readFileSync(bundle, 'utf8'), ranges = [];
  const take = (name, startMarker, endMarker) => {
    const start = source.indexOf(startMarker), end = source.indexOf(endMarker, start + startMarker.length);
    assert(start >= 0 && end > start, `Missing ${name}`);
    const code = source.slice(start, end);
    ranges.push({ name, startUtf16: start, endUtf16: end, startByte: Buffer.byteLength(source.slice(0, start)), endByte: Buffer.byteLength(source.slice(0, end)), sha256: hash(code) });
    return code;
  };
  const mode = take('modeFilter', 'function isMcpToolName(', 'function isToolAllowedInMode(');
  const catalogue = take('catalogueAndSearch', 'function tokenize(', 'function blockCancelsWait(');
  const search = take('searchTool', 'function renderSchema(', 'async function truncateContent(');
  const runner = take('runner', 'function createToolRunner(', 'function sanitizeAgentName(');
  const adapter = take('sdkToolAdapter', 'function toAiSdkToolSchemas(', 'function normalizeStopReason2(');
  const schemaName = /schema:\{name:(\w+),/.exec(search)[1];
  const retiredName = /schema:\{\.\.\.t.schema,name:(\w+),/.exec(search)[1];
  const maximumName = /maximum:(\w+),default:/.exec(search)[1];
  const defaultName = /maximum:\w+,default:(\w+)/.exec(search)[1];
  const sandbox = {
    __name: f => f,
    // Exact valid fixtures avoid repair/truncation, which are not under test.
    repairToolInput: ({ input }) => ({ input, repairs: [] }),
    truncateContent: async ({ content }) => content,
    applyRepairNotes: ({ content }) => content,
    resolveToolNameAlias: options => options,
    toRecords: x => x,
  };
  const literal = name => {
    const marker = name + '=', start = source.indexOf(marker);
    assert(start >= 0, `Missing constant ${name}`);
    const rest = source.slice(start + marker.length);
    const text = rest.startsWith('[') ? rest.slice(0, rest.indexOf(']') + 1) : /^[^,;]+/.exec(rest)[0];
    // Only arrays of strings, numbers, and strings are accepted here.
    assert(/^\[[\s\S]*\]$|^"[^"]*"$|^[.\d]+$/.test(text), `Unexpected literal ${name}`);
    const value = vm.runInNewContext(text);
    ranges.push({ name: `constant:${name}`, startUtf16: start, endUtf16: start + marker.length + text.length, sha256: hash(marker + text) });
    return value;
  };
  for (const match of mode.matchAll(/!(\w+)\.includes\(/g)) sandbox[match[1]] = literal(match[1]);
  for (const name of [schemaName, retiredName, maximumName, defaultName]) sandbox[name] = literal(name);
  // Failed exact matches (e.g. hidden tools) take the normal ranked-search path.
  const weightName = /Array\.from\(\{length:(\w+)\}/.exec(catalogue)[1];
  const scoreNames = /s=(\w+)\*\(1-(\w+)\+/.exec(catalogue);
  for (const name of [weightName, scoreNames[1], scoreNames[2]]) sandbox[name] = literal(name);
  vm.createContext(sandbox);
  vm.runInContext([mode, catalogue, search, runner, adapter].join('\n'), sandbox);
  return { sandbox, provenance: { version, bundleSha256: hash(Buffer.from(source)), ranges } };
}

function fixtureTools() {
  let executions = 0;
  const make = (name, properties = {}) => ({
    schema: { name, description: `Synthetic ${name} fixture.`, input_schema: { type: 'object', properties: { value: { type: 'string' } }, required: [], additionalProperties: false } },
    readOnly: true, ...properties,
    run: async () => { executions++; return { ok: true, content: [{ type: 'text', text: 'SYNTHETIC_TOOL_OK' }] }; },
  });
  return { tools: [
    make('read_file'), make('web_search', { shouldDefer: true }),
    make('mcp__fixture__ping', { isExternal: true }),
    make('mcp__fixture__hidden', { isExternal: true, visible: () => false }),
    make('mcp__fixture__always', { isExternal: true, alwaysLoad: true }),
  ], executions: () => executions };
}

const results = {
  generatedAt: new Date().toISOString(), node: process.version, platform: process.platform,
  scope: 'Exact published catalogue/search/runner functions with synthetic tools; installed current OpenAI-compatible serializer. No complete CLI execution in this script.',
  substitutions: ['identity valid-input repair', 'identity small-output truncation/repair-note helpers', 'identity alias resolver', 'synthetic runtime and tool implementations', 'identity jsonSchema adapter before direct prepareTools invocation'],
  serializer: { package: '@ai-sdk/openai-compatible', version: sdkVersion, sha256: hash(fs.readFileSync(serializerPath)), appliedToBothCatalogueVersions: true },
  versions: [], runs: [],
};

for (const [version, bundle] of [['1.40.0', oldArg], ['1.49.1', newArg]]) {
  const { sandbox: api, provenance } = extractContext(path.resolve(bundle), version);
  const support = loadDeferredModelSupport(path.resolve(bundle));
  const modelCases = [
    ['z-ai/glm-5.3-flash', false], ['zai-org/GLM-5.3', false],
    ['neuralwatt/glm-5.3-flash', true], ['openrouter/z-ai/glm-5.3-flash', true],
    ['neuralwatt/glm-5.2', true], ['glm-5.3-flash', true],
  ].map(([model, expected]) => {
    const canonicalModel = support.canonicalizeModelId(model), deferred = support.supportsDeferredTools(model);
    check(deferred, expected, 'Exact model canonicalizer/deferral decision');
    return { model, canonicalModel, deferred };
  });
  provenance.modelSupport = { metadata: support.metadata, cases: modelCases };
  results.versions.push(provenance);
  if (version === '1.49.1') check(provenance.bundleSha256, '10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05', 'Current published bundle identity');
  for (const defer of [true, false]) for (const mode of ['default', 'plan']) {
    const fixture = fixtureTools();
    const runner = api.createToolRunner({ runtime: {}, tools: fixture.tools,
      defer: () => defer ? support.supportsDeferredTools('neuralwatt/glm-5.3-flash') : false });
    const names = schemas => Array.from(schemas, x => x.name);
    const before = runner.getSchemas({ mode });
    const search = await runner.execute({ toolName: 'search_tools', input: { query: 'select:web_search,mcp__fixture__ping,mcp__fixture__hidden' }, permissionMode: mode });
    check(search.ok, true, 'Search tool returned normally');
    const text = search.content.map(x => x.text ?? '').join('\n');
    const after = runner.getSchemas({ mode });
    check(names(after), names(before), 'Search leaves declaration list unchanged');
    const expectsMcpLoaded = defer && mode !== 'plan';
    check(text.includes('### web_search'), defer, 'Deferred web schema returned in text');
    check(text.includes('### mcp__fixture__ping'), expectsMcpLoaded, 'Eligible deferred MCP schema returned in text');
    check(text.includes('### mcp__fixture__hidden'), false, 'Hidden fixture not discoverable');
    check(names(after).includes('web_search'), !defer, 'Web declaration depends on deferral, not prior discovery');
    check(names(after).includes('mcp__fixture__ping'), !defer && mode !== 'plan', 'MCP declaration also obeys plan filter');
    check(names(after).includes('mcp__fixture__hidden'), false, 'Hidden fixture remains absent even with eager declaration');
    check(names(after).includes('mcp__fixture__always'), mode !== 'plan', 'alwaysLoad control still obeys plan mode');
    check(fixture.executions(), 0, 'Discovery executed no underlying fixture');
    const sdkTools = api.toAiSdkToolSchemas({ tools: after, jsonSchema: x => x });
    const prepared = prepareTools({ tools: Object.entries(sdkTools).map(([name, t]) => ({ type: 'function', name, description: t.description, inputSchema: t.inputSchema })), toolChoice: { type: 'auto' } });
    const wireNames = prepared.tools.map(x => x.function.name);
    check(wireNames, names(after), 'Actual serializer emits exactly supplied declarations');
    check(prepared.toolWarnings, [], 'Synthetic function schemas serialize without warnings');
    if (mode === 'default') {
      const execute = await runner.execute({ toolName: 'mcp__fixture__ping', input: { value: 'fixture' }, permissionMode: mode });
      check(execute.ok, true, 'Underlying deferred tool can execute if actually called');
      check(fixture.executions(), 1, 'Underlying synthetic MCP fixture executed exactly once');
    }
    results.runs.push({ version, defer, mode, before: names(before), searchText: text, after: names(after), wireNames, preparedTools: prepared.tools, passed: true });
  }
}
results.summary = { passed: true, runs: results.runs.length, assertions,
  deferredDefaultRunsWithDiscoveredToolsStillUndeclared: results.runs.filter(r => r.defer && r.mode === 'default' && !r.wireNames.includes('mcp__fixture__ping')).length,
  eagerDefaultPositiveControls: results.runs.filter(r => !r.defer && r.mode === 'default' && r.wireNames.includes('mcp__fixture__ping')).length };
fs.writeFileSync(path.join(out, 'results.json'), JSON.stringify(results, null, 2));
console.log(JSON.stringify(results.summary, null, 2));
