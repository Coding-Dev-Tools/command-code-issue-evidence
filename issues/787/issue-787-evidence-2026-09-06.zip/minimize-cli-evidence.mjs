// Keeps the evidence needed for #787 without redistributing bundled prompts.
// Usage: node minimize-cli-evidence.mjs OUTPUT_JSON RAW_CAPTURE_JSON [...]
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const [output, ...inputs] = process.argv.slice(2);
assert(output && inputs.length, 'Provide output and at least one raw CLI capture');
const hash = x => crypto.createHash('sha256').update(x).digest('hex');
const target = 'mcp__fixture__echo_probe';
const captures = inputs.map(input => {
  const raw = fs.readFileSync(input), r = JSON.parse(raw);
  assert.equal(r.code, 0, 'Only successful complete probe runs go in the public evidence');
  assert.equal(r.timedOut, false);
  assert.equal(r.requests.length, 2);
  const first = r.requests[0].body, second = r.requests[1].body;
  const names = b => b.tools.map(t => t.function.name);
  assert(names(first).includes('search_tools'));
  assert.deepEqual(names(first), names(second));
  assert(!names(second).includes(target));
  const discovery = second.messages.find(m => m.role === 'tool' && typeof m.content === 'string' && m.content.includes(`### ${target}`));
  assert(discovery, 'Actual next request contains the discovered schema in messages');
  assert(JSON.parse(discovery.content.match(/```json\s*([\s\S]*?)\s*```/)[1]).properties.text);
  const events = r.stdout.split('\n').flatMap(line => {
    if (!line.trim()) return [];
    try {
      const j = JSON.parse(line), e = j.event;
      if (j.type === 'result') return [{ type: 'result', subtype: j.subtype, stopReason: j.stopReason, finalText: j.finalText }];
      if (!e) return [];
      if (['model_request_start', 'model_request_end', 'tool_queued', 'tool_running', 'tool_completed', 'turn_end'].includes(e.type)) {
        const { type, model, stopReason, toolCallId, toolName, input, result, turnNumber, hadToolCalls } = e;
        return [{ type, model, stopReason, toolCallId, toolName, input, result, turnNumber, hadToolCalls }];
      }
      return [];
    } catch { return []; }
  });
  return {
    sourceFilename: path.basename(input), rawFileSha256: hash(raw), mode: r.mode,
    node: r.nodeVersion, cliSha256: r.cliSha256, args: r.args, elapsedMs: r.elapsedMs,
    exitCode: r.code, timedOut: r.timedOut,
    requests: r.requests.map((q, index) => ({
      index: index + 1, path: q.path, model: q.body.model,
      parsedBodyCanonicalJsonSha256: hash(JSON.stringify(q.body)),
      toolNames: names(q.body), declaredToolCount: q.body.tools.length,
      toolsCanonicalJsonSha256: hash(JSON.stringify(q.body.tools)),
      messages: q.body.messages.map(m => {
        if (m.role === 'system') return { role: m.role, omitted: 'Bundled system prompt', canonicalJsonSha256: hash(JSON.stringify(m.content)), characterCount: JSON.stringify(m.content).length };
        return m;
      }),
    })),
    mcpMethods: r.mcpRequests.map(q => q.rpcMethod),
    mcpToolCalls: r.mcpRequests.filter(q => q.rpcMethod === 'tools/call'),
    events,
    verified: { schemaInSearchResultAndNextRequestMessages: true, schemaAbsentFromNextRequestTools: true, sameDeclarationsBeforeAndAfter: true },
  };
});
fs.writeFileSync(output, JSON.stringify({
  scope: 'Minimized actual CLI captures. System prompts and unrelated built-in schemas are omitted; hashes identify the retained local originals. Model responses are synthetic localhost fixtures, not actual provider inference.',
  targetTool: target, captures,
}, null, 2));
console.log(JSON.stringify({ output, verifiedCaptures: captures.length }));
