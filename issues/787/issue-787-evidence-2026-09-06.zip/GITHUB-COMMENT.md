I confirmed the **declaration gap in the unmodified 1.49.1 CLI**, using an isolated Windows run with a synthetic MCP server and localhost OpenAI-compatible responder. No real credentials or inference were used.

With `strict-probe/glm-5.3-flash` on the `openai-completions` wire:

1. Request 1 declared 11 tools, including `search_tools`.
2. The CLI executed discovery and returned the complete schema for `mcp__fixture__echo_probe`.
3. Request 2 still declared the same 11 tools. The discovered schema was present in `messages`, but its tool was absent from `tools`.

The declared-tools-only mock therefore returned no MCP call. Replaying the same captured request with only that tool's declaration appended changed the mock outcome to a tool call. This is a deterministic contract test, **not an independent measurement of NeuralWatt/OpenRouter model behavior**.

The source path explains the capture: `createSearchToolsTool.run()` returns schema text without changing declaration state; `createToolCatalog.schemas()` continues excluding deferred tools; `runAiSdkStream` serializes the supplied tool list.

The model-specific exception matters: canonical `z-ai/glm-5.3-flash` disables deferral, but arbitrary BYOK-qualified IDs do not necessarily receive that exception. Component checks found this distinction in both 1.40.0 and 1.49.1.

**Suggested fix:** add a provider/wire compatibility path that declares eligible tools before use through normal catalogue filtering. Alternatively, promote discovered schemas into subsequent request declarations and require discovery before invocation. Preserve visibility, mode, mod, and permission checks; avoid using `includeHidden:true` as a blanket fix.

**Regression acceptance:** after discovery, assert the exact tool/schema is present in the actual next outgoing request, then verify the mock emits the call, the tool executes, and the run completes. Cover web/MCP tools and custom BYOK IDs.

The attached ZIP includes the runnable fixture, minimized actual request evidence, package hashes, and 8 component scenarios with 117 assertions. The public evidence omits bundled system prompts and contains no real credentials.
