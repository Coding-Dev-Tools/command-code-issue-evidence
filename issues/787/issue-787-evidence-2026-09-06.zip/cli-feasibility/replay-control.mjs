import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root = path.dirname(fileURLToPath(import.meta.url));
const sourceFile = 'results-paired-baseline.json';
const source = JSON.parse(fs.readFileSync(path.join(root, sourceFile), 'utf8'));
assert.equal(source.code, 0);
assert.equal(source.requests.length, 2);
const targetName = 'mcp__fixture__echo_probe';
const first = source.requests[0].body;
const captured = source.requests[1].body;
const names = request => request.tools.map(tool => tool.function.name);
assert.ok(names(first).includes('search_tools'));
assert.ok(!names(first).includes(targetName));
assert.ok(!names(captured).includes(targetName));
assert.deepEqual(names(first), names(captured));
const discovered = captured.messages.find(message => message.role === 'tool').content;
assert.equal(typeof discovered, 'string');
assert.ok(discovered.includes(`### ${targetName}`));
const schemaMatch = discovered.match(/```json\s*([\s\S]*?)\s*```/);
assert.ok(schemaMatch);
const parameters = JSON.parse(schemaMatch[1]);
const appendedTool = { type: 'function', function: { name: targetName,
  description: 'Return a synthetic probe marker. Read-only localhost test fixture.', parameters } };
const declared = structuredClone(captured);
declared.tools.push(appendedTool);
const stripped = structuredClone(declared);
stripped.tools.pop();
assert.deepEqual(stripped, captured);

const server = http.createServer((req, res) => {
  let raw = '';
  req.on('data', chunk => { raw += chunk; });
  req.on('end', () => {
    const body = JSON.parse(raw);
    // Deterministic declaration-only contract fixture, not a real model.
    const canCall = names(body).includes(targetName);
    const message = canCall
      ? { role: 'assistant', content: null, tool_calls: [{ id: 'call_fixture_echo', type: 'function', function: { name: targetName, arguments: JSON.stringify({ text: 'probe' }) } }] }
      : { role: 'assistant', content: 'FIXTURE_UNDECLARED_TOOL', tool_calls: [] };
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ id: 'fixture', object: 'chat.completion', created: 1,
      model: body.model, choices: [{ index: 0, message, finish_reason: canCall ? 'tool_calls' : 'stop' }] }));
  });
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const endpoint = `http://127.0.0.1:${server.address().port}/v1/chat/completions`;
const variants = [];
for (const [name, body] of [['captured-after-discovery', captured], ['same-body-plus-declaration', declared]]) {
  const response = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(2000) });
  const json = await response.json();
  variants.push({ name, requestSha256: createHash('sha256').update(JSON.stringify(body)).digest('hex'), declaredToolNames: names(body), response: json });
}
server.closeAllConnections();
await new Promise(resolve => server.close(resolve));
assert.equal(variants[0].response.choices[0].message.tool_calls.length, 0);
assert.equal(variants[1].response.choices[0].message.tool_calls.length, 1);
const result = { sourceFile, scope: 'A/B replay of a real CLI request to a synthetic declaration-only responder. This demonstrates the declared-tool contract only, not real provider behavior or a product fix.',
  actualCliEvidence: { model: captured.model, requestCount: 2, declaredToolsBefore: names(first), declaredToolsAfter: names(captured), discoveredName: targetName, discoverySchemaPresentInMessages: true, discoverySchemaAbsentFromTools: true },
  singleChangedField: 'tools (one declaration appended); all other JSON unchanged', appendedTool, variants };
fs.writeFileSync(path.join(root, 'replay-control-results-paired-baseline.json'), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
