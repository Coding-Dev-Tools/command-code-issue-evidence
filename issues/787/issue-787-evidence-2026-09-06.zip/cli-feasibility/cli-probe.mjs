import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root = path.dirname(fileURLToPath(import.meta.url));
const installedRoot = path.join(process.env.APPDATA, 'npm/node_modules/command-code');
const installed = path.join(installedRoot, 'dist/index.mjs');
const mode = process.argv[2] ?? 'discovery';
const home = path.join(root, `home-${mode.replace(/[^a-zA-Z0-9_-]/g, '_')}`);
const tmp = path.join(home, 'tmp');
const providerId = mode === 'upfront-control' || mode.includes('canonical') ? 'z-ai' : 'strict-probe';
const modelId = `${providerId}/glm-5.3-flash`;
const requests = [];
const mcpRequests = [];
for (const dir of [home, tmp, path.join(home, '.commandcode'), path.join(home, 'AppData/Roaming'), path.join(home, 'AppData/Local')]) fs.mkdirSync(dir, { recursive: true });

function sendSse(res, delta, finishReason) {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' });
    const base = { id: `fixture-${requests.length}`, object: 'chat.completion.chunk', created: 1, model: 'glm-5.3-flash' };
  res.write(`data: ${JSON.stringify({ ...base, choices: [{ index: 0, delta, finish_reason: null }] })}\n\n`);
  res.write(`data: ${JSON.stringify({ ...base, choices: [{ index: 0, delta: {}, finish_reason: finishReason }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } })}\n\n`);
  res.end('data: [DONE]\n\n');
}
const server = http.createServer((req, res) => {
  let raw = '';
  req.on('data', chunk => { raw += chunk; if (raw.length > 2_000_000) req.destroy(); });
  req.on('end', () => {
    let body;
    try { body = raw ? JSON.parse(raw) : {}; } catch { res.writeHead(400); res.end(); return; }
    if (req.url === '/mcp') {
      mcpRequests.push({ method: req.method, rpcMethod: body.method, params: body.params });
      if (req.method !== 'POST') { res.writeHead(405); res.end(); return; }
      if (body.id === undefined) { res.writeHead(202); res.end(); return; }
      let result;
      if (body.method === 'initialize') result = { protocolVersion: body.params.protocolVersion, capabilities: { tools: {} }, serverInfo: { name: 'issue-787-fixture', version: '1.0.0' } };
      else if (body.method === 'tools/list') result = { tools: [{ name: 'echo_probe', description: 'Return a synthetic probe marker. Read-only localhost test fixture.', inputSchema: { type: 'object', properties: { text: { type: 'string' } }, required: ['text'] }, annotations: { readOnlyHint: true, destructiveHint: false } }] };
      else if (body.method === 'tools/call') result = { content: [{ type: 'text', text: 'MCP_FIXTURE_OK' }] };
      else result = {};
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ jsonrpc: '2.0', id: body.id, result }));
      return;
    }
    if (!req.url.endsWith('/chat/completions')) { res.writeHead(404); res.end('fixture endpoint not found'); return; }
    requests.push({ path: req.url, body });
    const tools = (body.tools ?? []).map(tool => tool.function?.name);
    const targetName = 'mcp__fixture__echo_probe';
    const toolMessages = body.messages.filter(message => message.role === 'tool').map(message => String(message.content));
    const hasMcpResult = toolMessages.some(text => text.includes('MCP_FIXTURE_OK'));
    const hasDiscoveryResult = toolMessages.some(text => text.includes(`### ${targetName}`));
    // Identical deterministic policy for every mode: only call declared tools.
    if (hasMcpResult) {
      sendSse(res, { role: 'assistant', content: 'SYNTHETIC_OK' }, 'stop');
    } else if (tools.includes(targetName)) {
      sendSse(res, { role: 'assistant', tool_calls: [{ index: 0, id: 'call_fixture_echo', type: 'function', function: { name: 'mcp__fixture__echo_probe', arguments: JSON.stringify({ text: 'probe' }) } }] }, 'tool_calls');
    } else if (!hasDiscoveryResult && tools.includes('search_tools')) {
      sendSse(res, { role: 'assistant', tool_calls: [{ index: 0, id: 'call_fixture_search', type: 'function', function: { name: 'search_tools', arguments: JSON.stringify({ query: 'echo_probe', max_results: 1 }) } }] }, 'tool_calls');
    } else {
      sendSse(res, { role: 'assistant', content: 'FIXTURE_UNDECLARED' }, 'stop');
    }
  });
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const port = server.address().port;
fs.writeFileSync(path.join(home, '.commandcode/providers.json'), JSON.stringify({ provider: { [providerId]: { api: 'openai-completions', baseURL: `http://127.0.0.1:${port}/v1`, apiKey: '$FIXTURE_PROVIDER_KEY', models: { 'glm-5.3-flash': { contextWindow: 200000, maxOutput: 200, cost: { input: 0, output: 0 } } } } } }, null, 2));
fs.writeFileSync(path.join(home, '.commandcode/mcp.json'), JSON.stringify({ mcpServers: { fixture: { transport: 'http', url: `http://127.0.0.1:${port}/mcp`, enabled: true } } }, null, 2));
fs.writeFileSync(path.join(home, '.commandcode/config.json'), JSON.stringify({ model: modelId, provider: providerId, localOnly: true, telemetry: false, tasteLearning: false }, null, 2));
fs.writeFileSync(path.join(home, '.commandcode/settings.json'), JSON.stringify({ disableScratchpad: true, disableSkillShellExecution: true }, null, 2));

const env = {};
for (const key of ['SystemRoot', 'WINDIR', 'ComSpec', 'PATHEXT', 'PROCESSOR_ARCHITECTURE']) if (process.env[key]) env[key] = process.env[key];
env.PATH = [path.dirname(process.execPath), path.join(process.env.SystemRoot, 'System32')].join(path.delimiter);
Object.assign(env, { HOME: home, USERPROFILE: home, APPDATA: path.join(home, 'AppData/Roaming'), LOCALAPPDATA: path.join(home, 'AppData/Local'), TEMP: tmp, TMP: tmp,
  CMD_LOCAL_ONLY: '1', DO_NOT_TRACK: '1', OTEL_SDK_DISABLED: 'true', COMMANDCODE_SKIP_UPDATES: '1', COMMANDCODE_DISABLE_CRON: '1', COMMANDCODE_DISABLE_DURABLE_CRON: '1',
  DOTENV_CONFIG_PATH: path.join(home, 'missing.env'), NO_COLOR: '1', FIXTURE_PORT: String(port), FIXTURE_PROVIDER_KEY: 'synthetic-provider-key-not-real', COMMAND_CODE_API_KEY: 'synthetic-command-key-not-real' });
const args = mode === 'version' ? ['--no-auto-update', '--local-only', '--version'] : ['--no-auto-update', '--local-only', '--skip-onboarding', '--trust', '--no-skills', '--no-session', '--model', modelId, '--max-turns', '3', '--output-format', 'json', '--print', 'Use the synthetic echo_probe MCP tool to return a fixture marker.'];
const nodeArgs = ['--permission', `--allow-fs-read=${installedRoot}`, `--allow-fs-read=${root}`, `--allow-fs-write=${root}`, '--require', path.join(root, 'offline-guard.cjs'), installed, ...args];
const started = Date.now();
const child = spawn(process.execPath, nodeArgs, { cwd: root, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
let stdout = '', stderr = '', timedOut = false;
child.stdout.on('data', chunk => { stdout += chunk; });
child.stderr.on('data', chunk => { stderr += chunk; });
const timer = setTimeout(() => { timedOut = true; child.kill(); }, 15000);
const exit = await new Promise(resolve => child.on('close', (code, signal) => resolve({ code, signal })));
clearTimeout(timer);
server.closeAllConnections();
await new Promise(resolve => server.close(resolve));
const result = { mode, home, mockPolicy: 'After MCP result => SYNTHETIC_OK; else if target declared => MCP call; else if search declared and target not yet discovered => search_tools; else FIXTURE_UNDECLARED.', nodeVersion: process.version, cliSha256: createHash('sha256').update(fs.readFileSync(path.join(installedRoot, 'dist/cli.mjs'))).digest('hex'), elapsedMs: Date.now() - started, args, ...exit, timedOut, requests, mcpRequests, stdout, stderr, scope: 'Unmodified published CLI, isolated synthetic HOME/auth keys, filesystem permission restrictions, only own localhost network endpoint; no real inference.' };
fs.writeFileSync(path.join(root, `results-${mode}.json`), JSON.stringify(result, null, 2));
console.log(JSON.stringify({ ...result, requests: requests.map(r => ({ path: r.path, toolNames: r.body.tools?.map(t => t.function?.name), messageRoles: r.body.messages?.map(m => m.role) })), stdout: stdout.slice(-3000), stderr: stderr.slice(-3000) }, null, 2));
