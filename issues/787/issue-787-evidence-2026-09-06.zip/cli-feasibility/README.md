# Issue #787: real CLI declaration capture and synthetic contract control

The unmodified published Command Code **1.49.1** completed a headless run
against an entirely synthetic localhost OpenAI-completions responder and HTTP
MCP server. No real provider, inference, credentials, installed-source edits,
or user configuration were used.

## Final real CLI observation

`results-paired-baseline.json` is the final primary capture. It uses
`--model strict-probe/glm-5.3-flash` and a separate generated HOME.
The mock uses one explicit declaration-only policy:

1. After a successful MCP result, return `SYNTHETIC_OK`.
2. If the MCP tool is declared in `tools`, emit its tool call.
3. Otherwise, if `search_tools` is declared and discovery has not happened,
   emit a `search_tools` call for `echo_probe`.
4. Otherwise return `FIXTURE_UNDECLARED` without a tool call.

Observed result: **exit 0, 2,929 ms, two model requests, no timeout**.

- MCP completed `initialize`, `notifications/initialized`, and `tools/list`.
- Request 1 declared 11 tools including `search_tools`; the MCP tool was absent.
- The CLI executed `search_tools` and returned the full schema for
  `mcp__fixture__echo_probe` as a tool-result message.
- Request 2 still declared exactly the same 11 tools. The discovered MCP schema
  was present in messages and absent from the request's `tools` array.
- Under the explicit mock policy, request 2 returned `FIXTURE_UNDECLARED`;
  no MCP `tools/call` occurred. CLI final text was `FIXTURE_UNDECLARED`.

This is direct product wire-format evidence. The mock's refusal behavior is
programmed; it is not evidence of NeuralWatt, OpenRouter, or any real model's
behavior. The absence of an MCP call in the earlier unconditional
`FIXTURE_COMPLETE` probe is not treated as independent failure evidence.

## Same-request positive control

Run `node artifacts/issue-787/cli-feasibility/replay-control.mjs`.
The script reads the real captured second request, extracts the synthetic tool's
schema from its tool-result message, and replays two requests to a localhost
declaration-only responder. An assertion verifies that the **only JSON change
is one appended tool declaration**.

- Captured request unchanged: zero tool calls, `finish_reason: stop`.
- Same request plus the MCP declaration: one tool call,
  `finish_reason: tool_calls`.

See `replay-control-results-paired-baseline.json`. This is a synthetic contract
control, not a product fix or a second end-to-end CLI success.

## Isolation and reproducible setup

Run `node artifacts/issue-787/cli-feasibility/cli-probe.mjs paired-baseline`.
`cli-probe.mjs` creates the fake configs, loopback server, and fresh per-mode
HOME. It uses only its server's ephemeral localhost port, a 15-second owned-child
deadline, and a rebuilt allowlisted environment. The Node permission model
limits reads to the installed package and this fixture directory, writes to
this directory, and disallows child processes. The mock never requests shell
tools.

The CLI arguments include `--no-auto-update --local-only --skip-onboarding
--trust --no-skills --no-session --model strict-probe/glm-5.3-flash
--max-turns 3 --output-format json --print <synthetic prompt>`.

Environment includes `CMD_LOCAL_ONLY=1`, `DO_NOT_TRACK=1`, isolated
HOME/USERPROFILE/APPDATA/LOCALAPPDATA/TEMP/TMP, a nonexistent dotenv path,
and deliberately fake Command Code/provider keys. The current print-mode
authentication check still requires a nonempty Command Code key locally;
`synthetic-command-key-not-real` satisfies the local presence check without
authenticating to a real service. `providers.json` references the fake provider
key through `$FIXTURE_PROVIDER_KEY` and routes only to the localhost responder.

The guard permits embedded `data:` URLs because Yoga initializes bundled WASM
that way; those URLs cause no network connection. All network URLs and socket
connections are restricted to the fixture's own localhost port. Earlier guard
failures that rejected the WASM data URL are preserved and excluded from issue
#787 evidence.

Runtime: Node v24.15.0 on Windows. Installed `cli.mjs` SHA-256:
`10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05`.

## Excluded canonical-model control

`results-paired-canonical.json` uses a distinct fake HOME and the same mock
policy, but changes provider/model configuration to `z-ai/glm-5.3-flash`.
The CLI selects its built-in gateway route before the localhost model endpoint;
local-only mode refuses `/alpha/generate`. It sends **zero mock model requests**.
A Windows libuv teardown assertion follows the error. This is an invalid
positive control for #787 and is excluded from its results; neither this
failure nor renaming a provider is presented as an issue #787 finding or user
workaround. No further routing changes were attempted.

Raw request/NDJSON captures contain the product's full generated prompt and are
local evidence. Share a minimized projection of tool names, synthetic discovery
results, and hashes instead of publishing the full proprietary prompt.
