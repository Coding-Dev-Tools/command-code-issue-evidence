import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const [pkgArg,outArg,mode='original']=process.argv.slice(2),pkg=fs.realpathSync(pkgArg),runtime=path.dirname(pkg),out=path.resolve(outArg);
assert.ok(!fs.existsSync(out));fs.mkdirSync(out,{recursive:true});
const {default:slugify}=await import(pathToFileURL(path.join(runtime,'@sindresorhus/slugify/index.js')).href);
const project=path.join(out,'MyProject'),alias=path.join(out,'myproject'),plain=path.join(out,'project'),plainAlias=path.join(out,'Project'),sibling=path.join(out,'OtherProject');
for(const p of [project,plain,sibling]){fs.mkdirSync(p);fs.writeFileSync(path.join(p,'physical-marker.txt'),p===project?'SAME_538_PHYSICAL_DIRECTORY':p===plain?'PLAIN_538':'OTHER_538');}
const physical={project,alias,realProject:fs.realpathSync.native(project),realAlias:fs.realpathSync.native(alias),projectIno:String(fs.statSync(project,{bigint:true}).ino),aliasIno:String(fs.statSync(alias,{bigint:true}).ino),projectKey:slugify(project),aliasKey:slugify(alias),plainKey:slugify(plain),plainAliasKey:slugify(plainAlias)};
assert.equal(physical.realProject,physical.realAlias);assert.equal(physical.projectIno,physical.aliasIno);assert.equal(fs.readFileSync(path.join(alias,'physical-marker.txt'),'utf8'),'SAME_538_PHYSICAL_DIRECTORY');
assert.notEqual(physical.projectKey,physical.aliasKey);assert.equal(physical.plainKey,physical.plainAliasKey);
const id='05380538-0538-4538-8538-053805380538',timestamp='2026-09-12T00:00:00.000Z';
function seedFor(cwd){return[
 {type:'session',version:3,id,timestamp,cwd},
 {type:'message',id:'user538a',parentId:null,timestamp,message:{role:'user',content:[{type:'text',text:'USER_538_SAVED_MARKER'}],meta:{messageId:'user538a',source:'user',createdAt:1789171200000}}},
 {type:'message',id:'assistant538b',parentId:'user538a',timestamp,message:{role:'assistant',content:[{type:'text',text:'ASSISTANT_538_SAVED_MARKER'}],meta:{messageId:'assistant538b',createdAt:1789171200000}}}
].map(x=>JSON.stringify(x)).join('\n')+'\n';}
const scenarios=[
 {name:'canonical-resume',cwd:project,source:project,args:['--resume',id],expect:'resume'},
 {name:'case-resume',cwd:alias,source:project,args:['--resume',id],expect:'resume'},
 {name:'canonical-continue',cwd:project,source:project,args:['--continue'],expect:'resume'},
 {name:'case-continue',cwd:alias,source:project,args:['--continue'],expect:'resume'},
 {name:'case-explicit-file',cwd:alias,source:project,args:'file',expect:'resume'},
 {name:'plain-case-resume',cwd:plainAlias,source:plain,args:['--resume',id],expect:'resume'},
 {name:'distinct-resume',cwd:sibling,source:project,args:['--resume',id],expect:'reject'},
 {name:'distinct-continue',cwd:sibling,source:project,args:['--continue'],expect:'new'}
];
if(mode.startsWith('legacy-'))scenarios.splice(0,scenarios.length,{name:'legacy-case-key-resume',cwd:alias,source:alias,args:['--resume',id],expect:'resume'});
const requests=[],violations=[];
const server=http.createServer((req,res)=>{let raw='';req.on('data',b=>raw+=b);req.on('end',()=>{
 if(req.method!=='POST'||req.url!=='/v1/chat/completions'){violations.push('route');res.writeHead(404).end();return}
 const body=JSON.parse(raw);requests.push({body});if(requests.length>scenarios.length+2){violations.push('cap');res.writeHead(400).end();return}
 res.writeHead(200,{'Content-Type':'text/event-stream'});
 for(const [delta,finish_reason] of [[{role:'assistant',content:'HISTORY_538_DONE'},null],[{},'stop']])res.write('data: '+JSON.stringify({id:'history538',object:'chat.completion.chunk',created:1,model:'model',choices:[{index:0,delta,finish_reason}],...(finish_reason?{usage:{prompt_tokens:20,completion_tokens:3,total_tokens:23}}:{})})+'\n\n');
 res.end('data: [DONE]\n\n');
})});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port,runs=[];
try{for(const scenario of scenarios){
 const runDir=path.join(out,scenario.name),home=path.join(runDir,'home'),tmp=path.join(home,'tmp');
 for(const p of [tmp,path.join(home,'.commandcode'),path.join(home,'AppData/Roaming'),path.join(home,'AppData/Local')])fs.mkdirSync(p,{recursive:true});
 const seedDir=path.join(home,'.commandcode/projects',slugify(scenario.source));fs.mkdirSync(seedDir,{recursive:true});
 const transcript=path.join(seedDir,id+'.jsonl'),seed=seedFor(scenario.source);
 fs.writeFileSync(transcript,seed);fs.writeFileSync(path.join(seedDir,id+'.meta.json'),JSON.stringify({entrypoint:'print',title:'SYNTHETIC_538_HISTORY_FIXTURE',model:'fixture538/model'}));
 fs.writeFileSync(path.join(home,'.commandcode/providers.json'),JSON.stringify({provider:{fixture538:{api:'openai-completions',baseURL:`http://127.0.0.1:${port}/v1`,apiKey:'$FIXTURE_PROVIDER_KEY',models:{model:{contextWindow:200000,maxOutput:100,cost:{input:0,output:0}}}}}}));
 fs.writeFileSync(path.join(home,'.commandcode/config.json'),JSON.stringify({model:'fixture538/model',provider:'fixture538',localOnly:true,telemetry:false,tasteLearning:false}));
 const env={};for(const k of ['SystemRoot','WINDIR','ComSpec','PATHEXT','PROCESSOR_ARCHITECTURE'])if(process.env[k])env[k]=process.env[k];
 env.PATH=[path.dirname(process.execPath),path.join(process.env.SystemRoot??'/','System32')].join(path.delimiter);
 Object.assign(env,{HOME:home,USERPROFILE:home,APPDATA:path.join(home,'AppData/Roaming'),LOCALAPPDATA:path.join(home,'AppData/Local'),TEMP:tmp,TMP:tmp,CMD_LOCAL_ONLY:'1',DO_NOT_TRACK:'1',OTEL_SDK_DISABLED:'true',COMMANDCODE_SKIP_UPDATES:'1',COMMANDCODE_DISABLE_CRON:'1',COMMANDCODE_DISABLE_DURABLE_CRON:'1',DOTENV_CONFIG_PATH:path.join(home,'absent.env'),NO_COLOR:'1',FIXTURE_PORT:String(port),FIXTURE_PROVIDER_KEY:'synthetic-unused',COMMAND_CODE_API_KEY:'synthetic-unused'});
 const args=['--no-auto-update','--local-only','--skip-onboarding','--trust','--no-skills','--model','fixture538/model','--max-turns','1','--output-format','json',...(scenario.args==='file'?['--session',transcript]:scenario.args),'--print','NEW_538_PROMPT'];
 const nodeArgs=['--permission',`--allow-fs-read=${runtime}`,`--allow-fs-read=${root}`,`--allow-fs-read=${out}`,`--allow-fs-write=${out}`,'--require',path.join(root,'offline-guard538.cjs'),path.join(pkg,'dist/index.mjs'),...args];
 let stdout='',stderr='',timedOut=false;const start=requests.length;
 const child=spawn(process.execPath,nodeArgs,{cwd:scenario.cwd,env,windowsHide:true,stdio:['ignore','pipe','pipe']});child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
 const timer=setTimeout(()=>{timedOut=true;child.kill()},30000);
 const exit=await new Promise((res,rej)=>{child.on('error',rej);child.on('close',(code,signal)=>res({code,signal}))});clearTimeout(timer);
 const events=stdout.split(/\r?\n/).flatMap(s=>{try{return[JSON.parse(s)]}catch{return[]}});
 const row={...scenario,cliArgs:args,seedPath:transcript,seedSha256:createHash('sha256').update(seed).digest('hex'),seedRecords:seedFor(scenario.source).trim().split('\n').map(JSON.parse),seedAfter:fs.readFileSync(transcript,'utf8'),exit,timedOut,stdout,stderr,events,requests:requests.slice(start)};
 runs.push(row);fs.writeFileSync(path.join(runDir,'raw.json'),JSON.stringify(row,null,2)+'\n');
 console.log(JSON.stringify({name:row.name,exit,timedOut,requests:row.requests.length,markers:row.requests.map(r=>({user:JSON.stringify(r.body.messages).includes('USER_538_SAVED_MARKER'),assistant:JSON.stringify(r.body.messages).includes('ASSISTANT_538_SAVED_MARKER')})),result:events.filter(e=>e.type==='result'),stderr:stderr.slice(-300)}));
 assert.ok(!timedOut&&stderr.includes('offline-guard-ready')&&!stderr.includes('blocked-network'));
}}finally{server.closeAllConnections();await new Promise(r=>server.close(r));}
const result={at:new Date().toISOString(),mode,version:JSON.parse(fs.readFileSync(path.join(pkg,'package.json'))).version,bundleSha256:createHash('sha256').update(fs.readFileSync(path.join(pkg,'dist/cli.mjs'))).digest('hex'),node:process.version,platform:process.platform,arch:process.arch,physical,runs,violations};
fs.writeFileSync(path.join(out,'raw.json'),JSON.stringify(result,null,2)+'\n');assert.deepEqual(violations,[]);
