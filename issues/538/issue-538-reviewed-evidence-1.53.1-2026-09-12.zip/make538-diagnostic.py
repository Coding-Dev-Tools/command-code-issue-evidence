from pathlib import Path
import sys,shutil,hashlib,json
src,dest=map(Path,sys.argv[1:3])
assert not dest.exists()
data=(src/'dist/cli.mjs').read_bytes()
assert hashlib.sha256(data).hexdigest()=='5cbe89ae1bc22aa2e5a15c5d69dda84dbae04369e381120fe4b27cda3c753fbd'
old=b'function getProjectDirName(e){return slugify(e.cwd)}'
new=b'function getProjectDirName(e){let n=e.cwd;try{n=I.realpathSync.native(n)}catch{}return slugify(n)}'
assert data.count(old)==1
shutil.copytree(src,dest)
modified=data.replace(old,new)
(dest/'dist/cli.mjs').write_bytes(modified)
print(json.dumps({'originalSha256':hashlib.sha256(data).hexdigest(),'diagnosticSha256':hashlib.sha256(modified).hexdigest(),'old':old.decode(),'new':new.decode(),'changes':1,'limitation':'Diagnostic only. Existing histories written under alternate case-generated keys need compatibility handling; canonicalization alone may strand them.'}))
