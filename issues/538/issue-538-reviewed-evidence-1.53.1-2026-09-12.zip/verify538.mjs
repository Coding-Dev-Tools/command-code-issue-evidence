import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {assertRun,evaluate} from './assert538.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const read=n=>JSON.parse(fs.readFileSync(path.join(root,n),'utf8'));
const original=read('original-results.json'),diagnostic=read('diagnostic-results.json'),legacyOriginal=read('legacy-original-results.json'),legacyDiagnostic=read('legacy-diagnostic-results.json');
assert.deepEqual(evaluate(original).failures.map(r=>r.name),['case-resume','case-continue']);
assertRun(original.runs.find(r=>r.name==='case-resume'),'reject');assertRun(original.runs.find(r=>r.name==='case-continue'),'new');
assert.ok(evaluate(diagnostic).pass);assert.ok(evaluate(legacyOriginal).pass);
assert.deepEqual(evaluate(legacyDiagnostic).failures.map(r=>r.name),['legacy-case-key-resume']);assertRun(legacyDiagnostic.runs[0],'reject');
const good=diagnostic.runs.find(r=>r.name==='case-resume');
const mutateMessages=(r,f)=>{if(r.requests[0].messages)f(r.requests[0].messages);else f(r.requests[0].body.messages)};
const mutations=[
 ['missing user marker',r=>mutateMessages(r,m=>m.splice(m.findIndex(x=>x.role==='user'),1))],
 ['wrong assistant role',r=>mutateMessages(r,m=>m.find(x=>x.role==='assistant').role='user')],
 ['duplicate saved marker',r=>mutateMessages(r,m=>m.push(m.find(x=>x.role==='assistant')))],
 ['wrong session ID',r=>r.events.find(x=>x.type==='result').sessionId='other-session'],
 ['wrong case path',r=>r.cwd=r.source],
 ['deleted stored transcript',r=>r.seedAfter=''],
 ['unclean exit',r=>r.exit.code=1],
 ['wrong request count',r=>r.requests.push(r.requests[0])]
];
for(const [name,change] of mutations){const r=structuredClone(good);change(r);assert.throws(()=>assertRun(r),undefined,name)}
const leak=structuredClone(original.runs.find(r=>r.name==='distinct-continue'));leak.requests=structuredClone(good.requests);assert.throws(()=>assertRun(leak));
console.log(JSON.stringify({ok:true,applicationProcesses:original.runs.length+diagnostic.runs.length+legacyOriginal.runs.length+legacyDiagnostic.runs.length,localhostRequests:[original,diagnostic,legacyOriginal,legacyDiagnostic].reduce((n,d)=>n+d.runs.reduce((n,r)=>n+r.requests.length,0),0),originalAcceptanceFailures:2,diagnosticPrimaryPasses:8,legacyDiagnosticFails:1,negativeControls:mutations.length+1,applicationTestsRun:0},null,2));
