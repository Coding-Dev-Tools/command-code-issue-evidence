import assert from 'node:assert/strict';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
const id='05380538-0538-4538-8538-053805380538';
const text=m=>typeof m.content==='string'?m.content:(m.content??[]).filter(x=>x.type==='text').map(x=>x.text).join('');
export function assertRun(r,want=r.expect){
 assert.equal(r.timedOut,false);assert.equal(r.exit.signal,null);
 assert.ok(r.stderr.includes('offline-guard-ready'));assert.ok(!r.stderr.includes('blocked-network'));
 assert.equal(r.seedRecords.length,3);assert.equal(r.seedRecords[0].type,'session');assert.equal(r.seedRecords[0].id,id);
 assert.equal(r.seedRecords[0].cwd,r.source);
 assert.equal(text(r.seedRecords[1].message),'USER_538_SAVED_MARKER');assert.equal(text(r.seedRecords[2].message),'ASSISTANT_538_SAVED_MARKER');
 assert.ok(r.seedAfter.startsWith(r.seedRecords.map(x=>JSON.stringify(x)).join('\n')+'\n'),'Existing seed was destroyed or changed');
 if(r.name.startsWith('case-'))assert.equal(r.cwd,r.source.replace(/MyProject$/,'myproject'));
 if(r.name==='plain-case-resume')assert.equal(r.cwd,r.source.replace(/project$/,'Project'));
 if(r.name.startsWith('distinct-'))assert.equal(r.cwd,r.source.replace(/MyProject$/,'OtherProject'));
 const result=r.events.filter(e=>e.type==='result');assert.equal(result.length,1);
 if(want==='reject'){
  assert.equal(r.exit.code,1);assert.equal(r.requests.length,0);assert.equal(result[0].subtype,'error');
  assert.ok(result[0].error.includes('No session'));return;
 }
 assert.equal(r.exit.code,0);assert.equal(r.requests.length,1);assert.equal(result[0].subtype,'success');assert.equal(result[0].finalText,'HISTORY_538_DONE');
 const messages=r.requests[0].messages??r.requests[0].body.messages.filter(m=>m.role!=='system');
 if(want==='resume'){
  assert.equal(result[0].sessionId,id);
  assert.deepEqual(messages.map(m=>({role:m.role,text:text(m)})),[
   {role:'user',text:'USER_538_SAVED_MARKER'},
   {role:'assistant',text:'ASSISTANT_538_SAVED_MARKER'},
   {role:'user',text:'NEW_538_PROMPT'}
  ]);
 }else{
  assert.notEqual(result[0].sessionId,id);assert.ok(result[0].sessionId);
  assert.deepEqual(messages.map(m=>({role:m.role,text:text(m)})),[{role:'user',text:'NEW_538_PROMPT'}]);
 }
}
export function evaluate(data){
 assert.deepEqual(data.violations,[]);assert.equal(data.platform,'win32');
 assert.equal(data.physical.realProject,data.physical.realAlias);assert.equal(data.physical.projectIno,data.physical.aliasIno);
 assert.notEqual(data.physical.projectKey,data.physical.aliasKey);assert.equal(data.physical.plainKey,data.physical.plainAliasKey);
 assert.equal(new Set(data.runs.map(r=>r.name)).size,data.runs.length);
 const expected=data.mode.startsWith('legacy-')?['legacy-case-key-resume']:['canonical-resume','case-resume','canonical-continue','case-continue','case-explicit-file','plain-case-resume','distinct-resume','distinct-continue'];
 assert.deepEqual(data.runs.map(r=>r.name),expected);
 const failures=[];for(const r of data.runs)try{assertRun(r)}catch(e){failures.push({name:r.name,reason:e.message})}
 return {pass:failures.length===0,failures};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){const result=evaluate(JSON.parse(fs.readFileSync(process.argv[2],'utf8')));console.log(JSON.stringify(result,null,2));process.exitCode=result.pass?0:1;}
