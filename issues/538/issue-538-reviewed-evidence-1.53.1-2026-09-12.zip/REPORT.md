# Issue 538: current path-case lookup and compatibility regression

Current 1.53.1 reproduces case-dependent history lookup on native Windows. A physical `MyProject` directory and its `myproject` alias have identical realpaths/identity, but slugification generates different storage keys because decamelization precedes lowercasing. A simple `project`/`Project` pair passes; testing only that pair would miss the bug.

Eight original CLI processes use complete manually seeded V3 transcripts. Canonical resume/continue and simple-case resume recover the exact prior user/assistant messages and session ID. Camel-case-alias resume fails with exit1 before any request. Alias continue exits0 with a new ID and only the new user prompt; the old seed remains. Explicit absolute transcript-path selection recovers history. Different-directory controls enforce isolation.

An isolated one-site realpath-before-slug diagnostic passes those eight primary cases. A further two-process old-key compatibility control shows a transcript under the alternate key resumes in the unchanged CLI but fails in the diagnostic. This is a concrete regression requirement for migration/lookup compatibility, not a production-ready patch.

Total: 18 application processes, 14 localhost model requests, 14 exit0 and four recorded exit1 resume failures. No watchdog timeout, runtime abort, tools or paid inference. Nine corrupted-result controls reject incomplete/wrong-role/duplicated message replay, wrong session ID or case input, deleted original storage, wrong process/request accounting and cross-project leakage. The frozen verifier executes no application tests.

Evidence classes remain separate: reporter's 0.40.14 interactive history report; current published-bundle source; original headless CLI with seeded durable state; modified diagnostic CLI; and deliberately seeded legacy-key regression. We do not claim natural creation of these transcripts, deletion of histories, interactive picker reproduction, native macOS/Linux results, case-sensitive filesystem correctness, symlink semantics or a safe migration policy.

The earlier #607 preparation stopped on a preliminary slug-identity assertion before any Command Code process launched. That assertion exposed this more valuable case distinction. It is not evidence about Mod loading. The unfinished #607 fixture remains private scratch and is excluded from this packet.
