Reproduced on **command-code 1.53.1, Windows x64 / Node 24.15.0**. The useful distinction is that **some case changes work, while changes that affect camel-case word boundaries split the history lookup**.

I used one physical directory named `MyProject` through both `MyProject` and `myproject`. Native realpath and filesystem identity matched, but the generated session-directory keys ended in `my-project` and `myproject` respectively. The simpler `project` / `Project` control generated the same key and resumed successfully.

With a complete, manually seeded V3 transcript containing distinct user and assistant markers:

| Actual CLI invocation | Result on unchanged 1.53.1 |
|---|---|
| Original casing, `--resume <id>` or `--continue` | Same session ID; both saved messages sent to the model |
| Alternate casing, `--resume <id>` | Exit 1, “No session … found to resume”; zero model requests |
| Alternate casing, `--continue` | Exit 0 with a **new session ID**, neither saved message sent, and no missing-history warning |
| Alternate casing, `--session <absolute-transcript-path>` | Same session ID and both saved messages recovered |
| Different physical directory | ID-based resume rejected; continue started a new session without leaking the original history |

The stored transcript remained present and unchanged at its original prefix. This isolates lookup from transcript creation/flush behavior; it is not evidence that the history file was deleted. These are headless CLI tests, not interactive picker captures.

The source boundary is `getProjectDirName` → `slugify(cwd)`. The resolved `@sindresorhus/slugify` **2.2.1** defaults to `decamelize: true` and inserts word separators **before** lowercasing. Lowercase output therefore does not guarantee case-insensitive identity. Both project-scoped listing and ID resume use the resulting directory key.

**A compatibility control catches an incomplete fix:** canonicalizing the filesystem path before slugification in an isolated one-site diagnostic makes all eight primary cases pass. However, when the transcript is seeded under the alternate key that the old code can generate, the original CLI resumes it and the diagnostic fails. Canonicalization alone can strand existing histories; a production fix needs compatibility lookup/migration and tests for both old keys. Unconditional lowercasing across filesystems is not established as safe by these tests.

The reproduction packet contains **18 CLI processes / 14 scripted localhost requests**, exact source and dependency hashes, fixtures, and executable acceptance checks. Nine deliberately corrupted-result controls are rejected, including missing/duplicate messages, wrong roles/session identity, cross-project leakage and changed case inputs. All processes exited without a timeout or runtime abort; the four exit-1 results are the recorded resume failures. No paid inference.

The explicit-file `--session` form is a verified retrieval workaround for this fixture. Subsequent persistence, interactive mode, native macOS/Linux, case-sensitive Windows directories, symlinks and migration policy remain unvalidated. No upstream source change is claimed.
