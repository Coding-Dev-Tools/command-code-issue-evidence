# Reproduce issue 538

Tested with Windows x64, Node24.15.0, command-code1.53.1 and the exact package-lock included here. No real model/provider or credentials are needed. Copy this whole directory into a fresh scratch directory; do not overwrite retained results.

Inspect the saved results without installing dependencies or running application tests:

```text
node verify538.mjs
node assert538.mjs original-results.json
node assert538.mjs diagnostic-results.json
node assert538.mjs legacy-diagnostic-results.json
```

The verifier exits0. Original acceptance intentionally exits1 for case-resume and case-continue; primary diagnostic acceptance exits0. Legacy diagnostic acceptance intentionally exits1, demonstrating why the diagnostic is not a complete fix.

For fresh application runs, create `runtime`, copy `runtime-package.json` to `runtime/package.json` and `runtime-package-lock.json` to `runtime/package-lock.json`, then run `npm ci --ignore-scripts --no-audit --no-fund` in `runtime`. The tested runtime was reused from the earlier fresh locked #655 installation; its original bundle hash was checked before and after the investigation. This case did not claim a new dependency installation.

From the copied fixture directory:

```text
node history538-probe.mjs runtime/node_modules/command-code runs/original original
python make538-diagnostic.py runtime/node_modules/command-code runtime/node_modules/command-code-538-diagnostic
node history538-probe.mjs runtime/node_modules/command-code-538-diagnostic runs/diagnostic diagnostic
node history538-probe.mjs runtime/node_modules/command-code runs/legacy-original legacy-original
node history538-probe.mjs runtime/node_modules/command-code-538-diagnostic runs/legacy-diagnostic legacy-diagnostic
node assert538.mjs runs/original/raw.json
node assert538.mjs runs/diagnostic/raw.json
node assert538.mjs runs/legacy-original/raw.json
node assert538.mjs runs/legacy-diagnostic/raw.json
```

Each scenario has an isolated home and manually seeded, complete V3 transcript plus print-entrypoint metadata. The project directories are real Windows directories; the fixture verifies that case aliases have identical native realpaths and filesystem identity. It also confirms that a simpler project/Project pair has the same slug and a distinct project does not inherit the seeded history. It never changes the user's home, project configuration or installed CLI.

The original and diagnostic matrices have eight fresh processes each. Two further processes test the legacy alternate-key hazard. The owned ephemeral model endpoint returns a fixed answer and captures outgoing requests. Each process has a 30-second watchdog; Node network access is restricted to that endpoint by the preload guard, and filesystem writes are restricted to the run directory. No child-process permission is granted. This is not OS isolation.

The shareable captures retain actual non-system message arrays, result/error events, exits, seed records and retained transcript prefixes. The private lab path prefix is consistently replaced with `<lab>` in paths and with `lab` in storage slugs; `seedSha256BeforePathRedaction` preserves the original seed hash. Shipped system-prompt text and tool declarations are omitted; system-message hashes are retained. Full synthetic requests remain in private scratch. Do not mistake the model's fixed final answer for history proof: the checks inspect exact outgoing roles, marker order/count and session IDs.

The diagnostic changes one function in a separate package copy. It deliberately does not implement migration. Preserve both old-key fixtures when designing a production correction. Explicit transcript-path retrieval was tested; subsequent persistence and interactive selection were not.
