# Issue #725: a reproduced shell-stdin crash in Command Code 1.49.1

## Result and limits

A real Windows pipe failure crashes the **unchanged extracted `createNodeShell.run` implementation** from published Command Code 1.49.1. With 1 MiB of input and a child that exits without reading, the three original trials exited 1 with:

```text
Error: write EOF
    at WriteWrap.onWriteComplete [as oncomplete] (node:internal/stream_base_commons:87:19)
```

The same payload delivered to a consuming child succeeded in all three trials and the child independently reported receiving 1,048,576 bytes. A diagnostic change to the in-memory function prevented all three corresponding crashes by installing lifecycle/stdin handlers before writing and rejecting the affected operation on EOF.

This establishes a fixable defect in the published component. **It does not establish that this function caused the original issue's trace.** In particular, the original reporter's configured hooks and failing transport remain unknown. Normal foreground calls without a stdin argument, and the background-spawn path using ignored stdin, do not exercise this exact failure route.

An isolated full-CLI attempt did not complete startup within the 15-second limit, including help/version probes, with a fresh home and external networking disabled. It reached no localhost model request. That attempt is inconclusive, not an end-to-end reproduction or a newly diagnosed startup defect.

## Artifact identity

- Package: `command-code@1.49.1`.
- Test runtime: Windows x64, Node `v24.15.0`.
- Published `dist/cli.mjs`: 2,553,575 bytes.
- SHA-256: `10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05`.
- npm tarball SHA-512 integrity was verified against the registry metadata. The installed bundle matched the downloaded bundle byte-for-byte and its hash remained unchanged after testing.
- The test does not import the CLI or require its private source: it extracts the exact shell factory, process helpers and buffer classes, using native Node spawn and real OS pipes. No installed product/configuration files were changed. No model credits were consumed.

## What is wrong

`createNodeShell.run` selects a piped stdin when its caller provides input, then calls `child.stdin.end(payload)` without an error listener or completion callback on that stream. Its `child.on('error', ...)` listener is on a different emitter and cannot handle the stdin socket's error event. The pending Promise's catch path is likewise insufficient for an unhandled stream event.

Both `runSyncHook` and `fireAsyncHook` pass hook JSON through this runner. The synchronous caller catches Promise rejections and the asynchronous caller attaches a rejection callback, but neither attaches the missing stream listener. The outer CLI uncaught-exception handler is fatal, consistent with a stream error escaping to the crash banner.

Search the exact published artifact by symbol; these are **zero-based UTF-8 byte offsets**, not private source locations:

| Location | Offset | Relevance |
| --- | ---: | --- |
| `createNodeShell` | 35,160 | Shared shell-runner implementation |
| stdin `.end(payload)` | 35,634 | Input is written before lifecycle listeners; no stdin error listener/callback |
| `fireAsyncHook` | 650,970 | Supplies hook payload as stdin |
| `runSyncHook` | 651,500 | Supplies payload with timeout/abort handling |
| `createStdioMcpClient` | 726,868 | Separate transport; already attaches stdin error handling |

MCP is an important negative control: the current custom stdio client's stdin error listener and request write callback are already present. Seven synthetic factory probes exercised error and lifecycle conditions without an escaped Promise rejection; callback EOF returned an operation error. These use substituted transports and do not demonstrate real MCP end-to-end behavior. They do contradict the claim that all current MCP stdin writes lack a handler. Other synthetic MCP lifecycle findings are outside this #725 diagnosis.

## Controlled evidence

The published-component driver ran 36 cases, spanning original/candidate behavior, exiting/consuming children, 1 KiB/64 KiB/1 MiB payloads, and three trials of each combination. All expected outcomes pass the accompanying validator.

| Case at 1 MiB | Result |
| --- | --- |
| Original component, early-exit child | 3/3 uncaught EOF; process exit 1 |
| Original component, consuming child | 3/3 success; exact byte count |
| Diagnostic candidate, early-exit child | 3/3 caught operation rejection; process exit 0 |
| Diagnostic candidate, consuming child | 3/3 success; exact byte count |

The smaller inputs did not crash in these runs. That does not prove a fixed threshold or that the application consumed the bytes; the OS can accept data before the reader exits.

An independently written real-pipe fixture also passed all 12 assertions: six open-pipe controls, three unhandled EOF crashes, and three handled EOF failures. Its child sends a stdout readiness signal; the parent queues 1 MiB and asks the nonreading child to exit over IPC. It uses no injected errors or sleeps. The exact native error is `EOF`, errno `-4095`, syscall `write`; these tests did not produce `EPIPE`.

## Recommended engineering change

1. Install child stdin error handling and all lifecycle/cancellation handlers **before** the first write/end call. Convert owned-stream delivery errors into the shell operation's failure result, preserving the error code and available output.
2. Track input completion and process completion separately. Settle once across delivery error, spawn error, cancellation, timeout and child completion. Exit zero must not overwrite a known required-input delivery failure.
3. Keep the stdin error listener until stream teardown is complete, including after cancellation or callback settlement. Node invokes a failed write's callback before the stream error event; removing the listener in that callback can still crash.
4. Clean up only the still-owned child/process tree. Do not automatically retry hooks with possible side effects, and do not globally ignore EOF/EPIPE in `uncaughtException` and resume execution.
5. Preserve the documented behavior of static hooks that intentionally do not read input. The bundled quickstart uses such an `echo` hook. The team should make optional-input handling explicit, while preserving `failClosed` behavior and never silently presenting failed required input as successful.

The in-memory candidate is **a diagnostic comparison, not a production-ready patch**: it relocates the write, installs a stdin listener and rejects/kills on the owned operation failure. It does not fully resolve late-error-versus-success ordering, cancellation races or static-hook compatibility. Those belong in the implementation and tests above.

Primary references: [Node 24.15 stream callback/error ordering](https://nodejs.org/download/release/v24.15.0/docs/api/stream.html#writablewritechunk-encoding-callback), [Node uncaught-exception guidance](https://nodejs.org/download/release/v24.15.0/docs/api/process.html#warning-using-uncaughtexception-correctly), [issue #725](https://github.com/CommandCodeAI/command-code/issues/725), and the pinned published artifact.

## Regression cases the team should add

- Early-exit child plus large hook input: controlled failure, no process-level uncaught exception.
- Full input consumption with ordinary stdout/stderr: exact input byte count and output preserved.
- Input failure before and after child exit: no false required-input success.
- Abort/timeout during a pending write: one cancellation result; a late EOF is still handled.
- Spawn error and nonzero child exit remain distinct from input delivery errors.
- Synchronous and asynchronous hooks, including `failClosed` and documented static hooks.
- Session-level confirmation in the team's runnable build, followed by correlation with the original reporter's trace.

## Run the supplied checks

For the independent Node fixture, no package installation or model connection is needed:

```powershell
node .\pipe-test\reproduce.cjs
```

For the exact published-component fixture, from this folder prepare the pinned npm artifact (download only; no package installation):

```powershell
New-Item -ItemType Directory -Path .\published -Force | Out-Null
npm pack command-code@1.49.1 --ignore-scripts --pack-destination .\published
tar -xzf .\published\command-code-1.49.1.tgz -C .\published
node .\product-test.mjs
```

The product driver checks the exact bundle hash before evaluating code and validates its outcomes. Run `node .\validate-product-results.mjs` to validate the saved 36-case evidence without rerunning processes. These pinned expected outcomes intentionally describe the current defect; the team should invert the failure expectations when integrating a production fix.

The handoff ZIP includes authored tests and synthetic results, not the published proprietary bundle or private user configuration. The complete local audit additionally retains the inconclusive CLI startup attempt and preliminary pipe experiments; those are excluded from the positive crash evidence.
