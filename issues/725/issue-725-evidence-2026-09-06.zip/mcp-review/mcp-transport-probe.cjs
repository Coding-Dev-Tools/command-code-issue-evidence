// Offline regression probes against the verbatim published MCP factory.
// Only spawn/storage/schema dependencies are substituted; no CLI startup occurs.
const fs = require('node:fs');
const vm = require('node:vm');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const { Writable } = require('node:stream');

const bundle = process.argv[2] || (process.env.APPDATA && require('node:path').join(process.env.APPDATA, 'npm/node_modules/command-code/dist/cli.mjs'));
assert.ok(bundle, 'Pass the path to the published command-code/dist/cli.mjs bundle as the first argument.');
const bytes = fs.readFileSync(bundle);
const text = bytes.toString('utf8');
const start = text.indexOf('function createStdioMcpClient(');
const end = text.indexOf('function toOAuthConfig2(', start);
assert(start >= 0 && end > start, 'Published factory boundaries must exist');
const factorySource = text.slice(start, end);
const errors = [];
const onUnhandled = (e) => errors.push(String(e));
process.on('unhandledRejection', onUnhandled);
const results = [];
const eof = () => Object.assign(new Error('write EOF'), { code: 'EOF', syscall: 'write' });
const tick = () => new Promise(resolve => setImmediate(resolve));

function childFor(onMessage) {
  const child = new EventEmitter();
  child.stdout = new EventEmitter();
  child.stderr = new EventEmitter();
  child.stdin = new Writable({ write(chunk, encoding, callback) {
    onMessage(child, JSON.parse(chunk.toString()), callback);
  }});
  return child;
}
function reply(child, message, callback, result = {}) {
  callback();
  queueMicrotask(() => child.stdout.emit('data', JSON.stringify({ jsonrpc: '2.0', id: message.id, result }) + '\n'));
}
function loadFactory(spawn) {
  const context = vm.createContext({
    S: spawn, __name: (fn) => fn,
    process: { env: {}, platform: 'win32' },
    trackChild() {}, untrackChild() {}, killProcessTree2() {},
    looksLikeHttpUrl: () => false, explainSpawnError: e => e,
    resolveMcpTimeoutMs: () => 40,
    createMcpBinaryStore: () => undefined,
    mcpToolDefToSchema: e => e,
    mcpResultToToolRunResult: e => ({ ok: true, content: e }),
    Ot: '2025-03-26', Dt: { name: 'offline-test', version: '0' },
    setTimeout, clearTimeout, Error, JSON, Map, Set,
  });
  return vm.runInContext(factorySource + '; createStdioMcpClient', context);
}
async function probe(name, run) {
  const observations = await run();
  await tick();
  results.push({ name, status: 'observed', ...observations });
}

(async () => {
  await probe('request_write_callback_eof_is_caught', async () => {
    const child = childFor((child, msg, cb) => {
      if (msg.method === 'initialize') reply(child, msg, cb);
      else if (msg.method === 'tools/call') cb(eof());
      else cb();
    });
    const client = loadFactory(() => child)({ name: 'fixture', command: 'fixture' });
    const result = await client.callTool({ tool: 'fixture', input: {} });
    assert.equal(result.ok, false);
    assert.match(result.error, /write EOF/);
    assert.equal(child.stdin.listenerCount('error'), 1);
    client.dispose();
    return { result, stdinErrorListeners: 1 };
  });
  await probe('notification_write_eof_does_not_escape', async () => {
    const child = childFor((child, msg, cb) => {
      if (msg.method === 'initialize') reply(child, msg, cb);
      else if (msg.method === 'notifications/initialized') cb(eof());
      else cb();
    });
    const client = loadFactory(() => child)({ name: 'fixture', command: 'fixture' });
    const result = await client.callTool({ tool: 'fixture', input: {} });
    assert.equal(result.ok, false);
    client.dispose();
    return { result };
  });
  await probe('stdin_error_event_without_write_callback_error_waits_for_timeout', async () => {
    const child = childFor((child, msg, cb) => {
      if (msg.method === 'initialize') reply(child, msg, cb);
      else if (msg.method === 'tools/call') { cb(); queueMicrotask(() => child.stdin.emit('error', eof())); }
      else cb();
    });
    const client = loadFactory(() => child)({ name: 'fixture', command: 'fixture' });
    const result = await client.callTool({ tool: 'fixture', input: {} });
    assert.match(result.error, /timed out/);
    client.dispose();
    return { result };
  });
  await probe('child_exit_rejects_pending_request', async () => {
    const child = childFor((child, msg, cb) => {
      if (msg.method === 'initialize') reply(child, msg, cb);
      else if (msg.method === 'tools/call') { cb(); queueMicrotask(() => child.emit('exit', 1, null)); }
      else cb();
    });
    const client = loadFactory(() => child)({ name: 'fixture', command: 'fixture' });
    const result = await client.callTool({ tool: 'fixture', input: {} });
    assert.match(result.error, /MCP server exited with code 1/);
    client.dispose();
    return { result };
  });
  await probe('close_without_exit_does_not_settle_pending', async () => {
    const child = childFor((child, msg, cb) => {
      if (msg.method === 'initialize') reply(child, msg, cb);
      else if (msg.method === 'tools/call') { cb(); queueMicrotask(() => child.emit('close', 1, null)); }
      else cb();
    });
    const client = loadFactory(() => child)({ name: 'fixture', command: 'fixture' });
    const result = await client.callTool({ tool: 'fixture', input: {} });
    assert.match(result.error, /timed out/);
    const closeListeners = child.listenerCount('close');
    client.dispose();
    return { result, closeListeners, note: 'Synthetic close-only event; not proof this sequence occurs for a real child.' };
  });
  await probe('stale_child_exit_rejects_new_child_request', async () => {
    let spawnCount = 0;
    const first = childFor((child, msg, cb) => { cb(); queueMicrotask(() => child.emit('error', new Error('old child error'))); });
    const second = childFor((child, msg, cb) => { cb(); queueMicrotask(() => first.emit('exit', 7, null)); });
    const client = loadFactory(() => ++spawnCount === 1 ? first : second)({ name: 'fixture', command: 'fixture' });
    const firstResult = await client.callTool({ tool: 'fixture', input: {} });
    const secondResult = await client.callTool({ tool: 'fixture', input: {} });
    assert.equal(spawnCount, 2);
    assert.match(firstResult.error, /old child error/);
    assert.match(secondResult.error, /MCP server exited with code 7/);
    client.dispose();
    return { firstResult, secondResult, spawnCount, note: 'Synthetic error-respawn-late-exit ordering; not a reproduced source of issue 725.' };
  });
  await probe('stderr_has_no_error_listener', async () => {
    const child = childFor((child, msg, cb) => msg.id ? reply(child, msg, cb, { tools: [] }) : cb());
    const client = loadFactory(() => child)({ name: 'fixture', command: 'fixture' });
    await client.listTools();
    assert.equal(child.stderr.listenerCount('error'), 0);
    assert.throws(() => child.stderr.emit('error', eof()), /write EOF/);
    client.dispose();
    return { stderrErrorListeners: 0, note: 'Synthetic stderr error escapes EventEmitter; stderr is read-only here, so this is not an attribution of write EOF.' };
  });
  await tick();
  assert.deepEqual(errors, [], 'No unhandled promise rejection should occur in these probes');
  console.log(JSON.stringify({
    bundle, sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
    factory: { symbol: 'createStdioMcpClient', utf16Start: start, utf16EndExclusive: end,
      byteStart: Buffer.byteLength(text.slice(0, start)), byteEndExclusive: Buffer.byteLength(text.slice(0, end)) },
    substitutedDependencies: ['spawn', 'child tracking/killing', 'timeout', 'binary store', 'schema/result converters', 'protocol/client constants'],
    realDependencies: ['Node Writable', 'Node EventEmitter', 'Promise', 'timers'],
    results, unhandledRejections: errors,
  }, null, 2));
})().catch(error => { console.error(error.stack); process.exitCode = 1; }).finally(() => process.removeListener('unhandledRejection', onUnhandled));
