I tested the published **1.49.1** bundle on **Windows x64 / Node 24.15.0** and found a reproducible crash path in `createNodeShell.run`.

The installed `dist/cli.mjs` matched the registry artifact byte-for-byte. I executed the unchanged extracted shell runner and its process helpers using real Node child processes and OS pipes:

| Test, 1 MiB stdin | Result |
| --- | --- |
| Child exits without reading | **3/3 uncaught `write EOF`, exit 1** |
| Child consumes the same input | **3/3 success**, exact byte count |
| Test-only handler/order change, exiting child | **3/3 caught operation failure**, host survives |

The stack matches `WriteWrap.onWriteComplete` at `node:internal/stream_base_commons:87:19`.

**Concrete gap:** `createNodeShell.run` calls `child.stdin.end(payload)` without a stdin error listener or completion callback. Its `child.on('error')` handler listens on a different emitter. Both `runSyncHook` and `fireAsyncHook` supply stdin through this path; their Promise handling does not catch an unhandled stdin stream event. In this exact bundle, `createNodeShell` starts at UTF-8 byte offset **35,160**, and the stdin write is at **35,634**.

**Recommended fix:** register stdin and lifecycle handlers before writing, report delivery failure through the owning operation, and settle once across stdin completion, child exit and cancellation. Keep the stream error listener through teardown, and prevent a known required-input failure from becoming success just because the child exits zero. Preserve static/nonreading hook compatibility and `failClosed` behavior.

The diagnostic change prevented this fixture's crash, but needs late-error/cancellation coverage before being treated as a production patch. Do not fix this by globally suppressing uncaught exceptions; [Node documents why that is unsafe](https://nodejs.org/download/release/v24.15.0/docs/api/process.html#warning-using-uncaughtexception-correctly).

**Scope:** this confirms a defect in the published component, not the origin of the original reporter's trace. The isolated full CLI did not complete startup under the offline test conditions. Current MCP stdin request handling already has protection, so I would not attribute this broadly to MCP. Please correlate the original trace with the active operation/hooks to determine whether it hit this path.
