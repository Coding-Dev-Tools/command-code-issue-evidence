import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import vm from 'node:vm';
import {spawn, spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';

const root = path.dirname(fileURLToPath(import.meta.url));
const bundle = path.join(root, 'published/package/dist/cli.mjs');
const text = fs.readFileSync(bundle, 'utf8');
assert.equal(createHash('sha256').update(fs.readFileSync(bundle)).digest('hex'),'10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05','This extraction is pinned to the published 1.49.1 artifact');
const between = (start, end) => {
  const a = text.indexOf(start), b = text.indexOf(end, a + start.length);
  if (a < 0 || b < 0) throw new Error(`Missing source boundary: ${start}`);
  return text.slice(a, b);
};
const shellSource = between('function createNodeShell(', 'function createNodeRuntime(');
const processHelpers = between('function ensureExitHandler(', 'function createNodeFileSystem(');
const constantsMarker = text.indexOf('__name(onChildFinished,"onChildFinished"),on=');
if (constantsMarker < 0) throw new Error('Missing buffer constants');
const constantsEnd = text.indexOf('__name(createNodeFileSystem', constantsMarker);
const buffers = 'var ' + text.slice(constantsMarker + '__name(onChildFinished,"onChildFinished"),'.length, constantsEnd).replace(/,$/, ';');
const finishConstant = text.match(/(?:var |,)en=(\d+)/);
const killConstant = text.match(/(?:var |,)tn=(\d+)/);
if (!finishConstant || !killConstant) throw new Error('Missing process timing constants');

function isolatedEnv() {
  const home = path.join(root,'isolated-home');
  const temp = path.join(home,'tmp');
  fs.mkdirSync(temp,{recursive:true});
  const env = {};
  for (const key of ['SystemRoot','WINDIR','ComSpec','PATH','PATHEXT']) if(process.env[key]) env[key]=process.env[key];
  return {...env,HOME:home,USERPROFILE:home,TEMP:temp,TMP:temp,APPDATA:path.join(home,'AppData/Roaming'),LOCALAPPDATA:path.join(home,'AppData/Local'),OTEL_SDK_DISABLED:'true',COMMANDCODE_SKIP_UPDATES:'1',COMMANDCODE_DISABLE_CRON:'1',COMMANDCODE_DISABLE_DURABLE_CRON:'1',DOTENV_CONFIG_PATH:path.join(home,'nonexistent.env')};
}

const mode = process.argv[2];
if (mode === 'case') {
  const variant=process.argv[3], kind=process.argv[4], size=Number(process.argv[5]);
  // The original createNodeShell and process helpers execute unchanged. The
  // comparison adds only an owning stdin error handler in the in-memory copy.
  // No installed product file is modified, and no stream errors are injected.
  let source=shellSource;
  if (variant==='candidate') {
    source=source.replace('void 0!==r&&m.stdin?.end(r),trackChildProcess(m);','trackChildProcess(m);');
    const needle='m.on("error",e=>{u||(u=!0,p(),l(e))})';
    if(!source.includes(needle)) throw new Error('Candidate patch target missing');
    source=source.replace(needle,needle+',m.stdin?.on("error",e=>{u||(u=!0,killProcessTree(m),p(),l(e))}),void 0!==r&&m.stdin?.end(r)');
  }
  fs.mkdirSync(path.join(root,'synthetic'),{recursive:true});
  const childFile=path.join(root,'synthetic',kind+'.cjs');
  fs.writeFileSync(childFile,kind==='consume' ? "let n=0;process.stdin.on('data',c=>n+=c.length);process.stdin.on('end',()=>{process.stdout.write(String(n));});" : "process.exit(0);");
  const context={S:spawn,v:spawnSync,A:fs.existsSync,G:os.constants,process,console,Buffer,Map,Set,Promise,Error,Date,Math,setTimeout,clearTimeout,AbortController,r:path.dirname,n:path.join,__name:(f,n)=>Object.defineProperty(f,'name',{value:n,configurable:true})};
  vm.createContext(context);
  const support=`var nn=new Set,rn=false,en=${finishConstant[1]},tn=${killConstant[1]},un=new Map;`+buffers+processHelpers+between('function signalExitCode(', 'function createNodeShell(');
  vm.runInContext(support+source+';globalThis.testShell=createNodeShell({fs:{}})',context,{filename:'extracted-command-code-1.49.1-shell.js'});
  const watchdog=setTimeout(()=>{console.error('case watchdog');process.exit(90)},6000);
  try {
    const result=await context.testShell.run({command:`"${process.execPath}" "${childFile}"`,cwd:root,env:isolatedEnv(),stdin:'x'.repeat(size)});
    console.log(JSON.stringify({outcome:'resolved',result}));
  } catch(error) {
    console.log(JSON.stringify({outcome:'rejected',code:error.code,message:error.message,stack:error.stack}));
  } finally {clearTimeout(watchdog);}
} else {
  const results=[];
  for(const variant of ['original','candidate']) for(const kind of ['early-exit','consume']) for(const size of [1024,65536,1048576]) for(let trial=1;trial<=3;trial++) {
    const run=spawnSync(process.execPath,[fileURLToPath(import.meta.url),'case',variant,kind,String(size)],{cwd:root,env:isolatedEnv(),timeout:9000,windowsHide:true,encoding:'utf8',maxBuffer:1000000});
    let outcome;try{outcome=JSON.parse(run.stdout.trim())}catch{}
    results.push({variant,kind,size,trial,exit:run.status,signal:run.signal,error:run.error?.message,stdout:run.stdout,stderr:run.stderr,outcome});
  }
  const report={node:process.version,platform:process.platform,arch:process.arch,bundleSHA256:createHash('sha256').update(fs.readFileSync(bundle)).digest('hex'),sourceUnchangedInOriginal:true,networkCalls:0,productCLI:false,scope:'Exact extracted published createNodeShell plus unchanged process helpers; native Node spawn and real Windows pipes',results};
  fs.writeFileSync(path.join(root,'product-test-results.json'),JSON.stringify(report,null,2));
  await import('./validate-product-results.mjs');
  for(const variant of ['original','candidate']) for(const kind of ['early-exit','consume']) for(const size of [1024,65536,1048576]) {
    const rows=results.filter(x=>x.variant===variant&&x.kind===kind&&x.size===size);
    console.log(JSON.stringify({variant,kind,size,exits:rows.map(x=>x.exit),outcomes:rows.map(x=>x.outcome?.outcome??(/write EOF/.test(x.stderr)?'uncaught write EOF':x.stderr.slice(0,90))),codes:rows.map(x=>x.outcome?.code??null)}));
  }
}
