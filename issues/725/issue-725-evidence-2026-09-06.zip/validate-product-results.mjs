import fs from 'node:fs';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';

const resultPath=new URL('./product-test-results.json',import.meta.url);
const report=JSON.parse(fs.readFileSync(resultPath,'utf8'));
assert.equal(report.bundleSHA256,'10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05');
assert.equal(report.platform,'win32','These expected error outcomes are Windows-specific');
assert.equal(report.productCLI,false);
assert.equal(report.results.length,36);
for(const variant of ['original','candidate']) for(const kind of ['early-exit','consume']) for(const size of [1024,65536,1048576]) {
  const rows=report.results.filter(r=>r.variant===variant&&r.kind===kind&&r.size===size);
  assert.deepEqual(rows.map(r=>r.trial),[1,2,3]);
  for(const row of rows){
    assert.equal(row.error,undefined,'No harness error or timeout is a valid reproduction');
    assert.equal(row.signal,null);
    if(variant==='original'&&kind==='early-exit'&&size===1048576){
      assert.equal(row.exit,1);
      assert.match(row.stderr,/Unhandled 'error' event/);
      assert.match(row.stderr,/Error: write EOF/);
      assert.match(row.stderr,/WriteWrap\.onWriteComplete/);
    } else if(variant==='candidate'&&kind==='early-exit'&&size===1048576){
      assert.equal(row.exit,0);
      assert.equal(row.outcome.outcome,'rejected');
      assert.equal(row.outcome.code,'EOF');
    } else {
      assert.equal(row.exit,0);
      assert.equal(row.outcome.outcome,'resolved');
      assert.equal(row.outcome.result.code,0);
      if(kind==='consume')assert.equal(row.outcome.result.stdout,String(size),'Consumer must confirm every input byte');
    }
  }
}
console.log('PASS: all 36 published-component outcomes and artifact identity validated.');
