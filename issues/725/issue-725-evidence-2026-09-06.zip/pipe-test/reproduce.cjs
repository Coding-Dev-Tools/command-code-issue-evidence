'use strict';

// Synthetic Windows pipe-close experiment. No Command Code code or APIs are used.
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const CHILD_TIMEOUT_MS = 6000;
const WORKER_TIMEOUT_MS = 8000;
const TRIAL_TIMEOUT_MS = 9000;
const PAYLOAD_BYTES = 1048576;
const TRIALS_PER_CONDITION = 3;

function emit(value) {
  fs.writeSync(1, JSON.stringify(value) + '\n');
}

function errorData(error) {
  return error ? { name: error.name, message: error.message, code: error.code,
    errno: error.errno, syscall: error.syscall } : null;
}

if (process.argv[2] === '--child') {
  const pipeState = process.argv[3];
  const deadline = setTimeout(() => process.exit(90), CHILD_TIMEOUT_MS);
  process.on('disconnect', () => process.exit(0));
  process.on('message', (message) => {
    if (message && (message.type === 'EXIT' || message.type === 'CLOSE_PEER_AND_EXIT')) {
      emit({ event: 'child-exiting', requestedByParent: message.type,
        intendedExitCode: 0 });
      clearTimeout(deadline);
      process.exit(0);
    }
  });
  if (pipeState === 'closed') {
    // Leave the pipe unread. The parent queues a bounded write and then asks
    // this child to exit over IPC, closing every OS handle without a sleep.
    // Closing CRT fd 0 or emitting a stdin close event alone was insufficient
    // to prove OS-peer closure in preliminary Windows trials.
  } else {
    let consumedBytes = 0;
    process.stdin.on('data', (chunk) => {
      consumedBytes += chunk.length;
      emit({ event: 'child-consumed', consumedBytes });
    });
    process.stdin.resume();
  }
  // The parent does not write until it parses this real stdout handshake.
  emit({ event: 'child-ready', pipeState, pid: process.pid,
    stdinBehavior: pipeState === 'closed' ? 'never-read; exit on IPC after write queued' : 'consume-all' });
} else if (process.argv[2] === '--worker') {
  const [pipeState, listenerMode] = process.argv.slice(3);
  const withListener = listenerMode === 'before-write';
  let callbackCalls = 0;
  let promiseOutcome = 'pending';
  let streamErrorEvents = 0;
  let inputConsumed = 0;
  let handshake = false;
  let finishing = false;
  let childExited = false;
  let child;
  const deadline = setTimeout(() => {
    emit({ event: 'worker-timeout' });
    if (child && !childExited) child.kill(); // Only this experiment's child.
    process.exitCode = 91;
  }, WORKER_TIMEOUT_MS);

  // Monitor records the default crash but does not catch/suppress it.
  process.on('uncaughtExceptionMonitor', (error, origin) => {
    emit({ event: 'uncaught-exception-monitor', origin, error: errorData(error),
      callbackCalls, promiseOutcome, streamErrorEvents });
  });

  child = spawn(process.execPath, [__filename, '--child', pipeState],
    { stdio: ['pipe', 'pipe', 'pipe', 'ipc'], windowsHide: true });
  emit({ event: 'worker-start', pid: process.pid, childPid: child.pid,
    nodeVersion: process.version, platform: process.platform, pipeState,
    listenerMode, payloadBytes: PAYLOAD_BYTES });

  child.on('error', (error) => {
    emit({ event: 'child-process-error', error: errorData(error) });
    process.exitCode = 92;
  });
  child.stderr.on('data', (chunk) => emit({ event: 'child-stderr', text: chunk.toString() }));
  child.on('exit', (code, signal) => {
    childExited = true;
    emit({ event: 'child-exit', code, signal });
  });
  child.on('close', (code, signal) => {
    clearTimeout(deadline);
    emit({ event: 'worker-summary', handshake, callbackCalls, promiseOutcome,
      streamErrorEvents, inputConsumed, childExitCode: code, childSignal: signal });
  });

  if (withListener) {
    child.stdin.on('error', (error) => {
      streamErrorEvents += 1;
      emit({ event: 'stdin-error-event', error: errorData(error),
        callbackCalls, promiseOutcome });
      maybeFinish();
    });
  }

  function maybeFinish() {
    if (finishing || promiseOutcome === 'pending') return;
    if (pipeState === 'open' && inputConsumed !== PAYLOAD_BYTES) return;
    if (pipeState === 'closed' && withListener && streamErrorEvents === 0) return;
    finishing = true;
    if (pipeState === 'closed') return; // Explicit peer exit was already requested.
    emit({ event: 'request-child-exit' });
    if (child.connected) child.send({ type: 'EXIT' }, (error) => {
      if (error) emit({ event: 'ipc-send-error', error: errorData(error) });
    });
  }

  let stdoutBuffer = '';
  child.stdout.on('data', (chunk) => {
    stdoutBuffer += chunk.toString();
    let newline;
    while ((newline = stdoutBuffer.indexOf('\n')) >= 0) {
      const line = stdoutBuffer.slice(0, newline);
      stdoutBuffer = stdoutBuffer.slice(newline + 1);
      const message = JSON.parse(line);
      emit(message);
      if (message.event === 'child-consumed') {
        inputConsumed = message.consumedBytes;
        maybeFinish();
      }
      if (message.event !== 'child-ready') continue;
      if (handshake) throw new Error('Unexpected duplicate readiness handshake');
      handshake = true;
      emit({ event: 'before-write', stdinErrorListeners: child.stdin.listenerCount('error'),
        childExitCode: child.exitCode, childConnected: child.connected,
        pipeStateConfirmed: message.pipeState });
      const writePromise = new Promise((resolve, reject) => {
        child.stdin.write(Buffer.alloc(PAYLOAD_BYTES, 0x61), (error) => {
          callbackCalls += 1;
          emit({ event: 'write-callback', error: errorData(error) });
          if (error) {
            emit({ event: 'promise-reject-called', error: errorData(error) });
            reject(error);
          } else {
            resolve();
          }
        });
      });
      // A Promise rejection handler is installed immediately in BOTH modes.
      writePromise.then(() => {
        promiseOutcome = 'fulfilled';
        emit({ event: 'promise-fulfilled' });
        maybeFinish();
      }, (error) => {
        promiseOutcome = 'rejected-and-handled';
        emit({ event: 'promise-rejection-handler', error: errorData(error) });
        maybeFinish();
      });
      if (pipeState === 'closed') {
        emit({ event: 'write-queued-request-peer-exit', pendingWriteBytes: child.stdin.writableLength });
        child.send({ type: 'CLOSE_PEER_AND_EXIT' }, (error) => {
          if (error) emit({ event: 'ipc-send-error', error: errorData(error) });
        });
      }
    }
  });
} else {
  (async () => {
    const results = [];
    for (const pipeState of ['open', 'closed']) {
      for (const listenerMode of ['none', 'before-write']) {
        for (let trial = 1; trial <= TRIALS_PER_CONDITION; trial++) {
          results.push(await runTrial(pipeState, listenerMode, trial));
        }
      }
    }
    const report = {
      generatedAt: new Date().toISOString(), nodeVersion: process.version,
      executable: process.execPath, platform: process.platform,
      architecture: process.arch, payloadBytes: PAYLOAD_BYTES,
      trialsPerCondition: TRIALS_PER_CONDITION,
      timeoutsMs: { child: CHILD_TIMEOUT_MS, worker: WORKER_TIMEOUT_MS, trial: TRIAL_TIMEOUT_MS },
      note: 'Child stdout readiness precedes a queued 1 MiB write, then IPC requests peer exit without reading. Real OS pipe closure; no injected errors. Component behavior, not product root-cause proof.',
      results
    };
    const output = path.join(__dirname, 'results.json');
    fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n');
    emit({ output, nodeVersion: process.version, conditions: summarize(results) });
  })().catch((error) => { console.error(error); process.exitCode = 1; });
}

function runTrial(pipeState, listenerMode, trial) {
  return new Promise((resolve) => {
    const worker = spawn(process.execPath,
      [__filename, '--worker', pipeState, listenerMode],
      { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    const startedAt = Date.now();
    let stdout = '';
    let stderr = '';
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      worker.kill(); // Only the trial worker; its child exits on IPC disconnect.
    }, TRIAL_TIMEOUT_MS);
    worker.stdout.on('data', (chunk) => { stdout += chunk.toString(); });
    worker.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
    worker.on('close', (exitCode, signal) => {
      clearTimeout(timer);
      const events = stdout.trim().split('\n').filter(Boolean).map((line) => JSON.parse(line));
      resolve({ pipeState, listenerMode, trial, elapsedMs: Date.now() - startedAt,
        exitCode, signal, timedOut, events, stderr });
    });
  });
}

function summarize(results) {
  const groups = new Map();
  for (const result of results) {
    const key = result.pipeState + '/' + result.listenerMode;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(result);
  }
  return [...groups].map(([condition, trials]) => ({
    condition,
    trials: trials.length,
    exitCodes: trials.map((trial) => trial.exitCode),
    callbacks: trials.map((trial) => trial.events.filter((event) => event.event === 'write-callback').map((event) => event.error && event.error.code)),
    promiseRejectionHandlers: trials.map((trial) => trial.events.filter((event) => event.event === 'promise-rejection-handler').length),
    streamErrorEvents: trials.map((trial) => trial.events.filter((event) => event.event === 'stdin-error-event').map((event) => event.error.code)),
    uncaughtExceptions: trials.map((trial) => trial.events.filter((event) => event.event === 'uncaught-exception-monitor').map((event) => event.error.code)),
    timeouts: trials.filter((trial) => trial.timedOut).length
  }));
}
