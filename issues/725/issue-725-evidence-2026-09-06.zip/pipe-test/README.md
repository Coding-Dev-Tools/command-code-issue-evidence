# Independent Windows pipe-close experiment for issue #725

This is synthetic Node component evidence. It does not execute Command Code,
modify its installed bundle, contact a model, or prove the root cause of #725.

## Environment and run

- Actual runtime: Node **v24.15.0**, `C:\Program Files\nodejs\node.exe`.
- Platform: Windows (`win32`), x64.
- Run from the repository root: `node artifacts/issue-725/pipe-test/reproduce.cjs`.
- Final machine-readable evidence: `results.json` (all 12 trial event traces and stderr).
- Maximum payload per trial: **1,048,576 bytes** of synthetic ASCII `a` data.
- Each child has a 6-second deadline; worker and trial deadlines are 8 and 9 seconds.
- The only termination targets in timeout cleanup are the experiment's own subprocesses.

## Readiness and actual closure

Every child emits a real JSON readiness line on stdout, which its worker parses
before writing. Open-pipe controls consume the entire payload and report its byte
count. Closed-peer trials deliberately never read stdin: the worker queues the
1 MiB write, immediately attaches Promise fulfillment/rejection handlers, then
requests child exit over IPC. The child's normal process exit closes its OS pipe
handles. There is no fixed sleep and no manually injected error.

## Final results

Each condition ran three times; all final assertions passed.

| Condition | Write callback | stdin error event | Promise outcome | Worker exit |
|---|---|---|---|---|
| Open pipe, no stdin error listener | success 3/3 | none | fulfilled 3/3 | 0, 0, 0 |
| Open pipe, listener before write | success 3/3 | none | fulfilled 3/3 | 0, 0, 0 |
| Closing peer, no stdin error listener | EOF 3/3 | unhandled; crash 3/3 | reject called; handler cannot run before crash | 1, 1, 1 |
| Closing peer, listener before write | EOF 3/3 | handled EOF 3/3 | rejected and handled 3/3 | 0, 0, 0 |

The exact Windows error was `write EOF`, `code: EOF`, `errno: -4095`,
`syscall: write`. **These final trials did not produce EPIPE.**

The no-listener stderr explicitly says `Unhandled 'error' event` and
`Emitted 'error' event on Socket instance`. An `uncaughtExceptionMonitor`
records this without catching or suppressing the normal process failure.
The explicit Promise rejection handler is already attached in both listener
conditions, so a callback-to-Promise wrapper by itself does not prevent the
stream's unhandled error from terminating the process.

The listener-before-write condition demonstrates both callback failure and a
separate stream error notification; handling that notification permits the Promise
rejection handler and normal child cleanup to complete. It does not demonstrate
that ignoring every stdin error is a correct application fix.

Final validation confirmed one readiness handshake and one write callback per
trial, 1 MiB consumed in every open control, no timeout, no IPC/process errors,
and normal child exit in all trials whose worker survives long enough to report it.

## Preliminary experiments retained for transparency

- `results-fd-close-64k.json`: closing CRT fd 0 alone did not force the 64 KiB
  write to fail. This was insufficient proof of actual pipe-peer closure.
- `results-stdin-destroy-1m.json`: a stdin `close` event alone did not produce the
  intended immediate OS-close behavior; child deadlines and a cleanup IPC race
  contaminated those results. They are **not** the final reproduction/control.

The final fixture uses normal child process exit to avoid those Windows
descriptor/lifecycle ambiguities.

## Adaptation to a product-path test

If a product path passes a payload through `child.stdin.end(payload)` with no
stdin error listener, run the unchanged product function in an isolated worker
against a synthetic child that does not read stdin and exits normally, using a
capped 1 MiB payload and a real readiness signal. Keep the normal-reading child as
the control, and preserve the exact shell/spawn options from the product path.
An end-to-end test should observe product Promise settlement and host survival,
not only this independent component fixture. It should classify Windows EOF
alongside any separately reproduced EPIPE rather than assume the errno matches.
