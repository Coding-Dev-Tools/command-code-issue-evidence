# Issue 853: settings hooks versus Mod hooks in plan mode

Command Code 1.54.1, original CLI SHA256 `74a7b03dc794b5be7fa2efa4a41f8d33f9f45927cb3febe2c5e52508d9df4ac5`. Tested on Windows, Node 24.15.0, using the actual CLI in ConPTY with an xterm parser and a scripted localhost OpenAI-compatible endpoint. No paid model, sensitive files, or patched product code.

## Run

Extract into a new folder, then:

```sh
npm ci --ignore-scripts --no-audit --no-fund
node repro.mjs
node verify-startup.mjs
node verify.mjs
```

`repro.mjs` creates isolated homes/projects and fresh captures under `runs/`. It runs eight startup sessions and four sessions that each perform three turns: default, `/plan`, `/mode default`. The controller exits only after each CLI exits. Both verification commands check retained captures by default. Supply a fresh `results.json` path to verify a new run. No real user configuration is read by the CLI. The test guards CLI filesystem access and network access; it is a controlled fixture, not an adversarial sandbox evaluation.

Each read uses a generated sentinel absent from the prompt and scripted response. The switch runner replaces the file's content between turns, so a previous result cannot satisfy the next read. Capture files include actual returned tool content. Settings audit hooks write PreToolUse/PostToolUse events and permit reads; settings guard hooks deny in PreToolUse. The Mod guard blocks only sentinel853.txt and permits ordinary853.txt.

The hook child uses explicit `--allow-fs-read=.. --allow-fs-write=..` inside its synthetic project. This accommodates inherited Node permission options and paths with spaces. These are fixture permissions, not a recommended global setting.

## Expected observations

| Mechanism | Default | After /plan | Back to default |
| --- | --- | --- | --- |
| Settings guard | Blocks | Skipped; file returned | Blocks |
| Settings audit | Pre and Post | Neither | Pre and Post |
| Matching Mod guard | Blocks | Blocks | Blocks |
| Nonmatching Mod read | Returns file | Returns file | Returns file |

Eight startup controls separately establish unguarded reads and exact `Read(sentinel853.txt)` deny behavior in default/plan. A successful verifier means these observations hold, including the settings-hook gap; it does not mean the product defect is fixed.

The verifier recomputes outcomes from tool content and tests deliberately corrupted results. No Stop, child/background agents, glob/ask rules, shell reads or native Linux coverage is claimed. Previous child-agent evidence on #852 is separate.

All primary #853 runs exited cleanly. Packaging replay and any failed attempts are recorded separately in failure-accounting.json. Source bundles, dependencies and generated home trees are not included in this packet.
