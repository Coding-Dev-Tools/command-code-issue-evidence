import {fs,path,assert,packageRuntime,save,isolatedEnv,configure,expectedHash,sleep} from './common.mjs';
import {terminal} from './terminal.mjs';
import {fileURLToPath} from 'node:url';import http from 'node:http';import {randomUUID} from 'node:crypto';
const here=path.dirname(fileURLToPath(import.meta.url)),pkg=packageRuntime(process.argv[2]??path.join(here,'node_modules'));
const base=path.resolve(process.argv[3]??path.join(here,'runs'));fs.mkdirSync(base,{recursive:true});
const out=fs.mkdtempSync(path.join(base,'switch853-')),runs=[];let active,phase;
const server=http.createServer((req,res)=>{let raw='';req.on('data',x=>raw+=x);req.on('end',async()=>{try{
 assert.equal(req.url,'/v1/chat/completions');const b=JSON.parse(raw),ordinal=phase.requests.length+1;
 const user=b.messages.filter(x=>x.role==='user').at(-1);assert.ok(JSON.stringify(user).includes(phase.task),'route current user turn');
 assert.ok(!JSON.stringify(b).includes(phase.sentinel)||ordinal===2,'sentinel must first arrive via actual tool result');
 phase.requests.push({ordinal,model:b.model,tools:(b.tools??[]).map(x=>x.function.name),toolResults:b.messages.filter(x=>x.role==='tool')});
 assert.ok(ordinal<=2,'exactly one tool call then finish');
 const delta=ordinal===1?{role:'assistant',tool_calls:[{index:0,id:phase.callId,type:'function',function:{name:'read_file',arguments:JSON.stringify({file_path:active.target})}}]}:{role:'assistant',content:phase.done};
 if(ordinal===2)await sleep(1000);
 res.writeHead(200,{'content-type':'text/event-stream'});
 for(const[d,f]of[[delta,null],[{},ordinal===1?'tool_calls':'stop']])res.write('data: '+JSON.stringify({id:'fixture853',object:'chat.completion.chunk',created:1,model:'model',choices:[{index:0,delta:d,finish_reason:f}],usage:{prompt_tokens:100,completion_tokens:20,total_tokens:120}})+'\n\n');
 res.end('data: [DONE]\n\n');
 }catch(e){active.errors.push(e.message);res.writeHead(500);res.end('fixture error');}})});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
let failure=null;
try{for(const guard of ['settings-audit','settings-block','mod-block','mod-nonmatching'].filter(x=>!process.argv[4]||x===process.argv[4])){
 const run=path.join(out,guard),home=path.join(run,'home'),project=path.join(run,'project');fs.mkdirSync(project,{recursive:true});
 const env=isolatedEnv(home,port);await configure(home,project,pkg,port);
 env.GUARD_LOG=path.join(run,'events.jsonl');env.FACTORY_LOG=path.join(run,'factories.txt');
 const target=path.join(project,guard==='mod-nonmatching'?'ordinary853.txt':'sentinel853.txt');
 const settings={permissions:{defaultMode:'default'},disableScratchpad:true,mods:{disabled:['titling','learning']}};
 if(guard.startsWith('settings')){
  fs.writeFileSync(path.join(run,'hook.cjs'),`const fs=require('node:fs');let raw='';process.stdin.on('data',b=>raw+=b);process.stdin.on('end',()=>{const p=JSON.parse(raw);fs.appendFileSync(process.env.GUARD_LOG,JSON.stringify({event:p.hook_event_name,mode:p.permission_mode,tool:p.tool_name,input:p.tool_input})+'\\n');console.log(JSON.stringify(${guard==='settings-block'}&&p.hook_event_name==='PreToolUse'?{hookSpecificOutput:{permissionDecision:'deny',permissionDecisionReason:'SETTINGS_853_BLOCK'}}:{}));});`);
  settings.hooks=Object.fromEntries(['PreToolUse','PostToolUse'].map(x=>[x,[{matcher:'read',hooks:[{type:'command',command:'node --allow-fs-read=.. --allow-fs-write=.. ../hook.cjs',timeout:10}]}]]));
 }else{
  const mods=path.join(home,'.commandcode/mods');fs.mkdirSync(mods,{recursive:true});
  fs.writeFileSync(path.join(mods,'guard853.ts'),`import {appendFileSync} from 'node:fs';export default function(cmd){appendFileSync(process.env.FACTORY_LOG,'loaded\\n');cmd.hooks({beforeToolCall:({toolName,input})=>{appendFileSync(process.env.GUARD_LOG,JSON.stringify({event:'beforeToolCall',tool:toolName,input})+'\\n');if(toolName==='read_file'&&JSON.stringify(input).includes('sentinel853.txt'))return{block:true,additionalContext:'MOD_853_BLOCK'};}});}`);
 }
 save(path.join(home,'.commandcode/settings.json'),settings);
 active={guard,target,phases:[],errors:[]};const t=terminal(pkg,here,out,project,env,['--permission-mode','default']);
 const events=()=>fs.existsSync(env.GUARD_LOG)?fs.readFileSync(env.GUARD_LOG,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse):[];
 try{
  assert.ok(await t.until(()=>t.screen().includes('Ask your question')),'ready prompt');
  for(const [i,mode]of ['default','plan','default'].entries()){
   const transition=i===1?'/plan':i===2?'/mode default':null;
   if(transition){await t.type(transition);const notice=i===1?'Entered plan mode.':'Switched to default mode.';assert.ok(await t.until(()=>t.screen().includes(notice)),'mode switch notice');await sleep(400);}
   const token=randomUUID().replaceAll('-','');phase={index:i,mode,transition,task:`RUN853_${i}`,callId:`call853_${i}`,done:`DONE853_${i}`,sentinel:'FILE853_'+token,requests:[],events:[]};active.phases.push(phase);
   fs.writeFileSync(target,phase.sentinel+'\n');const start=events().length;
   await t.type(phase.task+': perform the scripted harmless fixture read.');
   assert.ok(await t.until(()=>t.screen().includes(phase.done),35000),'turn completion');await sleep(400);
   phase.events=events().slice(start);phase.screen=t.screen();
   const result=phase.requests.flatMap(x=>x.toolResults).filter(x=>x.tool_call_id===phase.callId);phase.readResults=result;
   phase.contentReturned=result.some(x=>JSON.stringify(x.content).includes(phase.sentinel));
   phase.expectedContent=guard==='settings-audit'||guard==='mod-nonmatching'||guard==='settings-block'&&mode==='plan';
   assert.equal(phase.requests.length,2);assert.ok(result.length);assert.equal(phase.contentReturned,phase.expectedContent);
   const ev=phase.events.map(x=>x.event);
   assert.deepEqual(ev,guard.startsWith('settings')?(mode==='plan'?[]:guard==='settings-audit'?['PreToolUse','PostToolUse']:['PreToolUse']):['beforeToolCall']);
   if(mode==='default'&&guard.startsWith('settings'))assert.ok(phase.events.every(x=>x.mode==='default'));
   console.log(JSON.stringify({guard,mode,index:i,content:phase.contentReturned,events:ev}));save(path.join(run,'progress.json'),active);
  }
 }catch(e){active.failure={message:e.message,stack:e.stack};throw e;}
 finally{active.exit=await t.close();active.factoryLoaded=fs.existsSync(env.FACTORY_LOG);active.raw=t.raw;active.screen=t.screen();runs.push(active);save(path.join(run,'results.json'),active);}
 assert.equal(active.exit.exitCode,0);assert.equal(active.errors.length,0);if(guard.startsWith('mod'))assert.ok(active.factoryLoaded);
}}
catch(e){failure={message:e.message,stack:e.stack};}
finally{server.closeAllConnections();await new Promise(r=>server.close(r));}
save(path.join(out,'results.json'),{version:'1.54.1',bundleSha256:expectedHash,node:process.version,platform:process.platform,scope:'Unchanged actual Windows CLI; main-agent read_file; scripted localhost provider; default /plan /mode default within each session.',runs,failure});
console.log(JSON.stringify({out,failure}));setTimeout(()=>process.exit(failure?1:0),50);
