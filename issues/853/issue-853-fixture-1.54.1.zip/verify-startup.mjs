import fs from 'node:fs';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
const x=JSON.parse(fs.readFileSync(process.argv[2]??new URL('./startup-results.json',import.meta.url),'utf8'));
function check(d){assert.equal(d.failure,null);assert.equal(d.runs.length,8);assert.equal(d.version,'1.54.1');assert.equal(d.bundleSha256,'74a7b03dc794b5be7fa2efa4a41f8d33f9f45927cb3febe2c5e52508d9df4ac5');
 for(const r of d.runs){assert.equal(r.exit.code,0);assert.equal(r.timedOut,false);assert.equal(r.requests.length,2);assert.deepEqual(r.serverErrors,[]);
  const result=r.requests.flatMap(y=>y.toolResults).filter(z=>z.tool_call_id==='call_main_853');assert.equal(result.length,1);assert.deepEqual(result,r.readResults);
  const returned=result.some(y=>JSON.stringify(y.content).includes(r.sentinel));assert.equal(returned,r.guard==='none'||r.guard==='settings'&&r.mode==='plan');assert.equal(r.contentReturned,returned);
  if(r.guard==='mod'){assert.equal(r.factoryLoaded,true);assert.ok(r.events.some(e=>e.event==='beforeToolCall'&&e.tool==='read_file'));}
  if(r.guard==='settings')assert.equal(r.events.some(e=>e.event==='PreToolUse'),r.mode==='default');
 }}
check(x);for(const mutate of [d=>d.runs[0].readResults[0].content='CORRUPTED',d=>d.runs[5].events=[],d=>d.runs[0].exit.code=1]){const bad=structuredClone(x);mutate(bad);assert.throws(()=>check(bad));}
console.log(JSON.stringify({ok:true,sessions:8,requests:16,negativeControlsRejected:3}));
