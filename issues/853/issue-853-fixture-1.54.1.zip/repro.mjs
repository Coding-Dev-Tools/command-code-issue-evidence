import fs from 'node:fs';import path from 'node:path';import {spawnSync} from 'node:child_process';import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),runtime=path.resolve(process.argv[2]??path.join(here,'node_modules')),base=path.resolve(process.argv[3]??path.join(here,'runs'));
if(process.platform!=='win32')throw new Error('This terminal fixture is tested on Windows.');
fs.mkdirSync(base,{recursive:true});const outputs=[];
for(const script of ['startup-hooks.mjs','switch-hooks.mjs']){
 const p=spawnSync(process.execPath,[path.join(here,script),runtime,base],{encoding:'utf8',windowsHide:true,timeout:360000,maxBuffer:16*1024*1024});process.stdout.write(p.stdout??'');process.stderr.write(p.stderr??'');
 const last=p.stdout?.trim().split('\n').at(-1);outputs.push({script,exit:p.status,signal:p.signal,error:p.error?.message,result:last?JSON.parse(last):null});
 if(p.status!==0){fs.writeFileSync(path.join(base,'run-receipt.json'),JSON.stringify(outputs,null,2));process.exit(p.status??1);}
}
fs.writeFileSync(path.join(base,'run-receipt.json'),JSON.stringify(outputs,null,2)+'\n');
console.log('Fresh captures remain in the named run directories. verify.mjs checks the switch capture; verify-startup.mjs checks startup.');
