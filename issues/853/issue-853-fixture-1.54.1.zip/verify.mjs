import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
export function check(x){
 assert.equal(x.failure,null);assert.equal(x.version,'1.54.1');assert.equal(x.bundleSha256,'74a7b03dc794b5be7fa2efa4a41f8d33f9f45927cb3febe2c5e52508d9df4ac5');
 assert.deepEqual(x.runs.map(r=>r.guard),['settings-audit','settings-block','mod-block','mod-nonmatching']);
 for(const r of x.runs){assert.equal(r.exit.exitCode,0);assert.deepEqual(r.errors,[]);assert.equal(r.failure,undefined);assert.deepEqual(r.phases.map(p=>p.mode),['default','plan','default']);if(r.guard.startsWith('mod'))assert.equal(r.factoryLoaded,true);
  for(const p of r.phases){assert.equal(p.requests.length,2);assert.equal(p.requests[0].model,'model');assert.equal(p.transition,p.index===0?null:p.index===1?'/plan':'/mode default');assert.ok(p.screen.includes(p.done));
   const rr=p.requests.flatMap(z=>z.toolResults).filter(z=>z.tool_call_id===p.callId);assert.equal(rr.length,1);assert.deepEqual(rr,p.readResults);
   const returned=rr.some(z=>JSON.stringify(z.content).includes(p.sentinel));const want=r.guard==='settings-audit'||r.guard==='mod-nonmatching'||r.guard==='settings-block'&&p.mode==='plan';
   assert.equal(returned,want);assert.equal(p.contentReturned,returned);
   assert.deepEqual(p.events.map(e=>e.event),r.guard.startsWith('settings')?(p.mode==='plan'?[]:r.guard==='settings-audit'?['PreToolUse','PostToolUse']:['PreToolUse']):['beforeToolCall']);
   for(const e of p.events){assert.ok(JSON.stringify(e.input).includes(r.guard==='mod-nonmatching'?'ordinary853.txt':'sentinel853.txt'));if(r.guard.startsWith('settings'))assert.equal(e.mode,'default');}
  }
 }
 return {sessions:4,turns:12,providerRequests:24};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const file=path.resolve(process.argv[2]??path.join(here,'switch-results.json')),x=JSON.parse(fs.readFileSync(file,'utf8')),result=check(x),negative=[];
 for(const [name,mutate]of [['read-result',d=>d.runs[0].phases[0].requests[1].toolResults[0].content='CORRUPTED'],['missing-mod-event',d=>d.runs[2].phases[1].events=[]],['missing-post-audit',d=>d.runs[0].phases[2].events.pop()],['failed-exit',d=>d.runs[0].exit.exitCode=1]]){
  const copy=structuredClone(x);mutate(copy);assert.throws(()=>check(copy),name);negative.push(name);
 }
 console.log(JSON.stringify({ok:true,...result,negativeControlsRejected:negative}));
}
