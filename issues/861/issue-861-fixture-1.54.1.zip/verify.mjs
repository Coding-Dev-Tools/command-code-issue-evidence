import fs from 'node:fs';import assert from 'node:assert/strict';import path from 'node:path';
function clean(x){return x.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').trim().replaceAll('\\','/');}
function names(x){return [...new Set(x.map(z=>z.name))].sort();}
function check(x){
 assert.equal(x.failure,null);assert.equal(x.version,'1.54.1');assert.equal(x.bundleSha256,'74a7b03dc794b5be7fa2efa4a41f8d33f9f45927cb3febe2c5e52508d9df4ac5');assert.equal(x.rows.length,8);assert.equal(x.sessions.length,2);
 const out=clean(x.out),win=x.platform==='win32',local=win?'nested861':'root861',other=win?'root861':'nested861';
 for(const r of x.rows)assert.equal(r.code,0);
 const row=n=>x.rows.find(r=>r.name===n);
 assert.equal(clean(row('nested-open').stdout),out+'/repo'+(win?'/nested':'')+'/.commandcode/mods');
 assert.ok(row('nested-list-uninitialized').stdout.includes('user861'));for(const n of ['root861','nested861'])assert.ok(!row('nested-list-uninitialized').stdout.includes(n));
 assert.ok(row('nested-list-initialized').stdout.includes(local));assert.ok(!row('nested-list-initialized').stdout.includes(other));assert.ok(row('nested-list-project-setting').stdout.includes(other));
 for(const [name,rel]of [['nested-git-empty-cwd-open',win?'home':'repo/child-repo'],['nested-git-local-commandcode-open',win?'repo/child-repo/deep':'repo/child-repo'],['worktree-empty-cwd-open',win?'home':'worktree'],['worktree-local-commandcode-open',win?'worktree/deep':'worktree']])assert.equal(clean(row(name).stdout),out+'/'+rel+'/.commandcode/mods');
 const s=x.sessions[0];assert.equal(s.exit.exitCode,0);assert.equal(s.failure,undefined);assert.deepEqual(names(s.steps[0].factories),[local,'user861'].sort());
 assert.ok(s.steps[1].commands.some(c=>c.name===other&&c.revision===1));assert.ok(s.steps[2].commands.some(c=>c.name===other&&c.revision===2));
 const pids=[...new Set(s.steps[2].factories.map(z=>z.pid))];assert.equal(pids.length,3);assert.ok(s.steps[2].factories.some(c=>c.name===other&&c.revision===2));
 assert.equal(x.sessions[1].exit.exitCode,0);assert.deepEqual(names(x.sessions[1].factories),['standalone861','user861']);assert.ok(x.sessions[1].commands.some(c=>c.name==='standalone861'));
}
const files=process.argv.slice(2);if(!files.length)files.push(new URL('./windows-results.json',import.meta.url),new URL('./linux-results.json',import.meta.url));
for(const f of files){const x=JSON.parse(fs.readFileSync(f,'utf8'));check(x);for(const mutate of [d=>d.sessions[0].steps[0].factories=[],d=>d.sessions[0].steps[2].commands=d.sessions[0].steps[2].commands.filter(x=>x.revision!==2),d=>d.rows[0].stdout='WRONG',d=>d.sessions[1].exit.exitCode=1]){const bad=structuredClone(x);mutate(bad);assert.throws(()=>check(bad));}console.log(JSON.stringify({ok:true,platform:x.platform,commands:8,sessions:2,reloadRestarts:2,negativeControlsRejected:4}));}
