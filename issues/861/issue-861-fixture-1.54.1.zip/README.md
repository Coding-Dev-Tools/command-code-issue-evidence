# Issue 861: root selection, scoped Mod paths and actual loading

Unchanged Command Code 1.54.1, CLI SHA256 `74a7b03dc794b5be7fa2efa4a41f8d33f9f45927cb3febe2c5e52508d9df4ac5`. Actual CLI commands and interactive factory/command execution were tested on Windows with Node 24.15.0 and in a Linux Docker container with Node 22.23.2. No model turn was submitted. These are generated layouts, not the undisclosed reporter environment.

## Run

Requires Node and Git. Use a fresh directory, including one with spaces if desired:

```sh
npm ci --ignore-scripts --no-audit --no-fund
node mod-discovery.mjs
node verify.mjs
```

The driver generates a repository, nested repository, real Git worktree, standalone project and isolated home under the OS temp directory. It creates an empty commit only in that generated repository, with an explicit synthetic identity and disabled commit signing/hooks. The printed output path contains the fresh results. `verify.mjs` checks retained Windows/Linux results; pass the new results.json path to check a rerun. An optional second argument to the driver chooses the runtime node_modules directory; an optional third chooses a result-copy path.

On Docker Desktop, running hundreds of dependency reads through a Windows bind mount timed out in an excluded pilot. The optional linux-local-runtime.mjs copies dependencies to the container filesystem first. The retained Linux runtime was freshly installed from the same lock, with platform-specific optional packages. Base image ID is recorded in provenance.json. No host credentials or repository checkout are mounted into the CLI's synthetic project.

## Controls

Eight CLI commands compare root printing, uninitialized/initialized listing, project-scoped file paths, nearest nested Git root and a real worktree .git file. Two terminal sessions cover the nested and unrelated standalone project; the first restarts twice through /reload.

Both initial project metadata and all Mods are synthetic. Project initialization is simulated by creating the existing per-cwd metadata directory, not by running onboarding. Factories and command handlers record distinct names, revisions and process IDs. The test waits for all expected factories and a parsed prompt before typing. Changing revision 1 to 2 verifies that reload executed the changed source. Listing alone cannot satisfy these assertions.

For the generated repo/nested launch directory:

- Windows with native backslash cwd resolves local repo/nested/.commandcode.
- Linux resolves repo's Git root.
- Project settings can add the otherwise unscanned Mod on both platforms.
- An unrelated standalone project's factories exclude both repository Mods.
- On Windows, an empty launch directory with neither .git nor .commandcode falls back to the user Mod directory even when ancestor Git metadata exists. Adding local .commandcode changes that result. Linux finds the ancestor .git directory or worktree .git file in both controls.

Relative mods.paths entries are resolved against the resolved project root. They target an actual .ts file here; an ordinary directory without a supported package entrypoint is a different input. No universal root override, other surface's root, reporter-specific cause or native macOS behavior is established.

Verifiers deliberately reject missing factories, missing revision-2 command execution, an incorrect resolved path and a failed exit. Historical driver mistakes and timeouts are retained separately in failure-accounting.json, not counted as completed product results.
