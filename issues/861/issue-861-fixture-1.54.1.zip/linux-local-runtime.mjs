import fs from 'node:fs';import {spawnSync} from 'node:child_process';
// For Docker Desktop: avoid repeated package loading over a Windows bind mount.
fs.cpSync('/mounted-runtime','/tmp/local-runtime',{recursive:true});
console.log('Copied fixture dependencies to the Linux container filesystem.');
const r=spawnSync(process.execPath,['/fixture/mod-discovery.mjs','/tmp/local-runtime/node_modules','/results/861-linux.json'],{stdio:'inherit'});process.exit(r.status??1);
