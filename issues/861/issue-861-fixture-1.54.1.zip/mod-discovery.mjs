import {fs,path,assert,packageRuntime,save,isolatedEnv,configure,expectedHash,sleep} from './common.mjs';
import {terminal} from './terminal.mjs';import {fileURLToPath} from 'node:url';import os from 'node:os';import {spawnSync} from 'node:child_process';
const here=path.dirname(fileURLToPath(import.meta.url)),pkg=packageRuntime(process.argv[2]??path.join(here,'node_modules'));
const out=fs.mkdtempSync(path.join(os.tmpdir(),'cc-review861-')),home=path.join(out,'home'),repo=path.join(out,'repo'),nested=path.join(repo,'nested'),standalone=path.join(out,'standalone'),rows=[],sessions=[];
const env=isolatedEnv(home,1);env.GUARD_LOG=path.join(out,'unused');env.FACTORY_LOG=path.join(out,'factories.jsonl');env.COMMAND_LOG=path.join(out,'commands.jsonl');
for(const dir of [repo,nested,standalone])fs.mkdirSync(dir,{recursive:true});
function git(args){const p=spawnSync('git',args,{encoding:'utf8',windowsHide:true,env:{...process.env,HOME:home,USERPROFILE:home,GIT_CONFIG_NOSYSTEM:'1',GIT_CONFIG_GLOBAL:path.join(home,'absent.gitconfig')}});assert.equal(p.status,0,p.stderr);}
git(['init','--quiet',repo]);
const factory=(name,revision=1)=>`import {appendFileSync} from 'node:fs';export default function(cmd){appendFileSync(process.env.FACTORY_LOG,JSON.stringify({name:'${name}',revision:${revision},pid:process.pid})+'\\n');cmd.addCommand({name:'${name}',description:'Synthetic discovery check',handler:()=>{appendFileSync(process.env.COMMAND_LOG,JSON.stringify({name:'${name}',revision:${revision},pid:process.pid})+'\\n');return{};}});}`;
function mod(dir,name,revision=1){const f=path.join(dir,'.commandcode/mods',name+'.ts');fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f,factory(name,revision));return f;}
mod(repo,'root861');mod(nested,'nested861');mod(standalone,'standalone861');mod(home,'user861');
const expectedRoot=process.platform==='win32'?nested:repo;
const otherMod=process.platform==='win32'?'root861':'nested861',localMod=process.platform==='win32'?'nested861':'root861';
const setting=process.platform==='win32'?'../.commandcode/mods/root861.ts':'nested/.commandcode/mods/nested861.ts';
const policy=['--permission','--allow-child-process',`--allow-fs-read=${pkg.runtime}`,`--allow-fs-read=${here}`,`--allow-fs-read=${out}`,`--allow-fs-write=${out}`,'--require',path.join(here,'offline-guard.cjs')];
function command(name,cwd,args){const p=spawnSync(process.execPath,[...policy,pkg.cli,'--no-auto-update','--local-only',...args],{cwd,env,encoding:'utf8',windowsHide:true,timeout:30000});const r={name,cwd,args,code:p.status,signal:p.signal,error:p.error?.message,stdout:p.stdout,stderr:p.stderr};rows.push(r);assert.equal(p.status,0,name+': '+p.stderr);return r;}
const clean=x=>x.replace(/\x1b\[[0-?]*[ -/]*[@-~]/g,'').trim();
const read=p=>fs.existsSync(p)?fs.readFileSync(p,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse):[];
function names(rows){return [...new Set(rows.map(x=>x.name))].sort();}
let failure=null;
try{
 assert.equal(path.normalize(clean(command('nested-open',nested,['mods','open','--path']).stdout)),path.join(expectedRoot,'.commandcode/mods'));
 const uninit=command('nested-list-uninitialized',nested,['mods','list']);assert.ok(uninit.stdout.includes('user861'));assert.ok(!uninit.stdout.includes('root861')&&!uninit.stdout.includes('nested861'));
 await configure(home,nested,pkg,1);save(path.join(home,'.commandcode/settings.json'),{disableScratchpad:true,mods:{disabled:['titling','learning']}});
 const listed=command('nested-list-initialized',nested,['mods','list']);assert.ok(listed.stdout.includes(localMod));assert.ok(!listed.stdout.includes(otherMod));
 let fStart=read(env.FACTORY_LOG).length,cStart=read(env.COMMAND_LOG).length;
 const t=terminal(pkg,here,out,nested,{...env});const session={name:'nested-runtime',steps:[]};
 const record=name=>session.steps.push({name,factories:read(env.FACTORY_LOG).slice(fStart),commands:read(env.COMMAND_LOG).slice(cStart),screen:t.screen()});
 try{
  assert.ok(await t.until(()=>t.screen().includes('Ask your question')&&[localMod,'user861'].every(n=>read(env.FACTORY_LOG).slice(fStart).some(x=>x.name===n))),'initial prompt and both factories');record('initial');
  assert.deepEqual(names(read(env.FACTORY_LOG).slice(fStart)),[localMod,'user861'].sort());
  await t.type('/'+localMod);assert.ok(await t.until(()=>read(env.COMMAND_LOG).slice(cStart).some(x=>x.name===localMod)),'initial factory command');
  save(path.join(expectedRoot,'.commandcode/settings.json'),{mods:{paths:[setting]}});
  const configured=command('nested-list-project-setting',nested,['mods','list']);assert.ok(configured.stdout.includes(otherMod));
  const before=read(env.FACTORY_LOG).length,view=t.view();await t.type('/reload');
  assert.ok(await t.until(()=>['root861','nested861','user861'].every(n=>read(env.FACTORY_LOG).slice(before).some(x=>x.name===n))&&view().includes('Ask your question'),25000),'all factories and reloaded prompt');await sleep(400);
  const again=read(env.COMMAND_LOG).length;await t.type('/'+otherMod);assert.ok(await t.until(()=>read(env.COMMAND_LOG).slice(again).some(x=>x.name===otherMod)),'configured Mod command');record('configured-and-reloaded');
  assert.deepEqual(names(read(env.FACTORY_LOG).slice(before)),['root861','nested861','user861'].sort());
  const changed=otherMod==='root861'?repo:nested;mod(changed,otherMod,2);const before2=read(env.FACTORY_LOG).length,view2=t.view();await t.type('/reload');
  assert.ok(await t.until(()=>read(env.FACTORY_LOG).slice(before2).some(x=>x.name===otherMod&&x.revision===2)&&view2().includes('Ask your question'),25000),'changed factory and second reloaded prompt');await sleep(400);
  const command2=read(env.COMMAND_LOG).length;await t.type('/'+otherMod);assert.ok(await t.until(()=>read(env.COMMAND_LOG).slice(command2).some(x=>x.name===otherMod&&x.revision===2)),'changed command on second reload');record('revision-2');
 }catch(e){session.failure={message:e.message,stack:e.stack};throw e;}
 finally{session.exit=await t.close();session.raw=t.raw;sessions.push(session);save(path.join(out,'runtime-progress.json'),session);}
 assert.equal(session.exit.exitCode,0);
 await configure(home,standalone,pkg,1);fStart=read(env.FACTORY_LOG).length;cStart=read(env.COMMAND_LOG).length;
 const solo=terminal(pkg,here,out,standalone,{...env}),s={name:'standalone-runtime'};
 try{assert.ok(await solo.until(()=>solo.screen().includes('Ask your question')&&['standalone861','user861'].every(n=>read(env.FACTORY_LOG).slice(fStart).some(x=>x.name===n))));s.factories=read(env.FACTORY_LOG).slice(fStart);assert.deepEqual(names(s.factories),['standalone861','user861']);await solo.type('/standalone861');assert.ok(await solo.until(()=>read(env.COMMAND_LOG).slice(cStart).some(x=>x.name==='standalone861')));s.commands=read(env.COMMAND_LOG).slice(cStart);}
 finally{s.exit=await solo.close();s.raw=solo.raw;sessions.push(s);}assert.equal(s.exit.exitCode,0);
 // Closest nested Git boundary and real worktree .git-file boundary, measured with the actual CLI.
 const childRepo=path.join(repo,'child-repo'),childDir=path.join(childRepo,'deep');fs.mkdirSync(childDir,{recursive:true});git(['init','--quiet',childRepo]);
 const childOpen=command('nested-git-empty-cwd-open',childDir,['mods','open','--path']);assert.equal(path.normalize(clean(childOpen.stdout)),path.join(process.platform==='win32'?home:childRepo,'.commandcode/mods'));
 fs.mkdirSync(path.join(childDir,'.commandcode'),{recursive:true});const childWithConfig=command('nested-git-local-commandcode-open',childDir,['mods','open','--path']);assert.equal(path.normalize(clean(childWithConfig.stdout)),path.join(process.platform==='win32'?childDir:childRepo,'.commandcode/mods'));
 git(['-C',repo,'-c','user.name=Fixture','-c','user.email=fixture@example.invalid','-c','commit.gpgSign=false','-c','core.hooksPath='+path.join(out,'no-hooks'),'commit','--quiet','--allow-empty','-m','Synthetic root fixture']);
 const wt=path.join(out,'worktree');git(['-C',repo,'worktree','add','--quiet','--detach',wt]);const wd=path.join(wt,'deep');fs.mkdirSync(wd,{recursive:true});
 assert.ok(fs.statSync(path.join(wt,'.git')).isFile());const w=command('worktree-empty-cwd-open',wd,['mods','open','--path']);assert.equal(path.normalize(clean(w.stdout)),path.join(process.platform==='win32'?home:wt,'.commandcode/mods'));
 fs.mkdirSync(path.join(wd,'.commandcode'),{recursive:true});const wc=command('worktree-local-commandcode-open',wd,['mods','open','--path']);assert.equal(path.normalize(clean(wc.stdout)),path.join(process.platform==='win32'?wd:wt,'.commandcode/mods'));
}catch(e){failure={message:e.message,stack:e.stack};}
const result={version:'1.54.1',bundleSha256:expectedHash,node:process.version,platform:process.platform,out,expectedRoot,settingsFile:path.join(expectedRoot,'.commandcode/settings.json'),setting,rows,sessions,failure,scope:'Actual CLI mods open/list and factory/command execution across reloads. Isolated synthetic homes; per-cwd initialization metadata; native Windows or Linux container. No model requests. Does not establish original reporter cause or memory/skills/hook roots.'};
save(path.join(out,'results.json'),result);if(process.argv[3])save(path.resolve(process.argv[3]),result);console.log(JSON.stringify({out,platform:process.platform,commands:rows.length,sessions:sessions.length,failure}));setTimeout(()=>process.exit(failure?1:0),50);
