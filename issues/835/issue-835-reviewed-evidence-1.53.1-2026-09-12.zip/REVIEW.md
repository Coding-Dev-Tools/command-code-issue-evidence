# Second-cohort review — September 12, 2026

The exported packet was independently exercised again: 2 scenarios, 4 CLI processes, 8 localhost requests, 2 post-result Windows shutdown aborts, no watchdog timeout. The original findings above remain supported. This cohort is retained in [review observations](review-observations.json); original observations are unchanged. [Review provenance](review-provenance.json) records which fresh locked runtime was used.

`node verify-review.mjs` checks the second retained cohort without product execution. The complete prepared post is in [COMMENT-FULL.md](COMMENT-FULL.md). This packet is private; no public evidence URL is implied.

The third npm installation failed with ENOSPC before running the application. These controls instead used the already fresh, hash-verified #788 runtime, whose lock exactly matches this packet. No third independent installation is claimed. Native macOS/Node 25.6.1 listener/EBADF causes remain unestablished. The optional observer passed a fresh Windows smoke; [new observer receipt](review-observer-validation.json).
