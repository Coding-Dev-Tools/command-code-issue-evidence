# #835 — correction and discriminating stop controls

The complete live issue, both comments and both sanitized reporter attachments were read. They show the same listener warning in two macOS sessions and later persistent shell failures in one. They do not contain an FD census or a failing syscall trace proving descriptor exhaustion.

## Correction to our earlier public comment

The extracted hooks attach per-instance resize subscriptions and provide cleanup. The earlier synthetic fixture itself returned to zero after unmount. That can demonstrate listener fan-out above the default warning threshold; it does not independently confirm a leak across actual resume/mount/unmount cycles. The earlier “all historical components mount” explanation was not tested against the real TUI. A global stdout listener-count requirement of one also incorrectly counts unrelated subscriptions.

`EBADF` means an invalid descriptor; `EMFILE` denotes too many open files. The former does not prove exhaustion, and a count trend alone does not identify a bad descriptor. [Node warning semantics](https://nodejs.org/api/events.html#eventsdefaultmaxlisteners), [libuv error definitions](https://docs.libuv.org/en/v1.x/errors.html).

## New actual CLI controls on 1.53.1

- **Pending todo plus normal text:** the mock discovers todo_write, submits one pending item with documented fields, receives the successful tool result, then returns “Moving to the next check.” without a tool call. The CLI emits normal `end_turn`, turn count 3, with no continuation-recovery event. It can end after an accepted pending todo without a listener warning or EBADF.
- **Empty output:** two empty responses, each with nonzero synthetic output-token usage, trigger `continuation_recovery(kind='empty', attempt=1/2, maxAttempts=2)`. The third response supplies text and finishes normally.

These are **two headless controls, four CLI processes and eight localhost requests**, including follow-up resume captures. Both initial processes produce their result then hit the separate Windows shutdown assertion; both resume processes exit zero. No timeout or blocked network attempt. The runtime's normal-stop path can explain the shape of a plain-text premature stop without a resource leak. It is not proof that the reporter's native macOS session followed that path.

Source: after committing a turn, no tool calls plus no queued follow-up and no continuing onStop hook can end the run. Pending todo text is not itself an unconditional continuation guarantee. The empty-response recovery path is separate. Equivalent provider/model names in OpenCode are a useful comparison but do not control system prompts, tool schemas, context, sampling or continuation policy.

## Minimal next observation

For one affected stop, retain a short timestamped window: model finish reason, final content/tool-call shape, turn count/limit, continuation_recovery events, last tool result, pending todo state and run-end reason. Avoid a full public transcript. A normal end_turn with text is different from max_turns, interruption, run_error or empty-output retry exhaustion.

For native EBADF, capture the CLI PID and a baseline / first-failure FD listing, including descriptor numbers and types. The reporter can compare `lsof -nP -p "$pid"` privately; numeric-FD counts alone omit descriptor identity and can be misleading. Record the actual errno/syscall near the first failure and whether unrelated non-shell tools continue. Do not raise limits as an assumed fix.

The optional [observer](observe-process.cjs) preserves the terminal and logs only changes in listener/resource counts plus child error codes. It opens one diagnostic FD and adds observation overhead. It uses the documented child_process diagnostic channel and errorMonitor, without adding stdout resize listeners or consuming errors. It may miss errors thrown before that channel exposes a child. It is smoke-tested on Windows Node 24.15.0, not validated on the reporter's Node/macOS combination. [Diagnostic channel](https://nodejs.org/api/diagnostics_channel.html#event-child_process).

The observer smoke caught and corrected an executable-name disclosure through error.syscall; the final version retains only the operation name. Tests confirm success/error observations, no new resize listener and unchanged unhandled-error failure. These are observer tests, not a macOS EBADF reproduction.

[Observations](observations.json), [source anchors](source-anchors.json), [provenance](provenance.json), [observer validation](observer-validation.json), [reproduction](README.md). A replacement comment is prepared to correct the existing post and answer the reporter. Nothing edited or posted.
