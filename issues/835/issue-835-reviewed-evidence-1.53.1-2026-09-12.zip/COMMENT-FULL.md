@LittleTOXA, I rechecked my earlier explanation and your two sanitized traces. **I need to correct two claims in my original comment:**

- The resize warning is **not an independently confirmed accumulation leak**. The extracted hooks attach per-instance listeners and include cleanup; my synthetic test returned to baseline after unmount. That demonstrates concurrent listener fan-out, but does not prove what mounts or leaks during an actual resumed TUI session. My claim that all historical components mount on resume was not verified. A global `stdout.listenerCount('resize') <= 1` requirement also incorrectly includes unrelated listeners. Node documents this as a warning threshold, not a hard limit. [Node documentation](https://nodejs.org/api/events.html#eventsdefaultmaxlisteners).
- **`EBADF` means a bad file descriptor; it does not establish descriptor exhaustion.** `EMFILE` is the too-many-open-files error. Neither my source inspection nor your traces identify the invalid descriptor or prove a causal connection to the resize warning. [libuv error definitions](https://docs.libuv.org/en/v1.x/errors.html).

There is a separate source path that can explain the *shape* of the stopping symptom. In **1.53.1**, after committing a turn, the engine can finish normally when the model supplies text without a tool call, there is no queued follow-up, and no `onStop` hook requests continuation. A pending checklist is not an unconditional continuation guarantee.

I checked that with the actual headless CLI and a scripted localhost model:

| Control | Observed result |
|---|---|
| Successfully accepted `todo_write` with one pending item, followed by “Moving to the next check” and no tool call | Normal `end_turn`, three model requests, no continuation-recovery event |
| Two empty responses with nonzero synthetic output-token usage, followed by text | `continuation_recovery(kind: empty)` attempts 1 and 2, then successful completion on the third request |

Both controls repeated in a second run. These are **Windows/headless controls**, not a reproduction of your macOS TUI session or real-model stopping rate. Across both cohorts there were eight CLI processes / sixteen localhost requests, including resume captures. The four initial processes emitted results then hit a separate Windows shutdown assertion; the resume processes exited normally. No timeout or paid inference.

For the next premature stop, the most useful small capture is the final model finish reason, whether text/tool calls were present, `turn_end`/`run_end`, any continuation-recovery event, the last tool outcome, and the pending todo state. This separates normal text completion from empty-output recovery, turn limits, interruption and runtime failure. It does not imply that forcing continuation whenever a todo remains is the correct fix.

**Yes, FD observations would help with the persistent shell failure.** Capture the same CLI PID before failure and at the first `EBADF`, including descriptor numbers/types and the spawn errno/syscall. `lsof -nP -p "$pid"` provides a snapshot; review paths and network targets privately before sharing. A rising count would support investigating resource growth, but a stable count would not rule out an invalid-descriptor bug. For the listener question, compare counts at equivalent mounted states and after cleanup, rather than raising the warning limit.

Keep the terminal attached during capture: piping through `tee` changes the TTY conditions. I prepared an optional observer that samples listener/resource counts and records child-process error codes without logging commands, prompts or environment values. It adds one diagnostic FD and some overhead, and its tests are Windows-only; it is not yet validated on your Node/macOS combination.

Your OpenCode comparison is useful evidence. Matching provider/model names does not also match system prompts, tool schemas, context or continuation policy, so it narrows the investigation without establishing a specific Command Code lifecycle cause.
