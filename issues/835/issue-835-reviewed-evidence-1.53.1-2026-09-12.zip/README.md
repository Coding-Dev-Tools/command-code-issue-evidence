# Reproduce the #835 stop controls and optional observer

Copy this entire files directory into a fresh scratch directory before running. Never overwrite retained evidence. Use Node 24.15.0 on Windows x64 for the recorded platform. All application inputs and keys are synthetic; the network guard allows only the fixture's ephemeral localhost port. This is not OS-level network isolation. A different OS/runtime is a separate test variable.

Create a `runtime` directory; copy `runtime-package.json` to `runtime/package.json` and `runtime-package-lock.json` to `runtime/package-lock.json`, then run `npm ci --ignore-scripts --no-audit --no-fund` in that directory. The application package path is `runtime/node_modules/command-code`. No private development package is needed. The lockfile pins resolved dependencies; `provenance.json` pins the bundle hash.

`node verify-results.mjs` verifies the included saved evidence without network or product execution. Fresh probes write full captures only inside their new scratch directories; the saved observations are not silently overwritten. Review and minimize fresh output before sharing: raw requests include the shipped system prompt and local fixture paths.

```text
node persistence-probe.mjs runtime/node_modules/command-code fresh-stop todo-stop-json
node persistence-probe.mjs runtime/node_modules/command-code fresh-stop empty-recovery-json
node test-observer.mjs
```

The headless controls do not reproduce macOS TUI behavior. They distinguish a normal text stop from empty-response recovery. They are not an instruction to force endless continuation while todos remain.

Optional native macOS observation, run by the reporter in their existing terminal with a private output file (replace the two paths and session ID):

```sh
CMD_DIAG_LOG=/tmp/cc835-observation.jsonl \
NODE_OPTIONS="${NODE_OPTIONS:+$NODE_OPTIONS }--trace-warnings --require=/absolute/path/observe-process.cjs" \
commandcode --debug --resume SESSION_ID
```

Keep the original terminal attached; piping through tee changes the TTY. The first observer line records the PID. In a second terminal, use `lsof -nP -p "$pid"` for a baseline and first-failure snapshot. Keep listings private until paths/network targets are reviewed. The observer's extra file descriptor and timing overhead are explicit; compare an uninstrumented run if behavior changes. It does not collect prompts, command arguments, environment variables or FD target names.


The [second-cohort review](REVIEW.md) contains the double-check results, qualifications and complete post. Run `node verify-review.mjs` to validate its saved evidence.
