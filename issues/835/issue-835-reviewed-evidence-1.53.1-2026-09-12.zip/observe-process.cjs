'use strict';
// Opt-in diagnostic preload. Preserves the TTY; does not collect prompts, args, env or fd targets.
const fs=require('node:fs');
const {errorMonitor}=require('node:events');
const dc=require('node:diagnostics_channel');
const output=process.env.CMD_DIAG_LOG;
if(!output)throw new Error('Set CMD_DIAG_LOG to a private diagnostic file before using this preload.');
const fd=fs.openSync(output,'a',0o600);
let last='',childSequence=0;const live=new Set();
function record(event,fields={}){try{fs.writeSync(fd,JSON.stringify({at:new Date().toISOString(),uptimeMs:Math.round(process.uptime()*1000),pid:process.pid,event,...fields})+'\n');}catch{}}
function sample(force=false){
 const resources={};for(const name of process.getActiveResourcesInfo?.()??[])resources[name]=(resources[name]??0)+1;
 const fields={resizeListeners:process.stdout.listenerCount('resize'),resizeLimit:process.stdout.getMaxListeners(),stdoutIsTTY:process.stdout.isTTY===true,liveObservedChildren:live.size,resources};
 const signature=JSON.stringify(fields);if(force||signature!==last){last=signature;record('sample',fields);}
}
process.on('warning',warning=>{if(warning.name==='MaxListenersExceededWarning')record('listener-warning',{name:warning.name,type:warning.type,count:warning.count,emitterIsStdout:warning.emitter===process.stdout});});
dc.subscribe('child_process',({process:child})=>{
 const id=++childSequence;live.add(id);record('child-created',{id,childPid:child.pid??null});
 // errorMonitor observes an error without changing unhandled-error semantics.
 child.once(errorMonitor,error=>record('child-error',{id,childPid:child.pid??null,code:error.code??null,errno:error.errno??null,syscall:typeof error.syscall==='string'?error.syscall.split(/\s+/,1)[0]:null}));
 child.once('close',(code,signal)=>{live.delete(id);record('child-close',{id,code,signal});});
});
record('start',{node:process.version,platform:process.platform,arch:process.arch,diagnosticOwnFd:true});
sample(true);
const timer=setInterval(()=>sample(),1000);timer.unref();
process.once('exit',code=>{sample(true);record('exit',{code});try{fs.closeSync(fd);}catch{}});
