import {fs,path,assert,packageRuntime,save,isolatedEnv,configure,expectedHash,sleep,createHash} from './common.mjs';
import {spawn} from 'node:child_process';
import http from 'node:http';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const pkg=packageRuntime(process.argv[2]??path.join(here,'node_modules'));
const base=path.resolve(process.argv[3]??path.join(here,'runs'));fs.mkdirSync(base,{recursive:true});
const out=fs.mkdtempSync(path.join(base,'reasoning887-'));
const selected=(process.argv[4]??'original-thinking,original-text,original-empty,diagnostic-thinking').split(',');
const sha=x=>createHash('sha256').update(x).digest('hex');
const marker='REASON887_exact_roundtrip_marker';
const errorText='FIXTURE887: The reasoning_content in the thinking mode must be passed back to the API.';
const projectGuard='(r.signature||r.redactedData)&&n.push({type:"reasoning",text:r.redactedData?"":r.thinking,providerOptions:reasoningProviderOptions(r)})';
const diagnosticGuard='(r.signature||r.redactedData||r.thinking)&&n.push({type:"reasoning",text:r.redactedData?"":r.thinking,providerOptions:reasoningProviderOptions(r)})';
let active=null;const runs=[];
const server=http.createServer((req,res)=>{let raw='';req.on('data',b=>raw+=b);req.on('end',async()=>{try{
 assert.equal(req.url,'/v1/chat/completions');const body=JSON.parse(raw);
 const assistant=body.messages.filter(m=>m.role==='assistant');
 const historical=assistant.find(m=>m.content==='FIRST887'||m.tool_calls?.some(t=>t.id==='call887'));
 const record={phase:active.phase,ordinal:active.requests.length+1,toolsCount:body.tools?.length??0,messages:body.messages.map(m=>m.role==='system'?{role:'system',sha256:sha(JSON.stringify(m.content)),characters:JSON.stringify(m.content).length}:m),toolsSha256:sha(JSON.stringify(body.tools??[])),stream:body.stream};
 active.requests.push(record);assert.ok(active.requests.length<=12,'bounded request count');
 const requiresMarker=active.reasoning&&historical;
 if(requiresMarker&&historical.reasoning_content!==marker){record.response={status:400,message:errorText};res.writeHead(400,{'content-type':'application/json'});res.end(JSON.stringify({error:{message:errorText,type:'invalid_request_error',code:'invalid_request_error'}}));}
 else{
  const initial=active.phase==='first'&&!historical;
  const responseText=initial&&!active.tool?'FIRST887':`DONE887_${active.phase}`;
  const delta=[{role:'assistant'}];
  if(initial&&active.reasoning)delta.push({reasoning_content:marker});
  if(initial&&active.empty)delta.push({reasoning_content:''});
  if(initial&&active.tool){
   assert.ok(body.tools.some(t=>t.function?.name==='read_file'),'read_file declared');
   delta.push({tool_calls:[{index:0,id:'call887',type:'function',function:{name:'read_file',arguments:JSON.stringify({file_path:path.join(active.project,'sentinel.txt')})}}]});
  }else delta.push({content:responseText});
  record.response={status:200,reasoning:initial&&active.reasoning?marker:undefined,text:initial&&active.tool?undefined:responseText,tool:initial&&active.tool?'read_file':undefined};
  res.writeHead(200,{'content-type':'text/event-stream'});
  for(const d of delta){res.write('data: '+JSON.stringify({id:'fixture887',object:'chat.completion.chunk',created:1,model:'model',choices:[{index:0,delta:d,finish_reason:null}]})+'\n\n');await sleep(70);}
  res.write('data: '+JSON.stringify({id:'fixture887',object:'chat.completion.chunk',created:1,model:'model',choices:[{index:0,delta:{},finish_reason:initial&&active.tool?'tool_calls':'stop'}],usage:{prompt_tokens:100,completion_tokens:20,total_tokens:120}})+'\n\n');res.end('data: [DONE]\n\n');
 }
 save(path.join(active.run,'progress.json'),active);
 }catch(e){active.errors.push(e.message);if(!res.headersSent)res.writeHead(500);res.end('fixture error');}})});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
let failure=null;
async function printTurn(actualPkg,env,project,prompt,sessionId){
 const policy=['--permission','--allow-child-process',`--allow-fs-read=${pkg.runtime}`,`--allow-fs-read=${here}`,`--allow-fs-read=${out}`,`--allow-fs-write=${out}`,'--require',path.join(here,'offline-guard.cjs')];
 const args=[actualPkg.cli,'--no-auto-update','--local-only','--skip-onboarding','--trust','--no-skills','--model','fixture/model','-p',prompt,'--output-format','json','--max-turns','3',...(sessionId?['--resume',sessionId]:[])];
 const p=spawn(process.execPath,args,{cwd:project,env:{...env,NODE_OPTIONS:policy.map(x=>JSON.stringify(x.replaceAll('\\','/'))).join(' ')},windowsHide:true});
 let stdout='',stderr='',timedOut=false;p.stdout.on('data',x=>stdout+=x);p.stderr.on('data',x=>stderr+=x);const timer=setTimeout(()=>{timedOut=true;p.kill();},45000);
 const exit=await new Promise(resolve=>p.on('close',(code,signal)=>resolve({code,signal})));clearTimeout(timer);
 return {phase:active.phase,pid:p.pid,args,stdout,stderr,exit,timedOut};
}
function storedFiles(home){const root=path.join(home,'.commandcode/projects');const result=[];function visit(p){for(const d of fs.readdirSync(p,{withFileTypes:true})){const f=path.join(p,d.name);if(d.isDirectory())visit(f);else if(f.endsWith('.jsonl')&&!f.endsWith('.checkpoints.jsonl'))result.push(f);}}visit(root);return result;}
function captureStored(home){return storedFiles(home).map(f=>({name:path.basename(f),records:fs.readFileSync(f,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse)}));}
try{for(const name of selected){
 const run=path.join(out,name),home=path.join(run,'home'),project=path.join(run,'project');fs.mkdirSync(project,{recursive:true});fs.writeFileSync(path.join(project,'sentinel.txt'),'SAFE_READ887');
 const env=isolatedEnv(home,port);await configure(home,project,pkg,port);
 save(path.join(home,'.commandcode/settings.json'),{disableScratchpad:true,mods:{disabled:['titling','learning']},permissions:{allow:['Read(sentinel.txt)']}});
 let actualPkg=pkg;const diagnostic=name.startsWith('diagnostic');
 if(diagnostic){
  const dist=path.join(run,'diagnostic-dist');fs.cpSync(path.dirname(pkg.bundle),dist,{recursive:true});
  fs.copyFileSync(path.join(pkg.runtime,'command-code/package.json'),path.join(run,'package.json'));
  assert.equal(pkg.source.split(projectGuard).length,2,'one guard replacement');
  fs.writeFileSync(path.join(dist,'cli.mjs'),pkg.source.replace(projectGuard,diagnosticGuard));
  // Symlink only dependency lookup; source remains a separately hashed diagnostic copy.
  fs.symlinkSync(pkg.runtime,path.join(run,'node_modules'),'junction');
  actualPkg={...pkg,cli:path.join(dist,'index.mjs'),bundle:path.join(dist,'cli.mjs')};
 }
 active={name,run,project,phase:'first',reasoning:!name.endsWith('text')&&!name.endsWith('empty'),empty:name.endsWith('empty'),tool:name.endsWith('tool'),diagnostic,bundleSha256:sha(fs.readFileSync(actualPkg.bundle)),requests:[],errors:[],processes:[],stored:[]};
 const expectFailure=active.reasoning&&!diagnostic;
 const p=await printTurn(actualPkg,env,project,'FIRST_USER887');active.processes.push(p);assert.equal(p.timedOut,false);assert.equal(active.errors.length,0);
 assert.ok(active.requests.length>0,'initial request');assert.equal(active.requests.at(-1).response.status,active.tool&&expectFailure?400:200);
 active.stored.push({phase:'after-first',files:captureStored(home)});
 const sessions=active.stored.at(-1).files;assert.equal(sessions.length,1,'single session');const sessionId=sessions[0].records[0].id;
 for(const phase of ['resume','continue']){
  active.phase=phase;const before=active.requests.length;const result=await printTurn(actualPkg,env,project,phase==='continue'?'continue':'SECOND_USER887',sessionId);active.processes.push(result);
  assert.equal(result.timedOut,false);assert.ok(active.requests.length>before,'fresh-process request');assert.equal(active.requests.at(-1).response.status,expectFailure?400:200);
  active.stored.push({phase:'after-'+phase,files:captureStored(home)});
 }
 runs.push(active);save(path.join(run,'results.json'),active);console.log(JSON.stringify({name,requests:active.requests.map(r=>({phase:r.phase,status:r.response.status,reasoning:r.messages.filter(m=>m.role==='assistant').map(m=>m.reasoning_content??null)})),exits:active.processes.map(p=>p.exit)}));
}}
catch(e){failure={message:e.message,stack:e.stack};if(active&&!runs.includes(active))runs.push(active);}
finally{server.closeAllConnections();await new Promise(r=>server.close(r));}
save(path.join(out,'results.json'),{version:'1.58.0',expectedHash,node:process.version,platform:process.platform,createdAt:new Date().toISOString(),marker,runs,failure});console.log(JSON.stringify({out,failure}));setTimeout(()=>process.exit(failure?1:0),75);
