import fs from 'node:fs';import assert from 'node:assert/strict';
const result=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
if(process.argv.includes('--negative'))result.runs.find(r=>r.name==='original-thinking').requests[1].messages.find(m=>m.role==='assistant').reasoning_content=result.marker;
assert.equal(result.failure,null);assert.equal(result.version,'1.58.0');
assert.equal(result.expectedHash,'aab2bec800371953112d18472bb7383992ef264cca22558bdcda77e7d0dc0f14');
const names=['original-thinking','original-text','original-empty','diagnostic-thinking'];
assert.deepEqual(result.runs.map(r=>r.name),names);
for(const r of result.runs){
 assert.equal(r.errors.length,0);assert.equal(r.requests.length,3);assert.equal(r.processes.length,3);
 assert.equal(new Set(r.processes.map(p=>p.pid)).size,3,'separate processes');
 assert.deepEqual(r.requests.map(q=>q.phase),['first','resume','continue']);assert.ok(r.requests.every(q=>q.toolsCount>0),'tools advertised');
 assert.ok(r.requests.every(q=>q.messages.every(m=>!m.tool_calls)),'no tool actually called');
 const bad=r.name==='original-thinking',reason=r.reasoning;
 assert.deepEqual(r.requests.map(q=>q.response.status),bad?[200,400,400]:[200,200,200]);
 assert.deepEqual(r.processes.map(p=>p.exit.code),bad?[0,1,1]:[0,0,0]);assert.ok(r.processes.every(p=>!p.timedOut));
 const saved=r.stored[0].files.flatMap(f=>f.records).filter(e=>e.type==='message'&&e.message.role==='assistant').flatMap(e=>e.message.content);
 if(reason){assert.ok(saved.some(p=>p.type==='thinking'&&p.thinking===result.marker&&p.signature===''),'original reasoning stored intact');}
 for(const q of r.requests.slice(1)){const first=q.messages.find(m=>m.role==='assistant');assert.equal(first.content,'FIRST887');assert.equal(first.reasoning_content,r.diagnostic?result.marker:undefined);}
}
console.log(JSON.stringify({passed:true,scenarios:names,requests:12,freshProcesses:12,scope:'Headless CLI with localhost synthetic provider. No interactive TUI or live-provider claim.'}));
