# Issue 887: BYOK reasoning history boundary

Tested with Command Code 1.58.0, Node 24.15.0, Windows 11 and the locked dependencies. The package downloads the public CLI from npm; no product binaries, credentials or system-prompt text are bundled. The CLI uses a fresh synthetic home and a guarded localhost provider. No paid inference occurs.

From this extracted files directory in PowerShell:

```powershell
npm ci --ignore-scripts --no-audit --no-fund
node .\repro.mjs .\node_modules .\runs
$result = Get-ChildItem .\runs -Directory | Sort-Object LastWriteTime -Descending | Select-Object -First 1
node .\verify.mjs (Join-Path $result.FullName 'results.json')
node .\verify.mjs (Join-Path $result.FullName 'results.json') --negative
node .\sdk-control.mjs .\node_modules .\sdk-control-results.json
```

The normal verifier exits 0. The negative verifier deliberately adds the missing reasoning field to the observed original result and must exit 1. Its nonzero exit is expected. The SDK control then checks that reasoning text serializes as reasoning_content with and without tools, without providerOptions.

The four primary cases use three fresh headless CLI processes each: initial response, resume, and another resumed prompt saying continue. All advertise tools, but none calls one. Original unsigned reasoning is saved intact but omitted in replay; a strict scripted 400 rejects the missing marker. Text-only and empty-reasoning controls return 200. A separately copied diagnostic build changes only the assistantParts signature gate and replays the marker successfully. Original and diagnostic bundle hashes are retained in results. This is isolation evidence, not a production patch; preserving provider-specific signed/encrypted reasoning rules still requires cross-provider review.

The mock intentionally rejects missing history; it does not demonstrate how DeepSeek or the reporter's relay enforces its contract. No interactive-mode retry claim is made. Tool-call experiments and failed TUI pilots are separately accounted for in FAILURE-ACCOUNTING.json, outside the primary matrix.

Fresh raw results remain local and contain temporary paths. The included reference-results.json replaces those paths, stdout and stderr with hashes. No personal configuration is loaded. The process has Node filesystem restrictions and an outbound guard allowing only the fixture endpoint; those are test substitutions. Each child has a 45-second timeout and output lives under a unique new directory.
