import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
export {fs,fsp,path,assert,createHash};
export const expectedHash='0de512d28b0a66708fbb0e367443ad7f9f9d4e8eda62a76563f1493b997dd61d';
export function packageRuntime(dir){
 const runtime=path.resolve(dir),req=createRequire(path.join(runtime,'../package.json'));
 const bundle=path.join(runtime,'command-code/dist/cli.mjs'),bytes=fs.readFileSync(bundle);
 assert.equal(createHash('sha256').update(bytes).digest('hex'),expectedHash);
 return {runtime,req,bundle,source:bytes.toString(),cli:path.join(runtime,'command-code/dist/index.mjs')};
}
export const sleep=ms=>new Promise(r=>setTimeout(r,ms));
export function save(file,value){fs.writeFileSync(file,JSON.stringify(value,null,2)+'\n');}
export function isolatedEnv(home,port){
 for(const p of ['tmp','AppData/Roaming','AppData/Local','.commandcode'])fs.mkdirSync(path.join(home,p),{recursive:true});
 const env={};for(const k of ['SystemRoot','WINDIR','ComSpec','PATHEXT','PROCESSOR_ARCHITECTURE'])if(process.env[k])env[k]=process.env[k];
 env.PATH=[path.dirname(process.execPath),...(process.env.SystemRoot?[path.join(process.env.SystemRoot,'System32')]:['/usr/bin','/bin'])].join(path.delimiter);
 return Object.assign(env,{HOME:home,USERPROFILE:home,APPDATA:path.join(home,'AppData/Roaming'),LOCALAPPDATA:path.join(home,'AppData/Local'),TEMP:path.join(home,'tmp'),TMP:path.join(home,'tmp'),CMD_LOCAL_ONLY:'1',DO_NOT_TRACK:'1',OTEL_SDK_DISABLED:'true',COMMANDCODE_SKIP_UPDATES:'1',COMMANDCODE_DISABLE_CRON:'1',COMMANDCODE_DISABLE_DURABLE_CRON:'1',DOTENV_CONFIG_PATH:path.join(home,'absent.env'),TERM:'xterm-256color',FIXTURE_PORT:String(port),FIXTURE_PROVIDER_KEY:'synthetic-unused',COMMAND_CODE_API_KEY:'synthetic-unused'});
}
export async function configure(home,project,pkg,port){
 const {default:slugify}=await import(pathToFileURL(pkg.req.resolve('@sindresorhus/slugify')).href);
 fs.mkdirSync(path.join(home,'.commandcode/projects',slugify(project)),{recursive:true});
 save(path.join(home,'.commandcode/config.json'),{model:'fixture/model',provider:'fixture',localOnly:true,telemetry:false,tasteLearning:false});
 save(path.join(home,'.commandcode/providers.json'),{provider:{fixture:{api:'openai-completions',baseURL:`http://127.0.0.1:${port}/v1`,apiKey:'$FIXTURE_PROVIDER_KEY',models:{model:{contextWindow:200000,maxOutput:1000,cost:{input:0,output:0}}}}}});
}
