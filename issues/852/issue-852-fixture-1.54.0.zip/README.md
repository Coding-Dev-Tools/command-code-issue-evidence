# Issue 852 fixture

Actual unchanged Command Code 1.54.0 in Windows ConPTY, Node 24.15.0. Eleven independent CLI sessions compare a real read_file result through the main agent and a foreground general child, with independent settings/Mod/permission controls. Model messages are scripted by an own-localhost server. No paid inference or sensitive data is used.

Extract to a fresh writable directory and run:

```sh
npm ci --ignore-scripts --no-audit --no-fund
node repro.mjs
node verify.mjs
```

The runtime/terminal dependencies are pinned in package-lock.json and the bundle hash is asserted. The native terminal runner requires Windows. It clears inherited credentials, isolates each home/project, disables learning/titling and restricts Node network traffic to the fixture port. Its guards are test isolation, not a general-purpose security sandbox. Hook subprocesses execute only the generated local Node script.

Each run retains its precise settings.json, hook.cjs or guard852.ts and result.json in a fresh runs/hooks852-* directory. Optional arguments are `NODE_MODULES OUTPUT_DIRECTORY CASE_NAME`, for example `node repro.mjs node_modules runs child-settings`. The unguarded positive controls and main-hook deny controls should be run before interpreting a child-only observation.

The provider emits read_file or the outer agent call; it never fabricates the unique sentinel in an assistant answer. Captured subsequent tool results establish successful reads or the exact deny reason. Main Mod factories and pre/post hook activity are checked. Each of the 11 selected native runs exited zero. The two earlier headless attempts hit a Windows/libuv assertion after completed results; their details are in failure-accounting.json. They are excluded from clean-run evidence. The one-second synthetic final-response delay was retained from that exploration and is not a product fix.

Scope excludes background children, plan mode, ask rules, custom tools, real-model behavior and the reporter's Linux setup. Permission evidence covers the exact Read(sentinel852.txt) deny rule only. The related plan-mode issue is not declared a duplicate.

`verify.mjs` independently checks the retained selected result content, input identity, factory markers, hook events, clean exits and six deliberately wrong results. It does not run the CLI or automatically select a new run. New runs have their own assertions and result files. Expected bypass assertions must change when checking an agreed fix; a pass does not establish implementation or adoption.

Public packet: synthetic fixtures, minimized observations and scripts only. Original output, local paths and historical failed attempts remain private. The companion ZIP contains this runnable fixture and the retained observations.

Delivery replay note: the generated settings-hook command uses the isolated Node PATH and project-relative filesystem grants for its own parent run directory. This avoids a Node 24.15.0 inherited-permission path-with-spaces failure that prevented the logging subprocess from writing. It does not modify Command Code or grant access to a real project. Working main-hook controls are mandatory before interpreting child-hook absence.
