import {fs,path,assert,packageRuntime,save,isolatedEnv,configure,expectedHash,sleep} from './common.mjs';
import {fileURLToPath} from 'node:url';import http from 'node:http';import {spawn} from 'node:child_process';import {randomUUID} from 'node:crypto';
const here=path.dirname(fileURLToPath(import.meta.url)),pkg=packageRuntime(process.argv[2]??path.join(here,'node_modules'));
const base=path.resolve(process.argv[3]??path.join(here,'runs'));fs.mkdirSync(base,{recursive:true});const out=fs.mkdtempSync(path.join(base,'hooks852-')),runs=[];
const matrix=[['main-none','main','none'],['child-none','child','none'],['main-settings','main','settings'],['child-settings','child','settings'],['main-mod','main','mod'],['child-mod','child','mod'],['main-deny','main','deny'],['child-deny','child','deny'],['main-settings-allow','main','settings-allow'],['child-settings-allow','child','settings-allow'],['main-mod-unmatched','main','mod','healthy852.txt']];
let active=null;const server=http.createServer((req,res)=>{let raw='';req.on('data',b=>raw+=b);req.on('end',async()=>{
 try{
  assert.equal(req.url,'/v1/chat/completions');const body=JSON.parse(raw),messages=body.messages??[];
  const user=messages.filter(m=>m.role==='user').at(-1),context=JSON.stringify(user).includes('CHILD_852_TASK')?'child':'main';
  const tools=messages.filter(m=>m.role==='tool').map(m=>({tool_call_id:m.tool_call_id,content:m.content}));
  const count=active.count[context]??0;active.count[context]=count+1;
  const record={context,ordinal:count+1,model:body.model,availableTools:(body.tools??[]).map(x=>x.function?.name),toolResults:tools};active.requests.push(record);
  let delta,finish;
  if(count===0){
   const name=active.kind==='child'&&context==='main'?'agent':'read_file';
   const input=name==='agent'?{description:'Read fixture sentinel',subagent_type:'general',prompt:'CHILD_852_TASK: read the harmless fixture at '+active.target+'. Return a short completion message.'}:{file_path:active.target};
   record.scriptedTool={name,input};delta={role:'assistant',tool_calls:[{index:0,id:`call_${context}_852`,type:'function',function:{name,arguments:JSON.stringify(input)}}]};finish='tool_calls';
  }else{delta={role:'assistant',content:`${context.toUpperCase()}_852_DONE`};finish='stop';}
  // Model timing is a fixture parameter. Retain the initial zero-delay Windows shutdown assertion as an excluded pilot.
  if(finish==='stop')await new Promise(r=>setTimeout(r,1000));
  res.writeHead(200,{'content-type':'text/event-stream'});
  for(const[d,f]of [[delta,null],[{},finish]])res.write('data: '+JSON.stringify({id:'fixture852',object:'chat.completion.chunk',created:1,model:'model',choices:[{index:0,delta:d,finish_reason:f}],usage:{prompt_tokens:10,completion_tokens:5,total_tokens:15}})+'\n\n');res.end('data: [DONE]\n\n');
 }catch(e){if(active)active.serverErrors.push(e.message);res.writeHead(500);res.end('fixture error');}
});});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;let failure=null;
try{for(const[name,kind,guard,filename='sentinel852.txt']of matrix.filter(x=>!process.argv[4]||x[0]===process.argv[4])){
 const run=path.join(out,name),home=path.join(run,'home'),project=path.join(run,'project'),env=isolatedEnv(home,port);fs.mkdirSync(project,{recursive:true});await configure(home,project,pkg,port);
 const sentinel='CONTENT_852_'+randomUUID(),target=path.join(project,filename);fs.writeFileSync(target,sentinel+'\n');
 Object.assign(env,{GUARD_LOG:path.join(run,'guard.jsonl'),FACTORY_LOG:path.join(run,'factory.txt')});
 const hook=path.join(run,'hook.cjs');fs.writeFileSync(hook,`const fs=require('node:fs');let raw='';process.stdin.on('data',b=>raw+=b);process.stdin.on('end',()=>{const p=JSON.parse(raw);fs.appendFileSync(process.env.GUARD_LOG,JSON.stringify({event:p.hook_event_name,tool:p.tool_name,input:p.tool_input})+'\\n');if(p.hook_event_name==='PreToolUse'&&${guard==='settings'}&&JSON.stringify(p.tool_input).includes('sentinel852.txt'))console.log(JSON.stringify({hookSpecificOutput:{permissionDecision:'deny',permissionDecisionReason:'SETTINGS_852_BLOCK'}}));else console.log('{}');});`);
 const settings={permissions:{defaultMode:'default'},disableScratchpad:true,mods:{disabled:['titling','learning']}};
 if(guard.startsWith('settings'))settings.hooks=Object.fromEntries(['PreToolUse','PostToolUse'].map(event=>[event,[{matcher:'read',hooks:[{type:'command',command:'node --allow-fs-read=.. --allow-fs-write=.. ../hook.cjs',timeout:10}]}]]));
 if(guard==='deny')settings.permissions.deny=['Read(sentinel852.txt)'];
 if(guard==='mod'){
  const mods=path.join(home,'.commandcode/mods');fs.mkdirSync(mods,{recursive:true});
  fs.writeFileSync(path.join(mods,'guard852.ts'),`import {appendFileSync} from 'node:fs';export default function(cmd){appendFileSync(process.env.FACTORY_LOG,'loaded\\n');cmd.hooks({beforeToolCall:({toolName,input})=>{appendFileSync(process.env.GUARD_LOG,JSON.stringify({event:'beforeToolCall',tool:toolName,input})+'\\n');if(toolName==='read_file'&&JSON.stringify(input).includes('sentinel852.txt'))return {block:true,additionalContext:'MOD_852_BLOCK'};}});}`);
 }
 save(path.join(home,'.commandcode/settings.json'),settings);
 active={name,kind,guard,target,count:{},requests:[],serverErrors:[]};let stdout='',stderr='',timedOut=false;
 const args=['--permission','--allow-child-process',`--allow-fs-read=${pkg.runtime}`,`--allow-fs-read=${here}`,`--allow-fs-read=${out}`,`--allow-fs-write=${out}`,'--require',path.join(here,'offline-guard.cjs'),pkg.cli,'--no-auto-update','--local-only','--skip-onboarding','--trust','--no-skills','--model','fixture/model','--permission-mode','default','--max-turns','4','MAIN_852_TASK: execute the scripted harmless fixture action.'];
 const pty=pkg.req('@lydell/node-pty'),{Terminal}=pkg.req('@xterm/headless'),term=new Terminal({cols:140,rows:45,allowProposedApi:true,scrollback:2000});
 const child=pty.spawn(process.execPath,args,{cwd:project,env,cols:140,rows:45,useConpty:true,windowsHide:true});let exit=null;
 term.onData(d=>child.write(d));child.onData(d=>{stdout+=d;term.write(d)});child.onExit(e=>exit={code:e.exitCode,signal:e.signal});
 const screen=()=>{const b=term.buffer.active;return Array.from({length:b.length},(_,i)=>b.getLine(i)?.translateToString(true)??'').join('\n')};
 let deadline=Date.now()+45000;while(Date.now()<deadline&&!screen().includes('MAIN_852_DONE')&&!exit)await sleep(100);
 if(!screen().includes('MAIN_852_DONE')){timedOut=true;child.kill();}else{await sleep(450);for(const c of '/exit'){child.write(c);await sleep(20);}child.write('\r');}
 deadline=Date.now()+8000;while(Date.now()<deadline&&!exit)await sleep(50);if(!exit){timedOut=true;child.kill();await sleep(500);}const finalScreen=screen();term.dispose();
 const events=fs.existsSync(env.GUARD_LOG)?fs.readFileSync(env.GUARD_LOG,'utf8').trim().split('\n').filter(Boolean).map(x=>JSON.parse(x)):[],factoryLoaded=fs.existsSync(env.FACTORY_LOG);
 const readResults=active.requests.filter(x=>x.context===kind).flatMap(x=>x.toolResults).filter(x=>x.tool_call_id===`call_${kind}_852`);
 const contentReturned=readResults.some(x=>JSON.stringify(x.content).includes(sentinel));
 const expectedContent=guard!=='deny'&&(kind==='child'||!['settings','mod'].includes(guard)||filename!=='sentinel852.txt');
 const row={...active,version:'1.54.0',exit,timedOut,stdout,stderr,finalScreen,events,factoryLoaded,readResults,contentReturned,expectedContent,sentinel};runs.push(row);save(path.join(run,'result.json'),row);
 console.log(JSON.stringify({name,exit,timedOut,contentReturned,expectedContent,events:events.map(e=>e.event+':'+e.tool),factoryLoaded,requests:active.requests.length}));
 assert.equal(exit.code,0,name+' exit');assert.equal(timedOut,false);assert.equal(active.serverErrors.length,0);assert.ok(readResults.length,name+' actual read result');assert.equal(contentReturned,expectedContent,name+' sentinel');
 if(guard==='mod')assert.equal(factoryLoaded,true);if(kind==='main'&&guard.startsWith('settings'))assert.ok(events.some(x=>x.event==='PreToolUse'),'main settings hook must actually run');
}}
catch(e){failure={message:e.message,stack:e.stack};}
finally{server.closeAllConnections();await new Promise(r=>server.close(r));}
save(path.join(out,'results.json'),{version:'1.54.0',bundleSha256:expectedHash,node:process.version,platform:process.platform,scope:'Unmodified actual CLI in Windows ConPTY with isolated homes/projects and scripted localhost model responses. Same actual read_file tool in main/foreground general child. No real model or reporter Linux environment. Background, plan mode, ask rules and custom tools are outside this matrix.',runs,failure});console.log(JSON.stringify({out,failure}));setTimeout(()=>process.exit(failure?1:0),50);
