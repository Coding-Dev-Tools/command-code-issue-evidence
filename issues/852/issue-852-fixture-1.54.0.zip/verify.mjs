import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
const dir=process.argv[2]?path.resolve(process.argv[2]):path.dirname(fileURLToPath(import.meta.url));
const data=JSON.parse(fs.readFileSync(path.join(dir,'terminal-results.json'),'utf8'));
function verify(x){
 assert.equal(x.failure,null);assert.equal(x.runs.length,11);assert.equal(x.bundleSha256,'0de512d28b0a66708fbb0e367443ad7f9f9d4e8eda62a76563f1493b997dd61d');
 for(const r of x.runs){
  assert.equal(r.exit.code,0);assert.equal(r.timedOut,false);assert.equal(r.serverErrors.length,0);assert.ok(r.readResults.length);
  const content=r.readResults.map(v=>v.content).join('\n'),returned=content.includes(r.sentinel);
  const denied=r.guard==='deny'||r.kind==='main'&&['settings','mod'].includes(r.guard)&&r.name!=='main-mod-unmatched';
  assert.equal(returned,!denied,r.name);assert.equal(r.contentReturned,returned);
  if(r.guard==='deny')assert.ok(content.includes('Blocked by permission deny rule Read(sentinel852.txt)'));
  if(r.name==='main-settings')assert.ok(content.includes('SETTINGS_852_BLOCK'));
  if(r.name==='main-mod')assert.ok(content.includes('MOD_852_BLOCK'));
  if(r.guard==='mod')assert.equal(r.factoryLoaded,true);
  if(r.name==='main-settings-allow')assert.deepEqual(r.events.map(e=>e.event),['PreToolUse','PostToolUse']);
  if(r.kind==='child'&&r.guard.startsWith('settings'))assert.equal(r.events.length,0);
  if(r.name==='child-mod')assert.deepEqual(r.events.map(e=>e.tool),['agent']);
  const request=r.requests.find(t=>t.context===r.kind&&t.scriptedTool?.name==='read_file');assert.equal(request.scriptedTool.input.file_path,r.target);
 }
}
verify(data);
const mutations=[x=>x.runs.find(r=>r.name==='child-settings').readResults=[],x=>x.runs.find(r=>r.name==='child-mod').factoryLoaded=false,x=>{const r=x.runs.find(r=>r.name==='child-deny');r.readResults[0].content=r.sentinel;},x=>x.runs.find(r=>r.name==='main-settings-allow').events.pop(),x=>x.runs[0].exit.code=1,x=>x.runs.find(r=>r.name==='main-settings').readResults[0].content='arbitrary empty failure'];
for(const mutate of mutations){const bad=structuredClone(data);mutate(bad);assert.throws(()=>verify(bad));}
const result={ok:true,negativeMutationsRejected:mutations.length,scope:'Checks actual read-result content, guard markers, deny reason, input identity and clean exits; no new product execution.'};fs.writeFileSync(path.join(dir,'verification.json'),JSON.stringify(result,null,2)+'\n');console.log(result);
