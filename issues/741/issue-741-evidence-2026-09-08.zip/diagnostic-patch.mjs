import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// This returns text only. The caller chooses an isolated diagnostic bundle path.
// Do not apply to an installed CLI or treat this fixed fixture namespace / 16 KiB
// limit as a production implementation decision.
export function createDiagnosticPatch(original, namespace) {
  assert.equal(crypto.createHash('sha256').update(original).digest('hex'),
    'd408a372d5d6c8a8851610e2a9840f806929595584d1cd8d909d501928c0037c');
  assert.match(namespace, /^[a-z][a-z0-9_-]{0,99}$/);
  assert.ok(!['constructor', 'prototype', '__proto__'].includes(namespace));
  const source = original.toString('utf8');
  const namespaced = JSON.stringify(namespace);
  const helper = `
// ISSUE741_DIAGNOSTIC_ONLY: exact known fixture adapter namespace, supported
// thoughtSignature field only. Bound selected UTF-8 value to 16384 bytes.
function issue741OwnValue(o,k){if(!o||typeof o!=="object"||Array.isArray(o))return;const p=Object.getPrototypeOf(o);if(p!==Object.prototype&&p!==null)return;const d=Object.getOwnPropertyDescriptor(o,k);return d&&"value"in d?d.value:void 0}
function issue741Signature(m){const n=issue741OwnValue(m,${namespaced}),s=issue741OwnValue(n,"thoughtSignature");return typeof s==="string"&&s.length>0&&new TextEncoder().encode(s).length<=16384?s:void 0}
function issue741Ingress(m){const s=issue741Signature(m);return s===void 0?{}:{providerMetadata:{[${namespaced}]:{thoughtSignature:s}}}}
function issue741Egress(m){const s=issue741Signature(m);return s===void 0?{}:{providerOptions:{google:{thoughtSignature:s}}}}
`;
  const replacements = [
    ['async function consumeFullStream(e){', helper + 'async function consumeFullStream(e){'],
    ['input:n.value,...!0===o.providerExecuted', 'input:n.value,...issue741Ingress(o.providerMetadata),...!0===o.providerExecuted'],
    ['input:r.input,...r.providerExecuted', 'input:r.input,...issue741Egress(r.providerMetadata),...r.providerExecuted'],
  ];
  let diagnostic = source;
  for (const [before, after] of replacements) {
    assert.equal(diagnostic.split(before).length, 2, `Patch anchor must appear once: ${before}`);
    diagnostic = diagnostic.replace(before, after);
  }
  return { diagnostic, helper, namespace, byteLimit: 16384,
    replacements: replacements.map(([before, after]) => ({ before, after })),
    originalSha256: crypto.createHash('sha256').update(original).digest('hex'),
    diagnosticSha256: crypto.createHash('sha256').update(diagnostic).digest('hex') };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const here = path.dirname(fileURLToPath(import.meta.url));
  assert.ok(process.argv[2] && process.argv[3],
    'Usage: node diagnostic-patch.mjs <path-to-pinned-cli.mjs> <known-fixture-provider-namespace>');
  const original = fs.readFileSync(path.resolve(process.argv[2]));
  const result = createDiagnosticPatch(original, process.argv[3]);
  // A reviewable patch record only; no product file writes.
  const { diagnostic, ...record } = result;
  fs.writeFileSync(path.join(here, 'diagnostic-patch-record.json'), JSON.stringify(record, null, 2) + '\n');
  console.log(JSON.stringify({ namespace: record.namespace, diagnosticSha256: record.diagnosticSha256,
    replacements: record.replacements.length, byteLimit: record.byteLimit }));
}
