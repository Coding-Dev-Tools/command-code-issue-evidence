# #741 evidence package

Read `REPORT.md` first. This package contains actual command-code 1.51.3 localhost observations, a separately derived diagnostic A/B, adapter controls and extracted-source controls. It includes no application bundle, credentials, private source or raw prompts.

## Verify retained observations

```text
node verify-results.mjs
```

Only Node standard libraries are used. This checks the recorded defect, call-ID associations, unsigned controls, session identity, eight qualified shutdown aborts and diagnostic JSON exposure. A successful verifier does not mean the product passed acceptance or a new reproduction ran. The repository's `npm run check` also validates the ZIP and complete expanded contents.

## Reproduce in a fresh scratch copy

Copy this directory into a new ignored `scratch/` directory before running anything. Do not run regenerating scripts inside the retained evidence tree. Recorded environment: Windows x64 10.0.26100 and Node v24.15.0. A different environment is a separate test variable.

Prepare the locked public runtime using these portable Node/npm commands from that copy:

```text
node -e "const f=require('node:fs');f.mkdirSync('runtime',{recursive:true});f.copyFileSync('runtime-package.json','runtime/package.json');f.copyFileSync('runtime-package-lock.json','runtime/package-lock.json')"
npm ci --prefix runtime --ignore-scripts --no-audit --no-fund
node source-contract.mjs runtime/node_modules/command-code/dist/cli.mjs
node diagnostic-bounds.mjs runtime/node_modules/command-code/dist/cli.mjs
node adapter-control.mjs runtime/node_modules
```

`npm ci` downloads pinned public packages. No private development packages or inference are needed. The CLI fixture checks the released bundle hash; the supplied lock and provenance pin the resolved dependencies. `source-contract.mjs` extracts functions from the actual pinned bundle and labels its in-memory diagnostic replacements separately.

Run each original scenario:

```text
node metadata-probe.mjs runtime/node_modules/command-code unsigned
node metadata-probe.mjs runtime/node_modules/command-code mixed
node metadata-probe.mjs runtime/node_modules/command-code reverse
node metadata-probe.mjs runtime/node_modules/command-code signed-resume
```

The last mode invokes `--continue` in a second process using the same synthetic session. It does not exercise the explicit `--resume` flag. Each scenario creates a unique `runs/MODE-TIMESTAMP/raw.json`; raw captures remain private scratch inputs and must be minimized before retention.

For the diagnostic A/B, build a separate copy. This leaves the original package unchanged and refuses to overwrite an existing diagnostic directory:

```text
node build-diagnostic.mjs runtime/node_modules/command-code
node metadata-probe.mjs runtime/node_modules/command-code-741-diagnostic unsigned 1ad4291de99a6f735e971492a182bf0fb75e05284bd16b5d05d1e911aafbb9a4
node metadata-probe.mjs runtime/node_modules/command-code-741-diagnostic mixed 1ad4291de99a6f735e971492a182bf0fb75e05284bd16b5d05d1e911aafbb9a4
node metadata-probe.mjs runtime/node_modules/command-code-741-diagnostic reverse 1ad4291de99a6f735e971492a182bf0fb75e05284bd16b5d05d1e911aafbb9a4
node metadata-probe.mjs runtime/node_modules/command-code-741-diagnostic signed-resume 1ad4291de99a6f735e971492a182bf0fb75e05284bd16b5d05d1e911aafbb9a4
node captured-cli-control.mjs runs runtime/node_modules
```

The final control requires regenerated raw runs; it is not a clean-clone saved-results check. It feeds their exact first response chunks into the pinned SDK using the actual tool schema. Its fetch is in-process and opens no sockets. The earlier adapter control includes namespace mapping and reversed-order tests independent of Command Code.

## Fixture limits

The CLI child has a fresh synthetic home, an allowlisted environment, fake keys, local-only settings, disabled updates/telemetry/cron/skills, Node filesystem permissions and no subprocess permission. The preload allows only the owned ephemeral loopback port; `data:` supports embedded Yoga WASM. This is a Node fixture guard, not OS-level network isolation. The guard's inherited optional SIGINT bridge is unused here; no cancellation is injected.

The mock proposes only two already-declared `read_file` calls against its own text file. Same name/input, distinct IDs; signatures are synthetic. Maximum five ordinary model requests per scenario, then a fixture-budget response; maximum 35 seconds per process. All observed requests reached their intended boundary without either limit. Session persistence stays inside the synthetic home. No `--trace` or `--no-session` is used.

The diagnostic's fixed `metadata-fixture` namespace and 16 KiB supported-string bound are experimental controls. It restores transport preservation but exposes signatures in JSON output; it is not suitable for installation as a production fix. Compaction, explicit resume, fork, nonstreaming CLI, real signatures and provider/model switching remain outside actual-CLI coverage.

`results.json` retains only controlled call projections, result frames and hashes. `file_path` becomes `<OWNED_FIXTURE_FILE>`; raw prompts, full state and home paths are omitted. Opaque values and call IDs are unchanged. Historical raw hashes cannot be recomputed from these minimized records. `MANIFEST.json` hashes every retained payload except itself; the ZIP has exactly this directory's files at its root.
