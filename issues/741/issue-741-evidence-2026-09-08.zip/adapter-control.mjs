import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, join, dirname } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';

// Dependencies are read from an explicitly supplied installation; no network is used.
if (!process.argv[2]) throw new Error('Usage: node adapter-control.mjs PATH_TO_PINNED_NODE_MODULES');
const dependencyRoot = resolve(process.argv[2]);
const outDir = dirname(fileURLToPath(import.meta.url));
const { createOpenAICompatible } = await import(pathToFileURL(join(dependencyRoot, '@ai-sdk/openai-compatible/dist/index.mjs')));
const { streamText, jsonSchema } = await import(pathToFileURL(join(dependencyRoot, 'ai/dist/index.mjs')));
const sha256 = x => createHash('sha256').update(x).digest('hex');
const provenance = Object.fromEntries(['ai', '@ai-sdk/openai-compatible', '@ai-sdk/provider', '@ai-sdk/provider-utils', 'zod'].map(name => {
  const bytes = readFileSync(join(dependencyRoot, name, 'package.json'));
  const pkg = JSON.parse(bytes);
  return [name, { version: pkg.version, packageJsonSha256: sha256(bytes), ...(name === 'ai' || name === '@ai-sdk/openai-compatible' ? { moduleSha256: sha256(readFileSync(join(dependencyRoot, name, 'dist/index.mjs'))) } : {}) }];
}));
const fixtures = [
  { index: 0, id: 'call_741_alpha', signature: 'FIXTURE_ONLY_Aa+/001==opaque-signature-alpha' },
  { index: 1, id: 'call_741_beta', signature: 'FIXTURE_ONLY_Bb+/002==opaque-signature-beta' },
];
const chunk = (delta, finish_reason = null) => ({ id: 'chatcmpl-741-fixture', object: 'chat.completion.chunk', created: 1, model: 'gemini-fixture', choices: [{ index: 0, delta, finish_reason }] });
function sse(order, withMetadata) {
  const events = [chunk({ role: 'assistant' })];
  for (const i of order) {
    const f = fixtures[i];
    events.push(chunk({ tool_calls: [{ index: f.index, id: f.id, type: 'function', function: { name: 'fixture_tool', arguments: '{}' }, ...(withMetadata ? { extra_content: { google: { thought_signature: f.signature } } } : {}) }] }));
  }
  events.push(chunk({}, 'tool_calls'));
  return events.map(e => `data: ${JSON.stringify(e)}\n\n`).join('') + 'data: [DONE]\n\n';
}
const finalSse = [chunk({ role: 'assistant', content: 'CONTROL_OK' }), chunk({}, 'stop')].map(e => `data: ${JSON.stringify(e)}\n\n`).join('') + 'data: [DONE]\n\n';
const tools = { fixture_tool: { description: 'Inert fixture; no tool executes.', inputSchema: jsonSchema({ type: 'object', properties: {}, additionalProperties: false }) } };
async function consume(model, messages) {
  const result = streamText({ model, messages, tools, maxRetries: 0 });
  const events = [];
  for await (const event of result.fullStream) {
    if (event.type === 'error') throw event.error;
    if (event.type === 'tool-call') events.push(event);
  }
  return events;
}
const cases = [];
for (const name of ['custom741', 'google']) {
  for (const [orderName, order] of [['forward', [0, 1]], ['reverse-arrival', [1, 0]]]) {
    for (const withMetadata of [true, false]) {
      const captures = [];
      const provider = createOpenAICompatible({ name, baseURL: 'http://127.0.0.1:1/v1', apiKey: 'fixture-only', fetch: async (url, init) => {
        assert.equal(new URL(url).hostname, '127.0.0.1');
        captures.push(JSON.parse(init.body));
        return new Response(captures.length === 1 ? sse(order, withMetadata) : finalSse, { status: 200, headers: { 'content-type': 'text/event-stream' } });
      } });
      const model = provider.chatModel('gemini-fixture');
      const parsed = await consume(model, [{ role: 'user', content: 'Offline fixture.' }]);
      assert.equal(parsed.length, 2);
      for (const f of fixtures) {
        const event = parsed.find(e => e.toolCallId === f.id);
        assert.ok(event);
        assert.deepEqual(event.input, {});
        assert.equal(event.toolName, 'fixture_tool');
        assert.equal(event.providerMetadata?.[name]?.thoughtSignature, withMetadata ? f.signature : undefined);
      }
      const replays = [];
      for (const mapping of ['drop', 'copy-custom-namespace', 'google-namespace']) {
        // Reverse replay order separately from stream arrival, guarding ID association.
        const toolParts = [...parsed].reverse().map(e => ({ type: 'tool-call', toolCallId: e.toolCallId, toolName: e.toolName, input: e.input,
          ...(mapping === 'copy-custom-namespace' && e.providerMetadata ? { providerOptions: e.providerMetadata } : {}),
          ...(mapping === 'google-namespace' && e.providerMetadata?.[name]?.thoughtSignature ? { providerOptions: { google: { thoughtSignature: e.providerMetadata[name].thoughtSignature } } } : {}),
        }));
        await consume(model, [
          { role: 'user', content: 'Offline fixture.' },
          { role: 'assistant', content: toolParts },
          { role: 'tool', content: toolParts.map(p => ({ type: 'tool-result', toolCallId: p.toolCallId, toolName: p.toolName, output: { type: 'json', value: { ok: true } } })) },
        ]);
        const outgoing = captures.at(-1).messages.find(m => m.role === 'assistant').tool_calls;
        assert.deepEqual(outgoing.map(c => c.id), toolParts.map(p => p.toolCallId));
        for (const f of fixtures) {
          const wire = outgoing.find(c => c.id === f.id);
          const expectSignature = withMetadata && (mapping === 'google-namespace' || (mapping === 'copy-custom-namespace' && name === 'google'));
          assert.equal(wire.extra_content?.google?.thought_signature, expectSignature ? f.signature : undefined);
          if (!expectSignature) assert.equal(Object.hasOwn(wire, 'extra_content'), false);
        }
        replays.push({ mapping, outgoing });
      }
      cases.push({ providerName: name, orderName, withMetadata, parsedToolCalls: parsed, replays });
    }
  }
}
const result = { recordedAt: new Date().toISOString(), nodeVersion: process.version, provenance, networkCalls: 0, notes: [
  'Custom fetch returns fixed SSE in process. No real sockets, provider requests, inference, or tool execution.',
  'This proves adapter and SDK behavior, not Command Code transcript behavior or a Command Code fix.',
  'The provider name controls incoming metadata key. Google-compatible outgoing extension requires providerOptions.google.thoughtSignature.',
  'Mapping under google is an explicit fixture bridge for the tested Google extension, not a general namespace remapping recommendation.',
], caseCount: cases.length, replayCount: cases.reduce((n,c) => n+c.replays.length, 0), passed: true, cases };
writeFileSync(join(outDir, 'adapter-results.json'), JSON.stringify(result, null, 2) + '\n');
writeFileSync(join(outDir, 'signed-tool-calls.sse'), sse([0, 1], true));
writeFileSync(join(outDir, 'reverse-signed-tool-calls.sse'), sse([1, 0], true));
writeFileSync(join(outDir, 'unsigned-tool-calls.sse'), sse([0, 1], false));
console.log(JSON.stringify({ passed: true, caseCount: result.caseCount, replayCount: result.replayCount, provenance }, null, 2));
