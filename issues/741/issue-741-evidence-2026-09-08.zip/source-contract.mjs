import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

// Extracted-component investigation only. No application bundle is modified.
// The two in-memory diagnostic replacements are NOT a production patch: bounds,
// provider namespace mapping, privacy and application lifecycle need separate work.
const here = path.dirname(fileURLToPath(import.meta.url));
assert.ok(process.argv[2], 'Usage: node source-contract.mjs <path-to-pinned-cli.mjs>');
const bundle = path.resolve(process.argv[2]);
const raw = fs.readFileSync(bundle);
const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
const expectedHash = 'd408a372d5d6c8a8851610e2a9840f806929595584d1cd8d909d501928c0037c';
assert.equal(sha256(raw), expectedHash, 'Pinned bundle mismatch; reacquire/review before extraction');
const source = raw.toString('utf8');
const names = [
  'consumeFullStream', 'assistantParts', 'toAiSdkMessages', 'withResumedAssistantTurn',
  'coerceToolInput', 'toWireToolName', 'readReasoningMetadata', 'isNetworkFailureFinish',
  'toolResultOutput', 'reasoningProviderOptions', 'normalizeMessageContent',
  'toV2', 'fromV2', 'parseSessionLine', 'toWireMessages', 'toWireToolOutput',
  'stripThinking', 'toUserContent', 'entryToContextMessages', 'lastEntryId',
  'buildSessionPath', 'buildContextEntriesFromPath', 'projectContextMessages',
  'buildSessionContext', 'isSessionEntryV3', 'isSessionHeaderV3', 'safeParseRecord', 'parseV3Lines',
  'isClientToolUse', 'isReplayableBlock', 'isEmptyText', 'cleanContent',
];
const anchors = [];
const functions = {};
for (const name of names) {
  const startPattern = new RegExp(`(?:async )?function ${name}\\(`, 'g');
  const matches = [...source.matchAll(startPattern)];
  assert.equal(matches.length, 1, `Expected one ${name} declaration`);
  const start = matches[0].index;
  const rest = source.slice(start + matches[0][0].length);
  const next = /(?:async )?function [A-Za-z_$][\w$]*\(/.exec(rest);
  assert.ok(next, `No next declaration after ${name}`);
  const end = start + matches[0][0].length + next.index;
  const text = source.slice(start, end);
  // Compilation independently checks that the delimited original text is valid.
  new vm.Script(`(${text})`);
  functions[name] = text;
  anchors.push({ name, utf8ByteOffset: Buffer.byteLength(source.slice(0, start)),
    utf16CodeUnitOffset: start, utf8ByteLength: Buffer.byteLength(text), sha256: sha256(text) });
}

const constants = `
const __name = value => value;
const rw="tool_search", nw="search_tools";
const dk={inputTokens:0,outputTokens:0,cacheReadTokens:0,cacheWriteTokens:0};
const Yh=3;
const Jh=new Set(["message","model_change","effort_change","compaction","branch_summary","custom","custom_message","label","session_info"]);
const Wh="This is an auto-compacted summary of the earlier conversation that ran out of context.";
const zh=Wh+"\\n\\n", Kh="The following is a summary of a branch that this conversation came back from:\\n\\n<summary>\\n", qh="</summary>";
const transportError = () => { throw Error('Fixture unexpectedly entered transportError'); };
const toTransportError = () => { throw Error('Fixture unexpectedly entered toTransportError'); };
const wrapBareStringRoot = () => { throw Error('Fixture unexpectedly used bare input coercion'); };
`;
// Constants above were copied from the same hash-pinned bundle. No provider SDK
// behavior is stubbed: this fixture begins AFTER that boundary at fullStream.
const ingressNeedle = 'input:n.value,...!0===o.providerExecuted';
const ingressPatch = 'input:n.value,...void 0!==o.providerMetadata?{providerMetadata:o.providerMetadata}:{},...!0===o.providerExecuted';
const egressNeedle = 'input:r.input,...r.providerExecuted';
const egressPatch = 'input:r.input,...void 0!==r.providerMetadata?{providerOptions:r.providerMetadata}:{},...r.providerExecuted';
assert.equal(functions.consumeFullStream.split(ingressNeedle).length, 2);
assert.equal(functions.assistantParts.split(egressNeedle).length, 2);

function load({ ingress = false, egress = false } = {}) {
  const f = { ...functions };
  if (ingress) f.consumeFullStream = f.consumeFullStream.replace(ingressNeedle, ingressPatch);
  if (egress) f.assistantParts = f.assistantParts.replace(egressNeedle, egressPatch);
  const context = vm.createContext({});
  vm.runInContext(constants + Object.values(f).join('\n') + `\nthis.api={${names.join(',')}};`, context);
  return context.api;
}
const json = value => JSON.parse(JSON.stringify(value));
const events = [
  { type: 'tool-call', toolCallId: 'call_alpha', toolName: 'fixture_echo', input: { value: 'same' },
    providerMetadata: { google: { thoughtSignature: 'fixture-alpha-opaque-+/=\u03a9' } } },
  { type: 'tool-call', toolCallId: 'call_beta', toolName: 'fixture_echo', input: { value: 'same' },
    providerMetadata: { google: { thoughtSignature: 'fixture-beta-opaque-+/=\u03a9' } } },
  { type: 'tool-call', toolCallId: 'call_unsigned', toolName: 'fixture_echo', input: { value: 'same' } },
];
const finish = { type: 'finish', finishReason: 'tool-calls', rawFinishReason: 'tool_calls', totalUsage: {} };
async function consume(api, ordered) {
  const updates = [];
  const result = await api.consumeFullStream({ result: { fullStream: (async function* () { yield* ordered; yield finish; })() },
    callParams: { tools: [], onMessageUpdate: value => updates.push(json(value)) }, interleavedThinking: false });
  return { content: json(result.content), lastUpdate: updates.at(-1) };
}
const metadataById = content => Object.fromEntries(content.filter(x => 'tool_use' === x.type).map(x => [x.id, x.providerMetadata ?? null]));
const optionsById = messages => Object.fromEntries(messages.filter(x => 'assistant' === x.role).flatMap(x => x.content).filter(x => 'tool-call' === x.type).map(x => [x.toolCallId, x.providerOptions ?? null]));
const expected = Object.fromEntries(events.map(e => [e.toolCallId, e.providerMetadata ?? null]));
const expectedMissing = Object.fromEntries(events.map(e => [e.toolCallId, null]));
const matrix = [];
for (const reverse of [false, true]) {
  const ordered = reverse ? [...events].reverse() : events;
  for (const ingress of [false, true]) for (const egress of [false, true]) {
    const api = load({ ingress, egress });
    const consumed = await consume(api, ordered);
    const messages = [{ role: 'assistant', content: consumed.content }];
    const replay = json(api.toAiSdkMessages(messages));
    assert.deepEqual(metadataById(consumed.content), ingress ? expected : expectedMissing);
    assert.deepEqual(optionsById(replay), ingress && egress ? expected : expectedMissing);
    assert.deepEqual(consumed.content, consumed.lastUpdate, 'Final streamed update mismatch');
    assert.deepEqual(consumed.content.map(x => x.id), ordered.map(x => x.toolCallId));
    assert.deepEqual(json(api.withResumedAssistantTurn({ messages: [], partial: consumed.content })), replay,
      'Partial assistant continuation must share the same outgoing mapping');
    matrix.push({ order: reverse ? 'reverse' : 'forward', ingressDiagnosticPatch: ingress,
      egressDiagnosticPatch: egress, ingressPreserved: ingress, replayPreserved: ingress && egress,
      preservedReplayIds: Object.entries(optionsById(replay)).filter(([, value]) => value).map(([id]) => id),
      unsignedUnchanged: !('providerMetadata' in consumed.content.find(x => x.id === 'call_unsigned')) &&
        !('providerOptions' in replay[0].content.find(x => x.toolCallId === 'call_unsigned')) });
  }
}

const unmodified = load();
const diagnostic = load({ ingress: true, egress: true });
const signedInternal = (await consume(diagnostic, events)).content;
const assistant = { role: 'assistant', content: signedInternal };
// Same-call association is also retained by the unmodified v3 parser/context
// projection IF metadata already exists in its input. This does not exercise
// actual disk persistence or application --resume/--continue/fork commands.
const timestamp = '2026-09-09T00:00:00.000Z';
const entries = [
  { type: 'session', version: 3, id: 'synthetic_session', timestamp, cwd: '/fixture' },
  { type: 'message', id: 'old', parentId: null, timestamp, message: { role: 'user', content: [{ type: 'text', text: 'older' }] } },
  { type: 'message', id: 'kept', parentId: 'old', timestamp, message: assistant },
  { type: 'compaction', id: 'compact', parentId: 'kept', timestamp, summary: 'synthetic summary', firstKeptEntryId: 'kept', stripThinkingFromKept: true },
];
const parsed = unmodified.parseV3Lines({ lines: entries.map(x => JSON.stringify(x)), sessionId: 'synthetic_session', cwd: '/fixture', fallbackTimestamp: timestamp });
assert.equal(parsed.corrupted, 0);
const context = json(unmodified.buildSessionContext(parsed.entries.slice(1)).messages);
assert.deepEqual(metadataById(context.find(x => x.role === 'assistant').content), expected);
assert.deepEqual(metadataById(json(unmodified.cleanContent({ message: assistant, seenToolUseIds: new Set() })).content), expected);
assert.deepEqual(optionsById(json(unmodified.toAiSdkMessages(context))), expectedMissing);
assert.deepEqual(optionsById(json(diagnostic.toAiSdkMessages(context))), expected);

const v2 = json(unmodified.toV2([assistant]));
assert.deepEqual(optionsById(v2), expectedMissing);
assert.ok(v2[0].content.every(x => !('providerMetadata' in x)));
const v2WithOptions = [{ role: 'assistant', content: events.map(e => ({ type: 'tool-call', toolCallId: e.toolCallId, toolName: e.toolName, input: e.input,
  ...(e.providerMetadata ? { providerOptions: e.providerMetadata } : {}) })) }];
assert.deepEqual(metadataById(json(unmodified.fromV2(v2WithOptions))[0].content), expectedMissing);
assert.deepEqual(optionsById(json(unmodified.toWireMessages([assistant]))), expectedMissing);

const unsigned = [events[2]];
const unsignedOriginal = await consume(unmodified, unsigned);
const unsignedPatched = await consume(diagnostic, unsigned);
assert.deepEqual(unsignedOriginal, unsignedPatched);
assert.deepEqual(json(unmodified.toAiSdkMessages([{ role: 'assistant', content: unsignedOriginal.content }])),
  json(diagnostic.toAiSdkMessages([{ role: 'assistant', content: unsignedPatched.content }])));
const providerExecuted = { ...events[0], providerExecuted: true };
const executedContent = (await consume(diagnostic, [providerExecuted])).content;
assert.deepEqual(json(diagnostic.toAiSdkMessages([{ role: 'assistant', content: executedContent }])), []);
assert.equal(json(diagnostic.withResumedAssistantTurn({ messages: [], partial: executedContent }))[0].content[0].providerExecuted, true);

const result = {
  evidenceClass: 'hash-verified extracted components; synthetic AI SDK fullStream events; not actual CLI or provider SDK',
  packageVersion: '1.51.3', bundleSha256: expectedHash, runAt: new Date().toISOString(), node: process.version,
  allAssertionsPassed: true, matrix,
  supplementalControls: { noMetadataExactEquality: true, providerExecutedFilteringUnchanged: true,
    originalV3ParserAndKeptCompactionProjectionPreserveInjectedMetadata: true,
    originalCleanContentPreservesInjectedMetadata: true, originalToV2DropsMetadata: true,
    originalFromV2DropsOptions: true, originalGatewayWireMappingDropsMetadata: true },
  limitations: ['No provider SDK or namespace mapping tested here', 'No actual CLI or disk lifecycle tested here',
    'Diagnostic replacements have no metadata validation bounds and are not an implementation proposal',
    'V2 bridge loss is a component result; its use by any particular runtime resume path must be separately established',
    'Compaction result applies only to retained history; removed historical calls are intentionally summarized'],
  anchors,
};
fs.writeFileSync(path.join(here, 'source-contract-results.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ allAssertionsPassed: true, matrixCases: matrix.length, supplementalControls: result.supplementalControls }, null, 2));
