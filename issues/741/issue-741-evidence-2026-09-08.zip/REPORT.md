# #741: current CLI loses metadata; a complete correction needs more than copying it

**Confirmed in unmodified command-code 1.51.3:** Google-compatible tool-call signatures supplied by an owned localhost stream are absent from the next request, persisted JSONL and a fresh-process `--continue` request. The same resolved SDK successfully parses the exact captured stimuli. This independently establishes the reported CLI round-trip defect without using a real provider.

The most useful additional findings are **a second outgoing conversion loss**, **a custom-provider namespace mismatch in the pinned adapter**, and **JSON-output exposure introduced by a simple preservation patch**. The evidence identifies the correction boundaries; no upstream source fix or production acceptance is claimed.

## Observations and controls

Windows x64, Node **v24.15.0**, OS **10.0.26100**. Isolated command-code **1.51.3** installation with `ai@6.0.278`, `@ai-sdk/openai-compatible@2.0.74`, `@ai-sdk/provider@3.0.15`, provider-utils **4.0.50** and Zod **4.5.4**. Full locked resolution and hashes are supplied.

| Scenario, run once per bundle variant | Unmodified release | Diagnostic copy |
| --- | --- | --- |
| Two unsigned calls | Both stay unsigned | Both stay unsigned |
| First signed, second unsigned | First signature lost | First exact; second stays unsigned |
| Two different signatures, reversed call order | Both lost; IDs/order retained | Both exact and associated with correct IDs/order |
| Two signed calls, then restart with `--continue` | Both lost in immediate replay, JSONL and continuation | Both exact in immediate replay, JSONL and continuation |

Each fresh session uses two `read_file` calls with the same name and identical input, reading one synthetic owned file. Every replay carries both matching tool-result IDs and successful read markers. Both continuation processes reopen the same session ID. The mock's final success marker acknowledges the tool results regardless of metadata; **request inspection**, not model output, establishes preservation.

There are **eight scenarios, ten CLI processes and eighteen HTTP requests**. All ten emitted success results. **Eight initial processes subsequently aborted** with the Windows `UV_HANDLE_CLOSING` assertion, exit `3221226505`; both continuation processes exited zero. There were no timeouts, request-budget stops or blocked-network attempts. The abort also occurs in unsigned controls; its cause was not isolated. These are completed request observations with qualified exits, not ten clean process passes.

The original loses **seven signed replay occurrences across four replay requests**, and five signed records before persistence. The diagnostic preserves the corresponding values. Two signed parallel calls are a synthetic association stress case; Google's documented parallel shape normally signs the first call only, covered by the mixed control. Invented signatures are not valid real-provider credentials or proof of provider acceptance.

## Three correction boundaries

1. **Inbound conversion:** `consumeFullStream` constructs internal `tool_use` without `providerMetadata` (tool-call marker UTF-8 byte **822171**). The same exact stream is successfully parsed by the pinned SDK, including the custom namespace.
2. **Outbound conversion:** `assistantParts` independently reconstructs AI SDK tool calls without per-call `providerOptions` (function byte **817800**). Eight extracted-component cases show ingress-only and egress-only changes are insufficient; both are needed.
3. **Adapter namespace:** the tested custom adapter emits `providerMetadata['metadata-fixture'].thoughtSignature`, while openai-compatible 2.0.74 serializes only `providerOptions.google.thoughtSignature`. Blindly copying the custom-key object into `providerOptions` still loses the wire extension. Eight standalone parser cases and 24 replay controls cover this difference; eight additional exact-CLI-stimulus controls verify 16 calls, ten signed.

An upstream SDK [namespace issue](https://github.com/vercel/ai/issues/18962) was addressed by [PR #18964](https://github.com/vercel/ai/pull/18964), merged at `2f77de8c648c6ed53c8a3eb59e897183be6a06ca`. The v3 adapter fix reads the configured namespace with a Google fallback. This is a useful source/backport reference; a compatible v2 backport is not established, and an ai6-to-ai7 major upgrade is not recommended blindly.

## What the diagnostic proves—and still fails

The separately derived bundle changes the two mapping boundaries and explicitly maps the known fixture namespace's supported `thoughtSignature` into Google's outgoing options. Original hash: `d408a372d5d6c8a8851610e2a9840f806929595584d1cd8d909d501928c0037c`. Diagnostic hash: `1ad4291de99a6f735e971492a182bf0fb75e05284bd16b5d05d1e911aafbb9a4`.

The A/B result supports these causal boundaries. **It is not a production patch.** Its fixed provider namespace and 16 KiB signature limit are fixture choices. Fourteen helper checks cover selected value shape, byte limits, inheritance/accessors and unrelated cyclic data; they do not validate a generic metadata storage policy.

Preserving the field also exposes it in **13 JSON stdout records across four diagnostic processes**, despite no `--trace`: `message_update`, `message_end` and `run_end` state serialization. Continuation exposes it through `run_end`. No synthetic signature appears in captured stderr. The team should explicitly separate persisted provider data from public event/output serialization. Text/TUI, telemetry and general operational logs remain untested; an absence claim for those surfaces would be unsupported.

## Persistence and lifecycle nuance

The original v3 JSON reader and retained compaction projection preserve synthetically injected metadata in extracted-component controls. Do not describe the v3 schema as stripping it: the observed release discards it before storage, and the outgoing builder drops it again. Actual JSONL and fresh-process `--continue` were tested; explicit `--resume`, fork and actual summarization/compaction were not. The fixture mode named `signed-resume` uses `--continue`.

The original v2 conversion bridges and gateway wire builder separately omit injected metadata in extracted tests. These identify additional regression boundaries, not observed production gateway failures. Compaction may legitimately remove a whole historical call; preservation applies to calls retained and replayed, not invented signatures for summaries.

## Team implementation and acceptance

- Define typed, bounded JSON metadata on the internal call and applicable bridges. Preserve opaque values and originating provider identity per exact call ID; choose bounds from application policy and realistic fixtures.
- Restore supported per-call options through the correct adapter mapping. Do not guess namespaces, synthesize values, copy one signature between calls or forward arbitrary metadata after a provider/model switch.
- Keep no-metadata and provider-executed behavior unchanged. Reject unsafe/oversized data without printing or silently truncating opaque values.
- Add the mixed, distinct-ID/reversed, adapter-namespace and full-loop controls supplied here. Add actual nonstreaming, explicit resume, fork, compaction and cross-provider tests before broader claims.
- Exclude opaque provider values from normal output/events, telemetry and errors while retaining required persistence. The diagnostic's JSON exposure is a concrete failing acceptance case.

The issue reporter's real incident also includes a proxy-side component. No paid inference, real Gemini validation, production trace correlation, affected-user estimate, team adoption or released fix is established here. The [Google contract](https://ai.google.dev/gemini-api/docs/generate-content/thought-signatures) explains the real signature rules; strict validation should not be assumed identical for every historical call or model family.

See `README.md` for reproduction, `results.json` for minimized captures, `provenance.json` for exact runtime identity, and `SOURCE-FINDINGS.md` / `source-contract-results.json` for source anchors. Raw system prompts, credentials, full event state and home paths remain excluded from the portable package.
