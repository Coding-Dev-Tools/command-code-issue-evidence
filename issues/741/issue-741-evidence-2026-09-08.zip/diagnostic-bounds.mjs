import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
import { createDiagnosticPatch } from './diagnostic-patch.mjs';
const here = path.dirname(fileURLToPath(import.meta.url));
assert.ok(process.argv[2], 'Usage: node diagnostic-bounds.mjs <path-to-pinned-cli.mjs>');
const bytes = fs.readFileSync(path.resolve(process.argv[2]));
const patch = createDiagnosticPatch(bytes, 'metadata-fixture');
const context = vm.createContext({ TextEncoder });
vm.runInContext(patch.helper, context);
const checks = [];
function check(name, expression) {
  assert.equal(vm.runInContext(expression, context), true, name);
  checks.push(name);
}
check('exact known namespace maps to Google options', `issue741Egress({'metadata-fixture':{thoughtSignature:'fixture-a'}}).providerOptions.google.thoughtSignature==='fixture-a'`);
check('unknown namespace is not guessed', `JSON.stringify(issue741Egress({other:{thoughtSignature:'fixture-a'}}))==='{}'`);
check('Google namespace is not guessed on fixture adapter', `JSON.stringify(issue741Egress({google:{thoughtSignature:'fixture-a'}}))==='{}'`);
check('selected value survives ingress exactly', `issue741Ingress({'metadata-fixture':{thoughtSignature:'fixture-+/=Ω'}}).providerMetadata['metadata-fixture'].thoughtSignature==='fixture-+/=Ω'`);
check('unrelated fields are not retained', `JSON.stringify(issue741Ingress({'metadata-fixture':{thoughtSignature:'fixture-a',other:'omit'},unrelated:{deep:'omit'}}))===JSON.stringify({providerMetadata:{'metadata-fixture':{thoughtSignature:'fixture-a'}}})`);
check('absent metadata does not add options', `JSON.stringify(issue741Egress(undefined))==='{}'`);
check('non-string rejects', `[null,12,[],{},true,BigInt(1)].every(s=>JSON.stringify(issue741Ingress({'metadata-fixture':{thoughtSignature:s}}))==='{}')`);
check('empty rejects', `JSON.stringify(issue741Ingress({'metadata-fixture':{thoughtSignature:''}}))==='{}'`);
check('16384 byte boundary accepted', `issue741Signature({'metadata-fixture':{thoughtSignature:'a'.repeat(16384)}}).length===16384`);
check('16385 byte boundary rejected', `issue741Signature({'metadata-fixture':{thoughtSignature:'a'.repeat(16385)}})===undefined`);
check('Unicode uses UTF-8 bytes', `issue741Signature({'metadata-fixture':{thoughtSignature:'Ω'.repeat(8192)}}).length===8192&&issue741Signature({'metadata-fixture':{thoughtSignature:'Ω'.repeat(8193)}})===undefined`);
check('prototype property rejected', `issue741Signature(Object.create({'metadata-fixture':{thoughtSignature:'fixture-a'}}))===undefined`);
check('accessor not invoked', `(()=>{let calls=0;const x={};Object.defineProperty(x,'metadata-fixture',{get(){calls++;throw Error('bad')}});return issue741Signature(x)===undefined&&calls===0})()`);
check('cycles outside selected field not traversed', `(()=>{const x={'metadata-fixture':{thoughtSignature:'fixture-a'}};x.self=x;return issue741Signature(x)==='fixture-a'})()`);
fs.writeFileSync(path.join(here, 'diagnostic-bounds-results.json'), JSON.stringify({
  diagnosticOnly: true, chosenFixtureNamespace: patch.namespace, policyByteLimitNotTeamDecision: patch.byteLimit,
  testsPassed: checks.length, checks, actualCliTest: false, productionImplementation: false,
}, null, 2) + '\n');
console.log(JSON.stringify({ testsPassed: checks.length, diagnosticOnly: true }));
