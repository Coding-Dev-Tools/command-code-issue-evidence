import assert from 'node:assert/strict';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const runRoot = resolve(process.argv[2] ?? join(here, '../issue-741-cli/runs'));
const dependencies = resolve(process.argv[3] ?? join(here, '../issue-741-cli/runtime/node_modules'));
const { createOpenAICompatible } = await import(pathToFileURL(join(dependencies, '@ai-sdk/openai-compatible/dist/index.mjs')));
const { streamText, jsonSchema } = await import(pathToFileURL(join(dependencies, 'ai/dist/index.mjs')));
const sha256 = value => createHash('sha256').update(value).digest('hex');
const cases = [];
for (const entry of readdirSync(runRoot, { withFileTypes: true }).filter(e => e.isDirectory()).sort((a, b) => a.name.localeCompare(b.name))) {
  const rawBytes = readFileSync(join(runRoot, entry.name, 'raw.json'));
  const raw = JSON.parse(rawBytes);
  const chunks = [];
  for (const sent of raw.sent) {
    if (sent.stage !== 0) continue;
    chunks.push(sent.value);
    if (sent.value.choices?.some(c => c.finish_reason === 'tool_calls')) break;
  }
  assert.ok(chunks.at(-1).choices.some(c => c.finish_reason === 'tool_calls'), 'Tool-call response terminal chunk must be present');
  assert.ok(chunks.every(c => c.choices.every(p => !p.delta?.content)), 'Only first tool-call response is permitted');
  const expected = chunks.flatMap(c => c.choices.flatMap(p => p.delta?.tool_calls ?? [])).map(c => ({
    id: c.id, name: c.function.name, signature: c.extra_content?.google?.thought_signature ?? null,
  }));
  assert.equal(expected.length, 2);
  assert.equal(new Set(expected.map(c => c.id)).size, 2);
  const readFileDefinition = raw.requests[0].body.tools.find(t => t.function?.name === 'read_file')?.function;
  assert.ok(readFileDefinition?.parameters, 'Use initial actual CLI read_file schema');
  const sse = chunks.map(c => `data: ${JSON.stringify(c)}\n\n`).join('') + 'data: [DONE]\n\n';
  let fetchCalls = 0;
  const model = createOpenAICompatible({ name: 'metadata-fixture', baseURL: 'http://127.0.0.1:1/v1', apiKey: 'fixture-only', fetch: async (url) => {
    assert.equal(new URL(url).hostname, '127.0.0.1');
    fetchCalls += 1;
    return new Response(sse, { status: 200, headers: { 'content-type': 'text/event-stream' } });
  } }).chatModel('model');
  const parsed = [];
  const result = streamText({ model, maxRetries: 0, messages: [{ role: 'user', content: 'Offline parser positive control.' }], tools: {
    read_file: { description: 'Unexecuted recorded CLI tool schema.', inputSchema: jsonSchema(readFileDefinition.parameters) },
  } });
  for await (const event of result.fullStream) {
    if (event.type === 'error') throw event.error;
    if (event.type === 'tool-call') parsed.push(event);
  }
  assert.equal(fetchCalls, 1);
  assert.equal(parsed.length, expected.length);
  const calls = expected.map(wire => {
    const event = parsed.find(e => e.toolCallId === wire.id);
    assert.ok(event);
    assert.equal(event.toolName, wire.name);
    const actual = event.providerMetadata?.['metadata-fixture']?.thoughtSignature ?? null;
    assert.equal(actual, wire.signature);
    if (wire.signature === null) assert.equal(event.providerMetadata, undefined);
    return { callId: wire.id, toolName: wire.name, wireSignature: wire.signature, parsedSignature: actual, metadataKeys: Object.keys(event.providerMetadata ?? {}), exactMatch: true };
  });
  cases.push({ run: entry.name, mode: raw.mode, cliVersion: raw.cliVersion, bundleSha256: raw.bundleSha256, rawSourceSha256: sha256(rawBytes), firstResponseReconstructedSseSha256: sha256(sse), readFileParametersSha256: sha256(JSON.stringify(readFileDefinition.parameters)), chunkCount: chunks.length, passed: true, calls });
}
assert.equal(cases.length, 8, 'Expected precisely the eight parent runs under this control scope');
const provenance = Object.fromEntries(['ai', '@ai-sdk/openai-compatible'].map(name => [name, { version: JSON.parse(readFileSync(join(dependencies, name, 'package.json'))).version, moduleSha256: sha256(readFileSync(join(dependencies, name, 'dist/index.mjs'))) }]));
const output = { recordedAt: new Date().toISOString(), passed: true, nodeVersion: process.version, networkCalls: 0, runCount: cases.length, toolCallCount: cases.reduce((n, c) => n + c.calls.length, 0), signedCallCount: cases.reduce((n, c) => n + c.calls.filter(p => p.wireSignature !== null).length, 0), provenance, notes: [
  'Reconstructs first stage-zero SSE from the exact captured JSON chunks through finish_reason tool_calls, then adds the normal DONE terminator.',
  'Uses recorded initial request read_file JSON schema and exact fresh runtime adapter/SDK. No original user/system messages are sent or retained in output.',
  'In-process mocked fetch only; no sockets, inference, CLI invocation or tool execution.',
  'Only synthetic fixture signatures and call identifiers retained. Original file path arguments and session/system data are intentionally omitted.',
  'An initial harness assertion expected metadata-absent events not to own a providerMetadata property; SDK events own that property with value undefined. The control was corrected to assert the value is undefined. This was a harness-shape assertion failure, not a product failure.',
], cases };
writeFileSync(join(here, 'captured-cli-control-results.json'), JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify({ passed: true, runCount: output.runCount, toolCallCount: output.toolCallCount, signedCallCount: output.signedCallCount, provenance }, null, 2));
