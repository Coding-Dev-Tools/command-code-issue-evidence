import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root=path.dirname(fileURLToPath(import.meta.url));
const [packageArg,mode='signed',expectedHash='d408a372d5d6c8a8851610e2a9840f806929595584d1cd8d909d501928c0037c']=process.argv.slice(2);
if(!packageArg||!['unsigned','signed','mixed','reverse','signed-resume'].includes(mode))throw Error('Usage: node metadata-probe.mjs PACKAGE_DIR unsigned|signed|mixed|reverse|signed-resume [EXPECTED_DIAGNOSTIC_HASH]');
const packageRoot=fs.realpathSync(packageArg), runtimeRoot=path.dirname(packageRoot);
const sha=v=>createHash('sha256').update(v).digest('hex');
const bundleSha256=sha(fs.readFileSync(path.join(packageRoot,'dist/cli.mjs')));
if(bundleSha256!==expectedHash)throw Error('Bundle hash mismatch');
const runRoot=path.join(root,'runs',`${mode}-${Date.now()}`),fixtureHome=path.join(runRoot,'home'),tmp=path.join(fixtureHome,'tmp');
for(const p of [tmp,path.join(fixtureHome,'.commandcode'),path.join(fixtureHome,'AppData/Roaming'),path.join(fixtureHome,'AppData/Local')])fs.mkdirSync(p,{recursive:true});
const fixture=path.join(runRoot,'fixture.txt'),marker='ISSUE_741_OWNED_READ_OK';
fs.writeFileSync(fixture,marker+'\n');
const provider='metadata-fixture',model=`${provider}/model`;
const signatures={call_741_alpha:'SYNTHETIC_741_ALPHA_abcd0123+/=opaque',call_741_beta:'SYNTHETIC_741_BETA_wxyz9876+/=opaque'};
const requests=[],sent=[],stages=[],startedAt=new Date().toISOString(),origin=performance.now();let stage=0;
const server=http.createServer((req,res)=>{
 let body='';req.on('data',b=>{body+=b;if(body.length>2_000_000)req.destroy();});
 req.on('end',()=>{
  if(req.method!=='POST'||req.url!=='/v1/chat/completions'){res.writeHead(404);res.end();return;}
  let payload;try{payload=JSON.parse(body);}catch{res.writeHead(400);res.end();return;}
  const record={stage,path:req.url,receivedAtMs:performance.now()-origin,bodySha256:sha(body),body:payload};requests.push(record);
  if(requests.length>5){res.writeHead(400,{'Content-Type':'application/json'});res.end(JSON.stringify({error:{message:'Fixture request budget exceeded',type:'fixture_budget'}}));return;}
  const base={id:`fixture-${requests.length}`,object:'chat.completion.chunk',created:1,model:'model'};
  res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache'});
  const chunk=(delta,finish_reason=null)=>{const v={...base,choices:[{index:0,delta,finish_reason}]};sent.push({stage,value:v});res.write(`data: ${JSON.stringify(v)}\n\n`);};
  const finish=reason=>{chunk({},reason);res.end('data: [DONE]\n\n');};
  const tools=(payload.tools??[]).map(t=>t.function?.name),replies=(payload.messages??[]).filter(m=>m.role==='tool');
  if(replies.length||stage>0){
   const ok=replies.length>=2&&replies.filter(m=>JSON.stringify(m.content).includes(marker)).length>=2;
   chunk({role:'assistant',content:ok?'ISSUE_741_REPLAY_REACHED':'ISSUE_741_TOOL_RESULTS_MISSING'});finish('stop');return;
  }
  if(!tools.includes('read_file')){chunk({role:'assistant',content:'ISSUE_741_READ_TOOL_UNDECLARED'});finish('stop');return;}
  const ids=Object.keys(signatures);if(mode==='reverse')ids.reverse();
  for(const [index,id] of ids.entries()){
   const tool={index,id,type:'function',function:{name:'read_file',arguments:JSON.stringify({file_path:fixture})}};
   if(mode!=='unsigned'&&(mode!=='mixed'||index===0))tool.extra_content={google:{thought_signature:signatures[id]}};
   chunk({...(index===0?{role:'assistant'}:{}),tool_calls:[tool]});
  }
  finish('tool_calls');
 });
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
fs.writeFileSync(path.join(fixtureHome,'.commandcode/providers.json'),JSON.stringify({provider:{[provider]:{api:'openai-completions',baseURL:`http://127.0.0.1:${port}/v1`,apiKey:'$FIXTURE_PROVIDER_KEY',models:{model:{contextWindow:200000,maxOutput:200,cost:{input:0,output:0}}}}}}));
fs.writeFileSync(path.join(fixtureHome,'.commandcode/config.json'),JSON.stringify({model,provider,localOnly:true,telemetry:false,tasteLearning:false}));
fs.writeFileSync(path.join(fixtureHome,'.commandcode/settings.json'),JSON.stringify({disableScratchpad:true,disableSkillShellExecution:true}));
const env={};for(const k of ['SystemRoot','WINDIR','ComSpec','PATHEXT','PROCESSOR_ARCHITECTURE'])if(process.env[k])env[k]=process.env[k];
env.PATH=[path.dirname(process.execPath),path.join(process.env.SystemRoot??'/','System32')].join(path.delimiter);
Object.assign(env,{HOME:fixtureHome,USERPROFILE:fixtureHome,APPDATA:path.join(fixtureHome,'AppData/Roaming'),LOCALAPPDATA:path.join(fixtureHome,'AppData/Local'),TEMP:tmp,TMP:tmp,CMD_LOCAL_ONLY:'1',DO_NOT_TRACK:'1',OTEL_SDK_DISABLED:'true',COMMANDCODE_SKIP_UPDATES:'1',COMMANDCODE_DISABLE_CRON:'1',COMMANDCODE_DISABLE_DURABLE_CRON:'1',DOTENV_CONFIG_PATH:path.join(fixtureHome,'missing.env'),NO_COLOR:'1',FIXTURE_PORT:String(port),FIXTURE_PROVIDER_KEY:'synthetic-provider-key-not-real',COMMAND_CODE_API_KEY:'synthetic-command-key-not-real'});
for(stage=0;stage<(mode==='signed-resume'?2:1);stage++){
 const cliArgs=['--no-auto-update','--local-only','--skip-onboarding','--trust','--no-skills','--model',model,'--max-turns','3','--output-format','json',...(stage?['--continue']:[]),'--print',stage?'Continue the synthetic fixture session.':'Read the provided synthetic fixture with the requested read_file calls.'];
 const nodeArgs=['--permission',`--allow-fs-read=${runtimeRoot}`,`--allow-fs-read=${root}`,`--allow-fs-write=${runRoot}`,'--require',path.join(root,'offline-guard.cjs'),path.join(packageRoot,'dist/index.mjs'),...cliArgs];
 const child=spawn(process.execPath,nodeArgs,{cwd:runRoot,env,windowsHide:true,stdio:['ignore','pipe','pipe']});let stdout='',stderr='',timedOut=false;
 child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
 const timer=setTimeout(()=>{timedOut=true;child.kill();},35000);
 const exit=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('close',(code,signal)=>resolve({code,signal}));});clearTimeout(timer);
 stages.push({stage,cliArgs,exit,timedOut,stdout,stderr});
 if(timedOut)break;
}
server.closeAllConnections();await new Promise(r=>server.close(r));
const sessions=[];for(const p of fs.readdirSync(fixtureHome,{recursive:true})){const f=path.join(fixtureHome,p);if(p.endsWith('.jsonl')&&fs.statSync(f).isFile())sessions.push({path:p,text:fs.readFileSync(f,'utf8')});}
const result={mode,startedAt,node:process.version,platform:process.platform,arch:process.arch,osRelease:os.release(),cliVersion:JSON.parse(fs.readFileSync(path.join(packageRoot,'package.json'))).version,bundleSha256,signatures,stages,requests,sent,sessions,scope:'Actual released bundle unless a separately labeled diagnostic hash is provided; owned localhost service, isolated synthetic home/env, fixture filesystem permissions and Node network guard. No paid providers; no trace flag.'};
fs.writeFileSync(path.join(runRoot,'raw.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify({mode,bundleSha256,requests:requests.map(r=>({stage:r.stage,calls:r.body.messages?.flatMap(m=>m.tool_calls??[]),toolReplyCount:r.body.messages?.filter(m=>m.role==='tool').length})),stages:stages.map(s=>({stage:s.stage,exit:s.exit,timedOut:s.timedOut,stdoutTail:s.stdout.slice(-500),stderrTail:s.stderr.slice(-450)})),sessions:sessions.map(s=>({path:s.path,bytes:Buffer.byteLength(s.text)})),raw:path.relative(root,path.join(runRoot,'raw.json'))}));
