import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
const root=path.dirname(fileURLToPath(import.meta.url));
const read=n=>JSON.parse(fs.readFileSync(path.join(root,n),'utf8'));
const d=read('results.json'),p=read('provenance.json');
assert.equal(d.runs.length,8);
assert.equal(new Set(d.runs.map(r=>`${r.variant}/${r.mode}`)).size,8);
let signedReplayOccurrences=0,exposedFrames=0;
for(const variant of ['original','diagnostic'])for(const mode of ['unsigned','mixed','reverse','signed-resume']){
 const r=d.runs.find(x=>x.variant===variant&&x.mode===mode);assert.ok(r);
 assert.equal(r.bundleSha256,variant==='original'?p.bundleSha256:p.diagnosticSha256);
 assert.equal(r.stages.length,mode==='signed-resume'?2:1);
 assert.equal(r.requests.length,mode==='signed-resume'?3:2);
 const ids=mode==='reverse'?['call_741_beta','call_741_alpha']:['call_741_alpha','call_741_beta'];
 assert.deepEqual(r.sentToolCalls.map(c=>c.id),ids);
 const sent=new Map(r.sentToolCalls.map(c=>[c.id,c.extra_content?.google?.thought_signature]));
 for(const id of ids)assert.equal(sent.get(id),mode==='unsigned'||(mode==='mixed'&&id==='call_741_beta')?undefined:r.signatures[id]);
 assert.deepEqual(r.requests[0].toolCalls,[]);assert.ok(r.requests[0].readFileDeclared);
 for(const request of r.requests.slice(1)){
  assert.equal(request.path,'/v1/chat/completions');assert.equal(request.model,'model');assert.equal(request.stream,true);
  assert.deepEqual(request.toolCalls.map(c=>c.id),ids);assert.equal(request.toolResults.length,2);
  assert.deepEqual([...request.toolResults.map(t=>t.callId)].sort(),[...ids].sort());assert.ok(request.toolResults.every(t=>t.fixtureMarkerPresent));
  for(const c of request.toolCalls){
   assert.equal(c.function.name,'read_file');assert.deepEqual(JSON.parse(c.function.arguments),{file_path:'<OWNED_FIXTURE_FILE>'});
   assert.equal(c.extra_content?.google?.thought_signature,variant==='diagnostic'?sent.get(c.id):undefined);
   if(variant==='original'&&sent.get(c.id))signedReplayOccurrences++;
  }
 }
 assert.equal(r.persistedSessions.length,1);
 const disk=r.persistedSessions[0].toolCalls;assert.deepEqual(disk.map(c=>c.id),ids);
 for(const c of disk)assert.equal(c.providerMetadata?.['metadata-fixture']?.thoughtSignature,variant==='diagnostic'?sent.get(c.id):undefined);
 const sessionIds=[];
 for(const s of r.stages){
  assert.equal(s.timedOut,false);assert.equal(s.blockedNetworkCount,0);assert.equal(s.guardReady,true);assert.equal(s.resultFrames.length,1);
  assert.equal(s.resultFrames[0].subtype,'success');assert.equal(s.resultFrames[0].finalText,'ISSUE_741_REPLAY_REACHED');sessionIds.push(s.resultFrames[0].sessionId);
  assert.deepEqual(s.signatureIdsInStderr,[]);assert.equal(s.cliArgs.includes('--trace'),false);assert.equal(s.cliArgs.includes('--no-session'),false);
  assert.equal(s.exit.code,s.stage===0?3221226505:0);assert.equal(s.shutdownAssertion,s.stage===0);
  assert.equal(s.signatureBearingFrameCount>0,variant==='diagnostic'&&mode!=='unsigned');exposedFrames+=s.signatureBearingFrameCount;
 }
 assert.equal(new Set(sessionIds).size,1);assert.ok(r.persistedSessions[0].filename.startsWith(sessionIds[0]));
 if(mode==='signed-resume')assert.ok(r.stages[1].cliArgs.includes('--continue'));
}
assert.equal(signedReplayOccurrences,7);assert.equal(exposedFrames,13);
assert.deepEqual(d.totals,{scenarios:8,cliInvocations:10,httpRequests:18,successFrames:10,shutdownAssertions:8,timeouts:0,blockedNetworkAttempts:0});
const a=read('adapter-results.json');assert.equal(a.passed,true);assert.equal(a.caseCount,8);assert.equal(a.replayCount,24);
const exact=read('captured-cli-control-results.json');assert.equal(exact.passed,true);
assert.equal(exact.runCount,8);assert.equal(exact.toolCallCount,16);assert.equal(exact.signedCallCount,10);assert.equal(exact.networkCalls,0);
for(const control of exact.cases){
 const run=d.runs.find(r=>r.rawRun===control.run);assert.ok(run);assert.equal(run.rawSha256,control.rawSourceSha256);assert.equal(run.bundleSha256,control.bundleSha256);
 for(const call of control.calls){const sent=run.sentToolCalls.find(c=>c.id===call.callId);assert.ok(sent);assert.equal(call.wireSignature,sent.extra_content?.google?.thought_signature??null);assert.equal(call.parsedSignature,call.wireSignature);assert.equal(call.exactMatch,true);}
}
const c=read('source-contract-results.json');assert.equal(c.allAssertionsPassed,true);assert.equal(c.matrix.length,8);
for(const m of c.matrix)assert.equal(m.replayPreserved,m.ingressDiagnosticPatch&&m.egressDiagnosticPatch);
assert.equal(read('diagnostic-bounds-results.json').testsPassed,14);
assert.equal(createHash('sha256').update(fs.readFileSync(path.join(root,'runtime-package-lock.json'))).digest('hex'),p.lockSha256);
console.log(JSON.stringify({savedEvidenceVerified:true,productAcceptancePassed:false,scenarios:8,cliInvocations:10,httpRequests:18,signedReplayOccurrencesLostOriginally:7,diagnosticSignatureBearingJsonFrames:13,qualifiedShutdownAborts:8,meaning:'Validates saved defect and diagnostic observations; no application or network call is made.'}));
