# #741 current-bundle source and component investigation

This worker inspected the full live issue (open, assigned to `ahmadbilaldev`, zero comments) and hash-verified `command-code@1.51.3`. Bundle SHA256: `d408a372d5d6c8a8851610e2a9840f806929595584d1cd8d909d501928c0037c`.

## Most useful additional finding

**Changing `consumeFullStream` alone cannot fix replay.** `assistantParts`, used by both `toAiSdkMessages` and `withResumedAssistantTurn`, independently rebuilds tool calls without provider options. The extracted-components 2×2 patch matrix demonstrates that both boundaries must be corrected. Adapter namespace translation is a third requirement established separately by the parent's adapter worker: merely copying `providerMetadata.customNamespace` to equally named `providerOptions` does not satisfy the OpenAI-compatible adapter, which reads `providerOptions.google.thoughtSignature`.

## Verified source boundaries

Offsets below are zero-based UTF-8 bytes in the pinned file, physical line 2. Exact extracted-function length/hash pairs are in `source-contract-results.json`.

| Function | Byte offset | Finding |
| --- | ---: | --- |
| `consumeFullStream` | 821189 | Tool-call conversion discards `providerMetadata`; current tool-use has ID/name/input/optional providerExecuted only. The `case"tool-call"` marker is at byte 822171. |
| `assistantParts` | 817800 | Internal tool-use to AI SDK tool-call reconstruction drops injected metadata; no `providerOptions`. |
| `toAiSdkMessages` | 818535 | Calls `assistantParts` for historical assistant messages. |
| `withResumedAssistantTurn` | 819313 | Calls the same `assistantParts` for partial assistant continuation. This is not the session-resume command. |
| `cleanContent` | 489928 | Filters content blocks without reconstructing retained blocks; injected metadata survives. |
| `parseV3Lines` | 528180 | Parses original JSON objects and validates entry-level shape; injected metadata survives. |
| `buildSessionContext` | 524798 | Projects retained entries through compaction context and preserves injected metadata. |
| `stripThinking` | 520554 | Removes thinking blocks, not fields from retained tool-use blocks. |
| `toV2` | 515520 | Explicit reconstruction drops metadata. |
| `fromV2` | 517118 | Explicit reconstruction drops supplied provider options. |
| `toWireMessages` | 808721 | Gateway wire conversion separately drops injected metadata; this is not the BYOK `assistantParts` path. No production gateway claim follows. |

V3 `createSessionStoreV3.appendMessage` stores `message:e` wholesale; writing uses `JSON.stringify`. Its reader `migrateToV3` uses `parseV3Lines` when the format is v3. Current print `resolvePrintResumeState` prefers `loadResumeAgentState` / v3 context and only falls back to `buildPrintResumeState` / `fromV2`. Consequently, saying “the v3 persistence or resume schema strips metadata” would be unsupported and contradicted by the extracted reader controls. The confirmed ingress omission causes metadata to be absent before persistence; egress loses metadata even when a synthetic retained record already contains it.

Compaction intentionally removes older history and summarizes it. Preservation applies to exact retained/replayed tool calls; signatures should not be invented for a summary. These tests cover retained entry projection, not an actual summarization request, disk persistence, `--resume`, `--continue`, session fork or native CLI lifecycle.

## Executed component tests

`source-contract.mjs` passed all assertions (portable invocation: `node source-contract.mjs <path-to-pinned-cli.mjs>`):

- Eight cases: forward/reverse input order × original/diagnostic ingress × original/diagnostic egress.
- Same tool name and identical arguments on distinct `call_alpha` / `call_beta`, with different opaque signatures; third unsigned call.
- Original/original, ingress-only, and egress-only all fail replay preservation as expected; both in-memory replacements preserve each original value by ID.
- Unsigned input/output have exact equality before/after diagnostic changes.
- Existing provider-executed filtering remains unchanged.
- Original JSON v3 parser and retained compaction projection preserve synthetically injected metadata; original outgoing reconstruction still loses it.
- Original v2 bridges and gateway wire conversion independently discard supplied metadata.

This harness starts from synthetic AI SDK `fullStream` events, after the adapter boundary. It uses original extracted functions, hash-checked source, and separately labelled in-memory diagnostic replacements. It does not run the application or provider SDK.

## Diagnostic A/B patch for the parent

`diagnostic-patch.mjs` exports `createDiagnosticPatch(originalBuffer, namespace)`. It verifies the pinned input hash and returns diagnostic text plus exact replacement records; it never edits the installed CLI. The known fixture namespace must come from the actual adapter control. It does not guess a namespace from available metadata keys.

For the parent's `metadata-fixture` adapter, the returned diagnostic hash is `1ad4291de99a6f735e971492a182bf0fb75e05284bd16b5d05d1e911aafbb9a4`. It changes only the two mapping boundaries and adds helper functions. Helpers retain only the supported `thoughtSignature` string under the explicit fixture namespace, then map that string to `providerOptions.google.thoughtSignature` on egress. A 16 KiB UTF-8 limit is an arbitrary fixture protection, **not a proposed team policy**. No generic metadata copying or universal namespace mapping is implied.

`diagnostic-bounds.mjs` passed 14 diagnostic helper checks: known namespace, no namespace guessing, exact value, omit unrelated fields, absent/no-value behavior, invalid scalar/array/object/BigInt values, empty string, byte boundary, Unicode byte accounting, inherited property rejection, accessors not invoked, and not traversing unrelated cyclic data. These validate this synthetic helper's behavior; they do not establish application compatibility or a release-ready fix. Portable invocation: `node diagnostic-bounds.mjs <path-to-pinned-cli.mjs>`. To generate the reviewable patch record without writing a product bundle: `node diagnostic-patch.mjs <path-to-pinned-cli.mjs> <known-fixture-provider-namespace>`.

## Correction contract for the team's source implementation

1. Define a typed, bounded supported metadata representation on the internal tool-use and bridge schemas.
2. Retain the exact provider field per tool-call ID at ingress.
3. Reconstruct per-call outgoing options through the active provider's explicit adapter mapping. The namespace on provider output need not equal the required options namespace.
4. Preserve retained v3 records and update v2/import/export boundaries where replay relies on them. Test actual resume/continue/fork/compaction independently.
5. Keep absent metadata absent and current provider-executed behavior unchanged. Do not repair a missing signature with another call's value or a synthetic placeholder.
6. Keep opaque values out of normal output, telemetry and errors. `serializeAgentEventLine` (byte 993371) serializes full events; a simple ingress field copy can therefore affect explicit JSON event output and needs an intentional contract. The diagnostic patch does not implement privacy/output policy. The normal telemetry subscriber selects named attributes, but complete runtime privacy verification remains separate.

The private source repository, actual production frequency and proxy-side behavior remain unavailable to this worker. No upstream comment, issue mutation, paid inference or product source edit occurred.
