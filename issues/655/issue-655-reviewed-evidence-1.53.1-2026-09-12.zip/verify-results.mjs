import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {assertGrep} from './assert-grep.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const original=JSON.parse(fs.readFileSync(path.join(root,'original-results.json'),'utf8'));
const diagnostic=JSON.parse(fs.readFileSync(path.join(root,'diagnostic-results.json'),'utf8'));
assertGrep(original,{emptyShouldWork:false});assertGrep(diagnostic);
assert.throws(()=>assertGrep(original));
for(const [row,hasEmpty] of [[original,true],[diagnostic,false]]){
 assert.equal(row.shell.length,6);assert.ok(row.shell.every(s=>s.shell===true&&s.args.length===0));
 assert.equal(row.shell.filter(s=>s.command.includes('--type ""')).length,hasEmpty?1:0);
 assert.ok(row.shell[2].command.includes('--type "js"'));
 assert.ok(row.shell[3].command.includes('--type "text"'));
}
const mutants=[
 ['missing log match',r=>{r.requests.at(-1).body.messages.find(m=>m.tool_call_id==='call_empty-log').content='app.log:1:ERROR_655 LOG_A';}],
 ['wrong tool input',r=>{r.events.find(e=>e.event?.type==='tool_queued'&&e.event.toolCallId==='call_empty-log').event.input.type='js';}],
 ['wrong tool-call association',r=>{r.requests.at(-1).body.messages.find(m=>m.tool_call_id==='call_empty-log').tool_call_id='wrong';}],
 ['false no-match success',r=>{r.requests.at(-1).body.messages.find(m=>m.tool_call_id==='call_empty-log').content='No matches found';}],
 ['glob leakage',r=>{r.requests.at(-1).body.messages.find(m=>m.tool_call_id==='call_empty-log').content+='\nexclude.txt:1:ERROR_655 TXT_EXCLUDED';}],
 ['invalid type silently accepted',r=>{r.events.find(e=>e.event?.type==='tool_errored'&&e.event.toolCallId==='call_unknown-text').event.type='tool_completed';}],
 ['unclean exit',r=>{r.exit.code=1;}],
];
for(const [name,mutate] of mutants){const row=structuredClone(diagnostic);mutate(row);assert.throws(()=>assertGrep(row),undefined,name);}
console.log(JSON.stringify({ok:true,primaryCliProcesses:2,primaryRequests:14,toolCases:12,negativeControls:mutants.length,originalFailsAcceptance:true,diagnosticPassesAcceptance:true,applicationTestsRun:0}));
