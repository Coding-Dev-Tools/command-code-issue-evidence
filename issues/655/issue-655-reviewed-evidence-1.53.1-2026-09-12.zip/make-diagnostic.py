import sys,pathlib,shutil,hashlib,json
source=pathlib.Path(sys.argv[1]).resolve();target=pathlib.Path(sys.argv[2]).resolve()
assert source!=target and not target.exists(),'Use a new target directory; original package must remain unchanged'
blob=(source/'dist/cli.mjs').read_bytes();assert hashlib.sha256(blob).hexdigest()=='5cbe89ae1bc22aa2e5a15c5d69dda84dbae04369e381120fe4b27cda3c753fbd'
before=b'type:readString({input:e,key:"type"}),caseInsensitive:';after=b'type:readString({input:e,key:"type"})||void 0,caseInsensitive:'
assert blob.count(before)==1
shutil.copytree(source,target);(target/'dist/cli.mjs').write_bytes(blob.replace(before,after))
digest=hashlib.sha256((target/'dist/cli.mjs').read_bytes()).hexdigest();assert digest=='e317835d0eb21fe0a39ae5f508c5ba89aca169008074d75fdaa0c7849e3af347'
print(json.dumps({'diagnosticSha256':digest,'originalPreserved':True,'replacements':1}))
