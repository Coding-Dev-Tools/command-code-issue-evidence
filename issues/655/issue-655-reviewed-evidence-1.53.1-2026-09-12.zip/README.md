# Reproduce issue 655

Copy this entire directory to a fresh scratch directory. Retained results must not be overwritten. The primary run used Windows x64, Node24.15.0 and ripgrep15.1.0; see `ripgrep.json` for the tested executable hash and version. The binary is not included. Another platform/runtime or ripgrep build is a separate test variable.

To inspect saved evidence without installing dependencies, network or application execution:

```text
node verify-results.mjs
node assert-grep.mjs original-results.json
node assert-grep.mjs diagnostic-results.json
```

The second command intentionally exits1: the original empty-type call violates acceptance. The first and third exit0. `verify-results.mjs` also exercises seven corrupted-result controls.

For fresh application runs, create `runtime`, copy `runtime-package.json` to `runtime/package.json` and `runtime-package-lock.json` to `runtime/package-lock.json`, then run `npm ci --ignore-scripts --no-audit --no-fund` inside `runtime`. The lockfile pins command-code1.53.1 and resolved dependencies. Obtain the Windows MSVC executable from the [official ripgrep15.1.0 release](https://github.com/BurntSushi/ripgrep/releases/tag/15.1.0) and compare with `ripgrep.json`.

From the copied fixture directory, replace `RG_EXE_PATH` with its absolute path:

```text
node grep-probe.mjs runtime/node_modules/command-code runs/original "RG_EXE_PATH" native
python make-diagnostic.py runtime/node_modules/command-code runtime/node_modules/command-code-diagnostic
node grep-probe.mjs runtime/node_modules/command-code-diagnostic runs/diagnostic "RG_EXE_PATH" native
node assert-grep.mjs runs/original/raw.json
node assert-grep.mjs runs/diagnostic/raw.json
```

The original acceptance check should fail on `empty-log`; the diagnostic should pass all six cases. The diagnostic changes exactly one pinned byte sequence in a separate package copy. It is not an upstream implementation. Original package bytes remain intact.

Each probe starts an owned ephemeral localhost model endpoint and one CLI process, with six scripted grep inputs and a 45-second watchdog. It expects seven requests and caps them at nine. Configuration/home/project are synthetic; captures are outside the project. `--no-session` concerns only transcript behavior and is not an assertion that no sidecar is written. No real model or provider is contacted.

The preload guard restricts the Node CLI's network connections, while child-process permission enables the controlled ripgrep calls. This is not OS-level network or filesystem isolation. The spawn observer forwards the original call unchanged and records the generated shell command; it does not trace the nested executable's parsed argv. Fresh raw output includes shipped system prompts and local paths; minimize it before sharing.

`missing` backend mode is retained for the excluded exploration. Its omitted-type and valid-type positive controls failed; do not use that run as proof about the JavaScript fallback engine. The broad-glob pilot also remains in `exploratory-results.json`: `--glob "**/*"` caused the expected ripgrep glob override, so the primary valid-type control omits that glob.
