Reproduced on **command-code 1.53.1**, Windows x64 / Node **24.15.0**, with ripgrep **15.1.0**. The distinction is useful: **omitting `type` works; sending `type: ""` fails**, even with a valid log-file glob.

I used the actual CLI with scripted localhost model responses and a small project containing two matching log files, one JavaScript file and an excluded text file. The recorded shell command for the empty-string case includes:

```text
rg ... "ERROR_655" --type "" --glob "**/*.log" "."
```

| Tool input | Unmodified 1.53.1 | Diagnostic normalizing only the empty type |
|---|---|---|
| `type` omitted, `glob: "**/*.log"` | Both expected log matches | Same two matches |
| `type: ""`, same glob | `grep: rg: unrecognized file type:` | Both expected log matches |
| `type: "js"`, no glob | JavaScript match only | Same JavaScript match |
| `type: "text"` | Explicit unsupported-type error | Same error |
| `type: " "` | Explicit unsupported-type error | Same error |
| Pattern with no matches, log glob | `No matches found` | Same result |

The source boundary is small: `readString` preserves `""`, the grep input mapping retains it, and `buildRipgrepArguments` adds `--type` for every value other than `undefined`. An isolated one-site diagnostic converts the empty value to `undefined` at the grep input mapping. That removes the empty flag without changing supported types or hiding invalid nonempty types. No upstream source change is claimed.

The primary matrix contains **two clean CLI processes, twelve grep calls and fourteen localhost requests**. The executable acceptance check fails on the original empty-type call and passes all six diagnostic cases. It checks the actual queued inputs, matching tool-call IDs, tool success/error events, and returned file/line markers. Seven deliberately corrupted-result controls verify that missing matches, wrong call association, glob leakage and silently accepted invalid types are rejected.

One test detail matters: the valid-type control must omit a broad positive glob. For example, `--glob "**/*"` overrides ripgrep's type filtering and would make a supposed JavaScript-only control search other files too. The packet retains that exploratory result separately.

The prepared packet contains the pinned lockfile, fixture, shell-command captures, source/hash anchors, diagnostic and executable acceptance checks. The shell observer records the command passed by the CLI; it does not trace the nested ripgrep process's parsed argv. No paid inference or timeout. Native macOS and the JavaScript fallback search engine remain unvalidated; the separate missing-binary exploration did not pass its positive controls and is excluded from the primary result.
