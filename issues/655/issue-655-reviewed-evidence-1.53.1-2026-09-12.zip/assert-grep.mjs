import fs from 'node:fs';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
export const expectedCases=[
 {name:'omitted-log',args:{pattern:'ERROR_655',glob:'**/*.log',output_mode:'content'}},
 {name:'empty-log',args:{pattern:'ERROR_655',glob:'**/*.log',output_mode:'content',type:''}},
 {name:'valid-js',args:{pattern:'ERROR_655',output_mode:'content',type:'js'}},
 {name:'unknown-text',args:{pattern:'ERROR_655',glob:'**/*.log',output_mode:'content',type:'text'}},
 {name:'whitespace',args:{pattern:'ERROR_655',glob:'**/*.log',output_mode:'content',type:' '}},
 {name:'no-match',args:{pattern:'ABSENT_655',glob:'**/*.log',output_mode:'content'}},
];
export function assertGrep(row,{emptyShouldWork=true}={}){
 assert.equal(row.backend,'native');assert.deepEqual(row.exit,{code:0,signal:null});assert.equal(row.timedOut,false);
 assert.equal(row.guardReady,true);assert.equal(row.blockedNetwork,false);assert.deepEqual(row.violations,[]);
 assert.deepEqual(row.cases,expectedCases);assert.equal(row.requests.length,7);
 const result=row.events.filter(e=>e.type==='result');assert.equal(result.length,1);assert.equal(result[0].subtype,'success');assert.equal(result[0].finalText,'GREP_655_MATRIX_DONE');
 const events=row.events.map(e=>e.event).filter(Boolean),messages=row.requests.at(-1).body.messages;
 assert.equal(messages.filter(m=>m.role==='tool').length,6);
 for(const c of expectedCases){
  const id='call_'+c.name;
  const queued=events.filter(e=>e.type==='tool_queued'&&e.toolCallId===id);assert.equal(queued.length,1);assert.equal(queued[0].toolName,'grep');assert.deepEqual(queued[0].input,c.args);
  const calls=messages.flatMap(m=>m.tool_calls??[]).filter(t=>t.id===id);assert.equal(calls.length,1);assert.equal(calls[0].function.name,'grep');assert.deepEqual(JSON.parse(calls[0].function.arguments),c.args);
  const replies=messages.filter(m=>m.role==='tool'&&m.tool_call_id===id);assert.equal(replies.length,1);const output=replies[0].content;assert.equal(typeof output,'string');
  const terminal=events.filter(e=>['tool_completed','tool_errored'].includes(e.type)&&e.toolCallId===id);assert.equal(terminal.length,1);assert.equal(terminal[0].toolName,'grep');
  const expectError=['unknown-text','whitespace'].includes(c.name)||(c.name==='empty-log'&&!emptyShouldWork);
  assert.equal(terminal[0].type,expectError?'tool_errored':'tool_completed',c.name+' tool outcome');
  if(expectError){assert.match(output,/^grep: rg: unrecognized file type:/);assert.equal(terminal[0].error,output);continue;}
  if(c.name==='no-match'){assert.equal(output,'No matches found');continue;}
  if(c.name==='valid-js'){
   assert.match(output,/sample\.js:1:.*ERROR_655 JS_ONLY/);assert.ok(!/LOG_A|LOG_B|TXT_EXCLUDED/.test(output));
  }else{
   const lines=output.split(/\r?\n/);assert.equal(lines.length,2);
   assert.equal(lines.filter(s=>/app\.log:1:ERROR_655 LOG_A$/.test(s)).length,1);
   assert.equal(lines.filter(s=>/error\.log:2:ERROR_655 LOG_B$/.test(s)).length,1);
   assert.ok(!/JS_ONLY|TXT_EXCLUDED/.test(output));
  }
 }
 return {ok:true,cases:6,emptyShouldWork,applicationTestsRun:0};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
 const row=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
 try{console.log(JSON.stringify(assertGrep(row)))}catch(e){console.error(e.message);process.exitCode=1;}
}
