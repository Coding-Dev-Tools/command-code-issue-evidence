'use strict';
const fs = require('node:fs');
const cp = require('node:child_process');
const {syncBuiltinESMExports} = require('node:module');
const original = cp.spawn;
cp.spawn = function(command, args, options) {
  if (typeof command === 'string' && (command.includes('--color=never') || /(?:^|[\\/])rg(?:\.exe)?/.test(command))) {
    fs.appendFileSync(process.env.FIXTURE_SHELL_LOG, JSON.stringify({command, args, shell:options?.shell, cwd:options?.cwd})+'\n');
  }
  return Reflect.apply(original, this, arguments);
};
syncBuiltinESMExports();
