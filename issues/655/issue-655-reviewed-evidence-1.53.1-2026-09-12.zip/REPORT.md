# Current grep empty-type regression

The actual command-code1.53.1 CLI passes an explicit empty type through to a real ripgrep15.1.0 executable. It produces an unsupported-type error, whereas the same log glob with type omitted returns both known log matches. A one-site diagnostic at the grep input mapping converts only the empty value to undefined and restores the expected results.

Primary matrix: two clean CLI processes, twelve grep calls, fourteen localhost requests. No timeout, blocked network attempt or Windows shutdown abort. Fresh locked runtime, Windows x64 / Node24.15.0. The original and diagnostic have separate result files and bundle hashes.

| Input | Original | Diagnostic |
|---|---|---|
| Omitted type + log glob | LOG_A and LOG_B | LOG_A and LOG_B |
| Empty type + log glob | Explicit type error | LOG_A and LOG_B |
| js, no glob | JS_ONLY | JS_ONLY |
| text | Explicit type error | Explicit type error |
| One space | Explicit type error | Explicit type error |
| Genuine absent pattern + log glob | No matches found | No matches found |

The observer captures the CLI's actual command passed to the child-process API. The empty original command contains `--type ""`; the diagnostic command omits it. This capture is a shell-command string, not a trace of nested ripgrep argv. Source anchors show `readString` preserving the empty string, its propagation through the grep options, and the definedness check before the native flag.

Acceptance validates exact queued inputs, tool-call IDs, outcome event types, forwarded tool responses, two distinct file/line markers, valid-type narrowing, invalid-type errors and clean exit. Seven negative controls must fail: dropping a log match, changing the input, changing the call ID, replacing matches with false no-match, leaking an excluded file, falsely accepting an invalid type and changing the exit to nonzero. A successful final model answer alone is not a passing search result.

## Explorations and limits

Two earlier exploratory CLI processes each made six grep calls and seven localhost requests, both with clean exits. These are excluded from the primary count and retained in `exploratory-results.json`:

- A positive `**/*` glob overrode the valid js type, as native ripgrep's glob precedence allows. The final control omits the broad glob.
- A missing-binary setup returned no matches even for known matching positive controls. It did not establish successful fallback execution. Do not attribute its outputs to empty-type fallback filtering.

The primary Windows result adds current-version evidence to an older macOS report. Native macOS, actual model propensity to emit empty types, fallback engine behavior and production-provider execution are untested. The diagnostic does not define a new whitespace policy or silently accept unsupported nonempty types. No public post, released fix or team adoption is claimed by this packet.
