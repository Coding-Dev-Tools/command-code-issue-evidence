import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const [packageArg,outArg,rgArg,backend='native']=process.argv.slice(2);
assert.ok(packageArg&&outArg&&rgArg);assert.ok(['native','missing'].includes(backend));
const packageRoot=fs.realpathSync(packageArg),runtimeRoot=path.dirname(packageRoot),rg=fs.realpathSync(rgArg),out=path.resolve(outArg);
assert.ok(!fs.existsSync(out),'Each run must have a new output directory');
const project=path.join(out,'project logs'),home=path.join(out,'home'),tmp=path.join(home,'tmp'),shellLog=path.join(out,'shell.jsonl');
for(const p of [project,tmp,path.join(project,'nested'),path.join(home,'.commandcode'),path.join(home,'AppData/Roaming'),path.join(home,'AppData/Local')])fs.mkdirSync(p,{recursive:true});
fs.writeFileSync(path.join(project,'app.log'),'ERROR_655 LOG_A\nclean\n');
fs.writeFileSync(path.join(project,'nested','error.log'),'clean\nERROR_655 LOG_B\n');
fs.writeFileSync(path.join(project,'sample.js'),'// ERROR_655 JS_ONLY\n');
fs.writeFileSync(path.join(project,'exclude.txt'),'ERROR_655 TXT_EXCLUDED\n');
const cases=[
 {name:'omitted-log',args:{pattern:'ERROR_655',glob:'**/*.log',output_mode:'content'}},
 {name:'empty-log',args:{pattern:'ERROR_655',glob:'**/*.log',output_mode:'content',type:''}},
 {name:'valid-js',args:{pattern:'ERROR_655',output_mode:'content',type:'js'}},
 {name:'unknown-text',args:{pattern:'ERROR_655',glob:'**/*.log',output_mode:'content',type:'text'}},
 {name:'whitespace',args:{pattern:'ERROR_655',glob:'**/*.log',output_mode:'content',type:' '}},
 {name:'no-match',args:{pattern:'ABSENT_655',glob:'**/*.log',output_mode:'content'}},
];
const hash=b=>createHash('sha256').update(b).digest('hex'),requests=[],sent=[],violations=[];
const server=http.createServer((req,res)=>{
 let body='';req.on('data',b=>{body+=b;if(body.length>2_000_000)req.destroy()});
 req.on('end',()=>{
  if(req.method!=='POST'||req.url!=='/v1/chat/completions'){violations.push('unexpected-route');res.writeHead(404).end();return;}
  let payload;try{payload=JSON.parse(body)}catch{violations.push('invalid-json');res.writeHead(400).end();return;}
  requests.push({bodySha256:hash(body),body:payload});
  if(requests.length>9){violations.push('request-cap');res.writeHead(400).end('{}');return;}
  const replies=(payload.messages??[]).filter(m=>m.role==='tool'),done=new Set(replies.map(m=>m.tool_call_id));
  const next=cases.find(c=>!done.has('call_'+c.name));
  const tools=(payload.tools??[]).map(t=>t.function?.name);
  if(next&&!tools.includes('grep')){violations.push('grep-not-declared');res.writeHead(400).end('{}');return;}
  res.writeHead(200,{'Content-Type':'text/event-stream'});
  const chunk=(delta,finish_reason=null)=>{const event={id:'fixture-'+requests.length,object:'chat.completion.chunk',created:1,model:'model',choices:[{index:0,delta,finish_reason}],...(finish_reason?{usage:{prompt_tokens:100,completion_tokens:10,total_tokens:110}}:{})};sent.push(event);res.write('data: '+JSON.stringify(event)+'\n\n')};
  if(next){chunk({role:'assistant',tool_calls:[{index:0,id:'call_'+next.name,type:'function',function:{name:'grep',arguments:JSON.stringify(next.args)}}]});chunk({},'tool_calls');}
  else {chunk({role:'assistant',content:'GREP_655_MATRIX_DONE'});chunk({},'stop');}
  res.end('data: [DONE]\n\n');
 });
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port,provider='grep-fixture',model=provider+'/model';
fs.writeFileSync(path.join(home,'.commandcode/providers.json'),JSON.stringify({provider:{[provider]:{api:'openai-completions',baseURL:`http://127.0.0.1:${port}/v1`,apiKey:'$FIXTURE_PROVIDER_KEY',models:{model:{contextWindow:200000,maxOutput:500,cost:{input:0,output:0}}}}}}));
fs.writeFileSync(path.join(home,'.commandcode/config.json'),JSON.stringify({model,provider,localOnly:true,telemetry:false,tasteLearning:false}));
const env={};for(const k of ['SystemRoot','WINDIR','ComSpec','PATHEXT','PROCESSOR_ARCHITECTURE'])if(process.env[k])env[k]=process.env[k];
env.PATH=[path.dirname(process.execPath),...(backend==='native'?[path.dirname(rg)]:[]),path.join(process.env.SystemRoot??'/','System32')].join(path.delimiter);
Object.assign(env,{HOME:home,USERPROFILE:home,APPDATA:path.join(home,'AppData/Roaming'),LOCALAPPDATA:path.join(home,'AppData/Local'),TEMP:tmp,TMP:tmp,CMD_LOCAL_ONLY:'1',DO_NOT_TRACK:'1',OTEL_SDK_DISABLED:'true',COMMANDCODE_SKIP_UPDATES:'1',COMMANDCODE_DISABLE_CRON:'1',COMMANDCODE_DISABLE_DURABLE_CRON:'1',DOTENV_CONFIG_PATH:path.join(home,'absent.env'),NO_COLOR:'1',FIXTURE_PORT:String(port),FIXTURE_PROVIDER_KEY:'synthetic-unused',COMMAND_CODE_API_KEY:'synthetic-unused',FIXTURE_SHELL_LOG:shellLog,COMMAND_CODE_RIPGREP_PATH:backend==='native'?rg:path.join(out,'missing-rg.exe')});
const cliArgs=['--no-auto-update','--local-only','--skip-onboarding','--trust','--no-skills','--no-session','--model',model,'--max-turns','9','--output-format','json','--print','Run the six synthetic grep fixture requests, then finish.'];
const nodeArgs=['--permission','--allow-child-process',`--allow-fs-read=${runtimeRoot}`,`--allow-fs-read=${root}`,`--allow-fs-read=${out}`,`--allow-fs-read=${path.dirname(rg)}`,`--allow-fs-write=${out}`,'--require',path.join(root,'offline-guard.cjs'),'--require',path.join(root,'observe-shell.cjs'),path.join(packageRoot,'dist/index.mjs'),...cliArgs];
const child=spawn(process.execPath,nodeArgs,{cwd:project,env,windowsHide:true,stdio:['ignore','pipe','pipe']});let stdout='',stderr='',timedOut=false;
child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
const timer=setTimeout(()=>{timedOut=true;child.kill()},45000);
const exit=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('close',(code,signal)=>resolve({code,signal}))});clearTimeout(timer);
server.closeAllConnections();await new Promise(r=>server.close(r));
const events=stdout.split(/\r?\n/).flatMap(s=>{try{return[JSON.parse(s)]}catch{return[]}});
const shell=fs.existsSync(shellLog)?fs.readFileSync(shellLog,'utf8').trim().split('\n').filter(Boolean).map(JSON.parse):[];
const result={at:new Date().toISOString(),backend,node:process.version,platform:process.platform,arch:process.arch,cliVersion:JSON.parse(fs.readFileSync(path.join(packageRoot,'package.json'),'utf8')).version,bundleSha256:hash(fs.readFileSync(path.join(packageRoot,'dist/cli.mjs'))),ripgrepSha256:hash(fs.readFileSync(rg)),cases,cliArgs,exit,timedOut,guardReady:stderr.includes('offline-guard-ready'),blockedNetwork:stderr.includes('blocked-network'),stdout,stderr,events,requests,sent,shell,violations};
fs.writeFileSync(path.join(out,'raw.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({backend,exit,timedOut,requests:requests.length,shellCommands:shell.length,toolResults:requests.at(-1)?.body.messages.filter(m=>m.role==='tool'),results:events.filter(e=>e.type==='result'),stderrTail:stderr.slice(-450),resultPath:path.join(out,'raw.json')}));
assert.deepEqual(violations,[]);assert.ok(!timedOut&&result.guardReady&&!result.blockedNetwork);
