# Issue #651: PowerShell command missing from approval prompt

Issue: https://github.com/CommandCodeAI/command-code/issues/651

Investigation date: 2026-09-06. Suggested priority: **P1**, because default-mode users cannot inspect a proposed PowerShell command before authorizing it. This is a prioritization recommendation, not an existing issue label. The issue remains open; no issue fields or comments were changed in this investigation.

## Verified outcome

The actual interactive Command Code 1.49.1 CLI on a Windows TTY omitted the PowerShell command, target path, flags and working directory from its approval prompt. The prompt showed the tool name. A paired `shell_command` fixture displayed its supplied command and working directory. Both used default permission mode and an owned localhost provider returning deterministic tool calls.

Before-denial captures establish the visibility comparison. Both raw terminal traces then contained the CLI status `Permission denied`, following Escape. Neither proposed marker file existed before or after. Node permissions independently blocked every subprocess; the test did not approve or execute the PowerShell command. Therefore marker absence is not, by itself, proof of unguarded denial enforcement.

The initial PowerShell fixture remained idle after its denial and hit its own 45-second cleanup deadline. This is a fixture cleanup limitation, not evidence of a Command Code hang. The shell control was terminated by the fixture after detecting its denial status. These termination results do not negate the captured pre-decision prompt comparison.

## Root cause and repair boundary

The published bundle's `buildToolPermissionRequest` sends PowerShell through the generic request path. `buildGenericToolPermissionRequest` retains toolName and optional description but discards the input. The outer builder preserves risk. The generic renderer receives no command or cwd to display. With on-demand descriptions enabled by default, prose can also be absent; `input.description` is not itself the separately generated permission explanation.

Repair both the request contract and presentation: preserve the authoritative command and supplied execution parameters, then display them independently of generated prose. Keeping the existing generic policy path is the narrowest display-focused repair. A dedicated presentational command component can be shared without also sharing policy choice construction.

Moving PowerShell into the shell category has additional effects: shell-specific automatic decisions and command-derived `Shell(...)` approval rules replace the generic decision-store path and whole-tool remembered approval. This review establishes a behavioral difference, not an exploitable bypass. Any deliberate policy migration requires separate validation.

Exact function locations and the adapter/service/UI route appear in `permission-source-review.md`. `independent-validation.md` documents saved-rule and classifier differences.

## Extracted request-builder regression

`request-preservation-test.mjs` executes only bounded, exact functions from hash-pinned published bundles in a fresh VM context. It does not import the application or execute tool commands. The real file-tool registry is extracted too. Untested file and kill branches are not exercised or stubbed into successful results.

| Version | PowerShell command omitted | Shell/monitor command retained |
| --- | ---: | ---: |
| 1.14.1 | 6/6 | 12/12 |
| 1.49.1 | 6/6 | 12/12 |

All 36 cases passed against the expected defect/control behavior. Each version tests three distinct command shapes, with descriptions present and absent, through three tool kinds. Shapes include a quoted path and literal `-Force:$false`, multiline text and a long path. The fixture also checks that input is unchanged, risk survives, and no explanation callback runs. The PowerShell request loses cwd and the lazy explanation callback as well as the command. Shell controls preserve command, cwd and the expected explanation callback.

These tests establish data preservation, not all terminal widths, explanation failure modes or rendered long-command readability. The historical 1.14.1 application was not run interactively. The current 1.49.1 CLI was run interactively for the two paired tool cases.

## Provenance

On 2026-09-06, npm's latest tag was 1.49.1. The installed bundle hash matches the previously integrity-verified published 1.49.1 bundle. The historical 1.14.1 package was downloaded without installation and verified against npm's SHA512 integrity. No product files or user configuration were edited.

| Version | SHA256 of dist/cli.mjs |
| --- | --- |
| 1.14.1 | ce237300d1df027cce9bdc4cb8af32ac2ae915f74d3fd9b387aedc184eec7c27 |
| 1.49.1 | 10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05 |

Runtime: Node v24.15.0, Windows TTY. Synthetic home/config/provider, zero real provider credentials or paid inference. The mock model fixes the requested tool/input; it does not test model command-generation quality. This observation does not establish a Windows 10 versus 11 distinction.

## Maintainer acceptance

1. Preserve and show the exact command, cwd and relevant execution options before approval. The display must not derive command text from an explanation.
2. Keep command visibility independent of description presence, on-demand configuration, loading or generation failure.
3. Preserve quoted paths, dollar signs, flags, redirections and newlines. Make full multiline/long commands inspectable in narrow terminals.
4. Verify that rendering never executes commands, denial prevents execution, and one-time/project decisions, risk handling and stored rule scope remain correct.
5. Retain the existing shell display as a positive control.

## Evidence handling

`GITHUB-COMMENT.md` is the prepared comment. Curated evidence includes scripts, result summaries, narrow source pointers and redacted terminal excerpts. Raw model requests, full bundled system prompts, synthetic home/session data, package tarballs and full application bundles are excluded from the shareable archive. Four depth-1 reviewers supplied bounded results; the parent performed integration and final verification.
