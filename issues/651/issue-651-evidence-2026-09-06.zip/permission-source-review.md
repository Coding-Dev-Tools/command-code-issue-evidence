# Issue 651: published permission path review

Reviewed the published Command Code 1.49.1 bundle at `artifacts/issue-725/published/package/dist/cli.mjs`, SHA-256 `10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05`. This review is static; the parent separately tests extracted components. No product files, user configuration, credentials, permissions, or GitHub comments were changed.

## Finding

The actual command is discarded when the permission request is built, before rendering. `buildToolPermissionRequest` classifies `shell_command`, `monitor_command`, and `kill_shell` as shell requests. `powershell` reaches its generic fallback. The file-tool set `WT` contains only `write_file` and `edit_file`.

The fallback invokes `buildGenericToolPermissionRequest({toolName, description})`, which returns those fields only. It drops `input.command`, `input.cwd`, arguments, and the lazy `explain` callback. The enclosing builder preserves risk. The generic renderer can therefore show a tool name, risk, and an optional description, but cannot show the actual command.

The full route is `createPermissions` confirmation -> `buildInteraction.confirmTool` -> `buildToolPermissionRequest` -> generic permission service -> `usePermissionMode.onGenericPermissionRequest` -> `PermissionView2` -> `GenericPermissionPrompt` (`XD`). The shell route preserves command, args, workingDirectory, and optional explanation. `usePermissionMode.onShellPermissionRequest` normalizes the pending top-level toolName to `shell_command`, so a corrected builder classification could already reach the existing shell renderer without adding a separate PowerShell branch to `PermissionView2`.

## Exact extraction locations

Offsets are zero-based UTF-16 code units, with exclusive ends, in the exact bundle above. The minified bundle has very long lines; offsets are the useful locator.

| Unit | Start | End | Notes |
|---|---:|---:|---|
| buildShellToolPermissionRequest | 1081077 | 1081502 | Preserves command/args/cwd/description/explain |
| buildGenericToolPermissionRequest | 1081913 | 1082027 | Drops the tool input and explain |
| buildToolPermissionRequest | 1082027 | 1082556 | Root omission: no powershell classification |
| buildInteraction | 2419383 | 2420875 | Selects shell/generic/file service |
| usePermissionMode | 2436445 | 2437666 | Shell callback normalizes pending toolName |
| GenericPermissionPrompt assignment | 2057502 | 2058421 | Includes `XD=__name(...)` assignment and semicolon |
| ShellPermissionPrompt assignment | 2076319 | 2078625 | Includes `sN=__name(...)` assignment and semicolon |
| PermissionView2 marker through wrapper tail | 2078988 | 2080495 | Includes closing `,"PermissionView"));`; not a standalone function extraction |
| getCommandDisplay | 1077787 | 1077904 | Joins command and optional args; no truncation |
| getShellPermissionChoices | 1076644 | 1077208 | Command-derived persistent allow rules |
| getGenericToolPermissionChoices | 1077208 | 1077489 | Persistent allow for the whole tool |
| gateToolDescriptionGenerator | 871160 | 871305 | Suppresses automatic description when onDemand is true |
| createToolDescriptionGenerator | 871305 | 871940 | Separate model-produced prose, returns null on failure |
| createPermissionDecisionStore | 1069034 | 1076194 | Different shell vs generic persistence behavior |

`WT=new Set(["write_file","edit_file"])` begins at 1796453. The PowerShell tool schema name appears at 1505112; its `command` is the actual PowerShell text, and its optional `description` is documented as text displayed while the command runs.

## Display and description distinctions

The shell prompt unconditionally renders `getCommandDisplay(request)` in its subtitle and renders `workingDirectory` separately when supplied. The optional prose description is another element. No string truncation occurs in that component or helper, although actual terminal layout still requires rendering checks.

The generic prompt uses only `request.toolName`, `request.description`, and `request.risk`. Adding a PowerShell branch to the renderer alone cannot recover a command that the builder already discarded.

For this permission path, `checkPermissions` obtains an optional generated description separately from the tool input. `createPermissions` passes both the original input and that description into confirmation. `createToolDescriptionGenerator` asks a model for a cleaned one-line explanation and may return null. It does not supply authoritative command text. With the default `onDemandToolDescriptions` setting, the gate returns null instead of generating prose; the shell request can retain a lazy explanation callback, but the generic builder drops it. Thus the current generic prompt may contain only the tool name when prose is absent, or prose without the command when a description is supplied/generated.

## Fix and acceptance boundaries

Routing PowerShell through the shell builder is a plausible repair, but it changes more than appearance: the shell decision store derives command rules, whereas generic project approval stores the entire tool name. Review PowerShell command parsing and persistence deliberately. An alternative is to preserve authoritative command fields in the generic request and display them while retaining its existing approval semantics. The invariant is that the actual command is visible before a decision; a generated explanation must never substitute for it.

Focused acceptance: PowerShell text, paths, flags, quoting, pipes, redirections, and working directory remain visible before approval; both description-present and description-absent/on-demand/failure cases work; multiline/narrow terminal layout is usable; shell_command remains correct; denial does not execute the command; one-time/project approvals retain the intended and accurately labeled scope. Parent component tests can establish request and render behavior; they do not establish full live CLI execution or Windows Terminal layout unless those are separately exercised.

## Live discussion supporting the distinction

- Reporter identifies 1.14.1, Windows Terminal, PowerShell 7, and missing arguments: https://github.com/CommandCodeAI/command-code/issues/651#issuecomment-5230699207
- Follow-up points out that the maintainer screenshot also lacks the PowerShell command, confirms Windows 10: https://github.com/CommandCodeAI/command-code/issues/651#issuecomment-5362054997
- Same commenter contrasts Bash showing its actual command: https://github.com/CommandCodeAI/command-code/issues/651#issuecomment-5362494696

The source path matches the PowerShell-versus-Bash distinction. It does not support attributing the omission to a Windows 10/11 difference or terminal escaping alone.
