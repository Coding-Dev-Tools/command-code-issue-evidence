# Issue #651 evidence

Prepared 2026-09-06 for https://github.com/CommandCodeAI/command-code/issues/651.

Start with `REPORT.md` for the integrated result and limits, or `GITHUB-COMMENT.md` for the ready-to-post comment. No comment was posted by this investigation.

The observed defect is the current 1.49.1 PowerShell approval prompt dropping the supplied command; `shell_command` displays its command in the paired interactive control. `cli-feasibility/CLI-CAPTURE-summary.md` links the redacted before-denial terminal excerpts and verification. These are captured terminal text, not screenshots.

## Reproduce the isolated request-builder comparison

Use Node.js and obtain the exact published bundles listed in `provenance.json`. Download/extract the npm tarballs without installing or executing them. Verify their listed SHA512 integrity and `dist/cli.mjs` SHA256 before running the test. Full packages are deliberately excluded from this archive.

```text
node request-preservation-test.mjs --historical=C:/path/to/1.14.1/package/dist/cli.mjs --current=C:/path/to/1.49.1/package/dist/cli.mjs
```

Expected result: 36 cases pass against the recorded defect/control behavior; 12 PowerShell cases omit command and 24 shell/monitor controls preserve it. This imports only extracted pure functions, never the application or proposed commands. Hash mismatches stop the fixture.

## Reproduce the guarded interactive comparison

Follow `cli-feasibility/RUN-INSTRUCTIONS.md`. The probe requires an actual Windows TTY and the 1.49.1 CLI, creates a synthetic home and localhost provider, and prohibits subprocess creation. Capture the permission prompt, then press Escape to deny. Do not approve the proposed command. `verify-captures.mjs` verifies the resulting local traces and generates the shareable excerpts.

The original PowerShell run reached its fixture cleanup deadline after the CLI displayed denial. The shell control stopped after detecting its denial. Guarded marker absence is separate from an unguarded execution-prevention test. Real provider behavior, historical full-CLI rendering, a product patch, all terminal layouts and saved-permission migration were not tested.

## Archive contents and integrity

`MANIFEST.json` lists included file sizes and SHA256 hashes. Only reports, narrow source pointers, reproduction/verification scripts, metadata and redacted excerpts are included. Raw model requests/system prompts, raw terminal/event traces, synthetic homes, full npm bundles and package tarballs remain outside the archive. To independently verify captures, reproduce the probe to create fresh raw local traces, then run the verifier.
