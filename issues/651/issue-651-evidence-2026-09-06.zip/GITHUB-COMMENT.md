Retested on **Command Code 1.49.1** on Windows, in default permission mode. This still reproduces in the actual interactive CLI with a deterministic localhost provider fixture:

- **`powershell`:** the approval prompt says `Command Code needs to run powershell.` but omits the supplied command, target path, flags and working directory.
- **`shell_command` control:** the prompt displays the command, target path, flags and working directory.

Both prompts were captured before denial; the CLI then displayed `Permission denied`. Neither test marker was created. The fixture also independently blocked subprocess creation, so this verifies the visibility problem without executing the proposed commands or using real provider credentials. It is not an unguarded execution/denial test.

**Root-cause pointer in the published bundle:** `buildToolPermissionRequest` sends PowerShell to the generic permission path. `buildGenericToolPermissionRequest` retains only `toolName` and optional description, discarding the input before `GenericPermissionPrompt` renders it. Risk is preserved by the outer builder. Updating the renderer alone cannot recover the missing command. With the default on-demand explanation setting, the prompt can show only the tool name.

Exact extracted-builder tests reproduce the loss in **1.14.1 and 1.49.1**: 12/12 PowerShell cases dropped the command; all 24 `shell_command`/`monitor_command` controls retained it. Cases covered descriptions present/absent, quoted paths with literal `-Force:$false`, multiline commands and long commands. These are data-preservation tests, not terminal-layout tests of every case.

**Suggested fix:** retain the authoritative PowerShell input in the permission request and display its exact command, supplied cwd and execution options before approval, independently of the optional explanation. Preserve the existing permission choices and saved-rule semantics. Simply routing PowerShell through the shell category also changes permission classification and persistence (`powershell` tool approval versus generated `Shell(...)` rules), so that would need separate policy validation.

Acceptance: command visibility with descriptions present/absent/failed; complete quoted, multiline and long commands inspectable in narrow terminals; denial prevents execution; risk handling and remembered-approval scope remain correct; existing shell display stays intact.
