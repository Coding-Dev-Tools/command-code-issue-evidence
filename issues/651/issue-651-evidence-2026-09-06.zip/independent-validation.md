# Issue #651: independent permission-policy review

Reviewed 2026-09-06 as the fourth, depth-1 reviewer. No descendant delegation, external posting, real credentials, product edits, or PowerShell command execution were used. This is a source review of the proposed repair and the available evidence, not a claim of complete end-to-end regression coverage.

## Verdict

Retain the PowerShell command and execution parameters when building its permission request, then display the raw command alongside the explanation. Keep the existing generic permission category and its decision semantics for this display fix, or explicitly test and document any intentional policy migration.

Simply adding `powershell` to the shell-kind branch changes more than the visible prompt. The category selects a different decision-store entry point before the UI renders; that entry point has different automatic decisions, remembered permission keys, and persistent rule generation.

## Exact source evidence

Inspected installed `command-code` 1.49.1 `dist/cli.mjs`, SHA256 `10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05`. Locations below are zero-based UTF-16 offsets in that exact bundle, not source line numbers. Function names are more useful for the maintainers' original source tree.

| Location | Observation | Repair implication |
| --- | --- | --- |
| `buildToolPermissionRequest`, 1082027; `buildGenericToolPermissionRequest`, 1081913 | `powershell` falls through to generic. The generic builder receives only tool name and description; it drops input before UI rendering. | A renderer-only change cannot recover the command. Preserve the input in the request/adapter contract too. |
| Adapter call to `buildToolPermissionRequest`, 2419728 | `kind === "shell"` calls `requestShellPermission`; generic calls `requestGenericPermission`. | Moving PowerShell to shell kind changes the service path, not just presentation. |
| `createPermissionDecisionStore`, 1069034–1076194 | Generic project approval invokes `addPermissionToSettings(e.toolName)`, records trusted tool names and tool-name keys. Shell project approval invokes `shellPermissionRulesForCommand`, records trusted shell rules and command/argument keys. | Preserve generic approval behavior for a display-only repair. Do not describe category migration as behavior-neutral. |
| Same store, `requestShellPermission` / `isTrustedCommand` | The shell entry point evaluates read-only shell classification and trusted shell-command rules before prompting. Generic evaluates trusted tools and generic caches instead. | A category change adds a different opportunity for an automatic decision. This is a source-level policy difference; this review does not claim an exploitable bypass. |
| `isReadOnlyOperation`, 750362 | The upstream permission layer explicitly uses `isReadonlyPowerShellCommand` for `powershell`. | The shell store's `isReadonlyShellCommand` and `classifyShellCommand` are not a PowerShell-specific substitute. If category migration is intentional, test their combined behavior for PowerShell syntax. |
| `getGenericToolPermissionChoices`, 1077208; `getShellPermissionChoices`, 1076644 | Generic project choice says not to ask again for the tool. Shell project choice describes the exact command or generated command families. | Reusing the shell renderer must not silently replace the permission choices or make their text disagree with what is saved. |
| `shellPermissionRulesForCommand`, 1068393–1069034 | Produces `Shell(...)` rules using shell classification and parsing; the generic path writes a bare tool name instead. | Verify saved allow-rule format and scope, not merely that the same buttons are visible. |
| `getPermissionChoicesForRisk`, 1076533; decision-store risk branches | A request with risk removes scoped choices and requests one-off confirmation. | Retain risk metadata and its forced-confirmation behavior while adding display fields. |

The upstream rule engine can also consume existing settings. This review does **not** claim that changing the downstream category necessarily invalidates all existing `powershell` rules; the verified point is that downstream persistence and decision behavior differ and need intentional validation.

## Minimum acceptance controls

1. Use the same PowerShell input for the existing and repaired request pipeline. Assert the exact `command` string reaches the pending permission request and appears before any decision. Include the original quoted path and `-Force:$false` example; do not derive the command from an AI explanation.
2. Show the description as additional context. Command visibility must also work with no description, on-demand explanation disabled, explanation pending, and explanation failure. Command display must not call the explanation generator as a prerequisite.
3. Preserve meaningful execution input such as supplied `cwd`, timeout and background mode. Show the PowerShell input command, rather than an unrelated reconstructed Bash command or only an opaque encoded wrapper. Test quotes, dollar signs, redirections, multiline text and paths with spaces. A generic structured fallback must retain false, zero, empty strings, arrays and nested values.
4. Keep command visibility and readability under a narrow terminal and with a long command tail. Full content must be inspectable before approval. A string-preservation assertion alone does not prove that terminal rendering makes the whole command visible.
5. Capture the actual No selection and resulting denial response. Assert execution was not called; marker-file absence is an additional control. Request rendering itself must have no command-execution side effects.
6. Preserve one-off Yes, No, project approval, stored rule format and scope. Test the next different PowerShell command after a remembered approval, and the next invocation after settings reload. Test existing allow and deny settings without claiming all historical settings are covered.
7. Retain risk metadata, forced confirmation and removal of remembered-approval choices. Cover default mode; verify the display repair does not alter mode transitions or auto-approval decisions.
8. Keep `shell_command` as a positive control. If implementing a shared presentational command component, keep policy choice construction outside it and check that Bash's existing command display and approval semantics remain intact.

## Evidence interpretation

The initial available real-CLI fixture result (`cli-feasibility/powershell-result.json`, read during this review) showed a 45-second timeout terminated with SIGTERM and the marker file absent. The fixture also blocks every subprocess through Node permissions. That result can support captured prompt observations and safe nonexecution; by itself it cannot establish that the UI accepted No and propagated a denial. Use a later successful denial capture if produced, or state that limitation plainly.

Likewise, a synthetic localhost provider makes the CLI tool request deterministic but does not test a real model's command generation or explanation accuracy. Neither is required to establish that the request builder discards an already supplied command.

Reports reviewed: `history-and-acceptance-review.md` and the initial CLI result. Parent-owned extracted-function tests and any later interactive results require their own validation record.

### Parent integration verification

The parent subsequently read both raw ANSI captures. Each contains its distinct pre-decision prompt followed by the CLI's `Permission denied` status. PowerShell's initial fixture timeout happened after that recorded denial, while the shell fixture cleaned up after detecting its denial status. This resolves the narrow question of whether denial appeared in the actual UI; the independent subprocess guard still means marker absence alone does not prove unguarded execution prevention. The parent separately ran the exact request-builder fixture: 36 cases, with all 12 PowerShell command-preservation checks reproducing the omission and all 24 shell/monitor controls preserving the command. Full integration and limitations are recorded in `REPORT.md`.
