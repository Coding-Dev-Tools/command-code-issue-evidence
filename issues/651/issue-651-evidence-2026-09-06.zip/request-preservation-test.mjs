import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';

// Executes only the named, bounded functions extracted from the published bundles.
// It does not import the CLI, contact a provider, or execute any proposed command.
const here = path.dirname(fileURLToPath(import.meta.url));
const arg = name => process.argv.find(x => x.startsWith(`--${name}=`))?.slice(name.length + 3);
const targets = [
  ['1.14.1', arg('historical') ?? path.join(here, 'published-1.14.1/package/dist/cli.mjs'), 'ce237300d1df027cce9bdc4cb8af32ac2ae915f74d3fd9b387aedc184eec7c27'],
  ['1.49.1', arg('current') ?? path.join(process.env.APPDATA, 'npm/node_modules/command-code/dist/cli.mjs'), '10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05'],
];
const inputs = [
  { label: 'quoted-path-and-literal-false', input: { command: "New-Item -ItemType File -Path 'C:\\fixture dir\\permission-test.tmp' -Force:$false", cwd: 'C:\\fixture dir', timeout: 1700, run_in_background: false } },
  { label: 'multiline-command', input: { command: "$target = 'C:\\fixture dir\\permission-test.tmp'\nNew-Item -ItemType File -Path $target -Force:$false", cwd: 'C:\\fixture dir', timeout: 1700, run_in_background: false } },
  { label: 'long-command', input: { command: "New-Item -ItemType File -Path 'C:\\fixture dir\\" + 'nested folder\\'.repeat(20) + "permission-test.tmp' -Force:$false", cwd: 'C:\\fixture dir', timeout: 1700, run_in_background: false } },
];
const result = { kind: 'exact-extracted-request-builder-test', versions: [], cases: [], execution: 'No proposed command executed; no network; explanation callback never called.' };

for (const [version, bundlePath, expectedHash] of targets) {
  const bytes = fs.readFileSync(bundlePath);
  const sha256 = crypto.createHash('sha256').update(bytes).digest('hex');
  assert.equal(sha256, expectedHash, `Unexpected ${version} bundle: verify provenance before adapting this fixture`);
  const source = bytes.toString('utf8');
  const offsets = {};
  const extract = (name, nextName) => {
    const begin = source.indexOf(`function ${name}(`);
    const end = source.indexOf(`function ${nextName}(`, begin + 1);
    assert.ok(begin >= 0 && end > begin && end - begin < 2000);
    offsets[name] = { startUtf16: begin, endUtf16Exclusive: end };
    return source.slice(begin, end);
  };
  const helpers = extract('objectInput', 'getFileToolPermissionAction');
  const shell = extract('buildShellToolPermissionRequest', 'buildFileToolPermissionRequest');
  const generic = extract('buildGenericToolPermissionRequest', 'buildToolPermissionRequest');
  const dispatcher = extract('buildToolPermissionRequest', 'getFileActionToolName');
  const registryName = dispatcher.match(/:([\w$]+)\.has\(e\)\?/)[1];
  const setPattern = new RegExp(`${registryName.replace(/\$/g, '\\$')}=new Set\\((\\[[^\\]]+\\])\\)`);
  const setMatch = source.match(setPattern);
  assert.ok(setMatch, 'Must use the actual bundled file-tool registry');
  const context = vm.createContext({});
  const functionCode = `const __name=(fn)=>fn; const ${registryName}=new Set(${setMatch[1]});\n${helpers}\n${shell}\n${generic}\n${dispatcher}\nglobalThis.make=buildToolPermissionRequest;`;
  vm.runInContext(functionCode, context, { timeout: 1000 });
  let explanationCalls = 0;
  const explain = () => { explanationCalls++; throw Error('Must not generate explanation while building a request'); };

  for (const { label, input } of inputs) {
    for (const description of [undefined, 'Create a new file without overwriting']) {
      for (const toolName of ['powershell', 'shell_command', 'monitor_command']) {
        const before = JSON.stringify(input);
        const request = context.make({ toolName, input, description, risk: 'fixture-risk', explain });
        assert.equal(JSON.stringify(input), before, 'Builder must not modify source input');
        assert.equal(request.request.risk, 'fixture-risk');
        if (toolName === 'powershell') {
          assert.equal(request.kind, 'generic');
          assert.deepEqual(Object.keys(request.request).sort(), description ? ['description', 'risk', 'toolName'] : ['risk', 'toolName']);
          assert.equal(request.request.command, undefined);
          assert.equal(request.request.input, undefined);
          assert.equal(request.request.workingDirectory, undefined);
          assert.equal(request.request.explain, undefined);
        } else {
          assert.equal(request.kind, 'shell');
          assert.equal(request.request.command, input.command);
          assert.equal(request.request.workingDirectory, input.cwd);
          assert.equal(request.request.description, description);
          assert.equal(request.request.explain, description ? undefined : explain);
        }
        result.cases.push({ version, label, toolName, descriptionPresent: !!description, requestKind: request.kind, commandPreserved: request.request.command === input.command, cwdPreserved: request.request.workingDirectory === input.cwd, requestKeys: Object.keys(request.request), pass: true });
      }
    }
  }
  assert.equal(explanationCalls, 0);
  result.versions.push({ version, sha256, extractionOffsets: offsets, fileToolRegistry: JSON.parse(setMatch[1]), extractedCodeSha256: crypto.createHash('sha256').update(functionCode).digest('hex') });
}
result.summary = { cases: result.cases.length, passed: result.cases.filter(x => x.pass).length, powershellCommandsLost: result.cases.filter(x => x.toolName === 'powershell' && !x.commandPreserved).length, shellControlCommandsRetained: result.cases.filter(x => x.toolName !== 'powershell' && x.commandPreserved).length };
fs.writeFileSync(path.join(here, 'request-preservation-results.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result.summary, null, 2));
