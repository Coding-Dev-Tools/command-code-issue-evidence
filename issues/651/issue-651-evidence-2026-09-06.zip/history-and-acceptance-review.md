# Issue #651: published-version and acceptance review

Reviewed 2026-09-06. This worker performed static inspection and read the current discussion; interactive and rendered-component evidence is being produced separately.

## Current discussion

The report identifies 1.14.1, Windows Terminal, PowerShell 7, and default permission mode. The template's Unknown/cmd.exe fields were reported as uneditable and should not override the explicit environment statement.

The maintainer requested a screenshot on August 9. The reporter supplied one and a complete New-Item example, and said they denied the request. August 20 comments distinguish Bash's visible command from the PowerShell tool's missing command; the Windows 10 screenshot was challenged as showing the same problem. No subsequent maintainer resolution or fixed-version confirmation appears in the current discussion. Windows 10 versus 11 is not established as the deciding factor.

Source: https://github.com/CommandCodeAI/command-code/issues/651

## Published-version comparison

Downloaded npm command-code 1.14.1 without installing it. The tarball's SHA512 matched the registry dist.integrity. Metadata is in `published-1.14.1/provenance.json`.

| Published bundle | SHA256 |
| --- | --- |
| 1.14.1 | ce237300d1df027cce9bdc4cb8af32ac2ae915f74d3fd9b387aedc184eec7c27 |
| 1.49.1 | 10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05 |

In both bundles:

- `buildGenericToolPermissionRequest` returns only toolName and optional description. Its function text is identical between these versions; it has no input field.
- `buildToolPermissionRequest` routes shell_command and monitor_command to the shell request, kill_shell to its specialized request, recognized file tools to file requests, and other tools to the generic request. PowerShell is not included in the shell branch.
- `GenericPermissionPrompt` renders tool name, optional risk, optional description, and choices. It does not render command, cwd, or arbitrary input.
- `ShellPermissionPrompt` renders `getCommandDisplay(request)` and optional working directory as well as explanation.
- The PowerShell schema's executable text is the `command` string; `cwd`, `timeout`, and `run_in_background` are separate arguments.

Current package changelog has no entry explicitly claiming this PowerShell command-visibility issue is fixed. Absence from the changelog is not itself proof; the unchanged request and renderer paths are the stronger evidence.

## Repair recommendation

Preserve complete tool input in the permission request and render the exact PowerShell command and supplied cwd before approval, independently of the optional description. A generic structured-input fallback would address other generic tools whose arguments are currently discarded too, but that can be scoped separately if the immediate patch is PowerShell-specific.

JSON is a useful lossless fallback, not a requirement that a PowerShell command must appear as escaped JSON. A dedicated verbatim, wrapped command view is easier to inspect. Keep all meaningful argument values, including false, zero, empty strings, nested arrays, and paths, in any structured fallback.

Avoid casually routing PowerShell through the shell permission kind solely to reuse its renderer: generic and shell prompts have different remembered-approval choices and rule formats. A display fix should preserve existing permission decisions and saved-rule behavior unless changing them is intentional and separately tested.

## Acceptance boundaries

1. In default mode, the complete command appears before approval for the reporter's benign New-Item example. Keep description visible as additional context.
2. Command visibility does not depend on description being present, on on-demand explanation configuration, or on explanation success.
3. Preserve quotes, backslashes, flags, literal dollar signs, redirections, and newlines. Long commands and narrow terminals must wrap or offer full expansion before approval without silently dropping the command tail.
4. Show supplied cwd and other execution-changing parameters. If a generic fallback is included, cover nested values and false/zero values rather than only string arguments.
5. The displayed command is the same command value passed to execution. Rendering and requesting approval must not execute it. Denial must leave the benign test file absent.
6. Retain shell_command as a positive control. Approval choices, persistent permission rules, and permission modes must remain unchanged by the display repair.

These are acceptance recommendations. They are not claims that all terminal widths, explanation states, approval semantics, or command execution paths were runtime-tested by this review.

No real credentials, inference, product edits, comments, or descendant delegation were used.
