# Issue 651: actual Windows CLI permission dialogs

Pristine published Command Code **1.49.1**, Node **v24.15.0**, Windows, real stdin/stdout/stderr TTY. Both runs used `--permission-mode default`, a fresh synthetic home per tool, and a synthetic model served only by the fixture's own localhost endpoint. The installed product was not modified.

| Forced tool | What the real permission dialog displayed | Decision recorded after capture |
|---|---|---|
| `powershell` | “Tool Permission” / “Command Code needs to run powershell.” No command, flags, target path, working directory, supplied description, or explanation shortcut. | Escape (`1b`), followed by rendered **“Permission denied”**. |
| `shell_command` | Full `powershell.exe -NoProfile -NonInteractive -Command "New-Item ... -Force"` command, target path, working directory, and Ctrl+E explanation shortcut. Supplied description was not displayed. | Escape (`1b`), followed by rendered **“Permission denied”**. |

The proposed operation was a harmless `New-Item` targeting `never-approved.txt` in each fixture's own scratch directory. Neither command was approved or executed. The marker was absent before and after both runs. Independently, the Node permission model prohibited **all** child process launches by the CLI and restricted writes to the fixture directory; this was not an unguarded test proving denial alone suppresses execution.

Each run made one request to `/v1/chat/completions` on the fixture's own localhost server, which returned the synthetic tool call. No real provider, credentials, model inference, or paid API was used. The raw model requests stay local because they include the product's full system prompt. `verified-summary.json` contains only request metadata, hashes, synthetic command data, and capture findings.

The PowerShell run remained idle after the captured denial and was stopped at the fixture's 45-second deadline (45,026 ms). Its SIGTERM is cleanup, **not** evidence of denial or a product finding. The actual denial evidence is the ordered event trace: dialog line 18, Escape input line 23, rendered “Permission denied” line 24. The shell control was stopped by the fixture after recording denial (32,293 ms); its corresponding event lines are 19, 23, and 24. These are one-based JSONL line numbers, verified by `verify-captures.mjs`. Later Ctrl+C inputs in the first run occurred only after denial; no approval input was sent in either run.

The two `*-before-denial.txt` files are excerpts from the real terminal output with terminal control sequences removed and the absolute local user path replaced by `<FIXTURE_ROOT>`. Line wrapping is retained except inside the redacted path. They are terminal captures, not screenshots or reconstructed component renders. The two `*-denial.txt` files contain the captured decision and subsequent rendered denial status.

CLI bundle SHA-256: `10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05`.

## Curated publication files

- `CLI-CAPTURE-summary.md`
- `RUN-INSTRUCTIONS.md`
- `verified-summary.json`
- `powershell-before-denial.txt`
- `powershell-denial.txt`
- `shell_command-before-denial.txt`
- `shell_command-denial.txt`
- `interactive-probe.mjs`
- `capture-preload.cjs`
- `offline-guard.cjs`
- `verify-captures.mjs`

Exclude `*-requests.json`, `*-capture.ansi`, `*-events.jsonl`, `*-result.json`, `.commandcode`, both synthetic homes, and scratch directories. Preserve those locally for audit. The verification script reads local raw evidence; rerunning the fixture recreates it.
