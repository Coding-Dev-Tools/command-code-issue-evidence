# Reproduce the guarded permission dialog capture

Use Windows, Node v24.15.0, and the pristine globally installed `command-code` 1.49.1 package under `%APPDATA%\npm\node_modules\command-code`. Place the scripts in a disposable fixture directory. Run from a real terminal, with stdin, stdout, and stderr attached to its TTY. The installed CLI is only read; the fixture does not modify it or read the user's Command Code configuration.

The harness creates a separate synthetic home and scratch directory for each mode, installs fake keys into an allowlisted child environment, and creates its own localhost mock provider. Node's permission model restricts filesystem access to the fixture and installed package and permits **no child processes**. The preload permits network access only to the fixture's exact localhost port; `data:` URLs remain available for embedded WASM. This is a guarded UI test, not an unguarded command execution test.

1. Run `node interactive-probe.mjs powershell`.
2. Wait until the actual “Tool Permission” dialog is fully visible. Capture/inspect it **before** providing input.
3. Press **Escape once**. Never press Enter, Yes, or an approval shortcut. Confirm the UI displays **“Permission denied”**. The harness then stops only its owned CLI child.
4. Run `node interactive-probe.mjs shell_command`; repeat the same before-denial capture and Escape decision.
5. Run `node verify-captures.mjs` to create the sanitized excerpts and `verified-summary.json` from the local raw evidence.

Each run has an owned 45-second timeout. If the UI never reaches a permission dialog, let that timeout clean up; do not approve anything or weaken the guards. The marker's existence is checked before startup, and the harness refuses to run if it already exists. A repeated run overwrites that mode's local captures, so preserve any existing evidence first.

The current harness stops after it records “Permission denied.” The original captured PowerShell run preceded that cleanup watcher and reached its timeout while idle **after** the recorded denial; its original raw result is preserved. This cleanup difference does not change either captured permission dialog.

Do not publish the entire fixture directory. Model request files contain the product's full system prompt. Publish only the explicit curated file list in `CLI-CAPTURE-summary.md`.
