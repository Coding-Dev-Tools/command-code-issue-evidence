'use strict';
require('./offline-guard.cjs');
const fs = require('node:fs');
const capture = process.env.FIXTURE_CAPTURE;
const events = process.env.FIXTURE_EVENTS;
const append = (stream, text) => {
  fs.appendFileSync(capture, text);
  fs.appendFileSync(events, JSON.stringify({ stream, at: Date.now(), text }) + '\n');
};
for (const name of ['stdout', 'stderr']) {
  const stream = process[name];
  const original = stream.write;
  stream.write = function (chunk, ...args) {
    append(name, Buffer.isBuffer(chunk) ? chunk.toString() : String(chunk));
    return original.call(this, chunk, ...args);
  };
}
const originalEmit = process.stdin.emit;
process.stdin.emit = function (event, ...args) {
  if (event === 'data') fs.appendFileSync(events, JSON.stringify({ stream: 'stdin', at: Date.now(), hex: Buffer.from(args[0]).toString('hex') }) + '\n');
  return originalEmit.call(this, event, ...args);
};
fs.appendFileSync(events, JSON.stringify({ event: 'tty-state', stdin: process.stdin.isTTY, stdout: process.stdout.isTTY, stderr: process.stderr.isTTY }) + '\n');
