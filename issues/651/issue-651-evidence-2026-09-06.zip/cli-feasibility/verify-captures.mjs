import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { stripVTControlCharacters } from 'node:util';
import { createHash } from 'node:crypto';

// Read local raw evidence, then publish only the permission dialog and synthetic
// metadata. Never copy model messages or the full system prompt into the summary.
const root = path.dirname(fileURLToPath(import.meta.url));
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const clean = stripVTControlCharacters;
const runs = [];
for (const name of ['powershell', 'shell_command']) {
  const eventPath = path.join(root, `${name}-events.jsonl`);
  const events = fs.readFileSync(eventPath, 'utf8').trim().split('\n').map(JSON.parse);
  const result = JSON.parse(fs.readFileSync(path.join(root, `${name}-result.json`)));
  const requests = JSON.parse(fs.readFileSync(path.join(root, `${name}-requests.json`)));
  const tty = events.find(x => x.event === 'tty-state');
  assert.equal(tty.stdin, true); assert.equal(tty.stdout, true); assert.equal(tty.stderr, true);
  const inputIndex = events.findIndex(x => x.stream === 'stdin');
  assert(inputIndex >= 0); assert.equal(events[inputIndex].hex, '1b');
  const title = name === 'powershell' ? 'Tool Permission' : 'Execute Shell Command';
  const dialogIndex = events.findLastIndex((x, i) => i < inputIndex && clean(x.text ?? '').includes(title));
  assert(dialogIndex >= 0);
  let dialog = clean(events[dialogIndex].text);
  dialog = dialog.slice(dialog.indexOf(title)).trim();
  const denialIndex = events.findIndex((x, i) => i > inputIndex && clean(x.text ?? '').includes('Permission denied'));
  assert(denialIndex > inputIndex);
  // Escape is the only permission decision input. Any Ctrl+C below was later
  // cleanup after the already-rendered denial; it was never an approval.
  assert(events.slice(inputIndex + 1, denialIndex).every(x => x.stream !== 'stdin'));
  assert(events.filter(x => x.stream === 'stdin').every(x => ['1b', '03', '0303'].includes(x.hex)));
  assert.equal(requests.length, 1);
  assert.equal(requests[0].path, '/v1/chat/completions');
  assert(requests[0].body.tools.some(x => x.function?.name === name));
  assert.equal(result.markerExistedBefore, false); assert.equal(result.markerExistsAfter, false);
  assert.equal(fs.existsSync(result.marker), false);
  const checks = ['New-Item', '-ItemType', '-Force', 'never-approved.txt', 'Working directory:', 'ctrl+e'];
  const expectedVisible = name === 'shell_command';
  for (const token of checks) assert.equal(dialog.includes(token), expectedVisible, `${name}: ${token}`);
  assert.equal(dialog.includes(result.toolInput.description), false);
  // Match the wrapping paths structurally; a literal root replacement would
  // miss terminal-inserted newlines in "artifacts" and "issue-651".
  dialog = dialog.replace(/C:\\Users\\[\s\S]*?never-approved\.txt/g, '<FIXTURE_ROOT>\\scratch-shell_command\\never-approved.txt');
  dialog = dialog.replace(/Working directory: C:\\Users\\[\s\S]*?scratch-shell_command/g, 'Working directory: <FIXTURE_ROOT>\\scratch-shell_command');
  assert(!dialog.includes('C:\\Users\\'));
  fs.writeFileSync(path.join(root, `${name}-before-denial.txt`), `${dialog}\n`);
  const denyText = clean(events[denialIndex].text);
  const denialExcerpt = denyText.slice(denyText.indexOf('Permission denied')).split('\n')[0].trim();
  fs.writeFileSync(path.join(root, `${name}-denial.txt`), `Captured stdin decision: Escape (hex 1b)\nNext rendered status: ${denialExcerpt}\n`);
  runs.push({
    tool: name, node: result.node, cliVersion: '1.49.1', cliSha256: result.cliSha256,
    realTTY: { stdin: tty.stdin, stdout: tty.stdout, stderr: tty.stderr },
    permissionMode: 'default', modelRequests: requests.length,
    requestSummary: { path: requests[0].path, model: requests[0].body.model, selectedToolDeclared: true, declarationCount: requests[0].body.tools.length, rawFileSha256: hash(path.join(root, `${name}-requests.json`)), rawFileExcludedFromPublication: true },
    proposedCommand: name === 'powershell' ? "New-Item -ItemType File -Path '<FIXTURE_ROOT>\\scratch-powershell\\never-approved.txt' -Force" : "powershell.exe -NoProfile -NonInteractive -Command \"New-Item -ItemType File -Path '<FIXTURE_ROOT>\\scratch-shell_command\\never-approved.txt' -Force\"",
    proposedDescription: result.toolInput.description,
    prompt: { commandVisible: expectedVisible, flagsVisible: expectedVisible, targetPathVisible: expectedVisible, cwdVisible: expectedVisible, explanationShortcutVisible: expectedVisible, suppliedDescriptionVisible: false },
    evidenceOrder: { dialogEvent: dialogIndex + 1, escapeInputEvent: inputIndex + 1, denialRenderedEvent: denialIndex + 1, indicesAreOneBasedJSONLLines: true },
    decisionInputHex: '1b', denialStatus: 'Permission denied', noApprovalInput: true,
    markerAbsentBeforeAndAfter: true,
    executionBoundary: 'All CLI child process launches independently prohibited by Node permission model. This is not an unguarded execution-suppression test.',
    cleanup: { signal: result.signal, elapsedMs: result.elapsedMs, timedOut: result.timedOut, reason: result.timedOut ? 'Owned 45-second harness deadline while CLI was idle after recorded denial.' : 'Owned child stopped after capture watcher observed rendered denial.' },
    rawEventFileSha256: hash(eventPath),
  });
}
assert.equal(runs[0].cliSha256, runs[1].cliSha256);
const summary = { scope: 'Actual published CLI permission dialog capture with synthetic localhost provider. Escape was sent only after each real dialog had rendered.', runs, limitations: ['Captured terminal output is not a screenshot.', 'The CLI network, filesystem, and child processes were guarded; no real provider or inference was used.', 'Neither proposed command was approved or executed. Marker absence and subprocess prohibition are separate from the recorded denial status.', 'Powershell cleanup reached the owned 45-second deadline after denial. SIGTERM alone is not evidence of denial.', 'Raw model requests, raw full terminal streams, synthetic homes, and system prompts remain local and are excluded from the publication file list.'] };
fs.writeFileSync(path.join(root, 'verified-summary.json'), JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify({ verified: true, runs: runs.map(x => ({tool:x.tool, commandVisible:x.prompt.commandVisible, denialStatus:x.denialStatus, markerAbsent:x.markerAbsentBeforeAndAfter})) }));
