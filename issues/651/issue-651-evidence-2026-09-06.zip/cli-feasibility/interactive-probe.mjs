import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { stripVTControlCharacters } from 'node:util';

const root = path.dirname(fileURLToPath(import.meta.url));
const installedRoot = path.join(process.env.APPDATA, 'npm/node_modules/command-code');
const toolName = process.argv[2] ?? 'powershell';
if (!['powershell', 'shell_command'].includes(toolName)) throw new Error('Unsupported fixture mode');
const home = path.join(root, `home-${toolName}`);
const tmp = path.join(home, 'tmp');
const scratch = path.join(root, `scratch-${toolName}`);
const marker = path.join(scratch, 'never-approved.txt');
const capture = path.join(root, `${toolName}-capture.ansi`);
const eventFile = path.join(root, `${toolName}-events.jsonl`);
const resultFile = path.join(root, `${toolName}-result.json`);
for (const dir of [tmp, scratch, path.join(home, '.commandcode'), path.join(home, 'AppData/Roaming'), path.join(home, 'AppData/Local')]) fs.mkdirSync(dir, { recursive: true });
if (fs.existsSync(marker)) throw new Error('Precondition failed: proposed marker already exists');
fs.writeFileSync(capture, '');
fs.writeFileSync(eventFile, '');
const psCommand = `New-Item -ItemType File -Path '${marker.replaceAll("'", "''")}' -Force`;
const command = toolName === 'powershell' ? psCommand : `powershell.exe -NoProfile -NonInteractive -Command "${psCommand}"`;
const toolInput = { command, description: 'Create one local permission-test marker file', cwd: scratch, timeout: 1000 };
const requests = [];
let child;
let timedOut = false;
let denialObserved = false;
const server = http.createServer((req, res) => {
  let raw = '';
  req.on('data', chunk => { raw += chunk; if (raw.length > 2_000_000) req.destroy(); });
  req.on('end', () => {
    if (!req.url.endsWith('/chat/completions')) { res.writeHead(404); res.end(); return; }
    const body = JSON.parse(raw);
    requests.push({ path: req.url, body });
    fs.writeFileSync(path.join(root, `${toolName}-requests.json`), JSON.stringify(requests, null, 2));
    const delta = requests.length === 1
      ? { role: 'assistant', tool_calls: [{ index: 0, id: 'call_permission_fixture', type: 'function', function: { name: toolName, arguments: JSON.stringify(toolInput) } }] }
      : { role: 'assistant', content: 'DENIAL_RECEIVED. No test command needs to run.' };
    const finish = requests.length === 1 ? 'tool_calls' : 'stop';
    res.writeHead(200, { 'Content-Type': 'text/event-stream' });
    const base = { id: `fixture-${requests.length}`, object: 'chat.completion.chunk', created: 1, model: 'permission-fixture' };
    res.write(`data: ${JSON.stringify({ ...base, choices: [{ index: 0, delta, finish_reason: null }] })}\n\n`);
    res.write(`data: ${JSON.stringify({ ...base, choices: [{ index: 0, delta: {}, finish_reason: finish }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } })}\n\n`);
    res.end('data: [DONE]\n\n');
  });
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const port = server.address().port;
const model = 'strict-probe/permission-fixture';
fs.writeFileSync(path.join(home, '.commandcode/providers.json'), JSON.stringify({ provider: { 'strict-probe': { api: 'openai-completions', baseURL: `http://127.0.0.1:${port}/v1`, apiKey: '$FIXTURE_PROVIDER_KEY', models: { 'permission-fixture': { contextWindow: 200000, maxOutput: 200, cost: { input: 0, output: 0 } } } } } }, null, 2));
fs.writeFileSync(path.join(home, '.commandcode/config.json'), JSON.stringify({ model, provider: 'strict-probe', localOnly: true, telemetry: false }, null, 2));
fs.writeFileSync(path.join(home, '.commandcode/settings.json'), JSON.stringify({ disableScratchpad: true, disableSkillShellExecution: true, permissions: { defaultMode: 'default' } }, null, 2));
const env = {};
for (const key of ['SystemRoot', 'WINDIR', 'ComSpec', 'PATHEXT', 'PROCESSOR_ARCHITECTURE']) if (process.env[key]) env[key] = process.env[key];
env.PATH = [path.dirname(process.execPath), path.join(process.env.SystemRoot, 'System32')].join(path.delimiter);
Object.assign(env, { HOME: home, USERPROFILE: home, APPDATA: path.join(home, 'AppData/Roaming'), LOCALAPPDATA: path.join(home, 'AppData/Local'), TEMP: tmp, TMP: tmp,
  CMD_LOCAL_ONLY: '1', DO_NOT_TRACK: '1', OTEL_SDK_DISABLED: 'true', COMMANDCODE_SKIP_UPDATES: '1', COMMANDCODE_DISABLE_CRON: '1', COMMANDCODE_DISABLE_DURABLE_CRON: '1',
  DOTENV_CONFIG_PATH: path.join(home, 'missing.env'), NO_COLOR: '1', TERM: 'xterm-256color', FIXTURE_PORT: String(port), FIXTURE_PROVIDER_KEY: 'synthetic-provider-key-not-real', COMMAND_CODE_API_KEY: 'synthetic-command-key-not-real', FIXTURE_CAPTURE: capture, FIXTURE_EVENTS: eventFile });
const args = ['--no-auto-update', '--local-only', '--skip-onboarding', '--trust', '--no-skills', '--model', model, '--permission-mode', 'default', '--max-turns', '3', 'Request the synthetic permission check. Wait for my permission decision.'];
const nodeArgs = ['--permission', `--allow-fs-read=${installedRoot}`, `--allow-fs-read=${root}`, `--allow-fs-write=${root}`, '--require', path.join(root, 'capture-preload.cjs'), path.join(installedRoot, 'dist/index.mjs'), ...args];
const initial = { toolName, args, command, toolInput, marker, markerExistedBefore: false,
  parentTTY: { stdin: process.stdin.isTTY, stdout: process.stdout.isTTY, stderr: process.stderr.isTTY },
  node: process.version, cliSha256: createHash('sha256').update(fs.readFileSync(path.join(installedRoot, 'dist/cli.mjs'))).digest('hex'),
  scope: 'Real interactive CLI, synthetic own-localhost provider, default permission mode; Node permission model blocks every child process. Never approve the proposed command.' };
fs.writeFileSync(resultFile, JSON.stringify(initial, null, 2));
console.log(JSON.stringify({ event: 'fixture-start', toolName, marker, ...initial.parentTTY }));
child = spawn(process.execPath, nodeArgs, { cwd: root, env, windowsHide: true, stdio: 'inherit' });
const started = Date.now();
const timer = setTimeout(() => { timedOut = true; child.kill(); }, 45000);
const denialWatcher = setInterval(() => {
  const text = stripVTControlCharacters(fs.readFileSync(capture, 'utf8'));
  if (!denialObserved && text.includes('Permission denied')) {
    denialObserved = true;
    // End only this fixture's child after the real UI has recorded denial.
    child.kill();
  }
}, 100);
const exit = await new Promise(resolve => child.on('close', (code, signal) => resolve({ code, signal })));
clearTimeout(timer);
clearInterval(denialWatcher);
server.closeAllConnections();
await new Promise(resolve => server.close(resolve));
const final = { ...initial, ...exit, elapsedMs: Date.now() - started, timedOut, denialObserved, cleanupAfterDenial: denialObserved, modelRequests: requests.length, markerExistsAfter: fs.existsSync(marker) };
fs.writeFileSync(resultFile, JSON.stringify(final, null, 2));
console.log(JSON.stringify({ event: 'fixture-finished', ...final }));
