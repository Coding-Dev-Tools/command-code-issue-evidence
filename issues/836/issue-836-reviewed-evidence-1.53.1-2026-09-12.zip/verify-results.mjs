import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const data=JSON.parse(fs.readFileSync(path.join(root,'observations.json'),'utf8'));
const text=m=>typeof m?.content==='string'?m.content:(m?.content??[]).filter(b=>b.type==='text').map(b=>b.text).join('');
const matching=(messages,role,marker)=>messages.filter(m=>m.role===role&&text(m).includes(marker));
export function verifyCase(row){
 const {markers:m,mode,variant}=row,initial=row.processes[0],files=row.afterInitial.filter(f=>f.kind==='transcript');
 assert.deepEqual(row.violations,[]);
 for(const p of row.processes){assert.equal(p.timedOut,false);assert.equal(p.guardReady,true);assert.equal(p.blockedNetwork,false);if(p.exit.code===3221226505)assert.ok(p.stderr.includes('UV_HANDLE_CLOSING'));else assert.ok([0,1].includes(p.exit.code));}
 assert.ok(initial.result?.finalText===m.assistant||initial.stdoutFinalMarker===m.assistant,'Initial answer must actually complete');
 assert.equal(matching(row.requests[0].messages,'user',m.user).length,1);
 if(mode==='no-session-json'){assert.equal(files.length,0);assert.equal(row.processes.length,1);assert.ok(row.afterInitial.every(f=>f.kind==='checkpoint'));return;}
 const messages=files.flatMap(f=>f.records.filter(r=>r.type==='message').map(r=>r.message));
 const assistantCount=matching(messages,'assistant',m.assistant).length;
 if(variant==='flush-diagnostic'){
  assert.equal(files.length,1);assert.ok(files[0].bytes>0);assert.equal(matching(messages,'user',m.user).length,1);assert.equal(assistantCount,1);
  assert.ok(messages.findIndex(r=>r.role==='user'&&text(r).includes(m.user))<messages.findIndex(r=>r.role==='assistant'&&text(r).includes(m.assistant)));
  const ids=files[0].records.filter(r=>r.type==='message').map(r=>r.message.meta?.messageId);assert.equal(new Set(ids).size,ids.length);assert.ok(ids.every(Boolean));
  const resumed=row.requests.find(r=>r.phase==='resume');assert.ok(resumed);assert.equal(matching(resumed.messages,'assistant',m.assistant).length,1);assert.equal(matching(resumed.messages,'user',m.user).length,1);assert.equal(matching(resumed.messages,'user',m.followup).length,1);
  const rp=row.processes.find(p=>p.label==='resume');assert.equal(rp.exit.code,0);if(rp.result)assert.equal(rp.result.sessionId,row.sessionId);
  const resumedFiles=row.afterResume.filter(f=>f.kind==='transcript');assert.equal(resumedFiles.length,1);const rm=resumedFiles[0].records.filter(r=>r.type==='message').map(r=>r.message);assert.equal(matching(rm,'assistant',m.response).length,1);assert.equal(matching(rm,'assistant',m.assistant).length,1);
 }else{
  assert.equal(assistantCount,0,'Recorded original failure must show missing final answer');
  if(mode.startsWith('no-tool')){assert.equal(files.length,0);assert.equal(row.processes.find(p=>p.label==='resume').exit.code,1);assert.equal(row.requests.filter(r=>r.phase==='resume').length,0);}
  else{assert.equal(matching(messages,'user',m.user).length,1);const resumed=row.requests.find(r=>r.phase==='resume');assert.ok(resumed);assert.equal(matching(resumed.messages,'assistant',m.assistant).length,0);}
 }
 if(mode==='no-tool-json'){
  const cp=row.processes.find(p=>p.label==='continue'),cr=row.requests.find(r=>r.phase==='continue');assert.ok(cp&&cr);assert.equal(cp.exit.code,0);
  if(variant==='flush-diagnostic'){assert.equal(cp.result.sessionId,row.sessionId);assert.equal(matching(cr.messages,'assistant',m.assistant).length,1);assert.equal(matching(cr.messages,'assistant',m.response).length,1);}
  else{assert.notEqual(cp.result.sessionId,row.sessionId);assert.equal(matching(cr.messages,'assistant',m.assistant).length,0);}
 }
 if(['read-json','tool-error-json','blocked-write-json'].includes(mode)){
  const completion=initial.toolOutcomes.find(t=>t.toolCallId==='call_target_836');assert.ok(completion);const result=JSON.stringify(completion);
  if(mode==='read-json'){assert.equal(completion.type,'tool_completed');assert.equal(completion.toolName,'read_file');assert.ok(result.includes('LOCAL_READ_CONTROL_836'));assert.ok(!result.includes('repair_note'));}
  if(mode==='tool-error-json'){assert.equal(completion.type,'tool_errored');assert.ok(result.includes('File not found or not readable'));}
  if(mode==='blocked-write-json'){assert.equal(completion.type,'tool_hook_blocked');assert.ok(result.includes('requires permissions'));}
 }
}
assert.equal(data.observations.length,12);for(const row of data.observations)verifyCase(row);
const baseline=data.observations.find(r=>r.variant==='flush-diagnostic'&&r.mode==='no-tool-json');
const mutations=[
 ['assistant stored under wrong role',r=>{r.afterInitial.find(f=>f.kind==='transcript').records.find(x=>x.message?.role==='assistant').message.role='user';}],
 ['old assistant absent from resumed request',r=>{const request=r.requests.find(x=>x.phase==='resume');request.messages=request.messages.filter(m=>m.role!=='assistant');}],
 ['duplicate assistant persisted',r=>{const f=r.afterInitial.find(f=>f.kind==='transcript');f.records.push(structuredClone(f.records.find(x=>x.message?.role==='assistant')));}],
 ['resume used a new session',r=>{r.processes.find(p=>p.label==='resume').result.sessionId='wrong-session';}],
 ['failed initial run',r=>{r.processes[0].result.finalText='';}],
];
for(const [name,mutate]of mutations){const r=structuredClone(baseline);mutate(r);assert.throws(()=>verifyCase(r),undefined,name);}
console.log(JSON.stringify({ok:true,cases:12,negativeControls:mutations.length,applicationTestsRun:0,meaning:'Saved evidence verifies original loss and diagnostic persistence; no new product run.'}));
