# Reproduce #836

Copy this entire files directory into a fresh scratch directory before running. Never overwrite retained evidence. Use Node 24.15.0 on Windows x64 for the recorded platform. All application inputs and keys are synthetic; the network guard allows only the fixture's ephemeral localhost port. This is not OS-level network isolation. A different OS/runtime is a separate test variable.

Create a `runtime` directory; copy `runtime-package.json` to `runtime/package.json` and `runtime-package-lock.json` to `runtime/package-lock.json`, then run `npm ci --ignore-scripts --no-audit --no-fund` in that directory. The application package path is `runtime/node_modules/command-code`. No private development package is needed. The lockfile pins resolved dependencies; `provenance.json` pins the bundle hash.

`node verify-results.mjs` verifies the included saved evidence without network or product execution. Fresh probes write full captures only inside their new scratch directories; the saved observations are not silently overwritten. Review and minimize fresh output before sharing: raw requests include the shipped system prompt and local fixture paths.

```text
node persistence-probe.mjs runtime/node_modules/command-code fresh-original no-tool-json
node persistence-probe.mjs runtime/node_modules/command-code fresh-original no-tool-text
node persistence-probe.mjs runtime/node_modules/command-code fresh-original read-json
node persistence-probe.mjs runtime/node_modules/command-code fresh-original tool-error-json
node persistence-probe.mjs runtime/node_modules/command-code fresh-original blocked-write-json
node persistence-probe.mjs runtime/node_modules/command-code fresh-original no-session-json
python run-matrix.py flush-diagnostic no-tool-json no-tool-text read-json tool-error-json blocked-write-json no-session-json
```

The Python runner copies the package and applies exactly the recorded one-site diagnostic. It never edits the original package. Each CLI process has a 30-second watchdog; each scenario has a 15-request cap. A watchdog result is inconclusive, not a persistence failure. Captures are outside the project so the model cannot read the answer from them. See REPORT.md for exact-ID resume, continue and shutdown qualifications.

Run `node assert-persistence.mjs PATH/TO/FRESH/raw.json` for the product persistence acceptance check. It accepts fresh probe output without a package-version expectation and fails if completed messages or fresh-process replay are lost. Initial-process shutdown is a separate check; the saved tool runs retain their aborts.

Against retained evidence, `node assert-persistence.mjs observations.json original` exits 1 with five failed ordinary cases (`--no-session` passes). `node assert-persistence.mjs observations.json flush-diagnostic` exits 0 for all six cases. These commands assert desired persistence, whereas `verify-results.mjs` verifies the recorded before/after findings.


The [second-cohort review](REVIEW.md) contains the double-check results, qualifications and complete post. Run `node verify-review.mjs` to validate its saved evidence.
