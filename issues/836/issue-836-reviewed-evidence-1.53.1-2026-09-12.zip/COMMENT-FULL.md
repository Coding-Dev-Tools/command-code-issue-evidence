Reproduced a related persistence failure on **command-code 1.53.1**, Windows x64 / Node **24.15.0**, using the actual CLI with an isolated home and a scripted localhost model. The useful additional finding is that **tool activity can produce a nonempty transcript while still losing the final assistant reply**.

| Completed first turn | Unmodified 1.53.1 | Isolated diagnostic awaiting the existing flush |
|---|---|---|
| No tools, JSON or text output | Main transcript missing; checkpoint exists | User and final assistant messages persisted |
| Successful read, failed read, or permission-blocked write | Earlier messages persisted; final assistant reply absent | Completed exchange persisted and replayed in fresh-process resume |
| `--no-session` | No main transcript | No main transcript |

I repeated all six scenarios against both variants from the exported test packet and a fresh locked installation. Across the two cohorts: **48 CLI processes / 56 localhost requests**. All five ordinary original cases fail the persistence acceptance check; all five diagnostic cases pass, with the no-session control also passing. The check inspects message roles, order, unique IDs, session identity and the next process’s outgoing request. It does not rely on the model claiming to remember.

**The source boundary is commit → queued writes → explicit process exit.** The engine calls `onCommit` before deciding to stop, and the recorder appends messages without a tool-use requirement. The session store queues asynchronous writes. `runPrintMode` awaits `harness.dispose()` but omits the separately exposed `harness.flush()`; its caller subsequently executes `process.exit(o.exitCode)`.

Changing only that finalizer in a diagnostic package restored persistence and fresh-process replay:

```js
// Existing finalizer
finally { await harness.dispose().catch(() => {}); }

// Tested diagnostic concept; not a production-ready patch
finally {
  await harness.flush();
  await harness.dispose().catch(() => {});
}
```

A long generation followed by polling after exit does not by itself exclude this failure: the final write is queued at commit, and an exited process cannot finish it. A production fix should still guarantee disposal if flushing rejects and define how write errors affect the result. The store’s queue tail currently absorbs rejected writes, so awaiting it alone does **not** prove durable success under disk failure.

**Missing and empty transcripts need separate resume tests.** A naturally missing transcript fails visibly with exit 1 on my host, before any model request. In an additional two-process control, I deliberately created a zero-byte transcript at the emitted session ID before resuming. The unchanged CLI then exited 0 with a successful result, sent neither original message to the model, and emitted no missing/empty-history warning. This is explicit filesystem fault injection; I have not reproduced natural zero-byte creation on the reported Linux/Node combination.

The regression should cover both original markers exactly once after exit, both in the fresh `--resume` request, and persistence of the resumed answer. The JSON `--continue` control should retain the same session ID and both completed exchanges. Missing/empty transcripts should have an explicit failure or warning policy. File size alone will miss the tool-turn failure.

Qualifications: twelve tool processes across the two cohorts emitted results and then hit Windows `UV_HANDLE_CLOSING`; the flush diagnostic does not fix that abort. No watchdog timeout or live-provider inference. `--no-session` still writes a checkpoint sidecar in both variants, so that control concerns only the main transcript. Native Linux/macOS, interactive mode, cancellation and disk failures remain untested.

The prepared reproduction packet includes the locked runtime, exact source/hash anchors, both cohorts, the empty-file control and executable acceptance checks. CLI SHA256: `5cbe89ae1bc22aa2e5a15c5d69dda84dbae04369e381120fe4b27cda3c753fbd`.
