import fs from 'node:fs';
import assert from 'node:assert/strict';
const row = JSON.parse(fs.readFileSync(new URL('./empty-transcript-observations.json', import.meta.url), 'utf8'));
function verify(r) {
  assert.equal(r.injectedEmptyTranscript.bytes, 0);
  assert.equal(r.injectedEmptyTranscript.sessionId, r.sessionId);
  assert.equal(r.afterInitial.filter(f => f.kind === 'transcript').length, 0);
  const injected = r.afterInjection.filter(f => f.kind === 'transcript');
  assert.equal(injected.length, 1); assert.equal(injected[0].bytes, 0); assert.deepEqual(injected[0].records, []);
  assert.equal(r.processes.length, 2);
  for (const p of r.processes) {
    assert.equal(p.exit.code, 0); assert.equal(p.timedOut, false); assert.equal(p.guardReady, true); assert.equal(p.blockedNetwork, false);
  }
  const p = r.processes[1]; assert.equal(p.result.subtype, 'success'); assert.equal(p.result.sessionId, r.sessionId);
  assert.equal(p.result.finalText, r.markers.response);
  const requests = r.requests.filter(q => q.phase === 'resume'); assert.equal(requests.length, 1);
  const messages = JSON.stringify(requests[0].messages);
  assert.ok(!messages.includes(r.markers.user)); assert.ok(!messages.includes(r.markers.assistant)); assert.ok(messages.includes(r.markers.followup));
  const diagnosticLines = p.stderr.trim().split(/\r?\n/).map(JSON.parse);
  assert.deepEqual(diagnosticLines.map(x => x.event), ['offline-guard-entered', 'offline-guard-ready']);
  assert.ok(!p.eventTypes.some(t => /error|warn|diagnostic/.test(t)));
}
verify(row);
for (const mutate of [r => { r.afterInjection.find(f => f.kind === 'transcript').bytes = 1; }, r => { r.processes[1].exit.code = 1; }, r => { r.processes[1].result.sessionId = 'wrong'; }, r => { r.requests.find(q => q.phase === 'resume').messages.push({ role: 'assistant', content: r.markers.assistant }); }]) {
  const copy = structuredClone(row); mutate(copy); assert.throws(() => verify(copy));
}
console.log(JSON.stringify({ ok: true, cases: 1, negativeControls: 4, applicationTestsRun: 0, scope: 'Validates explicitly injected zero-byte file resumes silently without original history; not natural zero-byte file creation.' }));
