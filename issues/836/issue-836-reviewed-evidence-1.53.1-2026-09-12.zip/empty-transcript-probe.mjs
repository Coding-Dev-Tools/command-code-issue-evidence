import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';

const root=path.dirname(fileURLToPath(import.meta.url));
const [packageArg, outArg, mode='no-tool-json']=process.argv.slice(2);
if(!packageArg||!outArg)throw Error('Usage: node persistence-probe.mjs PACKAGE OUTPUT MODE');
const packageRoot=fs.realpathSync(packageArg),runtimeRoot=path.dirname(packageRoot),out=path.resolve(outArg);
const allowed=['no-tool-json','no-tool-text','read-json','tool-error-json','blocked-write-json','no-session-json','todo-stop-json','empty-recovery-json'];
assert.ok(allowed.includes(mode));
const hash=b=>createHash('sha256').update(b).digest('hex');
const bundleSha256=hash(fs.readFileSync(path.join(packageRoot,'dist/cli.mjs')));
const expected=process.env.FIXTURE_EXPECTED_SHA256??'5cbe89ae1bc22aa2e5a15c5d69dda84dbae04369e381120fe4b27cda3c753fbd';
assert.equal(bundleSha256,expected);
const runRoot=path.join(out,`${mode}-${Date.now()}`),project=path.join(runRoot,'project'),home=path.join(runRoot,'home'),tmp=path.join(home,'tmp');
for(const p of [project,tmp,path.join(home,'.commandcode'),path.join(home,'AppData/Roaming'),path.join(home,'AppData/Local')])fs.mkdirSync(p,{recursive:true});
fs.writeFileSync(path.join(project,'target.txt'),'LOCAL_READ_CONTROL_836\n');
const provider='persistence-fixture',model=`${provider}/model`,format=mode.endsWith('text')?'text':'json';
const markers={user:'USER_HISTORY_836_A_93C1',assistant:'ASSISTANT_HISTORY_836_A_7F2B',followup:'FOLLOWUP_836_B_8D6E',response:'ASSISTANT_HISTORY_836_B_49F0'};
const requests=[],sent=[],violations=[];let phase='initial';
const server=http.createServer((req,res)=>{
 let body='';req.on('data',b=>{body+=b;if(body.length>2_000_000)req.destroy();});
 req.on('end',()=>{
  if(req.method!=='POST'||req.url!=='/v1/chat/completions'){violations.push('unexpected-route');res.writeHead(404);res.end();return;}
  let payload;try{payload=JSON.parse(body);}catch{violations.push('invalid-json');res.writeHead(400);res.end('{}');return;}
  const record={phase,at:new Date().toISOString(),bodySha256:hash(body),body:payload};requests.push(record);
  if(requests.length>15){violations.push('request-budget');res.writeHead(400);res.end('{}');return;}
  const phaseRequests=requests.filter(r=>r.phase===phase).length,tools=(payload.tools??[]).map(t=>t.function?.name),replies=(payload.messages??[]).filter(m=>m.role==='tool');
  res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache'});
  function chunk(delta,finish_reason=null){const event={id:`fixture-${requests.length}`,object:'chat.completion.chunk',created:1,model:'model',choices:[{index:0,delta,finish_reason}],...(finish_reason?{usage:{prompt_tokens:100,completion_tokens:10,total_tokens:110}}:{})};sent.push({phase,event});res.write(`data: ${JSON.stringify(event)}\n\n`);}
  function call(name,args,id){chunk({role:'assistant',tool_calls:[{index:0,id,type:'function',function:{name,arguments:JSON.stringify(args)}}]});chunk({},'tool_calls');}
  if(phase!=='initial'){chunk({role:'assistant',content:markers.response});chunk({},'stop');}
  else if(mode==='empty-recovery-json'&&phaseRequests<=2){chunk({role:'assistant',content:''});chunk({},'stop');}
  else if(['read-json','tool-error-json','blocked-write-json','todo-stop-json'].includes(mode)){
   const target=mode==='todo-stop-json'?'todo_write':mode==='blocked-write-json'?'write_file':'read_file';
   const didTarget=replies.some(m=>m.tool_call_id==='call_target_836');
   const didDiscovery=replies.some(m=>m.tool_call_id==='call_discovery_836');
   if(!didTarget&&!tools.includes(target)&&!didDiscovery)call('search_tools',{query:`select:${target}`,max_results:1},'call_discovery_836');
   else if(!didTarget){
    const args=target==='todo_write'?{todos:[{id:'pending-835',content:'UNFINISHED_TASK_835',status:'pending',activeForm:'Checking unfinished task 835'}]}:target==='write_file'?{file_path:path.join(project,'blocked.txt'),content:'CONTROL_WRITE_836'}:{file_path:path.join(project,mode==='tool-error-json'?'missing.txt':'target.txt')};
    call(target,args,'call_target_836');
   }else{chunk({role:'assistant',content:mode==='todo-stop-json'?`Moving to the next check. ${markers.assistant}`:markers.assistant});chunk({},'stop');}
  }else{chunk({role:'assistant',content:markers.assistant});chunk({},'stop');}
  res.end('data: [DONE]\n\n');
 });
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
fs.writeFileSync(path.join(home,'.commandcode/providers.json'),JSON.stringify({provider:{[provider]:{api:'openai-completions',baseURL:`http://127.0.0.1:${port}/v1`,apiKey:'$FIXTURE_PROVIDER_KEY',models:{model:{contextWindow:200000,maxOutput:500,cost:{input:0,output:0}}}}}}));
fs.writeFileSync(path.join(home,'.commandcode/config.json'),JSON.stringify({model,provider,localOnly:true,telemetry:false,tasteLearning:false}));
fs.writeFileSync(path.join(home,'.commandcode/settings.json'),JSON.stringify({disableScratchpad:true,disableSkillShellExecution:true}));
const env={};for(const k of ['SystemRoot','WINDIR','ComSpec','PATHEXT','PROCESSOR_ARCHITECTURE'])if(process.env[k])env[k]=process.env[k];
env.PATH=[path.dirname(process.execPath),path.join(process.env.SystemRoot??'/','System32')].join(path.delimiter);
Object.assign(env,{HOME:home,USERPROFILE:home,APPDATA:path.join(home,'AppData/Roaming'),LOCALAPPDATA:path.join(home,'AppData/Local'),TEMP:tmp,TMP:tmp,CMD_LOCAL_ONLY:'1',DO_NOT_TRACK:'1',OTEL_SDK_DISABLED:'true',COMMANDCODE_SKIP_UPDATES:'1',COMMANDCODE_DISABLE_CRON:'1',COMMANDCODE_DISABLE_DURABLE_CRON:'1',DOTENV_CONFIG_PATH:path.join(home,'absent.env'),NO_COLOR:'1',FIXTURE_PORT:String(port),FIXTURE_PROVIDER_KEY:'synthetic-unused',COMMAND_CODE_API_KEY:'synthetic-unused'});
async function launch(label,prompt,extra=[]){
 phase=label;
 const cliArgs=['--no-auto-update','--local-only','--skip-onboarding','--trust','--no-skills','--model',model,...(mode==='todo-stop-json'?['--tools-enable','todo_write']:[]),'--max-turns','8','--output-format',format,...extra,'--print',prompt];
 const nodeArgs=['--permission',`--allow-fs-read=${runtimeRoot}`,`--allow-fs-read=${root}`,`--allow-fs-read=${runRoot}`,`--allow-fs-write=${runRoot}`,'--require',path.join(root,'offline-guard.cjs'),path.join(packageRoot,'dist/index.mjs'),...cliArgs];
 const startedAt=new Date().toISOString(),child=spawn(process.execPath,nodeArgs,{cwd:project,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
 let stdout='',stderr='',timedOut=false;child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
 const timer=setTimeout(()=>{timedOut=true;child.kill();},30000);
 const exit=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('close',(code,signal)=>resolve({code,signal}));});clearTimeout(timer);
 const events=stdout.split(/\r?\n/).flatMap(line=>{try{return[JSON.parse(line)]}catch{return[]}});
 return {label,startedAt,cliArgs,exit,timedOut,stdout,stderr,events,guardReady:stderr.includes('offline-guard-ready'),blockedNetwork:stderr.includes('blocked-network')};
}
function walk(dir){return fs.existsSync(dir)?fs.readdirSync(dir,{withFileTypes:true}).flatMap(d=>d.isDirectory()?walk(path.join(dir,d.name)):[path.join(dir,d.name)]):[];}
function files(){return walk(path.join(home,'.commandcode/projects')).filter(p=>p.endsWith('.jsonl')).map(p=>({path:path.relative(home,p),bytes:fs.statSync(p).size,sha256:hash(fs.readFileSync(p)),text:fs.readFileSync(p,'utf8')}));}
const initial=await launch('initial',`${markers.user}: follow the local fixture response.`,mode==='no-session-json'?['--no-session']:[]);
const afterInitial=files();
let sessionId=initial.events.find(e=>e.sessionId)?.sessionId;
if(!sessionId){const p=afterInitial.find(f=>!f.path.endsWith('.checkpoints.jsonl'))??afterInitial.find(f=>f.path.endsWith('.checkpoints.jsonl'));if(p)sessionId=path.basename(p.path,'.jsonl').replace(/\.checkpoints$/,'');}
const injectedPath=path.join(home,afterInitial.find(f=>f.path.endsWith('.checkpoints.jsonl')).path.replace(/\.checkpoints\.jsonl$/,'.jsonl'));
assert.equal(mode,'no-tool-json');assert.ok(sessionId);assert.equal(fs.existsSync(injectedPath),false);
fs.writeFileSync(injectedPath,'');
const injectedEmptyTranscript={purpose:'Explicit empty-file fault injection before exact-ID resume; not a naturally produced zero-byte file.',bytes:fs.statSync(injectedPath).size,sessionId};
const afterInjection=files();
const processes=[initial];
if(sessionId&&mode!=='no-session-json')processes.push(await launch('resume',`${markers.followup}: continue this synthetic session.`,['--resume',sessionId]));
const afterResume=files();
// This fault-injection control ends after exact-ID resume.
server.closeAllConnections();await new Promise(r=>server.close(r));
const result={injectedEmptyTranscript,afterInjection,mode,at:new Date().toISOString(),node:process.version,platform:process.platform,arch:process.arch,cliVersion:JSON.parse(fs.readFileSync(path.join(packageRoot,'package.json'))).version,bundleSha256,markers,sessionId,processes,requests,sent,afterInitial,afterResume,afterContinue:files(),violations,scope:'Actual CLI with scripted localhost model; synthetic project and home; no real inference. Captures stored outside project. Guard is not OS network isolation.'};
const resultPath=path.join(runRoot,'raw.json');fs.writeFileSync(resultPath,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({mode,sessionId,requests:requests.map(r=>({phase:r.phase,toolReplies:r.body.messages?.filter(m=>m.role==='tool').length,hasOriginalUser:JSON.stringify(r.body.messages).includes(markers.user),hasOriginalAssistant:JSON.stringify(r.body.messages).includes(markers.assistant)})),processes:processes.map(p=>({label:p.label,exit:p.exit,timedOut:p.timedOut,results:p.events.filter(e=>e.type==='result'),stderrTail:p.stderr.slice(-500)})),afterInitial:afterInitial.map(({text,...f})=>({...f,hasUser:text.includes(markers.user),hasAssistant:text.includes(markers.assistant)})),resultPath}));
assert.deepEqual(violations,[]);assert.ok(processes.every(p=>!p.timedOut&&p.guardReady&&!p.blockedNetwork));
