# Second-cohort review — September 12, 2026

The exported packet was independently exercised again: 12 scenarios, 24 CLI processes, 28 localhost requests, 6 post-result Windows shutdown aborts, no watchdog timeout. The original findings above remain supported. This cohort is retained in [review observations](review-observations.json); original observations are unchanged. [Review provenance](review-provenance.json) records which fresh locked runtime was used.

`node verify-review.mjs` checks the second retained cohort without product execution. The complete prepared post is in [COMMENT-FULL.md](COMMENT-FULL.md). This packet is private; no public evidence URL is implied.

An additional, explicitly injected zero-byte transcript was accepted by exact-ID resume: both CLI processes exited zero; the resumed request lacked both original markers; stderr contained only the test guard messages, with no warning about missing or empty history. This is not a reproduction of natural zero-byte creation on Linux. The missing-file control still exits 1 visibly. The caller explicitly invokes `process.exit(o.exitCode)` after print output; see [additional source anchors](review-source-anchors.json). A long generation and post-exit polling do not exclude writes queued at commit being interrupted by exit.

Run `node verify-empty-transcript.mjs` for the saved injection result and four negative controls. To repeat it in a fresh copied packet on the recorded Windows runtime, use `node empty-transcript-probe.mjs runtime/node_modules/command-code fresh-empty no-tool-json`. This fixture requires the initial main transcript to be missing, then creates a zero-byte file explicitly. It does not edit the CLI bundle. Source-change details are in [the fixture receipt](empty-transcript-control.json).
