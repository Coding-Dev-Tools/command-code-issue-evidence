# #836 — completed headless turns leave queued transcript writes unfinished

Actual command-code **1.53.1**, Windows x64 / Node **v24.15.0**, fresh locked npm runtime. CLI SHA256 `5cbe89ae1bc22aa2e5a15c5d69dda84dbae04369e381120fe4b27cda3c753fbd`. No paid inference; the model is a scripted localhost SSE server. Full current issue and its linked text report were read.

## Result

The completed no-tool answer is emitted successfully, but the main transcript is absent. The checkpoint sidecar exists. A tool run writes earlier messages but loses its final assistant answer. This extends the report: a nonempty transcript alone is an insufficient success criterion.

| Scenario | Original transcript bytes | Await-flush diagnostic bytes |
|---|---:|---:|
| no-tool-json | missing | 1018 |
| no-tool-text | missing | 1018 |
| read-json | 1573 | 1988 |
| tool-error-json | 1749 | 2162 |
| blocked-write-json | 1726 | 2141 |
| no-session-json | missing | missing |

Every ordinary diagnostic case preserves both original user and final assistant markers in the correct roles and order. Exact-ID resume in a separate process includes both in its outgoing request, and that second answer is also persisted once. The no-tool JSON case additionally tests `--continue`: original starts a new session without the old markers; diagnostic continues the same ID with both completed exchanges.

On this host, explicit `--resume` of the missing original transcript **fails visibly with exit 1**, before any model request. That differs from the reporter's silent empty-context resume. Do not copy the latter claim into this result. `--no-session` still creates a checkpoint sidecar in both variants, but neither creates a main transcript; the control proves transcript behavior only.

Main matrix: **12 scenarios, 24 CLI processes, 28 localhost requests**. Six tool-run processes emitted successful results and then hit Windows `UV_HANDLE_CLOSING` (exit 3221226505), three per variant. Two original explicit-resume processes exit 1 for missing sessions. Other processes exit 0. No watchdog expiry or blocked network attempt. The diagnostic restores persistence without curing the separate shutdown assertion. Earlier pilots are retained in the campaign ledger and excluded from these counts.

## Supported boundary

The shared engine calls `onCommit` before its no-tool stop decision. `createSessionRecorder.onCommit` calls the store's append methods. `createSessionStoreV3` queues asynchronous filesystem writes. The harness exposes `flush()` separately from `dispose()`. In `runPrintMode`, the finalizer awaits disposal but does not await `flush()`.

An isolated diagnostic package changes exactly one site:

```js
// Original
finally { await harness.dispose().catch(() => {}); }
// Diagnostic concept (exact minified replacement in flush-diagnostic.json)
finally { await harness.flush(); await harness.dispose().catch(() => {}); }
```

Diagnostic CLI SHA256 `e22631c2205a48cb311010ec517d2fc069fd19a5d88349421a372cc39be48103`. This is causal evidence in the controlled environment, not an upstream implementation. A production change should guarantee disposal even if flushing rejects and decide how write failures affect the reported outcome. The existing queue also absorbs rejected writes in its tail promise, so waiting alone is not proof of durable success under disk failure. Native Linux/macOS, cancellation, disk errors, interactive persistence and crash durability remain untested.

## Regression oracle

Assert a successfully emitted final answer, exactly one user and one final assistant marker in the persisted messages, distinct message IDs, role/order correctness, exact session identity on resume, both markers in the fresh request, and persistence of the resumed answer. Include successful-read, failed-read, blocked-write, text/JSON, explicit resume, headless continue and no-session transcript controls.

`verify-results.mjs` checks the retained observations and rejects five corrupted variants: wrong stored role, missing old assistant in the resumed request, duplicate persisted assistant, wrong resumed session ID, and failed initial answer. This validates evidence, not a new product run.

See [observations](observations.json), [provenance](provenance.json), [source anchors](source-anchors.json), [diagnostic replacement](flush-diagnostic.json), and [reproduction](README.md). Private draft and archive only; nothing posted.
