// Product persistence acceptance, independent of the recorded failing baseline.
// Input: a fresh persistence-probe raw.json, or observations.json [variant].
import fs from 'node:fs';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';

const text = m => typeof m?.content === 'string' ? m.content : (m?.content ?? []).filter(x => x.type === 'text').map(x => x.text).join('');
const frames = p => p.events ?? (p.stdout ?? '').split(/\r?\n/).flatMap(s => { try { return [JSON.parse(s)]; } catch { return []; } });
const result = p => p.result ?? frames(p).find(x => x.type === 'result');
const files = list => list.filter(f => f.kind ? f.kind === 'transcript' : !f.path.endsWith('.checkpoints.jsonl')).map(f => ({ ...f, records: f.records ?? f.text.trim().split(/\r?\n/).map(JSON.parse) }));
function exchange(messages, pairs) {
  let last = -1;
  for (const [role, marker] of pairs) {
    const indexes = messages.flatMap((m, i) => m.role === role && text(m).includes(marker) ? [i] : []);
    assert.equal(indexes.length, 1, `${role} marker must appear exactly once: ${marker}`);
    assert.ok(indexes[0] > last, 'Conversation marker order must survive');
    last = indexes[0];
  }
}
function stored(list, sessionId, pairs) {
  const transcripts = files(list);
  assert.equal(transcripts.length, 1, 'Exactly one main transcript must exist');
  const records = transcripts[0].records;
  assert.equal(records.find(x => x.type === 'session')?.id, sessionId, 'Stored session ID');
  const messages = records.filter(x => x.type === 'message').map(x => x.message);
  const ids = messages.map(m => m.meta?.messageId);
  assert.ok(ids.every(Boolean), 'Stored message IDs required');
  assert.equal(new Set(ids).size, ids.length, 'No duplicate message IDs');
  exchange(messages, pairs);
}
export function assertPersistence(row) {
  const m = row.markers, initial = row.processes[0];
  assert.deepEqual(row.violations, []);
  for (const p of row.processes) {
    assert.equal(p.timedOut, false, 'Timeout is inconclusive');
    assert.equal(p.guardReady, true);
    assert.equal(p.blockedNetwork, false);
  }
  assert.ok(result(initial)?.finalText === m.assistant || (initial.stdoutFinalMarker ?? initial.stdout?.trim().split('\n').at(-1)) === m.assistant, 'Initial answer completed');
  if (row.mode === 'no-session-json') {
    assert.equal(files(row.afterInitial).length, 0);
    return; // Checkpoint suppression is a separate contract, not asserted here.
  }
  const original = [['user', m.user], ['assistant', m.assistant]];
  stored(row.afterInitial, row.sessionId, original);
  const resumed = row.requests.find(r => r.phase === 'resume');
  assert.ok(resumed, 'Fresh resume must reach the local provider');
  exchange(resumed.messages ?? resumed.body.messages, [...original, ['user', m.followup]]);
  const rp = row.processes.find(p => p.label === 'resume');
  assert.equal(rp.exit.code, 0, 'Fresh resume exits cleanly');
  if (result(rp)) assert.equal(result(rp).sessionId, row.sessionId);
  assert.ok(result(rp)?.finalText === m.response || (rp.stdoutFinalMarker ?? rp.stdout?.trim().split('\n').at(-1)) === m.response);
  const completed = [...original, ['user', m.followup], ['assistant', m.response]];
  stored(row.afterResume, row.sessionId, completed);
  if (row.mode === 'no-tool-json') {
    const cp = row.processes.find(p => p.label === 'continue');
    const cr = row.requests.find(r => r.phase === 'continue');
    assert.equal(cp.exit.code, 0);
    assert.equal(result(cp).sessionId, row.sessionId);
    exchange(cr.messages ?? cr.body.messages, completed);
  }
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const data = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  const rows = (data.observations ?? [data]).filter(r => !process.argv[3] || r.variant === process.argv[3]);
  assert.ok(rows.length, 'No matching cases');
  const failures = [];
  for (const r of rows) { try { assertPersistence(r); } catch (e) { failures.push({ mode: r.mode, reason: e.message }); } }
  console.log(JSON.stringify({ ok: !failures.length, cases: rows.length, failures, scope: 'Persistence/replay only; initial-process shutdown is a separate check.' }));
  process.exitCode = failures.length ? 1 : 0;
}
