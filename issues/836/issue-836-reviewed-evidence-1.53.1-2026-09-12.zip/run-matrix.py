import pathlib,json,subprocess,sys,hashlib,shutil,datetime
root=pathlib.Path(__file__).resolve().parent
variant=sys.argv[1]
package=root/'runtime/node_modules/command-code'
modes=sys.argv[2:] or ['no-tool-text','tool-error-json','blocked-write-json','no-session-json','todo-stop-json','empty-recovery-json']
env=None
if variant=='flush-diagnostic':
    import os
    source=package/'dist/cli.mjs';raw=source.read_bytes()
    old=b'finally{await d.dispose().catch(()=>{})}if("run_error"===m.stopReason)'
    new=b'finally{await d.flush();await d.dispose().catch(()=>{})}if("run_error"===m.stopReason)'
    assert raw.count(old)==1
    target=root/'runtime/node_modules/command-code-flush-diagnostic'
    if not target.exists():shutil.copytree(package,target)
    patched=raw.replace(old,new)
    (target/'dist/cli.mjs').write_bytes(patched)
    record={'purpose':'Diagnostic only: wait for existing session-store write queue before print harness disposal; no production fix claimed.','originalSha256':hashlib.sha256(raw).hexdigest(),'diagnosticSha256':hashlib.sha256(patched).hexdigest(),'replacements':1,'before':old.decode(),'after':new.decode(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (root/'flush-diagnostic.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    package=target;env={**os.environ,'FIXTURE_EXPECTED_SHA256':record['diagnosticSha256']}
results=[]
for mode in modes:
    completed=subprocess.run(['node',str(root/'persistence-probe.mjs'),str(package),str(root/('runs836-'+variant)),mode],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=125)
    (root/f'matrix-{variant}-{mode}.stdout.txt').write_bytes(completed.stdout)
    (root/f'matrix-{variant}-{mode}.stderr.txt').write_bytes(completed.stderr)
    assert completed.returncode==0,(mode,completed.returncode,completed.stderr.decode(errors='replace'))
    r=json.loads(completed.stdout);results.append(r)
    print(json.dumps({'variant':variant,'mode':mode,'requests':r['requests'],'exits':[p['exit']['code'] for p in r['processes']],'transcripts':[{k:v for k,v in f.items() if k!='path'} for f in r['afterInitial'] if not f['path'].endswith('.checkpoints.jsonl')]}),flush=True)
(root/f'matrix-{variant}-summary.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
