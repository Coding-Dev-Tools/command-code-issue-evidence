# Issue 874: short card lifecycle comparison

Windows 11 x64, Node 24.15.0. The unmodified Command Code 1.58.1 CLI runs in ConPTY. A local server holds one child response for 2.5 seconds. No account or paid inference is used. A network guard restricts the child CLI to its assigned localhost endpoint. Each run uses new isolated home and project directories.

From this extracted directory:

```powershell
npm ci --prefix runtime --ignore-scripts
node repro-874.mjs
node verify-874.mjs runs/<printed-run-directory>/results.json
```

The runner prints the exact result file. Replace the path in the last command with that file. To validate the retained reference capture only, run `node verify-874.mjs`. Dependency installation contacts the npm registry; test execution uses only localhost and generated data. The CLI bundle hash is checked before launch.

The original defect is expected in this pinned version: a detached launch card says Done while the actual same-ID child reports running, and retains zero elapsed time after completion. A foreground child shows Running then a nonzero duration. A passing verifier confirms this observed regression and healthy controls, not a product fix. Six deliberate corrupted evidence cases must fail the internal verifier.

Both reference modes show zero tokens, so token rendering is not attributed specifically to detachment. This does not test a separate Background panel, Linux/zsh, notifications, turn-limit semantics or a hosted provider.
