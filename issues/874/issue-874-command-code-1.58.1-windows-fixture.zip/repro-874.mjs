import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const runtime=path.join(here,'runtime');
const require=createRequire(path.join(runtime,'package.json'));
const {Terminal}=require('@xterm/headless');
const pty=require('@lydell/node-pty');
const cli=path.join(runtime,'node_modules/command-code/dist/index.mjs');
const cliSha256=createHash('sha256').update(fs.readFileSync(path.join(path.dirname(cli),'cli.mjs'))).digest('hex');
assert.equal(cliSha256,'2bc59dacb82a75d7db6b49699bf6e7537287a7ffcc20c78e143f907a62843198');
const guard=path.join(here,'offline-guard.cjs');
const run=path.join(here,'runs',new Date().toISOString().replaceAll(':','').replaceAll('.',''));
fs.mkdirSync(run,{recursive:true});
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const sanitize=s=>String(s).replace(/[A-Za-z]:[\\/]Users[\\/][^\r\n ]+/g,'<LOCAL_PATH>');
function textOf(block){return typeof block.output?.value==='string'?block.output.value:typeof block.content==='string'?block.content:JSON.stringify(block.output??block);}
async function scenario(background){
  const name=background?'background':'foreground';
  const dir=path.join(run,name),home=path.join(dir,'home'),project=path.join(dir,'project');
  for(const p of [home,project,path.join(home,'tmp'),path.join(home,'AppData/Roaming'),path.join(home,'AppData/Local')])fs.mkdirSync(p,{recursive:true});
  const frames=[],requests=[],responses=[];let rootId=null,rootRounds=0,pending=null,childStartedAt=null,childReleasedAt=null,rootCompletedAt=null,agentId=null,safetyHit=false,fixtureError=null;
  function send(res,events){for(const e of events)responses.push({at:Date.now(),event:e});res.writeHead(200,{'Content-Type':'application/x-ndjson'});res.end(events.map(e=>JSON.stringify(e)).join('\n')+'\n');}
  function finish(res,text){send(res,[{type:'text-delta',text},{type:'finish',finishReason:'stop',totalUsage:{inputTokens:17,outputTokens:5}}]);}
  function call(res,id,toolName,input){send(res,[{type:'tool-call',toolCallId:id,toolName,input},{type:'finish',finishReason:'tool-calls',totalUsage:{inputTokens:10,outputTokens:2}}]);}
  function release(){if(!pending)return;childReleasedAt=Date.now();const res=pending;pending=null;finish(res,'CHILD874_RESULT');}
  const server=http.createServer((req,res)=>{let raw='';req.on('data',b=>raw+=b);req.on('end',()=>{try{
    if(req.url!=='/alpha/generate'){res.writeHead(200,{'Content-Type':'application/json'});res.end('{}');return;}
    const body=JSON.parse(raw);rootId??=body.threadId;
    const tools=(body.params?.messages??[]).filter(m=>m.role==='tool').flatMap(m=>Array.isArray(m.content)?m.content:[m]);
    const toolResults=tools.map(b=>({id:b.toolCallId??b.tool_call_id??null,text:sanitize(textOf(b)).slice(0,12000)}));
    const row={ordinal:requests.length+1,at:Date.now(),thread:body.threadId===rootId?'root':'child',toolResults};requests.push(row);
    if(row.thread==='child'){assert.equal(childStartedAt,null,'one child request only');childStartedAt=Date.now();pending=res;return;}
    if(rootCompletedAt){finish(res,'AUXILIARY874');return;}
    rootRounds++;
    if(rootRounds===1){call(res,'launch874','agent',{description:'Card fixture child',subagent_type:'general',prompt:'Return CHILD874_RESULT.',run_in_background:background});return;}
    if(!background){rootCompletedAt=Date.now();finish(res,'ROOT874_DONE');return;}
    if(rootRounds===2){const launch=toolResults.find(t=>t.id==='launch874');agentId=launch?.text.match(/bg-[a-zA-Z0-9-]+/)?.[0];assert.ok(agentId,'launch result must provide real ID');call(res,'status874','agent_output',{agent_id:agentId,action:'status'});return;}
    if(rootRounds===3){assert.ok(toolResults.some(t=>t.id==='status874'&&t.text.includes(agentId)&&/status: running/i.test(t.text)),'actual same-ID running status required');call(res,'wait874','agent_output',{agent_id:agentId,action:'wait'});return;}
    assert.ok(toolResults.some(t=>t.id==='wait874'&&t.text.includes(agentId)&&t.text.includes('CHILD874_RESULT')),'actual same-ID completed wait result required');rootCompletedAt=Date.now();finish(res,'ROOT874_DONE');
  }catch(e){fixtureError=e.message;res.writeHead(500);res.end('{}');}});});
  await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
  const env={};for(const key of ['SystemRoot','WINDIR','ComSpec','PATHEXT','PROCESSOR_ARCHITECTURE'])if(process.env[key])env[key]=process.env[key];
  Object.assign(env,{PATH:[path.dirname(process.execPath),path.join(process.env.SystemRoot,'System32')].join(path.delimiter),HOME:home,USERPROFILE:home,APPDATA:path.join(home,'AppData/Roaming'),LOCALAPPDATA:path.join(home,'AppData/Local'),TEMP:path.join(home,'tmp'),TMP:path.join(home,'tmp'),COMMANDCODE_SANDBOX:'true',COMMANDCODE_API_URL:`http://127.0.0.1:${port}`,COMMAND_CODE_API_KEY:'synthetic-card-fixture',COMMANDCODE_SKIP_UPDATES:'1',COMMANDCODE_DISABLE_CRON:'1',COMMANDCODE_DISABLE_DURABLE_CRON:'1',DO_NOT_TRACK:'1',OTEL_SDK_DISABLED:'true',DOTENV_CONFIG_PATH:path.join(home,'absent.env'),TERM:'xterm-256color',FIXTURE_PORT:String(port),NODE_OPTIONS:'--require '+JSON.stringify(guard.replaceAll('\\','/'))});
  const term=new Terminal({cols:140,rows:45,allowProposedApi:true,scrollback:2000});let exited=null,raw='';
  const child=pty.spawn(process.execPath,[cli,'--no-auto-update','--skip-onboarding','--trust','--yolo','--no-skills','--model','deepseek-v4-flash','--max-turns','8','874 card control '+name],{cwd:project,env,cols:140,rows:45,useConpty:true,windowsHide:true});
  child.onData(s=>{raw+=s;term.write(s);});child.onExit(e=>exited=e);
  const capture=()=>{const text=Array.from({length:term.buffer.active.length},(_,i)=>term.buffer.active.getLine(i)?.translateToString(true)??'').join('\n');const row={at:Date.now(),childPending:Boolean(pending),afterRootCompletion:Boolean(rootCompletedAt),text:sanitize(text)};frames.push(row);return row;};
  const end=Date.now()+35000;let completeFrame=false;
  while(!exited&&Date.now()<end){const f=capture();if(pending&&Date.now()-childStartedAt>=2500){if(!background||rootRounds>=3){release();}else if(Date.now()-childStartedAt>10000){safetyHit=true;release();}}
    if(rootCompletedAt&&f.text.includes('ROOT874_DONE')&&Date.now()-rootCompletedAt>=500){completeFrame=true;break;}
    if(fixtureError)break;await pause(100);
  }
  const timedOut=!completeFrame;
  if(!exited){child.write('/exit\r');const end=Date.now()+4000;while(!exited&&Date.now()<end)await pause(100);}
  if(!exited)child.kill();await pause(300);release();server.closeAllConnections();await new Promise(r=>server.close(r));capture();term.dispose();
  const result={name,background,guardSeen:raw.includes('offline-guard-ready'),networkBlocked:raw.includes('blocked-network'),exit:exited,timedOut,safetyHit,fixtureError,childStartedAt,childReleasedAt,rootCompletedAt,agentId,requests,responses,frames};
  fs.writeFileSync(path.join(dir,'result.json'),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify({name,timedOut,fixtureError,exit:exited,requests:requests.length,agentId,childHoldMs:childReleasedAt-childStartedAt}));return result;
}
const results=[];for(const mode of [true,false])results.push(await scenario(mode));
fs.writeFileSync(path.join(run,'results.json'),JSON.stringify({issue:874,version:'1.58.1',cliSha256,node:process.version,platform:process.platform,at:new Date().toISOString(),results},null,2)+'\n');
console.log(JSON.stringify({resultFile:path.join(run,'results.json')}));
