import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const input=path.resolve(process.argv[2]??path.join(here,'REFERENCE-RESULTS.json'));
const value=JSON.parse(fs.readFileSync(input,'utf8'));
function verify(x){
  assert.equal(x.issue,874);assert.equal(x.version,'1.58.1');assert.equal(x.cliSha256,'2bc59dacb82a75d7db6b49699bf6e7537287a7ffcc20c78e143f907a62843198');
  assert.deepEqual(x.results.map(r=>r.name),['background','foreground']);
  for(const r of x.results){assert.equal(r.fixtureError,null);assert.equal(r.timedOut,false);assert.equal(r.safetyHit,false);assert.equal(r.exit.exitCode,0);assert.equal(r.guardSeen,true);assert.equal(r.networkBlocked,false);assert.ok(r.childReleasedAt-r.childStartedAt>=2500);assert.ok(r.rootCompletedAt>r.childReleasedAt);assert.equal(r.requests.filter(q=>q.thread==='child').length,1);}
  const b=x.results[0],f=x.results[1];
  const bgLive=b.frames.find(t=>t.childPending&&t.at>=b.childStartedAt&&t.at<b.childReleasedAt&&/GENERAL  \[Card fixture child\][\s\S]*?Done  \(0s \| 0 tokens\)/.test(t.text));assert.ok(bgLive,'background card must be Done while child is held');
  const bgDone=b.frames.find(t=>t.afterRootCompletion&&t.at>=b.rootCompletedAt&&t.text.includes('ROOT874_DONE')&&/Done  \(0s \| 0 tokens\)/.test(t.text));assert.ok(bgDone,'background card must remain zero after completed wait');
  assert.match(b.agentId,/^bg-\d+-[a-z0-9]+$/);
  const launch=b.requests.flatMap(q=>q.toolResults).find(t=>t.id==='launch874');assert.ok(launch.text.includes(b.agentId));
  const status=b.requests.find(q=>q.at<b.childReleasedAt&&q.toolResults.some(t=>t.id==='status874'&&t.text.includes('agent_id: '+b.agentId)&&t.text.includes('status: running')));assert.ok(status,'actual same-ID running tool result required');
  const completed=b.requests.find(q=>q.at>=b.childReleasedAt&&q.toolResults.some(t=>t.id==='wait874'&&t.text.includes('agent_id: '+b.agentId)&&t.text.includes('status: completed')&&t.text.includes('CHILD874_RESULT')&&t.text.includes('total_tokens: 22')));assert.ok(completed,'actual same-ID wait output required');
  const fgLive=f.frames.find(t=>t.childPending&&t.at>=f.childStartedAt&&t.at<f.childReleasedAt&&/GENERAL  \(Card fixture child\)[\s\S]*?Running/.test(t.text));assert.ok(fgLive,'foreground must display Running before release');
  const fgDone=f.frames.find(t=>t.afterRootCompletion&&t.text.includes('ROOT874_DONE')&&/Done  \([2-9]\ds?/.test(t.text));
  const fgFinal=f.frames.find(t=>t.afterRootCompletion&&t.text.includes('ROOT874_DONE')&&/Done  \([2-9]s \| 0 tokens\)/.test(t.text));assert.ok(fgDone||fgFinal,'foreground must display nonzero elapsed duration');
  assert.ok(f.requests.flatMap(q=>q.toolResults).some(t=>t.id==='launch874'&&t.text.includes('CHILD874_RESULT')&&t.text.includes('total_tokens: 22')));
  return {background:{live:bgLive,completed:bgDone,toolResults:[...new Map(b.requests.flatMap(q=>q.toolResults).map(t=>[t.id,t])).values()],agentId:b.agentId,holdMs:b.childReleasedAt-b.childStartedAt},foreground:{live:fgLive,completed:fgDone??fgFinal,toolResults:[...new Map(f.requests.flatMap(q=>q.toolResults).map(t=>[t.id,t])).values()],holdMs:f.childReleasedAt-f.childStartedAt}};
}
const projected=verify(value);
const mutations=[['missing foreground',x=>x.results.pop()],['missing live frames',x=>x.results[0].frames=x.results[0].frames.filter(f=>!f.childPending)],['wrong ID',x=>x.results[0].agentId='bg-1-foreign'],['missing real wait result',x=>{for(const q of x.results[0].requests)q.toolResults=q.toolResults.filter(t=>t.id!=='wait874');}],['stale status only',x=>{for(const q of x.results[0].requests)for(const t of q.toolResults)if(t.id==='status874')t.text=t.text.replace('status: running','status: completed');}],['fixture timeout',x=>x.results[0].timedOut=true]];
for(const[name,mutate]of mutations){const y=structuredClone(value);mutate(y);assert.throws(()=>verify(y),name);}
const report={issue:874,version:value.version,cliSha256:value.cliSha256,node:value.node,platform:value.platform,verifiedAt:new Date().toISOString(),rawResultPath:path.relative(here,input).replaceAll('\\','/'),rawResultSha256:createHash('sha256').update(fs.readFileSync(input)).digest('hex'),observations:projected,limitations:['Native API transport redirected to localhost; no real provider or Linux/zsh test.','Foreground token count was also zero despite the scripted usage in the tool result; token display is not attributed specifically to background mode.','No separate Background panel or completion-notification claim.','Post-completion capture is a bounded observation, not proof the card can never update.'],verification:{passed:true,deliberateCorruptionsRejected:mutations.map(([n])=>n)}};
fs.writeFileSync(path.join(here,'PARENT-VERIFIED-CONTROLS.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({passed:true,mutationsRejected:mutations.length,observations:{backgroundHoldMs:projected.background.holdMs,foregroundHoldMs:projected.foreground.holdMs},tokenDisplayLimitation:report.limitations[1]}));
