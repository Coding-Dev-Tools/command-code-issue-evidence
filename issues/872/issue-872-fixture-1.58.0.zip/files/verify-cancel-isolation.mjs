import fs from 'node:fs';
import path from 'node:path';

const input = path.resolve(process.argv[2] ?? path.resolve('output', 'results.json'));
const failures = [];
const expect = (condition, message) => {
  if (!condition) failures.push(message);
};
let value;
try {
  value = JSON.parse(fs.readFileSync(input, 'utf8'));
} catch (error) {
  console.error(`Could not read JSON results: ${error instanceof Error ? error.message : String(error)}`);
  process.exit(2);
}

expect(value?.schemaVersion === 1, 'schemaVersion must be 1');
expect(value?.version === '1.58.0', 'version must be 1.58.0');
expect(value?.bundleSha256 === 'aab2bec800371953112d18472bb7383992ef264cca22558bdcda77e7d0dc0f14', 'bundle SHA-256 does not match the pinned 1.58.0 bundle');
expect(Array.isArray(value?.scenarios), 'scenarios must be an array');

const scenarios = new Map((value?.scenarios ?? []).map(item => [item.scenario, item]));
for (const name of ['cancel-held', 'noescape']) {
  const item = scenarios.get(name);
  expect(Boolean(item), `${name} scenario is missing`);
  if (!item) continue;
  expect(item.failure === null, `${name} has a recorded failure`);
  expect(item.exit?.exitCode === 0, `${name} did not exit with code 0`);
  expect(item.summaryPendingObserved === true, `${name} did not observe a held summary`);
  const window = item.windowObservation;
  expect(window?.openSummaryCount === 1, `${name} must have one open summary at the fixed window`);
  expect(window?.summaryReceived === 1, `${name} must receive one summary request`);
  expect(window?.summaryCompleted === 0, `${name} must not complete the summary before release`);
  expect(window?.requestAborted === 0, `${name} unexpectedly aborted the summary request`);
  expect(window?.responseClosed === 0, `${name} unexpectedly closed the summary response`);
  expect(window?.responseFinished === 0, `${name} unexpectedly finished the summary response`);
  expect(window?.queueVisible === true, `${name} did not retain the queue marker at the fixed window`);
  expect(window?.healthyVisible === true, `${name} did not retain the healthy marker at the fixed window`);

  const summary = item.summaryRequests?.[0];
  expect(summary?.response?.status === 200, `${name} summary was not released with HTTP 200`);
  expect(summary?.response?.kind === 'summary-released', `${name} summary was not released by the fixture`);
  expect(summary?.wire?.reqAborted === false, `${name} summary request was aborted after release`);
  expect(summary?.wire?.resClose === true, `${name} summary response did not close after release`);
  expect(summary?.wire?.resFinish === true, `${name} summary response did not finish after release`);

  const events = new Set(item.eventNames ?? []);
  for (const event of ['summary_received', 'summary_pending_observed', 'fixed_window_observed', 'release_requested', 'summary_released']) {
    expect(events.has(event), `${name} is missing event ${event}`);
  }
  expect(events.has(name === 'cancel-held' ? 'escape_sent' : 'no_escape_control'), `${name} is missing its control event`);

  const deliveries = item.deliveries ?? {};
  const suffix = name === 'cancel-held' ? 'CANCEL_HELD' : 'NOESCAPE';
  expect(deliveries[`QUEUE872_${suffix}`] === 1, `${name} queue marker delivery count is not exactly one`);
  expect(deliveries[`HEALTHY872_${suffix}`] === 1, `${name} healthy marker delivery count is not exactly one`);
}

const unexpected = [...scenarios.keys()].filter(name => !['cancel-held', 'noescape'].includes(name));
expect(unexpected.length === 0, `unexpected scenarios present: ${unexpected.join(', ')}`);

if (failures.length) {
  console.error(`FAIL ${input}`);
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log(`PASS ${input}: held-summary cancellation isolation controls satisfy the wire and delivery invariants.`);
