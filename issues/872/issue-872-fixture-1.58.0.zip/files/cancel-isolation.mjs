import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import { createHash, randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { packageRuntime, save, isolatedEnv, configure, sleep } from './common.mjs';
import { terminal } from './terminal.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const runtime = packageRuntime(process.argv[2] ?? path.resolve(here, '..', 'node_modules'));
const runRoot = path.resolve(process.argv[3] ?? path.resolve(here, '..', 'output'));
const selected = (process.argv[4] ?? 'cancel-held,noescape').split(',').filter(Boolean);
const cancelWindowMs = 3000;
const fixedInputDelayMs = 1000;
const bundleSha256 = 'aab2bec800371953112d18472bb7383992ef264cca22558bdcda77e7d0dc0f14';
const summaryText = 'SUMMARY872_ISOLATION: local held summary released after the fixed cancellation window.';
fs.mkdirSync(runRoot, { recursive: true });

const sha256 = value => createHash('sha256').update(value).digest('hex');
const redact = value => String(value)
  .replace(/[A-Za-z]:\\Users\\[^\\\r\n]+/gi, '<USER_PATH>')
  .replace(/C:\/Users\/[^/\r\n]+/gi, '<USER_PATH>');
const sleepMs = ms => new Promise(resolve => setTimeout(resolve, ms));
const waitFor = async (predicate, timeoutMs, pollMs = 50) => {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    if (predicate()) return true;
    await sleep(pollMs);
  }
  return Boolean(predicate());
};
const markerPattern = /(?:QUEUE872|HEALTHY872|SEED872|WARMUP872|DELIVERED872)_[A-Z0-9_-]+/g;
const markersIn = value => [...new Set(String(value ?? '').match(markerPattern) ?? [])];

let active = null;
let server;

const record = (event, details = {}) => {
  if (!active) return;
  active.events.push({
    at: new Date().toISOString(),
    elapsedMs: Date.now() - active.startedAt,
    event,
    ...details
  });
};

const writeSse = (res, text) => {
  if (res.destroyed || res.writableEnded) return false;
  res.writeHead(200, { 'content-type': 'text/event-stream', connection: 'keep-alive' });
  res.write(`data: ${JSON.stringify({ id: 'fixture872isolation', object: 'chat.completion.chunk', created: 1, model: 'fixture/model', choices: [{ index: 0, delta: { role: 'assistant', content: text }, finish_reason: null }] })}\n\n`);
  res.write(`data: ${JSON.stringify({ id: 'fixture872isolation', object: 'chat.completion.chunk', created: 1, model: 'fixture/model', choices: [{ index: 0, delta: {}, finish_reason: 'stop' }], usage: { prompt_tokens: 100, completion_tokens: Math.ceil(text.length / 4), total_tokens: 100 + Math.ceil(text.length / 4) } })}\n\n`);
  res.end('data: [DONE]\n\n');
  return true;
};

const writeError = (res, status, message) => {
  if (res.destroyed || res.headersSent) return false;
  res.writeHead(status, { 'content-type': 'application/json' });
  res.end(JSON.stringify({ error: { message, type: 'fixture_error', code: 'fixture_872_isolation' } }));
  return true;
};

const serverReady = new Promise(resolve => {
  server = http.createServer((req, res) => {
    let raw = '';
    const wire = {
      requestIndex: null,
      kind: null,
      reqAborted: false,
      reqClose: false,
      resClose: false,
      resFinish: false,
      resError: null,
      responseSent: false,
      openedAt: new Date().toISOString()
    };
    req.on('aborted', () => {
      wire.reqAborted = true;
      record('request_aborted', { requestIndex: wire.requestIndex, kind: wire.kind, reqDestroyed: req.destroyed });
    });
    req.on('close', () => {
      wire.reqClose = true;
      record('request_close', { requestIndex: wire.requestIndex, kind: wire.kind, reqAborted: wire.reqAborted, reqComplete: req.complete });
    });
    res.on('close', () => {
      wire.resClose = true;
      record('response_close', { requestIndex: wire.requestIndex, kind: wire.kind, resFinished: res.writableFinished, resEnded: res.writableEnded });
    });
    res.on('finish', () => {
      wire.resFinish = true;
      record('response_finish', { requestIndex: wire.requestIndex, kind: wire.kind });
    });
    res.on('error', error => {
      wire.resError = redact(error instanceof Error ? error.message : String(error));
      record('response_error', { requestIndex: wire.requestIndex, kind: wire.kind, message: wire.resError });
    });
    req.on('data', chunk => { raw += chunk; });
    req.on('end', async () => {
      if (req.url !== '/v1/chat/completions') return writeError(res, 404, 'Unexpected fixture route');
      try {
        const body = JSON.parse(raw);
        const text = JSON.stringify(body.messages ?? []);
        const summary = text.includes('Please summarize the following conversation.');
        const foundMarkers = markersIn(text);
        const lastUser = [...(body.messages ?? [])].reverse().find(message => message?.role === 'user');
        const currentMarkers = markersIn(JSON.stringify(lastUser ?? {}));
        const kind = summary ? 'summary' : 'main';
        const request = {
          index: active.requests.length + 1,
          kind,
          bodyBytes: Buffer.byteLength(raw),
          messageCount: Array.isArray(body.messages) ? body.messages.length : null,
          toolsCount: Array.isArray(body.tools) ? body.tools.length : 0,
          markers: foundMarkers,
          currentMarkers,
          hasSummaryPrompt: summary,
          model: body.model
        };
        wire.requestIndex = request.index;
        wire.kind = kind;
        active.requests.push(request);
        active.wire.push(wire);
        record('request_received', { requestIndex: request.index, kind, bodyBytes: request.bodyBytes, messageCount: request.messageCount, currentMarkers });
        if (summary) {
          active.summaryRequests.push({ request, wire, req, res });
          active.summaryPendingCount += 1;
          active.summaryReceived += 1;
          record('summary_received', { requestIndex: request.index, openSummaryCount: active.summaryPendingCount });
          await waitFor(() => active.queueSubmitted || active.releaseRequested || wire.reqAborted || wire.resClose, 30000, 25);
          if (!active.releaseRequested && !wire.reqAborted && !wire.resClose) {
            await waitFor(() => active.releaseRequested || wire.reqAborted || wire.resClose, 30000, 25);
          }
          if (active.releaseRequested && !wire.reqAborted && !wire.resClose && !res.destroyed && !res.writableEnded) {
            request.response = { status: 200, kind: 'summary-released' };
            wire.responseSent = true;
            active.summaryCompleted += 1;
            active.summaryPendingCount = Math.max(0, active.summaryPendingCount - 1);
            record('summary_released', { requestIndex: request.index, openSummaryCount: active.summaryPendingCount });
            writeSse(res, summaryText);
            return;
          }
          request.response = {
            status: 'client_closed_before_release',
            reqAborted: wire.reqAborted,
            responseClosed: wire.resClose,
            responseFinished: wire.resFinish
          };
          active.summaryPendingCount = Math.max(0, active.summaryPendingCount - 1);
          record('summary_not_released', { requestIndex: request.index, reqAborted: wire.reqAborted, responseClosed: wire.resClose });
          return;
        }
        const queueMarkers = currentMarkers.filter(marker => marker.startsWith('QUEUE872_') || marker.startsWith('HEALTHY872_'));
        if (queueMarkers.length) {
          for (const marker of queueMarkers) active.deliveries[marker] = (active.deliveries[marker] ?? 0) + 1;
          request.response = { status: 200, delivered: queueMarkers[queueMarkers.length - 1], deliveredMarkers: queueMarkers };
          record('main_marker_delivery', { requestIndex: request.index, markers: queueMarkers });
          wire.responseSent = true;
          writeSse(res, `DELIVERED872_ISOLATION_${active.name}_${queueMarkers.join('_')}`);
          return;
        }
        active.mainResponses += 1;
        const ordinal = active.mainResponses;
        request.response = { status: 200, delivered: null };
        const padding = Array.from({ length: 1400 }, (_, index) => `LONG872_ISOLATION_${active.name}_${ordinal}_${index}`).join(' ');
        wire.responseSent = true;
        writeSse(res, `ACK872_ISOLATION_${active.name}_${ordinal} ${padding}`);
      } catch (error) {
        active?.errors.push(redact(error instanceof Error ? error.stack ?? error.message : String(error)));
        writeError(res, 500, 'fixture parse failure');
      }
    });
  });
  server.listen(0, '127.0.0.1', () => resolve(server.address().port));
});
const port = await serverReady;

const safeScreen = screen => redact(screen).slice(-50000);
const sessionFiles = async home => {
  const root = path.join(home, '.commandcode', 'projects');
  const out = [];
  async function walk(dir) {
    if (!fs.existsSync(dir)) return;
    for (const entry of await fsp.readdir(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) await walk(full);
      else if (entry.name.endsWith('.jsonl') && !entry.name.endsWith('.checkpoints.jsonl')) out.push(full);
    }
  }
  await walk(root);
  return out;
};
const transcriptSummary = async (home, runDir, scenario) => {
  const files = await sessionFiles(home);
  const summaries = [];
  for (const file of files) {
    const source = await fsp.readFile(file, 'utf8');
    const lines = source.split(/\r?\n/).filter(Boolean);
    const entries = lines.map(line => JSON.parse(line));
    const entryTypes = {};
    for (const entry of entries) entryTypes[entry.type] = (entryTypes[entry.type] ?? 0) + 1;
    const compactionEntries = entries.filter(entry => entry.type === 'compaction').map(entry => ({
      id: entry.id,
      parentId: entry.parentId,
      firstKeptEntryId: entry.firstKeptEntryId,
      summaryCharacters: String(entry.summary ?? '').length,
      summarySha256: sha256(String(entry.summary ?? ''))
    }));
    const markerCounts = {}, userMarkerCounts = {}, assistantMarkerCounts = {};
    const allMarkers = [...new Set([...markersIn(source), `QUEUE872_${scenario.toUpperCase().replaceAll('-', '_')}`, `HEALTHY872_${scenario.toUpperCase().replaceAll('-', '_')}`])];
    const countMarker = (value, marker) => value.split(marker).length - 1;
    for (const marker of allMarkers) {
      markerCounts[marker] = countMarker(source, marker);
      userMarkerCounts[marker] = entries.filter(entry => entry.type === 'message' && entry.message?.role === 'user').reduce((sum, entry) => sum + countMarker(JSON.stringify(entry), marker), 0);
      assistantMarkerCounts[marker] = entries.filter(entry => entry.type === 'message' && entry.message?.role === 'assistant').reduce((sum, entry) => sum + countMarker(JSON.stringify(entry), marker), 0);
    }
    const relativePath = path.relative(process.cwd(), file);
    await fsp.writeFile(path.join(runDir, `transcript-redacted-${summaries.length + 1}.jsonl`), lines.map(line => redact(line)).join('\n') + '\n');
    summaries.push({ relativePath, lineCount: lines.length, entryTypes, compactionEntries, markerCounts, userMarkerCounts, assistantMarkerCounts, transcriptSha256: sha256(source) });
  }
  const result = { scenario, files: summaries };
  save(path.join(runDir, 'transcript-summary.json'), result);
  return result;
};

async function runScenario(name) {
  const runDir = path.join(runRoot, name);
  const home = path.join(runDir, 'home');
  const project = path.join(runDir, 'project');
  fs.mkdirSync(project, { recursive: true });
  const env = isolatedEnv(home, port);
  await configure(home, project, runtime, port);
  save(path.join(home, '.commandcode', 'settings.json'), { disableScratchpad: true, mods: { disabled: ['titling', 'learning'] } });
  active = {
    name,
    startedAt: Date.now(),
    runId: randomUUID(),
    runDir,
    home,
    project,
    requests: [],
    wire: [],
    events: [],
    summaryRequests: [],
    summaryReceived: 0,
    summaryCompleted: 0,
    summaryPendingCount: 0,
    mainResponses: 0,
    deliveries: {},
    errors: [],
    queueSubmitted: false,
    healthySubmitted: false,
    escapeSent: false,
    releaseRequested: false
  };
  const term = terminal(runtime, here, runDir, project, env, []);
  const result = {
    schemaVersion: 1,
    runId: active.runId,
    scenario: name,
    version: '1.58.0',
    bundleSha256,
    node: process.version,
    platform: process.platform,
    provider: { host: '127.0.0.1', port, paidInference: false },
    cancelWindowMs,
    fixedInputDelayMs,
    ready: false,
    failure: null,
    events: null,
    wire: null,
    requests: null,
    deliveries: null,
    screens: {},
    transcript: null
  };
  const send = async (text, label) => {
    record('input_write', { label, text });
    term.child.write(text);
    await sleep(fixedInputDelayMs);
    term.child.write('\r');
    record('input_submit', { label });
  };
  const waitForCurrentMarker = (marker, timeoutMs) => waitFor(
    () => active.requests.some(request => request.kind === 'main' && request.currentMarkers.includes(marker)),
    timeoutMs
  );
  try {
    result.ready = await term.until(() => term.screen().includes('Ask your question'), 30000);
    record('prompt_ready', { ready: result.ready });
    if (!result.ready) throw new Error('interactive prompt did not become ready');
    await sleep(5000);
    await send('WARMUP872_ISOLATION_INITIAL', 'warmup_initial');
    if (!await waitForCurrentMarker('WARMUP872_ISOLATION_INITIAL', 8000)) {
      await send('WARMUP872_ISOLATION_RETRY', 'warmup_retry');
      if (!await waitForCurrentMarker('WARMUP872_ISOLATION_RETRY', 15000)) throw new Error('warmup response timeout');
    }
    for (let index = 0; index < 14; index++) {
      const marker = `SEED872_${name.toUpperCase().replaceAll('-', '_')}_${String(index).padStart(2, '0')}`;
      await send(`${marker}: retain this local isolation fixture marker.`, `seed_${index}`);
      if (!await waitForCurrentMarker(marker, 30000)) throw new Error(`seed response timeout ${index}`);
    }
    await send('/compact', 'manual_compact');
    if (!await waitFor(() => active.summaryReceived >= 1, 60000)) throw new Error('manual /compact did not reach the held provider summary request');
    result.summaryPendingObserved = true;
    record('summary_pending_observed', { openSummaryCount: active.summaryPendingCount });
    const suffix = name === 'cancel-held' ? 'CANCEL_HELD' : 'NOESCAPE';
    const queueMarker = `QUEUE872_${suffix}`;
    const healthyMarker = `HEALTHY872_${suffix}`;
    await send(`${queueMarker}: queued marker before the fixed cancellation window.`, 'queue_marker');
    active.queueSubmitted = true;
    await sleep(1200);
    result.screens.duringSummary = safeScreen(term.screen());
    record('queue_screen_captured', { queueMarker, visible: term.screen().includes(queueMarker), openSummaryCount: active.summaryPendingCount });
    await send(`${healthyMarker}: healthy marker submitted while summary remains held.`, 'healthy_marker');
    active.healthySubmitted = true;
    await sleep(1200);
    result.screens.afterHealthyInput = safeScreen(term.screen());
    record('healthy_input_screen_captured', { healthyMarker, visible: term.screen().includes(healthyMarker), openSummaryCount: active.summaryPendingCount });
    if (name === 'cancel-held') {
      term.child.write('\x1b');
      active.escapeSent = true;
      record('escape_sent', { openSummaryCount: active.summaryPendingCount });
    } else {
      record('no_escape_control', { openSummaryCount: active.summaryPendingCount });
    }
    await sleep(cancelWindowMs);
    result.screens.afterWindow = safeScreen(term.screen());
    result.windowObservation = {
      openSummaryCount: active.summaryPendingCount,
      summaryReceived: active.summaryReceived,
      summaryCompleted: active.summaryCompleted,
      requestAborted: active.summaryRequests.filter(item => item.wire.reqAborted).length,
      responseClosed: active.summaryRequests.filter(item => item.wire.resClose).length,
      responseFinished: active.summaryRequests.filter(item => item.wire.resFinish).length,
      queueVisible: term.screen().includes(queueMarker),
      healthyVisible: term.screen().includes(healthyMarker)
    };
    record('fixed_window_observed', result.windowObservation);
    active.releaseRequested = true;
    record('release_requested', { openSummaryCount: active.summaryPendingCount });
    await waitFor(() => active.summaryCompleted >= 1 || active.summaryPendingCount === 0, 30000);
    await waitFor(() => active.deliveries[queueMarker] === 1 && active.deliveries[healthyMarker] === 1, 30000);
    await sleep(1500);
    result.screens.final = safeScreen(term.screen());
  } catch (error) {
    result.failure = { message: redact(error instanceof Error ? error.message : String(error)), stack: redact(error instanceof Error ? error.stack ?? '' : '') };
    result.screens.failure = safeScreen(term.screen());
  } finally {
    record('before_terminal_close', { openSummaryCount: active.summaryPendingCount });
    const closed = await term.close();
    record('terminal_closed', { exitCode: closed.exitCode, openSummaryCount: active.summaryPendingCount });
    await sleep(100);
    const ptyPath = path.join(runDir, 'pty-redacted.log');
    await fsp.writeFile(ptyPath, redact(term.raw));
    result.exit = closed;
    result.rawPtyLogSha256 = sha256(await fsp.readFile(ptyPath));
    result.events = [...active.events];
    result.wire = active.wire.map(item => ({
      requestIndex: item.requestIndex,
      kind: item.kind,
      reqAborted: item.reqAborted,
      reqClose: item.reqClose,
      resClose: item.resClose,
      resFinish: item.resFinish,
      resError: item.resError,
      responseSent: item.responseSent
    }));
    result.requests = active.requests.map(request => ({ ...request }));
    result.summaryRequests = active.summaryRequests.map(item => ({
      index: item.request.index,
      response: item.request.response,
      wire: {
        reqAborted: item.wire.reqAborted,
        reqClose: item.wire.reqClose,
        resClose: item.wire.resClose,
        resFinish: item.wire.resFinish,
        resError: item.wire.resError,
        responseSent: item.wire.responseSent
      }
    }));
    result.deliveries = { ...active.deliveries };
    result.providerErrors = [...active.errors];
    result.transcript = await transcriptSummary(home, runDir, name);
    result.stopReason = result.failure ? 'bounded failure retained' : 'held summary released after fixed window';
    save(path.join(runDir, 'results.json'), result);
  }
  return result;
}

const results = [];
try {
  for (const name of selected) results.push(await runScenario(name));
} finally {
  server.closeAllConnections?.();
  await new Promise(resolve => server.close(resolve));
}
const summary = {
  schemaVersion: 1,
  version: '1.58.0',
  bundleSha256,
  runtimePath: path.relative(process.cwd(), runtime.runtime),
  node: process.version,
  platform: process.platform,
  scenarios: results.map(result => ({
    scenario: result.scenario,
    failure: result.failure,
    exit: result.exit,
    summaryPendingObserved: result.summaryPendingObserved,
    windowObservation: result.windowObservation,
    summaryRequests: result.summaryRequests,
    deliveries: result.deliveries,
    eventNames: result.events?.map(event => event.event)
  })),
  limits: [
    'Local scripted provider only.',
    'The summary response is held open through the fixed window and released after it; the fixture does not destroy it.',
    'Generated history remains below the reporter 655,598-token session.',
    'No paid inference, production provider, billing, gateway or release claim.'
  ]
};
save(path.join(runRoot, 'results.json'), summary);
console.log(JSON.stringify(summary));
process.exit(0);
