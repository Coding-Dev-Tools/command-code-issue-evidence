import {fs,path,assert,sleep} from './common.mjs';
export function terminal(pkg,here,out,project,env,extra=[]){
 const {Terminal}=pkg.req('@xterm/headless'),pty=pkg.req('@lydell/node-pty');
 const term=new Terminal({cols:150,rows:48,allowProposedApi:true,scrollback:3000});
 const policy=['--permission','--allow-child-process',`--allow-fs-read=${pkg.runtime}`,`--allow-fs-read=${here}`,`--allow-fs-read=${out}`,`--allow-fs-write=${out}`,'--require',path.join(here,'offline-guard.cjs')];
 env.NODE_OPTIONS=policy.map(x=>JSON.stringify(x.replaceAll('\\','/'))).join(' ');
 const args=[pkg.cli,'--no-auto-update','--local-only','--skip-onboarding','--trust','--no-skills','--model','fixture/model',...extra];
 const child=pty.spawn(process.execPath,args,{cwd:project,env,cols:150,rows:48,useConpty:true,windowsHide:true});
 let raw='',exit=null;term.onData(x=>child.write(x));child.onData(x=>{raw+=x;term.write(x)});child.onExit(x=>exit=x);
 const screen=()=>Array.from({length:term.buffer.active.length},(_,i)=>term.buffer.active.getLine(i)?.translateToString(true)??'').join('\n');
 async function until(pred,ms=20000){const end=Date.now()+ms;while(Date.now()<end&&!exit&&!pred())await sleep(100);return !!pred();}
 async function type(text){process.stdout.write(`TYPE872 input ${text.length}\n`);child.write(text);await sleep(300);child.write('\r');}
 async function close(){if(!exit){await type('/exit');await until(()=>exit,8000);}if(!exit){child.kill();await until(()=>exit,2000);}term.dispose();return exit;}
 return{child,screen,until,type,close,get raw(){return raw},get exit(){return exit},args};
}
