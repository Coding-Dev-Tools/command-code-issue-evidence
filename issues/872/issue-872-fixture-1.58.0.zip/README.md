# Issue #872 held-summary cancellation isolation packet

This packet is a local, read-only reproduction fixture for the manual `/compact` queue lifecycle. It compares an Escape control with a no-Escape control while the scripted summary response stays open. The provider is loopback only. No account, production provider, paid inference, gateway, billing or release claim is involved.

## Pinned environment

- Command Code `1.58.0`, bundle SHA-256 `aab2bec800371953112d18472bb7383992ef264cca22558bdcda77e7d0dc0f14`
- Node `24.15.0` was used for the retained run
- Windows ConPTY
- `@lydell/node-pty` `1.1.0`
- `@xterm/headless` `6.0.0`
- Dependencies are pinned in `package-lock.json`

## Run from an extracted directory

The packet intentionally excludes `node_modules`. From a fresh extraction whose path contains spaces, run:

```powershell
npm ci --ignore-scripts
node files\cancel-isolation.mjs .\node_modules .\output cancel-held,noescape
node files\verify-cancel-isolation.mjs .\output\results.json
```

The driver waits for `Ask your question...`, allows a five second focus settle, writes each input directly, waits one second before carriage return, and requires the local provider request before continuing. It creates isolated CLI homes under the selected output directory. The fixed observation window is 3,000 ms. The summary is released after that window and is never destroyed by the cancellation control.

## Expected observation

At the fixed window both controls should report one open summary, one received summary, zero completed summaries, zero request aborts, zero response closes, zero response finishes, and both queue and healthy markers visible. Escape should add the local `Interrupted` state. After release, both controls should record one compaction entry and deliver each marker once. The result verifier checks these invariants and the pinned bundle hash.

`reference/results.json` is the retained aggregate from the 1.58.0 run. It is an evidence reference, not a claim that the reporter's DeepSeek 1M session was reproduced. The generated request history is below the reporter's 655,598-token session.

## Negative verifier control

`negative-control/tampered-results.json` changes a required wire invariant. Running the verifier against it must fail with exit code 1. This checks that a superficially complete result cannot pass after an abort or lifecycle value is altered.
