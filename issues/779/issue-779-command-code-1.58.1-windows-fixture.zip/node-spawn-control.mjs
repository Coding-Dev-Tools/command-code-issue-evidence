import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
const root = process.cwd();
const out = path.join(root, 'node-spawn-runs', new Date().toISOString().replaceAll(':','').replaceAll('.',''));
fs.mkdirSync(out, { recursive: true });
const environment = {};
for (const key of ['SystemRoot','WINDIR','ComSpec','PATHEXT']) if (process.env[key]) environment[key]=process.env[key];
environment.PATH = [path.dirname(process.execPath), path.join(process.env.SystemRoot,'System32')].join(path.delimiter);
const cases = [];
for (const detached of [false,true]) {
  for (const nested of [false,true]) {
    const command = nested ? 'cmd.exe /d /c "echo PARENT779_OUT& echo PARENT779_ERR 1>&2& exit /b 7"' : 'echo PARENT779_OUT& echo PARENT779_ERR 1>&2& exit /b 7';
    const row = await new Promise(resolve=>{
      const row = {detached,nested,command,stdout:'',stderr:'',events:[]};
      const p = spawn(command,[],{shell:true,detached,stdio:['ignore','pipe','pipe'],windowsHide:true,env:environment,cwd:out});
      const timer=setTimeout(()=>{p.kill();row.timeout=true;},5000);
      p.stdout.on('data',b=>{row.stdout+=b; row.events.push('stdout-data');});
      p.stderr.on('data',b=>{row.stderr+=b; row.events.push('stderr-data');});
      p.on('error',e=>{row.error=e.message;});
      p.on('exit',(code,signal)=>{row.exit={code,signal};row.events.push('exit');});
      p.on('close',(code,signal)=>{clearTimeout(timer);row.close={code,signal};row.events.push('close');resolve(row);});
    });
    cases.push(row);
  }
}
const result={at:new Date().toISOString(),node:process.version,platform:process.platform,scope:'Plain Node spawn control, not CLI runtime evidence',cases};
fs.writeFileSync(path.join(out,'result.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));
