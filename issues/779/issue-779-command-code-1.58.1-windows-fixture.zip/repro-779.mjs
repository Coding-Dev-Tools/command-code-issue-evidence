import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = here;
const runtime = path.join(here, 'runtime/node_modules');
const runtimePackage = path.join(here, 'runtime/package.json');
const runtimeRoot = path.join(here, 'runtime');
const cli = path.join(runtime, 'command-code/dist/index.mjs');
const cliBundle = path.join(runtime, 'command-code/dist/cli.mjs');
const guard = path.join(here, 'offline-guard.cjs');
const outputRoot = path.resolve(process.env.ISSUE_779_OUTPUT ?? path.join(here, 'runs'));
const runId = process.env.ISSUE_779_RUN_ID ?? `${new Date().toISOString().replaceAll(':', '').replaceAll('.', '')}-${process.pid}`;
const runDir = path.join(outputRoot, runId);
const expectedCliSha256 = '2bc59dacb82a75d7db6b49699bf6e7537287a7ffcc20c78e143f907a62843198';
const cliSha256 = createHash('sha256').update(fs.readFileSync(cliBundle)).digest('hex');
assert.equal(cliSha256, expectedCliSha256, 'unexpected 1.58.1 CLI bundle');
assert.ok(fs.existsSync(runtimePackage), `missing isolated runtime manifest: ${runtimePackage}`);
if (fs.existsSync(runDir)) throw new Error(`Refusing to overwrite existing run directory: ${runDir}`);
fs.mkdirSync(runDir, { recursive: true });

const req = createRequire(runtimePackage);
const pty = req('@lydell/node-pty');
const { Terminal } = req('@xterm/headless');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const sha = value => createHash('sha256').update(value).digest('hex');
const read = file => fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
const writeJson = (file, value) => fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n');

const scenarios = [
  {
    "id": "child-background",
    "shell": "cmd",
    "command": "cmd.exe /d /c \"echo OUT779_CMD_IMMEDIATE& echo ERR779_CMD_IMMEDIATE 1>&2& exit /b 7\"",
    "expectedExit": 7,
    "stdoutMarkers": [
      "OUT779_CMD_IMMEDIATE"
    ],
    "stderrMarkers": [
      "ERR779_CMD_IMMEDIATE"
    ],
    "background": true
  },
  {
    "id": "child-foreground",
    "shell": "cmd",
    "command": "cmd.exe /d /c \"echo OUT779_CMD_IMMEDIATE& echo ERR779_CMD_IMMEDIATE 1>&2& exit /b 7\"",
    "expectedExit": 7,
    "stdoutMarkers": [
      "OUT779_CMD_IMMEDIATE"
    ],
    "stderrMarkers": [
      "ERR779_CMD_IMMEDIATE"
    ],
    "background": false
  },
  {
    "id": "builtin-background",
    "shell": "cmd",
    "command": "echo OUT779_CMD_IMMEDIATE& echo ERR779_CMD_IMMEDIATE 1>&2& exit /b 7",
    "expectedExit": 7,
    "stdoutMarkers": [
      "OUT779_CMD_IMMEDIATE"
    ],
    "stderrMarkers": [
      "ERR779_CMD_IMMEDIATE"
    ],
    "background": true
  },
  {
    "id": "builtin-foreground",
    "shell": "cmd",
    "command": "echo OUT779_CMD_IMMEDIATE& echo ERR779_CMD_IMMEDIATE 1>&2& exit /b 7",
    "expectedExit": 7,
    "stdoutMarkers": [
      "OUT779_CMD_IMMEDIATE"
    ],
    "stderrMarkers": [
      "ERR779_CMD_IMMEDIATE"
    ],
    "background": false
  }
];
const selectedIds = process.env.ISSUE_779_SCENARIOS?.split(',').map(value => value.trim()).filter(Boolean);
const selected = selectedIds?.length ? scenarios.filter(scenario => selectedIds.includes(scenario.id)) : scenarios;
if (selectedIds?.length && selected.length !== selectedIds.length) throw new Error(`Unknown scenario: ${selectedIds.join(',')}`);

function makeEnvironment(home, port) {
  for (const relative of ['tmp', 'AppData/Roaming', 'AppData/Local', '.commandcode']) fs.mkdirSync(path.join(home, relative), { recursive: true });
  const env = {};
  for (const key of ['SystemRoot', 'WINDIR', 'ComSpec', 'PATHEXT', 'PROCESSOR_ARCHITECTURE']) if (process.env[key]) env[key] = process.env[key];
  const system32 = process.env.SystemRoot ? path.join(process.env.SystemRoot, 'System32') : null;
  const windowsPowerShell = process.env.SystemRoot ? path.join(system32, 'WindowsPowerShell', 'v1.0') : null;
  env.PATH = [path.dirname(process.execPath), system32, windowsPowerShell, ...(process.env.SystemRoot ? [] : ['/usr/bin', '/bin'])].filter(Boolean).join(path.delimiter);
  return Object.assign(env, {
    HOME: home,
    USERPROFILE: home,
    APPDATA: path.join(home, 'AppData/Roaming'),
    LOCALAPPDATA: path.join(home, 'AppData/Local'),
    TEMP: path.join(home, 'tmp'),
    TMP: path.join(home, 'tmp'),
    CMD_LOCAL_ONLY: '1',
    DO_NOT_TRACK: '1',
    OTEL_SDK_DISABLED: 'true',
    COMMANDCODE_SKIP_UPDATES: '1',
    COMMANDCODE_DISABLE_CRON: '1',
    COMMANDCODE_DISABLE_DURABLE_CRON: '1',
    DOTENV_CONFIG_PATH: path.join(home, 'absent.env'),
    TERM: 'xterm-256color',
    NO_COLOR: '1',
    FIXTURE_PROVIDER_KEY: 'synthetic-provider-key-not-real',
    COMMAND_CODE_API_KEY: 'synthetic-command-key-not-real',
    FIXTURE_PORT: String(port)
  });
}

function screenText(term) {
  const buffer = term.buffer.active;
  return Array.from({ length: buffer.length }, (_, index) => buffer.getLine(index)?.translateToString(true) ?? '').join('\n');
}

function stripAnsi(value) {
  return value
    .replace(/[\u001b\u009b]\[[0-?]*[ -/]*[@-~]/g, '')
    .replace(/[\u001b\u009b][\]PX^_].*?(?:\u0007|\u001b\\)/g, '')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '');
}

function sanitize(value, replacements) {
  let result=String(value??'');
  for(const [from,to] of replacements){for(const form of [from,from.replaceAll('\\','/'),from.replaceAll('\\','\\\\')])result=result.split(form).join(to);}
  return result.replace(/C:[/\\]+Users[/\\]+[^/\\\r\n ]+/gi,'<LOCAL_USER>');
}

function writeSse(res, payloads, baseId) {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' });
  for (const payload of payloads) res.write(`data: ${JSON.stringify({ id: baseId, object: 'chat.completion.chunk', created: 1, model: 'fixture-model', ...payload })}\n\n`);
  res.end('data: [DONE]\n\n');
}

function toolCall(name, id, input) {
  return { index: 0, id, type: 'function', function: { name, arguments: JSON.stringify(input) } };
}

function parseTaskId(text) {
  return String(text).match(/(?:^|\n)Task:\s+([a-z0-9_-]+)/i)?.[1] ?? null;
}

async function until(predicate, timeoutMs = 30000) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end && !predicate()) await sleep(100);
  return predicate();
}

async function runScenario(scenario) {
  const scenarioDir = path.join(runDir, scenario.id);
  fs.mkdirSync(scenarioDir, { recursive: true });
  const home = path.join(scenarioDir, 'home');
  const project = path.join(scenarioDir, 'project');
  fs.mkdirSync(project, { recursive: true });
  const requests = [];
  let serverErrors = [];
  let server;
  server = http.createServer((request, response) => {
    let bodyText = '';
    request.on('data', chunk => { bodyText += chunk; if (bodyText.length > 4_000_000) request.destroy(); });
    request.on('end', () => {
      if (!request.url?.endsWith('/chat/completions')) { response.writeHead(404); response.end('fixture endpoint not found'); return; }
      let body;
      try { body = JSON.parse(bodyText); } catch { response.writeHead(400); response.end('invalid JSON'); return; }
      const toolNames = (body.tools ?? []).map(tool => tool.function?.name ?? tool.name).filter(Boolean);
      const toolMessages = (body.messages ?? []).filter(message => message.role === 'tool').map(message => ({ id: message.tool_call_id, content: String(message.content) }));
      const row = { index: requests.length + 1, toolNames, toolMessages: toolMessages.map(message => ({ id: message.id, content: message.content.slice(0, 12000) })) };
      requests.push(row);
      const baseId = `issue-779-${scenario.id}-${requests.length}`;
      try {
        if (requests.length === 1) {
          if (!toolNames.includes('shell_command')) throw new Error(`shell_command unavailable: ${toolNames.join(',')}`);
          const input = { command: scenario.command, cwd: project, run_in_background: scenario.background !== false, description: `Issue 779 ${scenario.id} child` };
          row.scriptedTool = { name: 'shell_command', input };
          writeSse(response, [
            { choices: [{ index: 0, delta: { role: 'assistant', tool_calls: [toolCall('shell_command', `call-779-${scenario.id}-start`, input)] }, finish_reason: null }] },
            { choices: [{ index: 0, delta: {}, finish_reason: 'tool_calls' }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } }
          ], baseId);
          return;
        }
        const last = toolMessages.at(-1)?.content ?? '';
        const previousCall = requests.at(-2)?.scriptedTool?.name ?? null;
        const taskId = toolMessages.map(message => parseTaskId(message.content)).find(Boolean) ?? null;
        if (requests.length === 2 && scenario.wrongIdFirst) {
          const wrong = `s779wrong-${scenario.id}`;
          const input = { id: wrong, wait: 'exit', timeout_ms: 2000 };
          row.scriptedTool = { name: 'shell_output', input };
          writeSse(response, [
            { choices: [{ index: 0, delta: { role: 'assistant', tool_calls: [toolCall('shell_output', `call-779-${scenario.id}-wrong`, input)] }, finish_reason: null }] },
            { choices: [{ index: 0, delta: {}, finish_reason: 'tool_calls' }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } }
          ], baseId);
          return;
        }
        if (scenario.background === false && requests.length === 2) {
          row.finalToolResults = toolMessages.map(message => ({ id: message.id, content: message.content.slice(0, 12000) }));
          writeSse(response, [
            { choices: [{ index: 0, delta: { role: 'assistant', content: `SHELL_779_DONE ${scenario.id}` }, finish_reason: null }] },
            { choices: [{ index: 0, delta: {}, finish_reason: 'stop' }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } }
          ], baseId);
          return;
        }
        if (requests.length === 2 || (scenario.wrongIdFirst && requests.length === 3)) {
          if (!taskId) throw new Error(`could not parse task id from tool result after ${previousCall ?? 'shell_command'}: ${last.slice(0, 500)}`);
          const input = { id: taskId, wait: 'exit', timeout_ms: scenario.delayed ? 5000 : 3000 };
          row.scriptedTool = { name: 'shell_output', input };
          writeSse(response, [
            { choices: [{ index: 0, delta: { role: 'assistant', tool_calls: [toolCall('shell_output', `call-779-${scenario.id}-output`, input)] }, finish_reason: null }] },
            { choices: [{ index: 0, delta: {}, finish_reason: 'tool_calls' }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } }
          ], baseId);
          return;
        }
        row.finalToolResults = toolMessages.map(message => ({ id: message.id, content: message.content.slice(0, 12000) }));
        writeSse(response, [
          { choices: [{ index: 0, delta: { role: 'assistant', content: `SHELL_779_DONE ${scenario.id}` }, finish_reason: null }] },
          { choices: [{ index: 0, delta: {}, finish_reason: 'stop' }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } }
        ], baseId);
      } catch (error) {
        serverErrors.push(error instanceof Error ? error.message : String(error));
        response.writeHead(500);
        response.end('fixture error');
      }
    });
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;
  const env = makeEnvironment(home, port);
  fs.writeFileSync(path.join(home, '.commandcode/providers.json'), JSON.stringify({ provider: { fixture779: { api: 'openai-completions', baseURL: `http://127.0.0.1:${port}/v1`, apiKey: '$FIXTURE_PROVIDER_KEY', models: { model: { contextWindow: 200000, maxOutput: 300, cost: { input: 0, output: 0 } } } } } }, null, 2));
  fs.writeFileSync(path.join(home, '.commandcode/config.json'), JSON.stringify({ model: 'fixture779/model', provider: 'fixture779', localOnly: true, telemetry: false, tasteLearning: false }, null, 2));
  const nodeArgs = [
    '--permission', '--allow-child-process', `--allow-fs-read=${runtimeRoot}`, `--allow-fs-read=${runDir}`, `--allow-fs-read=${repo}`, `--allow-fs-write=${runDir}`,
    '--require', guard, cli, '--no-auto-update', '--local-only', '--skip-onboarding', '--no-skills', '--yolo', '--model', 'fixture779/model', '--max-turns', '4',
    `Run the Issue 779 shell fixture for ${scenario.id}. Use shell_command with run_in_background, then shell_output wait exit, and report the observed markers and exit.`
  ];
  const policy = ['--permission', '--allow-child-process', `--allow-fs-read=${runtimeRoot}`, `--allow-fs-read=${runDir}`, `--allow-fs-read=${repo}`, `--allow-fs-write=${runDir}`, '--require', guard];
  env.NODE_OPTIONS = policy.map(value => JSON.stringify(value.replaceAll('\\', '/'))).join(' ');
  const term = new Terminal({ cols: 140, rows: 45, allowProposedApi: true, scrollback: 3000 });
  let raw = '';
  let exit = null;
  let child;
  const started = Date.now();
  try {
    child = pty.spawn(process.execPath, nodeArgs, { name: 'xterm-256color', cols: 140, rows: 45, cwd: project, env, useConpty: true, windowsHide: true });
    child.onData(data => { raw += data; term.write(data); });
    child.onExit(event => { exit = { code: event.exitCode, signal: event.signal }; });
    const completed = await until(() => screenText(term).includes(`SHELL_779_DONE ${scenario.id}`) || exit, scenario.delayed ? 40000 : 30000);
    const finalScreen = stripAnsi(screenText(term));
    if (!exit && completed) {
      child.write('/exit');
      await sleep(120);
      child.write('\r');
      await until(() => exit, 10000);
    }
    if (!exit) { child.kill(); await until(() => exit, 3000); }
    const replacements = [[repo, '<REPO>'], [home, '<HOME>'], [project, '<PROJECT>'], [runDir, '<RUN>']];
    const toolCalls = requests.flatMap(request => request.scriptedTool ? [{ index: request.index, name: request.scriptedTool.name, input: sanitize(JSON.stringify(request.scriptedTool.input), replacements) }] : []);
    const toolResults = requests.flatMap(request => request.finalToolResults ?? request.toolMessages ?? []).map(result => ({ id: result.id, content: sanitize(result.content, replacements) }));
    const outputResultText = toolResults.filter(result => result.id?.includes('-output') || result.id?.includes('-wrong') || (scenario.background === false && result.id?.includes('-start'))).map(result => result.content).join('\n');
    const startResultText = toolResults.filter(result => result.id?.includes('-start')).map(result => result.content).join('\n');
    const taskIds = [...startResultText.matchAll(/Task:\s+([a-z0-9_-]+)/gi)].map(match => match[1]);
    const outputTaskIds = [...outputResultText.matchAll(/Task:\s+([a-z0-9_-]+)/gi)].map(match => match[1]);
    const observedMarkers = [...scenario.stdoutMarkers, ...scenario.stderrMarkers].filter(marker => outputResultText.includes(marker));
    const observedExitCodes = [...outputResultText.matchAll(/Exit code:\s*(-?\d+)/gi)].map(match => Number(match[1]));
    const wrongIdErrorObserved = outputResultText.includes('shell_output: no background process found with id');
    const redirectionPath = scenario.redirectedFile ? path.join(project, scenario.redirectedFile) : null;
    const redirectionContent = redirectionPath ? read(redirectionPath) : null;
    const result = {
      scenario: scenario.id,
      shell: scenario.shell,
      command: scenario.command,
      expectedExit: scenario.expectedExit,
      stdoutMarkers: scenario.stdoutMarkers,
      stderrMarkers: scenario.stderrMarkers,
      fileMarkers: scenario.fileMarkers ?? [],
      wrongIdFirst: Boolean(scenario.wrongIdFirst),
      delayed: Boolean(scenario.delayed),
      version: '1.58.1',
      cliSha256,
      node: process.version,
      platform: process.platform,
      terminal: 'Windows ConPTY with @xterm/headless parser',
      elapsedMs: Date.now() - started,
      exit,
      completedMarkerObserved: finalScreen.includes(`SHELL_779_DONE ${scenario.id}`),
      requestCount: requests.length,
      background: scenario.background !== false,
      toolCalls,
      toolResults,
      outputResultText,
      startTaskIds: [...new Set(taskIds)],
      outputTaskIds: [...new Set(outputTaskIds)],
      observedMarkers,
      observedExitCodes,
      wrongIdErrorObserved,
      requests: requests.map(request => ({ index: request.index, toolNames: request.toolNames, scriptedTool: request.scriptedTool ? { name: request.scriptedTool.name, input: sanitize(JSON.stringify(request.scriptedTool.input), replacements) } : undefined, toolMessages: request.toolMessages.map(message => ({ id: message.id, content: sanitize(message.content, replacements) })) })),
      redirectionPath: redirectionPath ? '<PROJECT>/' + scenario.redirectedFile : null,
      redirectionContent,
      rawSha256: sha(raw),
      rawScreenTail: sanitize(finalScreen.slice(-12000), replacements),
      serverErrors,
      scope: 'Actual unmodified Command Code 1.58.1 CLI on Windows ConPTY with isolated home/project and localhost scripted provider. Shell output only; no provider/image/sub-agent claim.'
    };
    writeJson(path.join(scenarioDir, 'result.json'), result);
    fs.writeFileSync(path.join(scenarioDir, 'terminal-sanitized.txt'), sanitize(stripAnsi(raw), replacements));
    return result;
  } finally {
    if (child && !exit) child.kill();
    server.closeAllConnections();
    await new Promise(resolve => server.close(resolve));
    term.dispose();
  }
}

const results = [];
for (const scenario of selected) {
  try { results.push(await runScenario(scenario)); }
  catch (error) { results.push({ scenario: scenario.id, driverError: { name: error.name, message: error.message } }); }
}
const report = {
  runId,
  generatedAt: new Date().toISOString(),
  package: { name: 'command-code', version: '1.58.1', cliSha256, runtimeRoot: '<FIXTURE>/runtime', dependencies: { '@lydell/node-pty': '1.1.0', '@xterm/headless': '6.0.0', node: process.version } },
  platform: { node: process.version, platform: process.platform, windowsBuild: process.platform === 'win32' ? (process.env.OS ?? 'Windows') : null },
  scenarios: results,
  limitations: [
    'The localhost fixture scripted the model tool calls and final text; it does not establish real-provider or model behavior.',
    'The matrix covers tracked shell_command background tasks read through shell_output. It does not test Gradle, private HTML attachments, image limits, sub-agent failures, or a hosted gateway.',
    'Windows 11 ConPTY was exercised. Native Linux, Windows 10, macOS, Ghostty and Alacritty were not tested.',
    'Redirection file content was checked independently from shell_output; no claim is made about shell pipelines or daemon descendants.'
  ]
};
writeJson(path.join(runDir, 'results.json'), report);
console.log(JSON.stringify({ runDir, scenarios: results.map(result => ({ scenario: result.scenario, exit: result.exit, requests: result.requestCount, driverError: result.driverError?.message ?? null })) }));
