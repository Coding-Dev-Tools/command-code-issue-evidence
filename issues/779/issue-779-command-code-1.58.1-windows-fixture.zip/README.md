# Issue 779: Windows background child output

Windows 11 x64, Node 24.15.0. This fixture launches the unmodified Command Code 1.58.1 CLI in ConPTY using generated project/home directories and a localhost scripted provider. It executes only the four harmless echo/exit7 controls. No account or paid inference is used.

From this extracted directory:

```powershell
npm ci --prefix runtime --ignore-scripts
node repro-779.mjs
node verify-779.mjs runs/<printed-run-directory>/results.json
node node-spawn-control.mjs
```

Use the result path printed by the runner. Dependency installation contacts npm; test execution uses only generated local data and localhost. The CLI hash is checked before launch. The expected pinned behavior is missing child-executable output in background mode, with correct exit status; the other three cases retain both streams. A passing verifier confirms that regression and controls, not a fix.

This packet covers the four paired cmd/builtin CLI cases on 1.58.1. The separate Node spawn control varies detachment and nested cmd execution; it is a lower-level diagnostic and does not validate a process-management repair. Gradle, provider/image errors and subagent stalls remain outside this test. The earlier, larger 1.58.0 investigation is not relabeled as 1.58.1 evidence here.

To verify the retained reference capture without launching the CLI, run `node verify-779.mjs`. `NODE-REFERENCE-RESULTS.json` contains the separately verified Node control. A passing observation verifier means the pinned regression remains present; it is not a future-fix acceptance test.
