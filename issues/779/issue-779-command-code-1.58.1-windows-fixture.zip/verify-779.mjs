import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const file=path.resolve(process.argv[2]??path.join(here,'REFERENCE-RESULTS.json'));
const data=JSON.parse(fs.readFileSync(file,'utf8'));
function verify(x){
  assert.equal(x.package.version,'1.58.1');assert.equal(x.package.cliSha256,'2bc59dacb82a75d7db6b49699bf6e7537287a7ffcc20c78e143f907a62843198');
  assert.deepEqual(x.scenarios.map(s=>s.scenario),['child-background','child-foreground','builtin-background','builtin-foreground']);
  for(const s of x.scenarios){
    assert.equal(s.driverError??null,null);assert.deepEqual(s.serverErrors,[]);assert.equal(s.exit?.code,0);assert.equal(s.expectedExit,7);assert.ok(s.outputResultText.includes('Exit code: 7'));
    const expected=s.scenario!=='child-background';
    for(const m of ['OUT779_CMD_IMMEDIATE','ERR779_CMD_IMMEDIATE'])assert.equal(s.outputResultText.includes(m),expected,s.scenario+' '+m);
    if(s.background){assert.equal(s.startTaskIds.length,1);assert.ok(s.startTaskIds[0]);assert.deepEqual(s.outputTaskIds,s.startTaskIds);assert.ok(s.outputResultText.includes('Task: '+s.startTaskIds[0]));}
  }
  assert.equal(x.scenarios[0].command,x.scenarios[1].command);assert.equal(x.scenarios[2].command,x.scenarios[3].command);
}
verify(data);
const changes=[['missing case',x=>x.scenarios.pop()],['wrong ID',x=>x.scenarios[0].outputTaskIds=['foreign']],['wrong exit',x=>x.scenarios[0].expectedExit=0],['driver error',x=>x.scenarios[0].driverError='failed'],['missing healthy output',x=>x.scenarios[2].outputResultText=x.scenarios[2].outputResultText.replace('OUT779_CMD_IMMEDIATE','')]];
for(const[label,change]of changes){const copy=structuredClone(data);change(copy);assert.throws(()=>verify(copy),label);}
console.log(JSON.stringify({passed:true,scenarios:4,negativeControls:changes.length}));
