import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const modes = ['valid-text', 'eof-text', 'valid-tool', 'eof-complete-tool', 'eof-partial-tool', 'finish-no-done-tool', 'reset-text', 'explicit-error', 'eof-complete-tool-with-text', 'eof-partial-tool-with-text', 'explicit-error-with-text'];
const sha = data => createHash('sha256').update(data).digest('hex');
const rows = [];
const precise = 'Stream failed: Response stream ended without a finish reason.';
const generic = 'Error: Unable to connect to the API. Please check your network connection.';
for (const mode of modes) {
  const filename = path.join(root, `raw-${mode}.json`), bytes = fs.readFileSync(filename);
  const raw = JSON.parse(bytes);
  const parsed = raw.stdout.split(/\r?\n/).flatMap(line => { try { return [JSON.parse(line)]; } catch { return []; } });
  const events = parsed.filter(e => e.type === 'event').map(e => e.event);
  const result = parsed.findLast(e => e.type === 'result');
  const errors = events.filter(e => e.type === 'run_error').map(e => e.error);
  const retries = events.filter(e => e.type === 'api_retry').map(e => ({ attempt: e.attempt, message: e.error, delayMs: e.delayMs }));
  const toolEvents = events.filter(e => ['tool_queued', 'tool_running', 'tool_completed', 'tool_error'].includes(e.type));
  const toolResults = raw.requests.flatMap(r => r.body.messages.filter(m => m.role === 'tool'));
  const markerPresent = toolResults.some(r => JSON.stringify(r.content).includes('ISSUE_785_OWNED_READ_FIXTURE_7f6d'));
  assert.equal(raw.timedOut, false); assert.ok(result, `${mode}: final result required`);
  assert.equal(raw.cliSha256, '10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05');
  assert.ok(raw.requests[0].body.tools.some(t => t.function?.name === 'read_file'));
  let qualification = 'Natural single-request result';
  if (mode === 'valid-text') {
    assert.equal(raw.code, 0); assert.equal(result.subtype, 'success'); assert.equal(result.finalText, 'FIXTURE_COMPLETE_TEXT');
  } else if (['valid-tool', 'finish-no-done-tool'].includes(mode)) {
    assert.equal(result.subtype, 'success'); assert.equal(result.finalText, 'FIXTURE_TOOL_READ_CONFIRMED');
    assert.equal(raw.requests.length, 2); assert.equal(toolResults.length, 1); assert.equal(markerPresent, true);
    assert.equal(toolEvents.filter(e => e.type === 'tool_running').length, 1);
    assert.equal(toolEvents.filter(e => e.type === 'tool_completed').length, 1);
    // These controls prove tool flow; the process subsequently aborted in libuv.
    assert.equal(raw.code, 3221226505); assert.ok(raw.stderr.includes('UV_HANDLE_CLOSING'));
    qualification = 'Tool completed once and final success emitted; subsequent Windows libuv shutdown assertion, not a clean process pass';
  } else {
    assert.equal(result.subtype, 'error'); assert.equal(toolEvents.length, 0); assert.equal(toolResults.length, 0);
    assert.equal(result.finalText, '');
    if (['eof-text', 'eof-complete-tool-with-text', 'eof-partial-tool-with-text'].includes(mode)) {
      assert.equal(raw.requests.length, 1); assert.equal(raw.code, 6); assert.equal(errors[0].message, precise); assert.equal(result.error, generic);
      assert.ok(raw.stderr.includes(generic));
    } else if (['eof-complete-tool', 'eof-partial-tool', 'explicit-error'].includes(mode)) {
      assert.equal(raw.requests.length, 7); assert.equal(raw.code, 1); assert.ok(result.error.includes('Fixture request budget exceeded'));
      assert.ok(retries.length > 0);
      qualification = 'Six faulty responses observed without tool dispatch; seventh fixture-generated HTTP 400 stops retries. Not natural retry exhaustion';
    } else if (mode === 'reset-text') {
      assert.equal(raw.requests.length, 1); assert.equal(raw.code, 1); assert.equal(errors[0].message, 'Failed to process successful response');
    } else if (mode === 'explicit-error-with-text') {
      assert.equal(raw.requests.length, 1); assert.equal(raw.code, 6); assert.equal(errors[0].message, 'Stream failed: [object Object]'); assert.equal(result.error, generic);
    }
  }
  const sentChoices = raw.sent.filter(s => typeof s === 'object').flatMap(s => s.choices ?? []);
  rows.push({ mode, node: raw.node, cliVersion: raw.cliVersion, cliSha256: raw.cliSha256, exitCode: raw.code, timedOut: raw.timedOut, totalWallMs: raw.elapsedMs, modelRunMs: result.durationMs, requestCount: raw.requests.length,
    fixtureHttpStatus: qualification.startsWith('Six') ? '200 for six faulty responses; 400 on seventh guard response' : 200,
    finishReasonsSent: sentChoices.map(c => c.finish_reason).filter(x => x !== null), doneSentinelSent: raw.sent.includes('[DONE]'),
    eventTypes: events.map(e => e.type), toolEventTypes: toolEvents.map(e => e.type), toolResultMessages: toolResults.length, ownedReadMarkerReturned: markerPresent,
    errors, retries, result: { subtype: result.subtype, stopReason: result.stopReason ?? null, finalText: result.finalText, error: result.error ?? null }, qualification, rawEvidenceSha256: sha(bytes) });
}
const report = { scope: 'Eleven guarded current-CLI localhost fault-injection runs, not a production gateway reproduction. Raw system prompts and absolute local paths excluded.', runs: rows,
  summary: { runs: rows.length, naturallyCompletedMissingFinishFailures: 3, toolFlowControlsWithShutdownAssertion: 2, budgetTerminatedRetryExplorations: 3, textSuccessControls: 1, naturalResetErrors: 1, naturalExplicitErrorCases: 1 },
  limitations: ['SDK package versions are pinned in the separate component results.', 'Visible text was prepended in follow-up tool cases to exercise the existing no-retry-after-visible-output policy.', 'Tool-only exploratory cases ended with an injected budget error, not natural retry exhaustion.', 'Both tool-positive controls emitted successful results before a Windows libuv shutdown assertion. Do not count them as clean process exits.', 'The mock proposes only read_file against its owned text fixture. Node prohibits subprocesses; filesystem permissions also permit synthetic configuration and log writes.'] };
fs.writeFileSync(path.join(root, 'verified-summary.json'), JSON.stringify(report, null, 2) + '\n');
fs.writeFileSync(path.join(root, 'diagnostic-pair.txt'), `Observed with HTTP 200 and partial SSE data, then clean EOF without finish_reason:\n\nTrace run_error:\n${precise}\n\nFinal result.error and stderr:\n${generic}\n\nNatural process exit: 6; no tool dispatch in either tool-EOF follow-up.\n`);
console.log(JSON.stringify(report.summary));
