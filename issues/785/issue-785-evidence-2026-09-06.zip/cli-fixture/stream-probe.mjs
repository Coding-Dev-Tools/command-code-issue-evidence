import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root = path.dirname(fileURLToPath(import.meta.url));
const installedRoot = path.join(process.env.APPDATA, 'npm/node_modules/command-code');
const mode = process.argv[2];
const modes = ['valid-text', 'eof-text', 'valid-tool', 'eof-complete-tool', 'eof-partial-tool', 'finish-no-done-tool', 'reset-text', 'explicit-error', 'eof-complete-tool-with-text', 'eof-partial-tool-with-text', 'explicit-error-with-text'];
if (!modes.includes(mode)) throw Error(`Expected one of ${modes.join(', ')}`);
const home = path.join(root, `home-${mode}`), tmp = path.join(home, 'tmp');
const fixture = path.join(root, 'fixture.txt');
const marker = 'ISSUE_785_OWNED_READ_FIXTURE_7f6d';
for (const dir of [tmp, path.join(home, '.commandcode'), path.join(home, 'AppData/Roaming'), path.join(home, 'AppData/Local')]) fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(fixture, `${marker}\n`);
const requests = [], sent = [];
let resetTimer;
const model = 'stream-fixture/model';
const server = http.createServer((req, res) => {
  let raw = '';
  req.on('data', b => { raw += b; if (raw.length > 2_000_000) req.destroy(); });
  req.on('end', () => {
    if (!req.url.endsWith('/chat/completions')) { res.writeHead(404); res.end(); return; }
    let body; try { body = JSON.parse(raw); } catch { res.writeHead(400); res.end(); return; }
    requests.push({ path: req.url, body });
    if (requests.length > 6) { res.writeHead(400); res.end(JSON.stringify({ error: { message: 'Fixture request budget exceeded', type: 'fixture_budget' } })); return; }
    const base = { id: `fixture-${requests.length}`, object: 'chat.completion.chunk', created: 1, model: 'model' };
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' });
    const write = (delta, finish = null) => {
      const obj = { ...base, choices: [{ index: 0, delta, finish_reason: finish }] };
      sent.push(obj); res.write(`data: ${JSON.stringify(obj)}\n\n`);
    };
    const finish = (reason, done = true) => { write({}, reason); if (done) { sent.push('[DONE]'); res.write('data: [DONE]\n\n'); } res.end(); };
    // A second model call after an actual read must carry the real fixture marker.
    const toolReplies = (body.messages ?? []).filter(x => x.role === 'tool');
    if (toolReplies.length) {
      const readSucceeded = toolReplies.some(x => JSON.stringify(x.content).includes(marker));
      write({ role: 'assistant', content: readSucceeded ? 'FIXTURE_TOOL_READ_CONFIRMED' : 'FIXTURE_TOOL_RETURNED_ERROR' }); finish('stop'); return;
    }
    // Existing harness retry policy stops retrying after visible output. This
    // makes the stream failure's natural final message observable in one call.
    if (mode.endsWith('-with-text')) write({ role: 'assistant', content: 'FIXTURE_ALREADY_RECEIVED_TEXT' });
    if (mode.startsWith('explicit-error')) { const error = { error: { message: 'ISSUE_785_SYNTHETIC_UPSTREAM_FAILURE', type: 'fixture_error', code: 'fixture_error' } }; sent.push(error); res.end(`data: ${JSON.stringify(error)}\n\n`); return; }
    if (mode.includes('tool')) {
      const args = JSON.stringify({ file_path: fixture });
      const wireArgs = mode.includes('partial-tool') ? args.slice(0, -1) : args;
      write({ role: 'assistant', tool_calls: [{ index: 0, id: 'call_fixture_read', type: 'function', function: { name: 'read_file', arguments: '' } }] });
      const middle = Math.floor(wireArgs.length / 2);
      for (const part of [wireArgs.slice(0, middle), wireArgs.slice(middle)]) write({ tool_calls: [{ index: 0, function: { arguments: part } }] });
      if (mode === 'valid-tool') finish('tool_calls');
      else if (mode === 'finish-no-done-tool') finish('tool_calls', false);
      else res.end();
      return;
    }
    write({ role: 'assistant', content: mode === 'valid-text' ? 'FIXTURE_COMPLETE_TEXT' : 'FIXTURE_PARTIAL_TEXT' });
    if (mode === 'valid-text') finish('stop');
    else if (mode === 'reset-text') { resetTimer = setTimeout(() => res.destroy(new Error('owned fixture reset')), 80); }
    else res.end();
  });
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const port = server.address().port;
fs.writeFileSync(path.join(home, '.commandcode/providers.json'), JSON.stringify({ provider: { 'stream-fixture': { api: 'openai-completions', baseURL: `http://127.0.0.1:${port}/v1`, apiKey: '$FIXTURE_PROVIDER_KEY', models: { model: { contextWindow: 200000, maxOutput: 200, cost: { input: 0, output: 0 } } } } } }));
fs.writeFileSync(path.join(home, '.commandcode/config.json'), JSON.stringify({ model, provider: 'stream-fixture', localOnly: true, telemetry: false, tasteLearning: false }));
fs.writeFileSync(path.join(home, '.commandcode/settings.json'), JSON.stringify({ disableScratchpad: true, disableSkillShellExecution: true }));
const env = {};
for (const key of ['SystemRoot', 'WINDIR', 'ComSpec', 'PATHEXT', 'PROCESSOR_ARCHITECTURE']) if (process.env[key]) env[key] = process.env[key];
env.PATH = [path.dirname(process.execPath), path.join(process.env.SystemRoot, 'System32')].join(path.delimiter);
Object.assign(env, { HOME: home, USERPROFILE: home, APPDATA: path.join(home, 'AppData/Roaming'), LOCALAPPDATA: path.join(home, 'AppData/Local'), TEMP: tmp, TMP: tmp,
  CMD_LOCAL_ONLY: '1', DO_NOT_TRACK: '1', OTEL_SDK_DISABLED: 'true', COMMANDCODE_SKIP_UPDATES: '1', COMMANDCODE_DISABLE_CRON: '1', COMMANDCODE_DISABLE_DURABLE_CRON: '1',
  DOTENV_CONFIG_PATH: path.join(home, 'missing.env'), NO_COLOR: '1', FIXTURE_PORT: String(port), FIXTURE_PROVIDER_KEY: 'synthetic-provider-key-not-real', COMMAND_CODE_API_KEY: 'synthetic-command-key-not-real' });
const args = ['--no-auto-update', '--local-only', '--skip-onboarding', '--trust', '--no-skills', '--no-session', '--model', model, '--max-turns', '2', '--output-format', 'json', '--trace', '--print', 'Run the synthetic stream fixture. If a read tool is requested, read only the provided fixture file.'];
const nodeArgs = ['--permission', `--allow-fs-read=${installedRoot}`, `--allow-fs-read=${root}`, `--allow-fs-write=${root}`, '--require', path.join(root, 'offline-guard.cjs'), path.join(installedRoot, 'dist/index.mjs'), ...args];
const start = Date.now();
const child = spawn(process.execPath, nodeArgs, { cwd: root, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
let stdout = '', stderr = '', timedOut = false;
child.stdout.on('data', b => stdout += b); child.stderr.on('data', b => stderr += b);
const timer = setTimeout(() => { timedOut = true; child.kill(); }, 25000);
const exit = await new Promise(r => child.on('close', (code, signal) => r({ code, signal })));
clearTimeout(timer); clearTimeout(resetTimer); server.closeAllConnections(); await new Promise(r => server.close(r));
const events = stdout.split(/\r?\n/).flatMap(line => { try { return [JSON.parse(line)]; } catch { return []; } });
const result = { mode, node: process.version, cliVersion: JSON.parse(fs.readFileSync(path.join(installedRoot, 'package.json'))).version, cliSha256: createHash('sha256').update(fs.readFileSync(path.join(installedRoot, 'dist/cli.mjs'))).digest('hex'), args, ...exit, timedOut, elapsedMs: Date.now() - start, requests, sent, stdout, stderr, eventTypes: events.map(e => e.type), scope: 'Unmodified current CLI, owned localhost mock, isolated synthetic home/keys. No real provider or subprocesses. Mock proposes only a harmless owned read; filesystem guard also permits fixture config/log writes.' };
fs.writeFileSync(path.join(root, `raw-${mode}.json`), JSON.stringify(result, null, 2));
console.log(JSON.stringify({ mode, ...exit, timedOut, elapsedMs: result.elapsedMs, requestCount: requests.length, eventTypes: result.eventTypes, stdoutTail: stdout.slice(-1900), stderrTail: stderr.slice(-900) }));
