# Issue #785: history, evidence boundaries, and maintainer acceptance review

Reviewed live GitHub issue bodies and all available comments on 2026-09-06. No requests were sent to a model or Command Code gateway; no credentials were read. This is a discussion review, not an independent reproduction. No descendants were delegated.

## Main conclusion

The established user-reported symptom is an intermittent streaming response ending without a terminal signal, sometimes leaving partial tool-call arguments. The history does **not** establish a deterministic output-size or context-size trigger, a particular faulty gateway function, a billing defect, or equivalence across routes/models. A local synthetic premature-EOF test can establish how the current CLI handles that condition; it cannot establish why the production Provider API intermittently emits it.

## What the reports actually establish

| Evidence | Reported observation | Boundary |
|---|---|---|
| [Original #785](https://github.com/CommandCodeAI/command-code/issues/785) | Provider API `POST /provider/v1/chat/completions`, `deepseek/deepseek-v4-flash`, raw SSE reader, Linux. Some streaming tool-call arguments stop mid-string without `finish_reason`, `[DONE]`, or an explicit error. A non-streaming equivalent reportedly delivered a 190KB payload. | Reporter evidence; the published single-shot reproducer was subsequently reported passing. Original output-size correlation is not a confirmed trigger. |
| [Author's first follow-up](https://github.com/CommandCodeAI/command-code/issues/785#issuecomment-5496380973) | Direct 20k-character request passed: 3,973 chunks, approximately 18.5KB arguments, `tool_calls` finish reason, `[DONE]`. Relay version and relay version with roughly 50k-token context also passed. Original production environment had 53–64k prompt tokens and multi-turn tool history. | Author explicitly calls the failure intermittent/environment-dependent and has no minimal standalone failing repro. Reasoning/tool history interplay is a hypothesis. The separate `Thinking mode does not support this tool_choice` HTTP 400 is not this EOF defect. |
| [Author's later follow-up](https://github.com/CommandCodeAI/command-code/issues/785#issuecomment-5496495343) | Relay usage recorded three consecutive near-empty failures at 156150 / 156210 / 156270 prompt tokens with one completion token and no terminal signal. The same session had successful requests around 166k and 169k prompt tokens. | This does not demonstrate a monotonic context threshold. The reporter's claim that an effective upstream limit was exceeded remains unverified; do not repeat a model context-window figure as established. Relay status `ok` is not proof of complete streaming delivery. |
| [Independent reporter](https://github.com/CommandCodeAI/command-code/issues/785#issuecomment-5512382779) | Five DeepSeek incidents include connection closure, missing terminal chunk, and one actual HTTP 500; efforts were high/max. A separate Kimi incident had malformed tool-call arguments. Durations range approximately 1–134 seconds. No usage was reported for these responses. | Small token counts listed in the comment belong to the **immediately preceding successful requests**, not measured failing request sizes. These observations weaken a size-only explanation but do not prove failing requests were below 10k. No lower-effort control or failure-rate denominator was supplied. Missing usage is an observability gap, not proof of billing loss or charging behavior. |

No maintainer response or published resolution was present in #785 at this review.

## Related issues are useful comparisons, not confirmed duplicates

- [#628](https://github.com/CommandCodeAI/command-code/issues/628): CLI 1.11.0, macOS, explicit `500 Upstream stream ended before terminal chunk` and a trace ID. The client received or rendered an error, unlike #785's reported silent Provider API EOF. Source of that numeric status is not established by this short report.
- [#755](https://github.com/CommandCodeAI/command-code/issues/755): CLI 1.32.1, Windows, `/alpha/generate` transport; reporter traces both outer and upstream HTTP 200, then claims the CLI labels an exhausted stream failure `500 ERROR`. Useful formatter/transport regression target, but neither the Provider API route nor current 1.49.1 is demonstrated by the report.
- [#791](https://github.com/CommandCodeAI/command-code/issues/791): GLM 5.3 Flash, CLI 1.44.0, relay/multiple clients, empty tool arguments or missing finish reason around 80–100k context. Plan-change correlation and exclusion of relay/harness causes are reporter hypotheses, partly attributed to model advice; they are not measured route controls.
- [#798](https://github.com/CommandCodeAI/command-code/issues/798): sol, CLI 1.46.0, Linux, explicit `524 Invalid error response format: Gateway request failed` plus trace IDs. This is a visible gateway/timeout error signature and should be separately classified from silent EOF. Credits complaint is not a verified accounting diagnosis.

## Most useful sanitized capture

For each failed request and a matched successful request, retain:

1. UTC start/end timestamps, client/CLI version, endpoint path, direct-versus-relay route, exact model identifier requested and the effective upstream model/provider selected if maintainers can access it. Record reasoning settings, stream flag, output limit, tool-choice mode, and tool/message counts. Do not include authorization headers.
2. Actual response HTTP status and content type, request/trace IDs from an explicit allowlist, first-byte latency, last-event time, total duration, and total bytes/event counts. Distinguish no first byte, clean EOF, socket reset, timeout, cancellation, and explicit SSE error. Do not infer an HTTP status from the exception text.
3. Per-choice final `finish_reason`, whether `[DONE]` arrived, whether the event itself was complete, and any usage event received. For each tool-call index: whether ID/name arrived, argument byte count, and whether the **final accumulated** JSON parses and passes the tool schema. Do not publish prompt text or raw sensitive tool arguments.
4. The failed request's own prompt token count when measured, its source (provider usage, relay estimate, or local estimate), and request byte count. A previous successful request's count must remain labeled as such. Record output bytes independently of usage tokens, since usage can be absent precisely when the stream fails.
5. A body hash for matching controlled requests, sanitized message-role/tool-loop structure, and separate client→relay, relay→gateway, and gateway→upstream completion states where accessible. Gateway maintainers need to identify the **first hop** that lost completion, not merely the final client EOF.

## Regression matrix and acceptance criteria

Use deterministic fixtures with captured raw bytes. Each fixture is an injected condition, not evidence of its production frequency.

| Fixture | Required client/server behavior |
|---|---|
| HTTP 200, valid complete tool arguments, finish reason and `[DONE]` | Normal completion; tool invocation occurs at most once after stream completion and argument validation. |
| HTTP 200, partial argument JSON then clean EOF without a terminal signal | Surface incomplete-stream failure; do not promote it to a successful assistant turn or execute the partial tool. Preserve enough sanitized diagnostics to identify the missing terminal signal. |
| HTTP 200, parseable argument JSON but no terminal signal | Follow an explicit documented policy; do not silently equate parseable intermediate JSON with a completed model turn. This control detects accidental success based solely on parsability. |
| HTTP 200, complete tool JSON and `finish_reason`, but no `[DONE]` | Keep distinct from missing **both** terminal signals. Decide and test compatibility behavior; finish reason may be a usable per-choice completion signal. The finding should not imply that missing `[DONE]` alone proves truncation. |
| HTTP 200, `[DONE]` but no per-choice finish reason | Validate/report the malformed completion contract independently of clean EOF. Do not assume a usage-only or empty stream constitutes a successful assistant turn. |
| Actual HTTP 4xx/5xx before streaming, explicit error inside HTTP-200 SSE, socket reset, user cancellation | Preserve each failure category and genuine HTTP status. Do not invent HTTP 500 for an HTTP-200 EOF; do not retry user cancellation as a provider fault. |
| Failure after partial text, after an earlier complete tool, or with multiple concurrent tool-call indexes | Preserve completed history and avoid duplicate externally effective actions during retries. Verify any incomplete-tool rejection and retry policy together. |

For maintainers with gateway access, run matched direct/relay streaming/non-streaming and low/high reasoning controls across short and long contexts and both one-turn/multi-turn tool history. Keep tool output sizes independently controlled. Use repeated trials with denominators; capture paired hop-level termination traces rather than claiming a cause from one correlation. Reject requests that exceed an independently verified effective model limit with a clear structured error, but do not introduce an arbitrary threshold based only on this issue's narrative.

## New #806 priority comparison

[#806](https://github.com/CommandCodeAI/command-code/issues/806) was open with no comments. It offers a tighter minimal history-shape comparison: assistant `content` as two text parts plus `tool_calls` versus the same text as a string, with reported model recall 0/3 versus 3/3. This is valuable for a gateway owner to reproduce promptly. However, the claimed gateway serializer loss is inferred from model answers; there is no captured normalized/upstream request proving where the text disappeared. A hypothetical serializer fix is not yet a verified source-level cause.

For comment-only work without gateway source/credentials/inference, #785 remains a practical next task because current client failure handling can be tested locally with zero-cost fault injection. #806 is likely a strong subsequent maintainer-facing request for a wire-level array/string normalization test; current evidence does not justify switching away from the ongoing #785 local experiment.
