# Issue #785: incomplete-stream detection and lost final diagnostics

Reviewed and tested 2026-09-06. Issue: https://github.com/CommandCodeAI/command-code/issues/785.

## Decision-ready result

The current installed Command Code client rejects an injected incomplete SSE response. The reproducible client defect is **loss of the precise stream-failure explanation in final JSON and stderr**, which instead tells the user to check their network connection. Suggested priority for this client diagnostic fix: **P2**. This is advisory and does not change the severity, labels or status of the original gateway report.

The original issue describes intermittent production Provider API truncation, observed by other clients. These tests use the Command Code CLI's BYOK OpenAI-compatible receiver against an owned localhost endpoint. They do not reproduce the production gateway failure or establish its cause, frequency, context limit, output limit or billing impact.

## Smallest natural reproduction

1. Run the pristine installed CLI with a synthetic home/provider and the default configured OpenAI-compatible receiver.
2. The mock accepts the completion request and returns HTTP 200, a valid SSE partial text chunk, then a clean end with no `finish_reason` or `[DONE]`.
3. The trace reports `TransportError: Stream failed: Response stream ended without a finish reason.`
4. Final JSON and stderr replace it with `Error: Unable to connect to the API. Please check your network connection.` The process exits 6, naturally, after one request.

The same mismatch occurred in two follow-ups supplying visible text followed by complete or incomplete `read_file` arguments. Both naturally failed after one response, with no tool queued/running/completed event and no tool-result request. Visible text was deliberately included to exercise the existing no-retry-after-visible-output policy. These cases do not establish natural exhaustion of the tool-only retry path.

`cli-fixture/diagnostic-pair.txt` contains the exact trace/final pair. `cli-fixture/verified-summary.json` records all eleven actual CLI outcomes and their qualifications.

## Actual CLI results

| Cases | Direct result | Qualification |
| --- | --- | --- |
| Normal text with finish reason and DONE | Final success, exit 0 | Clean positive control |
| Partial text; clean EOF, missing finish | Precise trace error, generic connection final message, exit 6 | Natural one-request failure |
| Visible text + complete tool JSON; clean EOF, missing finish | Same diagnostic loss; no observed tool dispatch; exit 6 | Natural one-request failure |
| Visible text + incomplete tool JSON; clean EOF, missing finish | Same diagnostic loss; no observed tool dispatch; exit 6 | Natural one-request failure |
| Valid tool with finish and DONE; valid tool with finish but no DONE | Each read the owned fixture once, returned its marker in the next real HTTP request, and emitted final success | Both then hit an unattributed Windows libuv `UV_HANDLE_CLOSING` shutdown assertion, exit 3221226505. Protocol/tool-flow controls, not clean process passes |
| Tool-only complete/incomplete JSON without finish; explicit SSE error without text | Six faulty responses and retries; no tool dispatch; seventh request stopped by fixture HTTP 400 budget | Exploratory, not natural retry exhaustion or final EOF-message evidence |
| Text followed by actual response socket destruction | Unsuccessful result, `Failed to process successful response`, exit 1 | Distinct body-read failure |
| Visible text followed by explicit structured SSE error | Trace becomes `Stream failed: [object Object]`; final becomes generic connection advice, exit 6 | Secondary error-normalization loss; no production-error shape claim |

All eleven runs have preserved raw local evidence and final results; none timed out. This is **not eleven successful product tests**. Startup/cleanup time is recorded separately from the CLI-reported model run duration. No diagnosis of the later libuv assertions is claimed, and no additional crash issue was filed.

The controlled mock proposed only a harmless `read_file` of its owned text fixture. The Node permission model prohibited subprocesses and limited filesystem access to the installed package and fixture; fixture config/log writes were allowed. This filesystem boundary is not an intrinsic tool allowlist. No real provider credentials, inference, application edits or user configuration were used.

## Source cause and repair

The SDK emits a missing-finish error. Command Code's `consumeFullStream` throws before returning a completed response, and `agentLoop` calls `runTools` only after successful model completion. The actual tool tests match that boundary. A buffered `tool-call` or UI `message_update` is not execution evidence.

The diagnostic is subsequently lost in two places:

1. `toTransportError` keeps the precise message but assigns transport status 0. `transportErrorToApiError` passes it to `APIError.generate`; the status-0 branch creates a generic connection error without forwarding the message or original cause.
2. `classifyPrintModeError` substitutes fixed connection advice for that error class, and the final JSON result reuses the formatted stderr text.

Preserve a typed incomplete-stream failure, message and cause through conversion and formatting. Keep observed HTTP status separate from stream completeness; do not invent an HTTP error code to force a different presentation. Add paired assertions on trace, final JSON and stderr, with a genuine connection-failure control. Preserve the already-working completion-before-tool-execution boundary.

Exact hash-pinned function offsets and dependency lines are in `stream-source-review.md`. The secondary structured-error stringification is a separate normalization case worth retaining in that regression suite.

## Component coverage

The independent SDK probe ran 13 synthetic SSE cases in two byte-segmentation modes through two actual SDK layers: **52 component runs and 344 assertions**. It does not provide tool executors. These are deterministic component checks, not production trials.

The installed adapter emits buffered tool calls before its missing-finish error. At the general AI SDK boundary, error events can coexist with fulfilled text/tool-call promises; consumers must inspect error events/final status. Command Code's tested consumer does so. The adapter accepts a finish reason without DONE and rejects DONE without a finish reason. The CLI tool control with finish/no-DONE confirms the protocol flow, subject to its separately recorded shutdown assertion.

See `component-tests/REPORT.md`, its script, and synthetic-only results. No default JSON repair was observed in that SDK configuration; Command Code's own buffering/parsing can differ without causing execution before successful completion.

## Provenance and live discussion

Command Code 1.49.1 bundle SHA256: `10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05`. Node v24.15.0 on Windows. Installed adapter 2.0.74, AI SDK 6.0.277, provider-utils 4.0.50, provider 3.0.15. Exact hashes are in the component results and `provenance.json`. The CLI package specifies dependency ranges, so these observations must not be generalized to every installation with the same CLI version.

The original reporter later passed both direct and relay single-shot tests. Successful requests around 166k/169k coexist with later failures around 156k, which does not establish a hard context cutoff. Another reporter's small token counts belong to preceding successful requests, not the failed requests themselves. The next server investigation needs correlated hop-level termination evidence for an actual failed request and a matched success. `history-and-acceptance-review.md` retains source links and related-issue distinctions.

## Handoff

`GITHUB-COMMENT.md` is prepared and has not been posted. The curated archive includes reports, exact scripts, package metadata and sanitized outcomes. It excludes raw CLI model requests, full system prompts, synthetic home/session data and application bundles. Four depth-1 workers returned source, component, history and independent-validation results; the parent integrated and verified them. No descendants or separate user-visible tasks were used.
