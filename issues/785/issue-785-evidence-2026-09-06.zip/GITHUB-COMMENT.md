I isolated the **current client’s handling** of this failure using Command Code **1.49.1** on Windows, with an owned localhost OpenAI-compatible endpoint. Installed dependencies were `@ai-sdk/openai-compatible` **2.0.74** and `ai` **6.0.277**. No production gateway requests or paid inference were used; this does not reproduce the gateway’s intermittent drop.

There is a concrete diagnostic problem worth fixing:

1. Return HTTP 200, send partial text, then end SSE without `finish_reason` or `[DONE]`.
2. The CLI correctly emits `run_error`: `Stream failed: Response stream ended without a finish reason.`
3. Its final JSON error and stderr instead say: `Error: Unable to connect to the API. Please check your network connection.`

The connection succeeded and data arrived, so the final message hides the useful diagnosis. This also reproduced with complete and incomplete tool-call JSON following visible text: both runs exited with an error before any tool-running/completed event or tool result. The current client is detecting the incomplete response in these tests.

**Fix pointer:** preserve the stream error’s category, message and cause through `transportErrorToApiError` / `APIError.generate` and `classifyPrintModeError`. The status-0 conversion drops the original message, then the formatter replaces it with generic connection advice. Changing only the formatter is insufficient. Keep actual HTTP status distinct from stream-completion status.

Acceptance: final JSON/stderr retain the missing-finish explanation; real connection failures retain appropriate guidance; incomplete tool calls remain unexecuted. Keep missing `finish_reason` separate from missing `[DONE]` alone.

For the original gateway failure, the next useful evidence is a failed/successful request pair with correlated gateway/upstream IDs, route, reasoning settings, actual HTTP status, and terminal-event state at each hop. The discussion does not yet establish a fixed context/output-size trigger; counts from preceding successful requests should remain labeled as such.
