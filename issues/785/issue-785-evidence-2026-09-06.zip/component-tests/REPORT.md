# Issue 785: installed streaming adapter component results

Tested 2026-09-06 on Windows x64, Node 24.15.0. **52 component runs, 344 assertions passed**: 13 synthetic SSE cases, each delivered both as one body and in seven-byte fragments, through (1) the actual installed OpenAI-compatible chat adapter and (2) the actual installed AI SDK `streamText` API.

## What the tests establish

The current installed adapter **does detect a clean EOF without a `finish_reason`**. It emits `AI_InvalidResponseDataError: Response stream ended without a finish reason.`, followed by `finish` with unified reason `error`.

This is an **error event**, not an iterator exception. In the tested `streamText` calls, `fullStream` ended normally, `onError` received the error, `onFinish` received `finishReason: "error"`, and the `text` and `toolCalls` result promises fulfilled. A consumer relying only on `try/catch` or a fulfilled result promise will not detect this failure; the application must inspect error events and terminal status. This is a integration requirement demonstrated at the SDK boundary, not a claim that Command Code's live UI necessarily ignores these signals.

Buffered tool calls are emitted **before** the adapter checks for a missing finish reason. Complete JSON remains a valid parsed tool call in `streamText`, even when the final finish reason is `error`. Partial JSON is preserved by the adapter, then marked `invalid: true` with a `tool-error` by the AI SDK; there is **no default repair into valid arguments** in this tested API configuration. A downstream repair hook or Command Code-specific parser could differ and requires separate inspection.

The fixture supplies no tool `execute` callback. It does not test actual execution or prove an execution-prevention boundary.

## Case matrix

Both byte segmentation modes produced the same relevant results.

| Synthetic response | Adapter outcome | AI SDK outcome |
| --- | --- | --- |
| Text, `finish_reason: stop`, `[DONE]` | Normal stop | Normal stop, no errors |
| Complete tool JSON, `finish_reason: tool_calls`, `[DONE]` | Normal tool call | Valid parsed tool call, no errors |
| Partial text, clean EOF, no finish reason | Missing-finish error event; finish error | Error event/callback; partial text still fulfills |
| Complete tool JSON, clean EOF, no finish reason | Tool call, then missing-finish error | Valid parsed tool call, then error; finish error |
| Incomplete tool JSON, clean EOF, no finish reason | Raw incomplete tool call, then missing-finish error | Invalid tool call and tool-error, then stream error |
| Text with finish reason, no `[DONE]` | Normal stop | Normal stop, no errors |
| Complete tool JSON with finish reason, no `[DONE]` | Normal tool call | Valid parsed tool call, no errors |
| Text, `[DONE]`, no finish reason | Missing-finish error | Missing-finish error |
| Incomplete tool JSON with finish reason and `[DONE]` | Raw incomplete tool call; finish tool-calls | Invalid tool call and tool-error |
| Explicit provider error after text | Provider error event; finish error | Provider error event/callback; partial text still fulfills |
| Response body stream errors after text | Iterator throws API-call error with fixture error cause | Iterator and result promises reject |
| Truncated trailing SSE JSON event, clean EOF | Missing-finish error | Missing-finish error |
| Empty response body, clean EOF | Missing-finish error | Missing-finish error |

The `[DONE]` controls distinguish the sentinel from a model finish reason: this adapter accepts a present finish reason without `[DONE]`, and rejects `[DONE]` without a finish reason. Do not propose a blanket "missing `[DONE]` means failure" rule from these results.

## Exact implementation and provenance

Command Code installed package: **1.49.1**, bundle SHA-256 `10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05`.

| Installed dependency | Version | ESM entry SHA-256 |
| --- | --- | --- |
| `@ai-sdk/openai-compatible` | 2.0.74 | `d99610a3574365abb89c69d951e00ff6055b17dd3af6683f0c4f74fd43c6d5df` |
| `ai` | 6.0.277 | `e2951cc3f8c566bb9eab0cc221ccf433eeb4bd6e7f12dc3a162a831da79b9bc1` |
| `@ai-sdk/provider-utils` | 4.0.50 | `9b811e318708557dd60f4efc131952d9dc700a75434c4dfa5d572b1ebbe2dc3a` |
| `@ai-sdk/provider` | 3.0.15 | `7f543e6fe850de4cc0c547d4a0281b65c6b5897d163627c4fa6fccd67e1200ac` |

Paths below are relative to Command Code's installed `node_modules` directory:

- `@ai-sdk/openai-compatible/dist/index.mjs:874`: flush begins; `:900` emits buffered tool-call; `:913` checks missing finish; `:919` defines the explicit error message.
- `ai/dist/index.mjs:4038`: `parseToolCall` and its optional repair hook. This probe does not supply a repair hook.
- `@ai-sdk/provider-utils/dist/index.mjs:2554`: SSE `[DONE]` filtering.

These are the resolved installed dependency versions, not the minimum versions in Command Code's dependency ranges or proof of the dependencies used by the original issue reporter.

## Reproduce

Run `node artifacts/issue-785/component-tests/stream-probe.mjs` from the repository. It defaults to `%APPDATA%/npm/node_modules/command-code`; alternatively set `COMMAND_CODE_PACKAGE` to an installed package directory. No installation or application modification is performed.

The probe imports the exact installed ESM APIs. Each request is intercepted by an in-memory fetch implementation that checks the synthetic `.invalid` URL and returns the selected SSE fixture. Global real fetch is disabled. No real keys, remote inference, subprocesses, local files as proposed tool targets, or tool execution callbacks are used. The response-body error case is an in-memory stream error, not an actual TCP reset.

`results.json` records dependency and script hashes, all cases, event order, errors, promised results and callback results. It contains only synthetic fixture content and no full application/system prompt.

## Suggested integration checks

1. Mark missing terminal reason or a stream error as an incomplete turn even when the result promise fulfills; preserve partial output visibly as incomplete.
2. Check final stream state before treating buffered tool calls as actionable. Do not execute repaired or buffered arguments solely because a `tool-call` event arrived.
3. Keep explicit stream errors, transport exceptions, and user cancellation distinct when deciding status or retry behavior.
4. Include the finish-reason/no-`[DONE]` successful controls to avoid rejecting responses this adapter currently supports.

Command Code-specific behavior, transport retry policy and actual UI or CLI status remain outside this component probe and must be established by the parent investigation.
