// Synthetic in-memory SSE through the unmodified installed adapter and AI SDK.
// No provider requests, real credentials, subprocesses, or tool execution callbacks.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {pathToFileURL, fileURLToPath} from 'node:url';

const outputDir = path.dirname(fileURLToPath(import.meta.url));
const root = process.env.COMMAND_CODE_PACKAGE || path.join(process.env.APPDATA, 'npm/node_modules/command-code');
const req = createRequire(path.join(root, 'package.json'));
const hash = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
function packageInfo(name) {
  const cjsEntry = req.resolve(name);
  let dir = path.dirname(cjsEntry);
  while (!fs.existsSync(path.join(dir, 'package.json'))) dir = path.dirname(dir);
  const pkgFile = path.join(dir, 'package.json');
  const pkg = JSON.parse(fs.readFileSync(pkgFile, 'utf8'));
  const esmEntry = path.join(dir, 'dist/index.mjs');
  return {name, version:pkg.version, esmEntry, esmSha256:hash(esmEntry), packageSha256:hash(pkgFile)};
}
const packages = ['@ai-sdk/openai-compatible', 'ai', '@ai-sdk/provider-utils', '@ai-sdk/provider'].map(packageInfo);
const {createOpenAICompatible} = await import(pathToFileURL(packages[0].esmEntry).href);
const {streamText, jsonSchema} = await import(pathToFileURL(packages[1].esmEntry).href);
globalThis.fetch = async () => {throw new Error('GUARD: real fetch prohibited');};
const schema = {type:'object', properties:{message:{type:'string'}}, required:['message'], additionalProperties:false};
const sse = obj => `data: ${JSON.stringify(obj)}\n\n`;
const chunk = (delta, finish_reason = null) => ({id:'fixture-completion', object:'chat.completion.chunk', created:0, model:'fixture-model', choices:[{index:0, delta, finish_reason}]});
const text = sse(chunk({content:'Partial fixture text.'}));
const tool = args => sse(chunk({tool_calls:[{index:0, id:'fixture-call', type:'function', function:{name:'fixture_record', arguments:args}}]}));
const stop = reason => sse(chunk({}, reason));
const done = 'data: [DONE]\n\n';
const completeArgs = '{"message":"complete fixture"}';
const partialArgs = '{"message":"truncated fixture';
const cases = [
  {id:'text-finish-done', body:text+stop('stop')+done, expectedFinish:'stop'},
  {id:'tool-finish-done', body:tool(completeArgs)+stop('tool_calls')+done, expectedFinish:'tool-calls', tool:completeArgs},
  {id:'text-eof-no-finish', body:text, expectedFinish:'error', missingFinish:true},
  {id:'tool-complete-eof-no-finish', body:tool(completeArgs), expectedFinish:'error', missingFinish:true, tool:completeArgs},
  {id:'tool-partial-eof-no-finish', body:tool(partialArgs), expectedFinish:'error', missingFinish:true, tool:partialArgs, invalidTool:true},
  {id:'text-finish-no-done', body:text+stop('stop'), expectedFinish:'stop'},
  {id:'tool-finish-no-done', body:tool(completeArgs)+stop('tool_calls'), expectedFinish:'tool-calls', tool:completeArgs},
  {id:'text-done-no-finish', body:text+done, expectedFinish:'error', missingFinish:true},
  {id:'tool-partial-finish-done', body:tool(partialArgs)+stop('tool_calls')+done, expectedFinish:'tool-calls', tool:partialArgs, invalidTool:true},
  {id:'provider-error', body:text+sse({error:{message:'FIXTURE_PROVIDER_ERROR', type:'fixture', code:'fixture'}})+done, expectedFinish:'error'},
  {id:'transport-reset-after-text', body:text, reset:true},
  {id:'truncated-json-event', body:text+'data: {"choices":[', expectedFinish:'error', missingFinish:true},
  {id:'empty-clean-eof', body:'', expectedFinish:'error', missingFinish:true}
];
function serializable(value) {
  if (value instanceof Error) return {name:value.name, message:value.message, ...(value.cause?{cause:serializable(value.cause)}:{})};
  if (value === undefined) return null;
  if (Array.isArray(value)) return value.map(serializable);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).filter(([k])=>!['request','headers','response'].includes(k)).map(([k,v])=>[k,serializable(v)]));
  return value;
}
let assertions = 0;
function check(condition, label) {assert.ok(condition, label); assertions++;}
function makeFixture(test, segmentation) {
  let requests = 0;
  const mockFetch = async (url, init) => {
    check(String(url)==='https://stream-fixture.invalid/v1/chat/completions', `${test.id}: fixture URL only`);
    const body = JSON.parse(init.body);
    check(body.model === 'fixture-model' && body.stream === true, `${test.id}: actual streaming request`);
    requests++;
    const encoded = new TextEncoder().encode(test.body);
    const fragments = segmentation==='small-byte-chunks' ? Array.from({length:Math.ceil(encoded.length/7)}, (_,i)=>encoded.slice(i*7,(i+1)*7)) : [encoded];
    let index=0;
    const stream = new ReadableStream({pull(controller) {
      if (index < fragments.length) {controller.enqueue(fragments[index++]); return;}
      if (test.reset) controller.error(new Error('FIXTURE_TRANSPORT_RESET'));
      else controller.close();
    }});
    return new Response(stream, {status:200, headers:{'content-type':'text/event-stream'}});
  };
  const provider = createOpenAICompatible({name:'fixture', baseURL:'https://stream-fixture.invalid/v1', apiKey:'synthetic-not-a-credential', fetch:mockFetch});
  return {model:provider.chatModel('fixture-model'), requests:()=>requests};
}
async function adapterRun(test, segmentation) {
  const fixture=makeFixture(test, segmentation);
  const events=[]; let thrown=null;
  try {
    const result=await fixture.model.doStream({prompt:[{role:'user',content:[{type:'text',text:'Synthetic streaming fixture'}]}], tools:[{type:'function',name:'fixture_record',inputSchema:schema}], toolChoice:{type:'auto'}});
    for await (const event of result.stream) events.push(serializable(event));
  } catch(error) {thrown=serializable(error);}
  check(fixture.requests()===1, `${test.id}: adapter exactly one mocked request`);
  const finish=events.find(e=>e.type==='finish');
  if (test.reset) check(JSON.stringify(thrown).includes('FIXTURE_TRANSPORT_RESET'), `${test.id}: adapter transport error preserved in error or cause: ${JSON.stringify(thrown)}`);
  else {
    check(!thrown, `${test.id}: no iterator throw at clean EOF`);
    check(finish?.finishReason?.unified===test.expectedFinish, `${test.id}: adapter finish reason`);
  }
  if (test.missingFinish) check(events.some(e=>e.type==='error' && e.error?.message==='Response stream ended without a finish reason.'), `${test.id}: explicit missing-finish error`);
  if (test.tool) {
    const event=events.find(e=>e.type==='tool-call');
    check(event?.input===test.tool, `${test.id}: raw tool args preserved without repair`);
    if(test.missingFinish) check(events.indexOf(event)<events.findIndex(e=>e.type==='error'), `${test.id}: adapter emits tool-call before missing-finish error`);
  }
  return {case:test.id, segmentation, layer:'adapter.doStream', mockRequests:fixture.requests(), events, thrown};
}
async function aiRun(test, segmentation) {
  const fixture=makeFixture(test, segmentation);
  const events=[]; const errors=[]; const finishes=[]; let thrown=null;
  const result=streamText({model:fixture.model,prompt:'Synthetic streaming fixture',tools:{fixture_record:{description:'A synthetic declaration; no execute callback exists.',inputSchema:jsonSchema(schema)}}, maxRetries:0, onError:e=>errors.push(serializable(e.error)), onFinish:e=>finishes.push({finishReason:e.finishReason, rawFinishReason:e.rawFinishReason, toolCalls:serializable(e.toolCalls), text:e.text})});
  // Attach rejection handlers before consumption; capture exact SDK outcomes.
  const settledPromise=Promise.allSettled([result.finishReason,result.rawFinishReason,result.text,result.toolCalls]);
  try {for await (const event of result.fullStream) events.push(serializable(event));}
  catch(error) {thrown=serializable(error);}
  const settled=serializable(await settledPromise);
  check(fixture.requests()===1, `${test.id}: SDK exactly one mocked request`);
  if (test.reset) {
    check(JSON.stringify(thrown).includes('FIXTURE_TRANSPORT_RESET'), `${test.id}: SDK iterator propagates body-stream failure`);
    check(settled.every(x=>x.status==='rejected'), `${test.id}: SDK result promises reject`);
  } else {
    check(!thrown, `${test.id}: SDK iterator ends without throwing`);
    check(settled[0].status==='fulfilled' && settled[0].value===test.expectedFinish, `${test.id}: SDK fulfilled finish reason`);
    check(settled[2].status==='fulfilled' && settled[3].status==='fulfilled', `${test.id}: SDK text and tool-call result promises fulfill`);
  }
  if (test.invalidTool) {
    const invalid=events.find(e=>e.type==='tool-call');
    check(invalid?.invalid===true, `${test.id}: SDK marks incomplete JSON invalid`);
    check(events.some(e=>e.type==='tool-error'), `${test.id}: SDK tool-input error emitted`);
  }
  if (test.missingFinish) check(errors.some(e=>e.message==='Response stream ended without a finish reason.'), `${test.id}: SDK onError sees missing finish`);
  if (test.tool && !test.invalidTool) {
    const call=events.find(e=>e.type==='tool-call');
    check(call?.input?.message==='complete fixture' && call?.invalid!==true, `${test.id}: SDK retains valid tool call`);
    if(test.missingFinish) check(events.indexOf(call)<events.findIndex(e=>e.type==='error'), `${test.id}: SDK tool-call precedes missing-finish error`);
  }
  if (test.expectedFinish!=='error' && !test.reset && !test.invalidTool) check(errors.length===0 && !events.some(e=>e.type==='error'||e.type==='tool-error'), `${test.id}: successful controls have no error event`);
  return {case:test.id, segmentation, layer:'ai.streamText-no-execute', mockRequests:fixture.requests(), events, errors, finishes, settled, thrown};
}
const runs=[];
for (const segmentation of ['whole-body','small-byte-chunks']) for (const test of cases) {
  runs.push(await adapterRun(test,segmentation));
  runs.push(await aiRun(test,segmentation));
}
const provenance={createdAt:new Date().toISOString(), node:process.version, platform:process.platform, arch:process.arch, commandCodeVersion:JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8')).version, commandCodeBundleSha256:hash(path.join(root,'dist/cli.mjs')), packages:packages.map(({esmEntry,...rest})=>({...rest, entryRelativeToPackage:'dist/index.mjs'})), scriptSha256:hash(fileURLToPath(import.meta.url))};
fs.writeFileSync(path.join(outputDir,'results.json'), JSON.stringify({provenance, assertions, cases:cases.map(({body,...rest})=>({...rest,sseBytes:Buffer.byteLength(body)})), runCount:runs.length, runs},null,2)+'\n');
console.log(JSON.stringify({assertions, runCount:runs.length, caseCount:cases.length, packages:packages.map(p=>({name:p.name,version:p.version})), output:path.join(outputDir,'results.json')}));
