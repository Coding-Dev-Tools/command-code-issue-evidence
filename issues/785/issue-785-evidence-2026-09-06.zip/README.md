# Issue #785 evidence package

Start with `REPORT.md` for findings and limits, or `GITHUB-COMMENT.md` for the prepared comment. This package establishes a current BYOK client diagnostic defect; it does not reproduce the production gateway's intermittent truncation. No comment was posted during this investigation.

## Quick reproduction

Use Windows and Node v24.15.0, with the exact installed Command Code 1.49.1 package and resolved dependency versions listed in `provenance.json`. Verify bundle/dependency hashes before comparing results. The package and dependencies are not included or installed by these scripts.

```text
node cli-fixture/stream-probe.mjs valid-text
node cli-fixture/stream-probe.mjs eof-text
node cli-fixture/stream-probe.mjs eof-complete-tool-with-text
node cli-fixture/stream-probe.mjs eof-partial-tool-with-text
```

The valid-text case completes. Each missing-finish case should produce the precise trace error but the generic connection message in final JSON/stderr, exit 6. The tool follow-ups propose only an owned local read; they should emit no tool execution event or tool result.

Each run creates a synthetic home in the fixture, uses fake keys and an owned localhost server, and starts only its own guarded CLI process. No real credentials or inference are used. The fixture stops its own child after 25 seconds if necessary. Preserve existing raw captures before rerunning a mode; runs overwrite that mode's files.

`cli-fixture/verify-cli.mjs` expects all eleven named captures listed in the probe's `modes` array. It checks the recorded outcomes and produces the sanitized summary; it intentionally preserves qualifications for request-budget stops and libuv shutdown assertions. The archive contains the original sanitized summary, not the raw requests. Fresh raw evidence can be regenerated locally.

Run `node component-tests/stream-probe.mjs` for the independent 52-run SDK fixture. It uses in-memory fetch, disables real fetch, and supplies no tool executors. It defaults to `%APPDATA%/npm/node_modules/command-code`; `COMMAND_CODE_PACKAGE` can select another installation. A new resolution may behave differently, so compare the recorded hashes and versions.

## Scope and integrity

Reports distinguish natural failures, protocol/tool-flow successes followed by a shutdown assertion, and exploratory retries stopped by a fixture-generated error. Do not count every case as a clean product pass or claim the gateway was reproduced.

`MANIFEST.json` lists archive file sizes and SHA256 hashes. Raw full model requests/system prompts, user-path-bearing streams, synthetic homes, tarballs and application bundles are excluded. `cli-fixture/diagnostic-pair.txt` is a minimal publishable example of the confirmed error-message loss.
