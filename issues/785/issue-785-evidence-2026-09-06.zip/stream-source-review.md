# Issue #785: current client stream-contract source review

Reviewed 2026-09-06. This is **source evidence**, not a reproduction of the Command Code Provider API, a relay, or an upstream model. No inference requests, credentials, product edits, or external posts were used. The parent task independently runs localhost fixtures.

## Main finding

The installed OpenAI-compatible path already rejects clean EOF without a `finish_reason`. It also prevents the harness from executing buffered tool calls after that error. Therefore a blanket claim that current Command Code silently accepts a missing finish reason is unsupported by this source. Absence of `[DONE]` alone is a different condition: the current SSE parser discards that sentinel and does not track whether it arrived.

The original issue concerns `https://api.commandcode.ai/provider/v1/chat/completions` as observed by another client. Testing Command Code's BYOK client against a localhost OpenAI-compatible endpoint establishes client behavior only. It cannot identify why the production gateway or relay ended a response.

## Provenance

Installed root: `%APPDATA%/npm/node_modules/command-code`.

| File under installed root | Version | SHA-256 |
| --- | --- | --- |
| `dist/cli.mjs` | Command Code 1.49.1 | `10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05` |
| `node_modules/@ai-sdk/openai-compatible/dist/index.mjs` | 2.0.74 | `d99610a3574365abb89c69d951e00ff6055b17dd3af6683f0c4f74fd43c6d5df` |
| `node_modules/ai/dist/index.mjs` | 6.0.277 | `e2951cc3f8c566bb9eab0cc221ccf433eeb4bd6e7f12dc3a162a831da79b9bc1` |
| `node_modules/@ai-sdk/provider-utils/dist/index.mjs` | 4.0.50 | `9b811e318708557dd60f4efc131952d9dc700a75434c4dfa5d572b1ebbe2dc3a` |

The CLI is byte-identical to the previously verified published 1.49.1 bundle at `artifacts/issue-725/published/package/dist/cli.mjs`. Its package declares ranges `@ai-sdk/openai-compatible: ^2.0.35` and `ai: ^6.0.116`; these exact installed dependency versions matter. Do not characterize these dependency behaviors as invariant across every installation of Command Code 1.49.1.

## Live issue scope

The [issue](https://github.com/CommandCodeAI/command-code/issues/785) and its three comments were read. The reporter's first follow-up says their direct and relay single-shot tests passed and the observed failure was intermittent. A later reporter comment discusses long-context failures; another contributor reports broader conditions. These are attributed reports, not locally verified gateway facts. Neither large tool-call size nor context size is established as a sufficient cause.

## Request and consumption chain

All CLI offsets below are **zero-based UTF-16 string offsets**, as returned by JavaScript `indexOf`, not byte offsets. The minified functions are on line 2. Exact UTF-8 byte offsets are included where useful for other readers.

| CLI function/location | UTF-16 offset | UTF-8 byte offset | Relevant behavior |
| --- | ---: | ---: | --- |
| `declarativeWire` | 797013 | 797835 | `anthropic-messages` selects Anthropic; `api.openai.com` selects OpenAI; other configured completions endpoints select OpenAI-compatible. |
| `buildAiSdkTransport` | 798032 | 798854 | Constructs imported `createOpenAICompatible` with configured endpoint, fetch, and `includeUsage: true`. |
| `moduleFor` | 798860 | 799682 | Builds the configured BYOK module and transport. |
| `toAiSdkToolSchemas` | 814328 | 815154 | Passes only each tool's description and input schema into the AI SDK. There is no tool `execute` function or input callback here. |
| `consumeFullStream` | 816023 | 816849 | Consumes SDK events, buffers content, throws on an `error` event, checks completion, and only then returns content. |
| `runAiSdkStream` | 818637 | 819467 | Calls imported `streamText`, `maxRetries: 0`, then awaits `consumeFullStream`. |
| `createProviderRegistry` | 820887 | 821717 | Its model client awaits the AI SDK transport and rethrows errors. |
| `callModelWithRetry` | 494587 | 495223 | Awaits model completion; retries according to transport flags and visible output. |
| `agentLoop` | 504568 | 505204 | Awaits model completion before selecting and running client tools. |
| `x = await callModelWithRetry(...)` | 506196 | 506832 | Errors emit `run_error` and break the turn before tool execution. |
| `const I = x.content.filter(isClientToolUse)` | 507837 | 508473 | Only reached after successful completion. |
| `await runTools({toolUses: I, ...})` | 507958 | 508594 | Permission checks and execution occur after the preceding successful return. |

`onMessageUpdate` in the model request only emits a `message_update` UI event. Seeing a buffered `tool-call`/`tool_use` in a stream or display is not evidence that the tool ran.

## Guard matrix

References to SDK files below are one-based line numbers in the exact files hashed above.

| Input condition | Current source behavior | What a fixture should distinguish |
| --- | --- | --- |
| Clean EOF before any `finish_reason` | OpenAI-compatible `doStream.flush`, lines 913–921, emits `InvalidResponseDataError` with `Response stream ended without a finish reason.` and then a finish event whose unified reason is `error`. CLI throws on the error event. | Check surfaced error and unsuccessful turn, not only HTTP status. |
| Complete JSON tool arguments, clean EOF, no finish reason | Provider flush emits `tool-input-end` and `tool-call` at lines 892–911, **before** the missing-finish error. CLI buffers the tool call but throws before returning. Harness never reaches `runTools` for that failed response. | Instrument actual tool invocation independently; raw event presence is insufficient. |
| Incomplete JSON tool arguments, clean EOF, no finish reason | Provider still emits buffered string input. `ai` parses input against the schema and marks invalid calls. The subsequent missing-finish error makes CLI consumption fail before execution. | Verify no execution and preserve a truncation diagnosis; distinguish parse failure from the transport's missing terminal condition. |
| Explicit SSE `error` payload | Provider lines 675–687 emit SDK error for malformed/invalid chunks or an error-shaped chunk. CLI `consumeFullStream` throws on the first SDK error event. | Do not substitute a made-up upstream status. The displayed classification depends on the error object's actual fields. |
| Network failure while reading a successful HTTP response | `provider-utils.wrapResponseBodyStream`, lines 2866–2910, errors the stream, wrapping the read failure in `APICallError` with the original HTTP status/headers. Abort is passed through. `handleFetchError`, lines 722–766, marks recognized network failures retryable. | Distinguish HTTP 200 plus failed body transfer from a real HTTP error response. An errored TransformStream does not run its normal EOF flush. |
| Valid `finish_reason`, no `[DONE]` | `parseJsonEventStream`, provider-utils lines 2547–2560, discards `[DONE]` when present and tracks no sentinel flag. Provider completion checks the finish reason, not sentinel presence. | Use as a separate control; absence of sentinel alone does not exercise the missing-finish guard. |
| `[DONE]`, but no finish reason | Parser discards the sentinel; provider flush still emits the missing-finish error. | A sentinel is not a substitute for finish metadata in this path. |
| Unknown non-null raw finish reason | Provider mapping lines 304–317 yields unified `other` and preserves raw text. CLI rejects `other` only when raw is absent; separately rejects raw `network_error`, `connection_error`, `upstream_error` and equivalent single separator/space spellings. Other arbitrary raw reasons can pass. | Separate compatibility validation from the missing-finish scenario. Do not assume all unknown raw reasons are rejected. |

The OpenAI-compatible `flush` also rejects a pending tool call whose function name never arrived (`InvalidResponseDataError`, lines 882–890). It does not require tool argument JSON to be valid itself; that is delegated to `ai`.

## Tool-call guards in the AI SDK and harness

In `ai/dist/index.mjs`:

- `doParseToolCall`, lines 4120–4142, requires valid JSON matching the tool input schema. `parseToolCall`, lines 4038–4099, returns invalid dynamic tool-call metadata on failure when no repair succeeds.
- `runToolsTransformation`, lines 6800–7093, queues actual SDK tool executors until a finish event. Lines 6922–6936 execute them only when `isToolExecutionAllowedFinishReason` accepts the reason; lines 3160–3162 allow `stop` and `tool-calls`.
- Invalid tool calls become `tool-error` results and are not queued for SDK execution (lines 6969–6982).
- The Command Code mapping does not provide executors to this SDK anyway; execution belongs to the later harness `runTools` path.
- The generic AI SDK stream consumer also tracks terminal/output events. Its no-output guard at lines 8321–8331 is conditional on both no terminal and no output. The provider-specific missing-finish guard is what catches partially emitted OpenAI-compatible responses in this installation.

These layers establish a source expectation of zero client tool execution from either complete or incomplete tool JSON when the response has no finish reason. Runtime fixtures must confirm the exact application path.

## Error and retry differences worth keeping distinct

CLI `toTransportError` starts at UTF-16 814964 / UTF-8 815790. For recognized `APICallError` it preserves the available status and uses actual retry metadata; for a general Error it produces status `0`, message prefixed `Stream failed:`, retryable true. It does **not** assign `midStream`.

`callModelWithRetry` marks visible text/thinking. Its condition `i && !n` prevents retry once such output appeared unless the error has `midStream: true`. `isMidStreamFailure` at UTF-16 451265 checks exactly that flag. Thus no-text tool truncation and already-visible text truncation can follow different retry paths despite the same missing finish reason. This is a source finding about metadata and retry decisions, not evidence about gateway stability.

The main-loop retry count is hardcoded to `vh = 10` at UTF-16 1610187 (UTF-8 1611598); the searched request path exposes no supported retry-limit option. The SDK's `maxRetries: 0` does not disable that outer retry loop. A fixture can precede a tool call with visible text to exercise a natural one-attempt failure; that changes the fixture shape and should be reported.

### Confirmed source cause of the final print-mode message losing the diagnosis

The parent reported a real CLI fixture whose structured `run_error` retained `Stream failed: Response stream ended without a finish reason.`, while final JSON and stderr instead advised checking the network connection. The exact source explains both losses:

1. `toTransportError` (UTF-16 814964) preserves the missing-finish message in a `TransportError` with status `0`.
2. `runPrintMode` (1006646) remembers the `run_error` object, throws it after a failed run, and passes it into `classifyPrintModeError`.
3. `classifyPrintModeError` (985810 / UTF-8 986681) starts by calling `toApiError` (622951 / 623617).
4. `transportErrorToApiError` (622771 / 623437) calls `APIError.generate(e.status, parsedResponseBody, e.message, {})`.
5. `APIError.generate` (1358105 / 1359112) handles falsy status by returning `new APIConnectionError({cause: responseBody instanceof Error ? responseBody : undefined})`. It does not forward its message argument for this case. The original transport cause is not forwarded here either. `APIConnectionError` (1358427 / 1359434) consequently uses its default message.
6. `classifyPrintModeError` then replaces every `APIConnectionError` with the fixed message `Error: Unable to connect to the API. Please check your network connection.` and connection exit code. The failure-result builder uses that same formatted stderr text as the final JSON error.

A focused client fix should preserve a typed stream-incomplete error, original cause and precise message through transport-to-API conversion and print formatting. Updating only one of the two message-losing layers is insufficient. The regression should assert both structured run-error and final JSON/stderr, while a true connection-refused control retains appropriate connection guidance. This does not establish the Provider API server's cause or reproduce issue #755's separate gateway/status-500 branch.

The separate default gateway transport consumes Command Code JSON lines, **not OpenAI SSE**:

- `guardStreamFailures` (UTF-16 806584) wraps body errors with status `0`, retryable true and `midStream: true`.
- `consumeStream` (UTF-16 807192) requires its own `finish` event unless aborted, otherwise raises a truncation error with status `502`, retryable true, `midStream: true`.
- Its explicit stream-error conversion defaults a missing reported status to `500`. That is a different branch from the BYOK OpenAI-compatible source reviewed above and is related to the scope distinction in issue #755.

Do not combine these internal gateway event semantics with the Provider API's public SSE protocol. This review did not inspect server code or reproduce either production endpoint.

## Focused maintainer guidance supported by this review

1. Retain the existing missing-finish error and the completion-before-tool-execution boundary. Add a regression covering complete valid tool JSON followed by EOF, so a future streaming optimization does not accidentally execute it early.
2. Capture and classify missing finish metadata, body-read failure, explicit upstream error, and sentinel absence separately. Preserve the original status and cause; HTTP success does not establish completion.
3. Investigate the production gateway with correlated trace IDs across direct and relay calls, timestamps, model/options, and terminal-event observation. Payload-size assumptions are not a supported root-cause diagnosis.
4. If harmonizing retry behavior, validate the BYOK midstream flag and visible-content handling separately. Blindly retrying a tool-capable request without knowing execution state is not a sufficient design.

This source review does not establish the root cause, failure frequency, output/context cap, current accounting effects, or a completed server fix for #785.
