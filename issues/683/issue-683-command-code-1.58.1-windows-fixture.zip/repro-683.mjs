import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';

const here = path.dirname(fileURLToPath(import.meta.url));
const repo = here;
const runtime = path.join(here, 'runtime/node_modules');
const runtimePackage = path.join(here, 'runtime/package.json');
const runtimeRoot = path.join(here, 'runtime');
const cli = path.join(runtime, 'command-code/dist/index.mjs');
const cliBundle = path.join(runtime, 'command-code/dist/cli.mjs');
const guard = path.join(here, 'offline-guard.cjs');
const outputRoot = path.resolve(process.env.ISSUE_683_OUTPUT ?? path.join(here, 'runs')); 
const runId = process.env.ISSUE_683_RUN_ID ?? `${new Date().toISOString().replaceAll(':', '').replaceAll('.', '')}-${process.pid}`;
const runDir = path.join(outputRoot, runId);
const expectedCliSha256 = '2bc59dacb82a75d7db6b49699bf6e7537287a7ffcc20c78e143f907a62843198';
const cliSha256 = createHash('sha256').update(fs.readFileSync(cliBundle)).digest('hex');
assert.equal(cliSha256, expectedCliSha256, 'unexpected 1.58.1 CLI bundle');
assert.ok(fs.existsSync(runtimePackage), `missing isolated runtime manifest: ${runtimePackage}`);
if (fs.existsSync(runDir)) throw new Error(`Refusing to overwrite existing run directory: ${runDir}`);
fs.mkdirSync(runDir, { recursive: true });

const req = createRequire(runtimePackage);
const pty = req('@lydell/node-pty');
const { Terminal } = req('@xterm/headless');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const sha = value => createHash('sha256').update(value).digest('hex');
const writeJson = (file, value) => fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n');

const palettes = {
  dark: {
    accent: '#E4CCFF',
    cyan: '#7AD4D6',
    green: '#2EBD8E',
    gray: '#8A94A8',
    white: '#E5E5E5',
    background: '#2B2758'
  },
  light: {
    accent: '#5B21B6',
    cyan: '#0F6B6D',
    green: '#047857',
    gray: '#4B5563',
    white: '#111827',
    background: '#2B2758'
  }
};

const scenarios = [
  { id: 'dark-startup-selector', kind: 'theme', initialTheme: 'dark' },
  { id: 'light-startup-selector', kind: 'theme', initialTheme: 'light' }
];
const selectedIds = process.env.ISSUE_683_SCENARIOS?.split(',').map(value => value.trim()).filter(Boolean);
const selected = selectedIds?.length ? scenarios.filter(scenario => selectedIds.includes(scenario.id)) : scenarios;
if (selectedIds?.length && selected.length !== selectedIds.length) throw new Error(`Unknown ISSUE_683_SCENARIOS value: ${selectedIds.join(',')}`);

function colorToInt(value) {
  return Number.parseInt(value.slice(1), 16);
}

function intToColor(value) {
  if (!Number.isInteger(value) || value < 0) return null;
  return `#${value.toString(16).padStart(6, '0').toUpperCase()}`;
}

function makeEnvironment(home, port) {
  for (const relative of ['tmp', 'AppData/Roaming', 'AppData/Local', '.commandcode']) fs.mkdirSync(path.join(home, relative), { recursive: true });
  const env = {};
  for (const key of ['SystemRoot', 'WINDIR', 'ComSpec', 'PATHEXT', 'PROCESSOR_ARCHITECTURE']) if (process.env[key]) env[key] = process.env[key];
  const system32 = process.env.SystemRoot ? path.join(process.env.SystemRoot, 'System32') : null;
  const windowsPowerShell = process.env.SystemRoot ? path.join(system32, 'WindowsPowerShell', 'v1.0') : null;
  env.PATH = [path.dirname(process.execPath), system32, windowsPowerShell, ...(process.env.SystemRoot ? [] : ['/usr/bin', '/bin'])].filter(Boolean).join(path.delimiter);
  return Object.assign(env, {
    HOME: home,
    USERPROFILE: home,
    APPDATA: path.join(home, 'AppData/Roaming'),
    LOCALAPPDATA: path.join(home, 'AppData/Local'),
    TEMP: path.join(home, 'tmp'),
    TMP: path.join(home, 'tmp'),
    CMD_LOCAL_ONLY: '1',
    DO_NOT_TRACK: '1',
    OTEL_SDK_DISABLED: 'true',
    COMMANDCODE_SKIP_UPDATES: '1',
    COMMANDCODE_DISABLE_CRON: '1',
    COMMANDCODE_DISABLE_DURABLE_CRON: '1',
    DOTENV_CONFIG_PATH: path.join(home, 'absent.env'),
    TERM: 'xterm-256color',
    COLORTERM: 'truecolor',
    FIXTURE_PROVIDER_KEY: 'synthetic-provider-key-not-real',
    COMMAND_CODE_API_KEY: 'synthetic-command-key-not-real',
    FIXTURE_PORT: String(port)
  });
}

function writeSse(res, payloads, baseId) {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' });
  for (const payload of payloads) res.write(`data: ${JSON.stringify({ id: baseId, object: 'chat.completion.chunk', created: 1, model: 'fixture-model', ...payload })}\n\n`);
  res.end('data: [DONE]\n\n');
}

function toolCall(name, id, input) {
  return { index: 0, id, type: 'function', function: { name, arguments: JSON.stringify(input) } };
}

function stripAnsi(value) {
  return value
    .replace(/[\u001b\u009b]\[[0-?]*[ -/]*[@-~]/g, '')
    .replace(/[\u001b\u009b][\]PX^_].*?(?:\u0007|\u001b\\)/g, '')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '');
}

function sanitize(value, replacements) {
  let result = String(value ?? '');
  for (const [from, to] of replacements) {
    const variants = [from, from.replaceAll('\\', '/'), from.replaceAll('\\', '\\\\')];
    for (const variant of [...new Set(variants)]) result = result.split(variant).join(to);
  }
  return result;
}

function screenText(term) {
  const buffer = term.buffer.active;
  return Array.from({ length: buffer.length }, (_, index) => buffer.getLine(index)?.translateToString(true) ?? '').join('\n');
}

function cellColor(cell, field) {
  const rgb = field === 'fg' ? cell.isFgRGB() : cell.isBgRGB();
  return rgb ? intToColor(field === 'fg' ? cell.getFgColor() : cell.getBgColor()) : null;
}

function colorState(term) {
  const buffer = term.buffer.active;
  const counts = { fg: {}, bg: {} };
  const labels = {};
  for (let row = 0; row < buffer.length; row++) {
    const line = buffer.getLine(row);
    if (!line) continue;
    let text = '';
    for (let col = 0; col < term.cols; col++) {
      const cell = line.getCell(col);
      const chars = cell?.getChars() ?? '';
      text += chars;
      for (const field of ['fg', 'bg']) {
        const color = cell ? cellColor(cell, field) : null;
        if (color) counts[field][color] = (counts[field][color] ?? 0) + 1;
      }
    }
    if (text.trim()) labels[row] = text.replace(/\s+$/u, '');
  }
  return { rows: labels, rgbCounts: counts };
}

function ansiColors(raw) {
  const colors = new Set();
  for (const match of raw.matchAll(/\u001b\[38;2;(\d+);(\d+);(\d+)m/g)) colors.add(`#${[match[1], match[2], match[3]].map(value => Number(value).toString(16).padStart(2, '0')).join('').toUpperCase()}`);
  for (const match of raw.matchAll(/\u001b\[48;2;(\d+);(\d+);(\d+)m/g)) colors.add(`#${[match[1], match[2], match[3]].map(value => Number(value).toString(16).padStart(2, '0')).join('').toUpperCase()}`);
  return [...colors].sort();
}

function colorPresence(state, palette, colors = ['accent', 'green', 'gray']) {
  const expected = colors.map(name => palette[name]);
  const all = new Set([...Object.keys(state.rgbCounts.fg), ...Object.keys(state.rgbCounts.bg)]);
  return Object.fromEntries(colors.map(name => [name, all.has(palette[name])]));
}

async function until(predicate, timeoutMs = 20000) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end && !predicate()) await sleep(100);
  return predicate();
}

async function typeText(child, value) {
  for (const character of value) {
    child.write(character);
    await sleep(15);
  }
}

async function submit(child, value) {
  await typeText(child, value);
  await sleep(350);
  child.write('\n');
}

function currentStage(raw, stageRawStart, term, expectedTheme, name) {
  const state = colorState(term);
  const rawDelta = raw.slice(stageRawStart);
  return {
    name,
    theme: expectedTheme,
    text: stripAnsi(screenText(term)).slice(-10000),
    rows: state.rows,
    rgbCounts: state.rgbCounts,
    rgbColorsInRaw: ansiColors(rawDelta),
    rawDeltaSha256: sha(rawDelta),
    rawDeltaLength: rawDelta.length,
    expectedColorPresence: colorPresence(state, palettes[expectedTheme])
  };
}

async function runThemeScenario(scenario) {
  const scenarioDir = path.join(runDir, scenario.id);
  const home = path.join(scenarioDir, 'home');
  const project = path.join(scenarioDir, 'project');
  fs.mkdirSync(project, { recursive: true });
  const requests = [];
  const server = http.createServer((request, response) => {
    let bodyText = '';
    request.on('data', chunk => { bodyText += chunk; });
    request.on('end', () => {
      if (!request.url?.endsWith('/chat/completions')) { response.writeHead(404); response.end('fixture endpoint not found'); return; }
      let body;
      try { body = JSON.parse(bodyText); } catch { response.writeHead(400); response.end('invalid JSON'); return; }
      requests.push({ index: requests.length + 1, toolNames: (body.tools ?? []).map(tool => tool.function?.name ?? tool.name).filter(Boolean) });
      writeSse(response, [
        { choices: [{ index: 0, delta: { role: 'assistant', content: `ISSUE_683_THEME_${scenario.id}` }, finish_reason: null }] },
        { choices: [{ index: 0, delta: {}, finish_reason: 'stop' }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } }
      ], `issue-683-${scenario.id}-${requests.length}`);
    });
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;
  const env = makeEnvironment(home, port);
  fs.writeFileSync(path.join(home, '.commandcode/providers.json'), JSON.stringify({ provider: { fixture683: { api: 'openai-completions', baseURL: `http://127.0.0.1:${port}/v1`, apiKey: '$FIXTURE_PROVIDER_KEY', models: { model: { contextWindow: 200000, maxOutput: 300, cost: { input: 0, output: 0 } } } } } }, null, 2));
  fs.writeFileSync(path.join(home, '.commandcode/config.json'), JSON.stringify({ model: 'fixture683/model', provider: 'fixture683', theme: scenario.initialTheme, localOnly: true, telemetry: false, tasteLearning: false }, null, 2));
  fs.writeFileSync(path.join(home, '.commandcode/settings.json'), JSON.stringify({ theme: scenario.initialTheme, permissions: { defaultMode: 'default' } }, null, 2));
  const nodeArgs = [
    '--permission', '--allow-child-process', `--allow-fs-read=${runtimeRoot}`, `--allow-fs-read=${runDir}`, `--allow-fs-read=${repo}`, `--allow-fs-write=${runDir}`,
    '--require', guard, cli, '--no-auto-update', '--local-only', '--skip-onboarding', '--no-skills', '--trust', '--model', 'fixture683/model', '/theme'
  ];
  const policy = ['--permission', '--allow-child-process', `--allow-fs-read=${runtimeRoot}`, `--allow-fs-read=${runDir}`, `--allow-fs-read=${repo}`, `--allow-fs-write=${runDir}`, '--require', guard];
  env.NODE_OPTIONS = policy.map(value => JSON.stringify(value.replaceAll('\\', '/'))).join(' ');
  const term = new Terminal({ cols: 140, rows: 45, allowProposedApi: true, scrollback: 3000 });
  let raw = '';
  let exit = null;
  let child;
  const stages = [];
  const stageRaw = () => raw.length;
  const record = (name, expectedTheme) => {
    const stage = currentStage(raw, stageRaw.start, term, expectedTheme, name);
    stageRaw.start = raw.length;
    stages.push(stage);
    writeJson(path.join(scenarioDir, `${name}.json`), stage);
  };
  stageRaw.start = 0;
  try {
    child = pty.spawn(process.execPath, nodeArgs, { name: 'xterm-256color', cols: 140, rows: 45, cwd: project, env, useConpty: true, windowsHide: true });
    term.onData(data => child.write(data));
    child.onData(data => { raw += data; term.write(data); });
    child.onExit(event => { exit = { code: event.exitCode, signal: event.signal }; });
    const targetObserved = await until(() => /Select a theme/i.test(screenText(term)) || exit, 30000);
    record(`startup-${scenario.initialTheme}`, scenario.initialTheme);
    if (!targetObserved || exit) throw new Error('theme selector was not observed from the initial slash command');
    if (scenario.roundtrip) {
      term.input('\u001b[A');
      await sleep(500);
      term.input('\r');
      await sleep(500);
      await until(() => /Theme set to: Dark theme/i.test(screenText(term)) || exit, 10000);
      record('after-dark', 'dark');
    } else {
      record(`selector-${scenario.initialTheme}`, scenario.initialTheme);
    }
    if (!exit) { child.write('\u001b'); await sleep(250); child.write('\u0003\u0003'); await until(() => exit, 5000); }
  } finally {
    if (child && !exit) { child.kill(); await until(() => exit, 3000); }
    const replacements = [[repo, '<REPO>'], [home, '<HOME>'], [project, '<PROJECT>'], [runDir, '<RUN>']];
    fs.writeFileSync(path.join(scenarioDir, 'terminal-sanitized.txt'), sanitize(stripAnsi(raw), replacements));
    fs.writeFileSync(path.join(scenarioDir, 'terminal-ansi-sanitized.txt'), sanitize(raw, replacements));
    writeJson(path.join(scenarioDir, 'result.json'), {
      scenario: scenario.id,
      kind: scenario.kind,
      initialTheme: scenario.initialTheme,
      version: '1.58.1',
      cliSha256,
      node: process.version,
      platform: process.platform,
      terminal: 'Windows ConPTY with @xterm/headless parser',
      envColor: { TERM: env.TERM, COLORTERM: env.COLORTERM, NO_COLOR: Object.prototype.hasOwnProperty.call(env, 'NO_COLOR') },
      exit,
      requestCount: requests.length,
      stages,
      rawSha256: sha(raw),
      scope: 'Actual unmodified Command Code 1.58.1 CLI on Windows ConPTY with truecolor terminal env and isolated home/project. Colors are parsed terminal cells and emitted ANSI, not a native Ghostty or Alacritty capture.'
    });
    server.closeAllConnections();
    await new Promise(resolve => server.close(resolve));
    term.dispose();
  }
  return JSON.parse(fs.readFileSync(path.join(scenarioDir, 'result.json'), 'utf8'));
}

const results = [];
for (const scenario of selected) {
  try { results.push(await runThemeScenario(scenario)); }
  catch (error) { results.push({ scenario: scenario.id, driverError: { name: error.name, message: error.message, stack: error.stack } }); }
}
const report = {
  runId,
  generatedAt: new Date().toISOString(),
  package: { name: 'command-code', version: '1.58.1', cliSha256, runtimeRoot: '<FIXTURE>/runtime', dependencies: { '@lydell/node-pty': '1.1.0', '@xterm/headless': '6.0.0', node: process.version } },
  terminalEnvironment: { TERM: 'xterm-256color', COLORTERM: 'truecolor', NO_COLOR: 'omitted' },
  palettes,
  scenarios: results,
  limitations: [
    'The localhost fixture scripted only the permission tool call and final text; it does not establish real-provider or model behavior.',
    'Parsed RGB cell values and ANSI sequences are emitted terminal evidence. Any visual reconstruction from them would not be a native Ghostty or Alacritty screenshot.',
    'Windows 11 ConPTY was exercised. Native Linux, macOS, Ghostty, and Alacritty were not tested.',
    'This portable run covers separate dark and light startup selectors only. It does not test live switching, permission selectors, or a source patch.'
  ]
};
writeJson(path.join(runDir, 'results.json'), report);
console.log(JSON.stringify({ runDir, scenarios: results.map(result => ({ scenario: result.scenario, exit: result.exit, driverError: result.driverError?.message ?? null, permissionObserved: result.permissionObserved ?? null })) }));
