import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const require=createRequire(path.join(here,'runtime/package.json'));
const {Terminal}=require('@xterm/headless');
const input=path.resolve(process.argv[2]??path.join(here,'reference/results.json'));
const result=JSON.parse(fs.readFileSync(input,'utf8'));
const pin='2bc59dacb82a75d7db6b49699bf6e7537287a7ffcc20c78e143f907a62843198';
assert.equal(result.package.cliSha256,pin);
assert.deepEqual(result.scenarios.map(x=>x.scenario).sort(),['dark-startup-selector','light-startup-selector']);
const rows=[];
for(const scenario of result.scenarios){
  assert.ok(!scenario.driverError,'driver error');
  assert.equal(scenario.cliSha256,pin);
  assert.equal(scenario.version,'1.58.1');
  assert.equal(scenario.requestCount,0,'startup selector should need no model requests');
  assert.deepEqual(scenario.envColor,{TERM:'xterm-256color',COLORTERM:'truecolor',NO_COLOR:false});
  const file=path.join(path.dirname(input),scenario.scenario,'terminal-ansi-sanitized.txt');
  const raw=fs.readFileSync(file,'utf8');
  assert.ok(!/OFFLINE_GUARD_BLOCK/.test(raw),'blocked network attempt');
  const end=raw.indexOf(' to cancel');
  assert.ok(end>=0,'selector instruction boundary missing');
  const term=new Terminal({cols:140,rows:45,allowProposedApi:true,scrollback:3000});
  await new Promise(resolve=>term.write(raw.slice(0,end+' to cancel'.length),resolve));
  const matched=[];
  for(let r=0;r<term.buffer.active.length;r++){
    const line=term.buffer.active.getLine(r),text=line?.translateToString(true)??'';
    if(!/^\s*[❯ ]?\s*[123]\. (Auto|Dark|Light) theme/.test(text))continue;
    const cells=[];
    for(let c=0;c<term.cols;c++){
      const cell=line.getCell(c),chars=cell?.getChars()??'';
      if(chars)cells.push({text:chars,fg:cell.isFgRGB()?'#'+cell.getFgColor().toString(16).padStart(6,'0').toUpperCase():null});
    }
    matched.push({text,cells});
  }
  rows.push({theme:scenario.initialTheme,file:path.relative(path.dirname(input),file).replaceAll('\\','/'),sha256:createHash('sha256').update(raw).digest('hex'),matched});
  term.dispose();
}
function verify(rows){
  assert.equal(rows.length,2);
  for(const theme of ['dark','light']){
    const group=rows.find(x=>x.theme===theme);assert.ok(group);
    assert.equal(group.matched.length,3,'all choices required');
    const selected=group.matched.filter(x=>x.text.startsWith('❯'));
    assert.equal(selected.length,1);
    const label=theme==='dark'?'Dark theme':'Light theme';
    assert.ok(selected[0].text.includes(label+' ✔'),'selected label/check missing');
    const first=selected[0].text.indexOf(label);
    for(const cell of selected[0].cells.slice(first,first+label.length))assert.equal(cell.fg,'#E4CCFF');
    assert.equal(selected[0].cells.find(x=>x.text==='✔')?.fg,'#2EBD8E');
    for(const inactive of group.matched.filter(x=>!x.text.startsWith('❯'))){
      const start=inactive.text.search(/[123]\. /);
      for(const cell of inactive.cells.slice(start).filter(x=>x.text.trim()))assert.equal(cell.fg,theme==='light'?'#4B5563':'#8A94A8');
    }
  }
  return true;
}
verify(rows);
const mutations=[
  r=>r.pop(),
  r=>r[1].matched.splice(0,1),
  r=>{r[1].matched.find(x=>x.text.startsWith('❯')).cells.find(x=>x.text==='✔').fg='#047857';},
  r=>{const item=r[1].matched.find(x=>x.text.startsWith('❯'));item.cells[item.text.indexOf('Light')].fg='#5B21B6';},
  r=>{const item=r[1].matched.find(x=>!x.text.startsWith('❯'));item.cells[item.text.search(/[123]/)].fg='#8A94A8';}
];
for(const mutate of mutations){const bad=structuredClone(rows);mutate(bad);assert.throws(()=>verify(bad));}
const proof={verifiedAt:new Date().toISOString(),passed:true,negativeControls:mutations.length,inputSha256:createHash('sha256').update(fs.readFileSync(input)).digest('hex'),scope:'Exact choice-cell colors reparsed from retained ANSI; no product run by verifier.',rows};
fs.writeFileSync(path.join(path.dirname(input),'ROW-COLORS-VERIFIED.json'),JSON.stringify(proof,null,2)+'\n');
console.log(JSON.stringify({passed:true,negativeControls:mutations.length,rows:rows.map(x=>({theme:x.theme,choices:x.matched.length}))}));
