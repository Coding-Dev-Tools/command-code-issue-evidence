'use strict';

const fs = require('node:fs');
const net = require('node:net');
const tls = require('node:tls');
const { syncBuiltinESMExports } = require('node:module');

const allowedPort = String(process.env.FIXTURE_PORT || '');
function reject(target) {
  fs.writeSync(2, JSON.stringify({ event: 'blocked-network', target }) + '\n');
  throw new Error('Fixture permits only its own localhost endpoint');
}
function check(host, port) {
  const loopback = new Set(['127.0.0.1', 'localhost', '::1', '[::1]']);
  if (!loopback.has(String(host)) || String(port) !== allowedPort) reject(`${host}:${port}`);
}
function optionsFrom(args) {
  if (Array.isArray(args[0])) return optionsFrom(args[0]);
  if (typeof args[0] === 'object' && args[0] !== null) return args[0];
  return { port: args[0], host: typeof args[1] === 'string' ? args[1] : 'localhost' };
}
const nativeFetch = globalThis.fetch;
globalThis.fetch = function guardedFetch(input, init) {
  const url = new URL(typeof input === 'string' || input instanceof URL ? input : input.url);
  if (url.protocol === 'data:') return nativeFetch(input, init);
  check(url.hostname, url.port || (url.protocol === 'https:' ? '443' : '80'));
  return nativeFetch(input, init);
};
const nativeConnect = net.Socket.prototype.connect;
net.Socket.prototype.connect = function guardedConnect(...args) {
  const options = optionsFrom(args);
  check(options.host ?? options.hostname ?? 'localhost', options.port);
  return nativeConnect.apply(this, args);
};
const nativeTlsConnect = tls.connect;
tls.connect = function guardedTlsConnect(...args) {
  const options = optionsFrom(args);
  check(options.host ?? options.hostname ?? 'localhost', options.port);
  return nativeTlsConnect.apply(this, args);
};
syncBuiltinESMExports();
fs.writeSync(2, JSON.stringify({ event: 'offline-guard-ready', port: allowedPort }) + '\n');
