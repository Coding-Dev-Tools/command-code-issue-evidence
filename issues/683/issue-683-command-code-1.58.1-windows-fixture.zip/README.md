# Issue 683: exact selector color regression

Windows 11 / Node 24.15.0 / Command Code 1.58.1. This fixture starts the real CLI twice with isolated dark/light configurations and opens /theme. It makes no paid model calls. The child environment uses dummy credentials and a localhost-only network guard.

From this directory:

```powershell
npm ci --prefix runtime --ignore-scripts --no-audit --no-fund
node repro-683.mjs
node verify-683.mjs runs/<printed-run-directory>/results.json
```

Use the actual directory printed by the runner. The verifier reparses retained ANSI and checks the cells of the selected label, check mark and inactive labels. It does not infer colors from unrelated screen elements. It also rejects five deliberately corrupted projections. A passing verifier means the recorded 1.58.1 regression is reproduced, not fixed. A changed/fixed palette should fail this regression-observation verifier; it is not a future acceptance test.

The reference/ directory contains the selected sanitized output and results from a fresh portable run. Verify those without launching the CLI with `node verify-683.mjs reference/results.json`.

Limitations: Windows ConPTY and parsed terminal colors only; no native macOS/Linux/Ghostty/Alacritty capture, no contrast-ratio measurement, live switching or patch validation. Dependency installation uses npm; the CLI captures use only the local fixture. All versions are pinned by runtime/package-lock.json and the runner checks the actual CLI bundle SHA-256.
