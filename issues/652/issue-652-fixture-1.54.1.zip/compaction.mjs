import {fs,path,assert,packageRuntime,save,isolatedEnv,configure,expectedHash,sleep,createHash} from './common.mjs';
import {terminal} from './terminal.mjs';import {fileURLToPath,pathToFileURL} from 'node:url';import http from 'node:http';import {randomUUID} from 'node:crypto';
const here=path.dirname(fileURLToPath(import.meta.url)),pkg=packageRuntime(process.argv[2]??path.join(here,'node_modules'));
const base=path.resolve(process.argv[3]??path.join(here,'runs'));fs.mkdirSync(base,{recursive:true});const out=fs.mkdtempSync(path.join(base,'compact652-')),runs=[];
const sha=x=>createHash('sha256').update(x).digest('hex');let active=null;
const summaryText='SUMMARY652: Synthetic earlier discussion compressed. Continue the pending fixture task.';
const server=http.createServer((req,res)=>{let raw='';req.on('data',x=>raw+=x);req.on('end',async()=>{try{
 assert.equal(req.url,'/v1/chat/completions');const body=JSON.parse(raw),isSummary=(body.tools??[]).length===0&&body.messages.some(m=>JSON.stringify(m.content).includes('Please summarize the following conversation.'));
 const kind=isSummary?'summary':'main',ordinal=active.requests.filter(x=>x.phase===active.phase&&x.kind===kind).length+1;
 const projection=body.messages.map(m=>m.role==='system'?{role:'system',contentSha256:sha(JSON.stringify(m.content)),characters:JSON.stringify(m.content).length}:m);
 const record={phase:active.phase,kind,ordinal,model:body.model,bodyBytes:Buffer.byteLength(raw),messages:projection,toolsSha256:sha(JSON.stringify(body.tools??[])),toolsCount:body.tools?.length??0,hasSummary:JSON.stringify(body.messages).includes('SUMMARY652'),seedMarkers:Array.from({length:16},(_,i)=>'SEED652_'+String(i).padStart(2,'0')).filter(x=>JSON.stringify(body.messages).includes(x))};active.requests.push(record);
 save(path.join(active.run,'progress.json'),{...active,raw:undefined});
 assert.ok(active.requests.length<=(active.name.startsWith('live-')?22:12),'bounded provider sequence');
 let error=null,answer;
 if(active.phase==='seeding'){answer='SEED652_'+String(ordinal*2-1).padStart(2,'0')+' '+('synthetic discussion padding. '.repeat(1100))+' SEED_DONE652_'+(ordinal-1);}
 else if(active.phase==='resume'){answer='RESUMED652';}
 else if(isSummary){
  if(active.name==='summary-fails')error='Invalid summary request fixture';
  else if(active.name==='empty-summary')answer='';
  else if(active.name==='cancel-summary'){active.summaryPending=true;await sleep(5000);if(res.destroyed)return;answer=summaryText;}
  else answer=summaryText;
 }else if(active.phase==='followup'){answer='FOLLOWED652';}
 else if(active.name==='normal'||active.name==='live-normal'){answer='DONE652_'+active.name;}
 else if(active.name==='unrelated-400'){error='Invalid tool schema fixture';}
 else if(ordinal===1||['summary-fails','empty-summary','retry-overflow'].includes(active.name)){error=active.errorShape==='laguna'?'Input length 210000 exceeds the maximum allowed input length of 200000 tokens':'Your input exceeds the context window of this model.';}
 else answer='DONE652_'+active.name;
 if(error){record.response={status:400,message:error};res.writeHead(400,{'content-type':'application/json'});res.end(JSON.stringify({error:{message:error,type:'invalid_request_error',code:active.name==='unrelated-400'?'invalid_tool_schema':'context_length_exceeded'}}));}
 else{record.response={status:200,text:answer};await sleep(1000);res.writeHead(200,{'content-type':'text/event-stream'});for(const[d,f]of[[{role:'assistant',content:answer},null],[{},'stop']])res.write('data: '+JSON.stringify({id:'fixture652',object:'chat.completion.chunk',created:1,model:'model',choices:[{index:0,delta:d,finish_reason:f}],usage:{prompt_tokens:100,completion_tokens:20,total_tokens:120}})+'\n\n');res.end('data: [DONE]\n\n');}
 }catch(e){active.errors.push(e.message);if(!res.headersSent)res.writeHead(500);res.end('fixture error');}})});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;let failure=null;
const selected=process.argv[4]??'success';
try{for(const name of (selected==='all'?['success','laguna-success','normal','unrelated-400','summary-fails','empty-summary','retry-overflow','cancel-summary']:selected.split(','))){
 const run=path.join(out,name),home=path.join(run,'home'),project=path.join(run,'project');fs.mkdirSync(project,{recursive:true});const env=isolatedEnv(home,port);await configure(home,project,pkg,port);
 save(path.join(home,'.commandcode/settings.json'),{disableScratchpad:true,mods:{disabled:['titling','learning']}});
 const {default:slugify}=await import(pathToFileURL(pkg.req.resolve('@sindresorhus/slugify')).href);let sessionId=randomUUID(),sessionFile=path.join(home,'.commandcode/projects',slugify(project),sessionId+'.jsonl');
 const timestamp='2026-09-16T00:00:00.000Z',entries=[{type:'session',version:3,id:sessionId,timestamp,cwd:project}];let parentId=null;
 for(let i=0;i<16;i++){const id='seed'+i,marker='SEED652_'+String(i).padStart(2,'0');entries.push({type:'message',id,parentId,timestamp,message:{role:i%2?'assistant':'user',content:[{type:'text',text:marker+' '+('synthetic discussion padding. '.repeat(690))}]}});parentId=id;}
 if(!name.startsWith('live-'))fs.writeFileSync(sessionFile,entries.map(x=>JSON.stringify(x)).join('\n')+'\n');
 active={name,phase:name.startsWith('live-')?'seeding':'initial',run,sessionId,seedEntries:16,seedBytes:name.startsWith('live-')?null:fs.statSync(sessionFile).size,historySetup:name.startsWith('live-')?'eight actual user/assistant turns':'synthetic V3 transcript',requests:[],errors:[],processes:[],errorShape:name==='laguna-success'?'laguna':'generic'};
 const t=terminal(pkg,here,out,project,env,name.startsWith('live-')?[]:['--resume',sessionId]);let p={phase:'initial'};
 try{
  assert.ok(await t.until(()=>t.screen().includes('Ask your question'),25000),'ready prompt');await sleep(500);
  if(name.startsWith('live-')){
   for(let i=0;i<8;i++){await t.type('SEED652_'+String(i*2).padStart(2,'0')+': generate synthetic discussion for the fixture.');assert.ok(await t.until(()=>t.screen().includes('SEED_DONE652_'+i),30000),'live history turn '+i);await sleep(400);}
   const dir=path.dirname(sessionFile),files=fs.readdirSync(dir).filter(x=>x.endsWith('.jsonl')&&!x.endsWith('.checkpoints.jsonl'));assert.equal(files.length,1);sessionFile=path.join(dir,files[0]);sessionId=JSON.parse(fs.readFileSync(sessionFile,'utf8').split('\n')[0]).id;active.sessionId=sessionId;active.phase='initial';
  }
  await t.type('TRIGGER652: Continue this synthetic task.');
  if(name==='cancel-summary'){
   assert.ok(await t.until(()=>active.summaryPending,30000),'summary pending');t.child.write('\x1b');await sleep(2000);p.cancelledByEscape=true;
  }else{
   const done=['success','laguna-success','live-success','live-normal','normal'].includes(name)?'DONE652_'+name:name==='unrelated-400'?'Invalid tool schema fixture':'Your input exceeds';
   assert.ok(await t.until(()=>t.screen().includes(done),45000),'final outcome visible');await sleep(1000);
  }
  p.screen=t.screen();
  if(name.startsWith('live-')){
   active.afterRecoveryBeforeFollowup={hasSummary:fs.readFileSync(sessionFile,'utf8').includes('SUMMARY652'),hasCompaction:fs.readFileSync(sessionFile,'utf8').includes('"type":"compaction"')};
   active.phase='followup';await t.type('FOLLOWUP652: Continue in the same session.');assert.ok(await t.until(()=>t.screen().includes('FOLLOWED652'),30000),'same-session followup');await sleep(500);p.followupScreen=t.screen();
  }
 }catch(e){p.failure={message:e.message,stack:e.stack};throw e;}
 finally{p.exit=await t.close();p.raw=t.raw;active.processes.push(p);}
 assert.equal(p.exit.exitCode,0);assert.equal(active.errors.length,0);
 const stored=fs.readFileSync(sessionFile,'utf8').trim().split('\n').map(JSON.parse);
 active.afterInitial={entryTypes:stored.map(x=>x.type),summaryEntries:stored.filter(x=>x.type==='compaction'),messageMarkers:stored.filter(x=>x.type==='message').map(x=>({id:x.id,role:x.message.role,summary:JSON.stringify(x.message).includes('SUMMARY652'),done:JSON.stringify(x.message).includes('DONE652_'),seed:JSON.stringify(x.message).match(/SEED652_\d+/g)}))};
 if(name==='success'||name.startsWith('live-')){
  active.phase='resume';const resumed=terminal(pkg,here,out,project,{...env},['--resume',sessionId]);const p2={phase:'resume'};
  try{assert.ok(await resumed.until(()=>resumed.screen().includes('Ask your question'),25000));await sleep(500);await resumed.type('RESUME652: Verify this saved synthetic task.');assert.ok(await resumed.until(()=>resumed.screen().includes('RESUMED652'),30000));await sleep(500);p2.screen=resumed.screen();}
  finally{p2.exit=await resumed.close();p2.raw=resumed.raw;active.processes.push(p2);}assert.equal(p2.exit.exitCode,0);
 }
 runs.push(active);save(path.join(run,'results.json'),active);console.log(JSON.stringify({name,sequence:active.requests.map(x=>x.phase+':'+x.kind+':'+x.response?.status),summaryFlags:active.requests.map(x=>x.hasSummary),storedCompactions:active.afterInitial.summaryEntries.length,exits:active.processes.map(x=>x.exit),errors:active.errors}));
}}
catch(e){failure={message:e.message,stack:e.stack};if(active&&!runs.includes(active))runs.push(active);}
finally{server.closeAllConnections();await new Promise(r=>server.close(r));}
save(path.join(out,'results.json'),{version:'1.54.1',bundleSha256:expectedHash,node:process.version,platform:process.platform,scope:'Unmodified interactive CLI with seeded synthetic V3 history and scripted localhost provider. Provider overflow response is injected; no real-model context limit or reporter platform reproduction.',summaryText,runs,failure});console.log(JSON.stringify({out,failure}));setTimeout(()=>process.exit(failure?1:0),50);
