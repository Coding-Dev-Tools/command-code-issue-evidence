import fs from 'node:fs';import assert from 'node:assert/strict';import path from 'node:path';import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const markers=messages=>Array.from({length:16},(_,i)=>'SEED652_'+String(i).padStart(2,'0')).filter(m=>JSON.stringify(messages).includes(m));
function checkRow(r){
 assert.deepEqual(r.errors,[]);for(const p of r.processes){assert.equal(p.exit.exitCode,0);assert.equal(p.failure,undefined);}
 for(const q of r.requests){assert.deepEqual(q.seedMarkers,markers(q.messages));assert.equal(q.hasSummary,JSON.stringify(q.messages).includes('SUMMARY652'));assert.equal(q.model,'model');}
 const initial=r.requests.filter(q=>q.phase==='initial'),main=initial.filter(q=>q.kind==='main'),summaries=initial.filter(q=>q.kind==='summary');
 if(['success','laguna-success','live-success'].includes(r.name)){
  assert.equal(main.length,2);assert.equal(summaries.length,1);assert.equal(main[0].response.status,400);assert.equal(summaries[0].response.status,200);assert.equal(main[1].response.status,200);
  assert.equal(main[0].seedMarkers.length,16);assert.deepEqual(main[1].seedMarkers,main[0].seedMarkers.slice(10));assert.equal(main[1].hasSummary,true);assert.ok(main[1].bodyBytes<main[0].bodyBytes);
  assert.deepEqual(main[0].messages.filter(m=>m.role==='system'),main[1].messages.filter(m=>m.role==='system'));assert.equal(main[0].toolsSha256,main[1].toolsSha256);assert.ok(r.processes[0].screen.includes('DONE652_'+r.name));
 }else if(['normal','live-normal','unrelated-400'].includes(r.name)){assert.equal(main.length,1);assert.equal(summaries.length,0);assert.equal(main[0].response.status,r.name==='unrelated-400'?400:200);}
 else if(r.name==='cancel-summary'){assert.equal(main.length,1);assert.equal(summaries.length,1);assert.equal(r.processes[0].cancelledByEscape,true);assert.equal(summaries[0].response,undefined);}
 else{assert.equal(main.length,2);assert.equal(summaries.length,1);assert.equal(main[0].response.status,400);assert.equal(main[1].response.status,400);
  if(r.name==='retry-overflow'){assert.equal(main[1].hasSummary,true);assert.equal(main[1].seedMarkers.length,6);}else{assert.deepEqual(main[0].messages,main[1].messages);assert.equal(main[0].toolsSha256,main[1].toolsSha256);assert.equal(main[0].bodyBytes,main[1].bodyBytes);assert.equal(main[1].hasSummary,false);}
 }
 if(r.name.startsWith('live-')){
  assert.equal(r.historySetup,'eight actual user/assistant turns');assert.equal(r.requests.filter(q=>q.phase==='seeding').length,8);
  const followup=r.requests.filter(q=>q.phase==='followup'),resume=r.requests.filter(q=>q.phase==='resume');assert.equal(resume.length,1);assert.equal(resume[0].seedMarkers.length,16);assert.ok(r.processes[1].screen.includes('RESUMED652'));
  if(r.name==='live-success'){
   assert.equal(followup.length,2);assert.equal(followup[0].kind,'summary');assert.equal(followup[1].seedMarkers.length,6);assert.equal(followup[1].hasSummary,true);assert.ok(r.processes[0].followupScreen.includes('Auto-compacted conversation'));assert.equal(r.afterInitial.summaryEntries.length,1);assert.equal(resume[0].hasSummary,true);
   for(let i=0;i<16;i++){const m='SEED652_'+String(i).padStart(2,'0');assert.equal(r.afterInitial.messageMarkers.filter(q=>q.seed?.includes(m)).length,i<10?2:1,'disk marker count '+m);}
   let messageIndex=0,after=false;const replayed=[];for(const type of r.afterInitial.entryTypes){if(type==='compaction')after=true;else if(type==='message'){const m=r.afterInitial.messageMarkers[messageIndex++];if(after&&m.seed)replayed.push(...m.seed);}}
   assert.deepEqual(replayed,Array.from({length:10},(_,i)=>'SEED652_'+String(i).padStart(2,'0')),'old messages appended after compaction');
  }else{assert.equal(followup.length,1);assert.equal(r.afterInitial.summaryEntries.length,0);assert.equal(resume[0].hasSummary,false);for(let i=0;i<16;i++){const m='SEED652_'+String(i).padStart(2,'0');assert.equal(r.afterInitial.messageMarkers.filter(q=>q.seed?.includes(m)).length,1);}}
 }
}
function check(x){assert.equal(x.failure,null);assert.equal(x.version,'1.54.1');assert.equal(x.bundleSha256,'74a7b03dc794b5be7fa2efa4a41f8d33f9f45927cb3febe2c5e52508d9df4ac5');assert.ok(x.runs.length);for(const r of x.runs)checkRow(r);}
const args=process.argv.slice(2),files=args.length?args:['seeded-success-results.json','seeded-control-results.json','live-results.json'].map(x=>path.join(here,x));
for(const file of files){const x=JSON.parse(fs.readFileSync(file,'utf8'));check(x);const b=structuredClone(x);b.runs[0].processes[0].exit.exitCode=1;assert.throws(()=>check(b));console.log(JSON.stringify({ok:true,file:path.basename(file),scenarios:x.runs.map(r=>r.name),requests:x.runs.reduce((s,r)=>s+r.requests.length,0),processes:x.runs.reduce((s,r)=>s+r.processes.length,0)}));
 const live=x.runs.find(r=>r.name==='live-success');if(live){for(const mutate of [r=>r.afterInitial.summaryEntries=[],r=>r.requests.find(q=>q.phase==='initial'&&q.kind==='main'&&q.ordinal===2).messages=r.requests.find(q=>q.phase==='initial'&&q.kind==='main').messages,r=>r.requests.find(q=>q.phase==='resume').messages=r.requests.find(q=>q.phase==='followup'&&q.kind==='main').messages]){const bad=structuredClone(live);mutate(bad);assert.throws(()=>checkRow(bad));}console.log('Rejected missing compaction, unreconstructed retry and hidden resumed-history controls.');}
}
