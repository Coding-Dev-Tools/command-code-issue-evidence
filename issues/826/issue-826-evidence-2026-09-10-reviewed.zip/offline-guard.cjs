'use strict';
const net = require('node:net');
const tls = require('node:tls');
const fs = require('node:fs');
fs.writeSync(2, JSON.stringify({ event: 'offline-guard-entered' }) + '\n');
const { syncBuiltinESMExports } = require('node:module');
const allowedPort = String(process.env.FIXTURE_PORT);
function reject(target) {
  fs.writeSync(2, JSON.stringify({ event: 'blocked-network', target }) + '\n');
  throw new Error('Fixture permits only its own localhost endpoint');
}
function check(host, port) {
  if (!['127.0.0.1', 'localhost', '::1', '[::1]'].includes(String(host)) || String(port) !== allowedPort) reject(`${host}:${port}`);
}
const nativeFetch = globalThis.fetch;
globalThis.fetch = function(input, init) {
  const url = new URL(typeof input === 'string' || input instanceof URL ? input : input.url);
  // Yoga initializes its embedded WASM through a data: URL; this is no network.
  if (url.protocol === 'data:') return nativeFetch(input, init);
  check(url.hostname, url.port || (url.protocol === 'https:' ? '443' : '80'));
  return nativeFetch(input, init);
};
function optionsFrom(args) {
  if (Array.isArray(args[0])) return optionsFrom(args[0]);
  if (typeof args[0] === 'object' && args[0] !== null) return args[0];
  return { port: args[0], host: typeof args[1] === 'string' ? args[1] : 'localhost' };
}
const connect = net.Socket.prototype.connect;
net.Socket.prototype.connect = function(...args) {
  const options = optionsFrom(args);
  check(options.host ?? options.hostname ?? 'localhost', options.port);
  return connect.apply(this, args);
};
const tlsConnect = tls.connect;
tls.connect = function(...args) {
  const options = optionsFrom(args);
  check(options.host ?? options.hostname ?? 'localhost', options.port);
  return tlsConnect.apply(this, args);
};
syncBuiltinESMExports();
fs.writeSync(2, JSON.stringify({ event: 'offline-guard-ready' }) + '\n');
// Test-only cancellation bridge: exercise the CLI-installed signal handlers.
process.on('message', message => {
  if (message?.fixtureAction === 'inject-SIGINT') {
    process.send?.({ fixtureEvent: 'injecting-SIGINT', handlerCount: process.listenerCount('SIGINT') });
    process.emit('SIGINT');
  }
});
