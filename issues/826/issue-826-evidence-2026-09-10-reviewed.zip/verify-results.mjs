import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import {scenarios} from './scenarios.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const [cliFile=path.join(root,'cli-results.json'),componentFile=path.join(root,'component-results.json')]=process.argv.slice(2);
const cli=JSON.parse(fs.readFileSync(cliFile)),component=JSON.parse(fs.readFileSync(componentFile));
const expectedHash='b4f5398190f2912d90cecb3c558017f9e0c2c97d55ccf6b66848eed910642859';
assert.equal(cli.bundleSha256,expectedHash);assert.equal(component.bundleSha256,expectedHash);
assert.equal(cli.results.length,5);let requests=0,calls=0,aborts=0;
for(const scenario of scenarios){
 const r=cli.results.find(r=>r.name===scenario.name);assert.ok(r);assert.equal(r.timedOut,false);assert.equal(r.guardReady,true);assert.equal(r.blockedNetwork,false);assert.deepEqual(r.failures,[]);
 assert.deepEqual(r.submittedTodos.map(x=>x.input.todos),scenario.lists);
 for(const [i,reply] of r.toolReplies.entries()){assert.equal(reply.tool_call_id,`call_826_${i}`);assert.equal(r.submittedTodos[i].id,reply.tool_call_id);assert.ok(String(reply.content).startsWith('Todos have been modified successfully.'),'Every zero-warning control must execute the actual tool successfully');}
 assert.equal(r.requests,scenario.lists.length+2);assert.equal(r.toolCalls,scenario.lists.length);
 assert.ok(r.discoveryReply.content.includes('### todo_write\n'));
 const counts=r.toolReplies.map(m=>Number(String(m.content).match(/REMOVED (\d+)/)?.[1]??0));
 assert.deepEqual(counts,scenario.removed);assert.deepEqual(r.removed,counts);
 assert.equal(r.finalResult.length,1);assert.equal(r.finalResult[0].subtype,'success');assert.equal(r.finalResult[0].finalText,'ISSUE_826_SCRIPT_COMPLETE');
 assert.ok([0,3221226505].includes(r.exit.code));if(r.exit.code!==0){aborts++;assert.match(r.stderr,/Assertion failed:.*UV_HANDLE_CLOSING/);}
 requests+=r.requests;calls+=r.toolCalls;
 const c=component.results.find(c=>c.name===scenario.name);assert.deepEqual(c.steps.map(s=>s.removed),counts);
}
assert.equal(component.controls.length,10);
assert.deepEqual(component.diagnostics.positionalIdCounterexample.actualDropped.map(x=>x.content),['A']);
assert.deepEqual(component.diagnostics.positionalIdCounterexample.naiveIdDropped.map(x=>x.content),['B']);
console.log(JSON.stringify({ok:true,cliProcesses:5,requests,todoCalls:calls,cleanExits:5-aborts,qualifiedPostResultAborts:aborts,componentSequences:5,componentControls:10,diagnosticCounterexamples:2,freshProductExecution:false}));
