# Issue 826: deterministic todo identity regression packet

Prepared September 10, 2026. Upstream: https://github.com/CommandCodeAI/command-code/issues/826. Full issue body and its zero comments were read. Published `command-code@1.53.0`, Windows x64, Node 24.15.0. CLI SHA256 `b4f5398190f2912d90cecb3c558017f9e0c2c97d55ccf6b66848eed910642859`.

## Finding and useful new evidence

The actual unmodified CLI repeats the removal warning when a checklist alternates between `Phase -1: Auto-update check` and `Phase -1: Auto-Update Check`. Keeping explicit IDs does not help: removal detection compares content only. The same scripted sequence yields three removal notes in four updates with omitted IDs and with stable IDs.

This packet adds a reproducible current-build test and counterexamples to an easy but unsafe correction. `validateTodos` assigns absent IDs from array position. Comparing those IDs directly makes `[A(id=1), B(id=2)] -> [B(id=1)]` identify B as removed while missing the actual removal of A. Duplicate explicit IDs are also accepted by the current handler. An identity fix needs explicit identity provenance and uniqueness, not just an ID-first set lookup over the existing normalized data.

Conversely, exact content set membership already hides actual removal of a distinct task when two tasks have the same label. The actual CLI emits no removal note for `[api: "Run tests", ui: "Run tests"] -> [api: "Run tests"]`. A renamed task marked completed with the same stable ID still produces a removal warning about the old unfinished spelling.

Do not indiscriminately case-fold or strip punctuation from content to define identity. For example, lowercasing `Remove Foo.ts` and `Remove foo.ts` produces the same key, despite referring to potentially distinct files on a case-sensitive target. This is an identity-design counterexample, not a filesystem deletion experiment.

## Original actual CLI matrix

The fixture discovers `todo_write` through the real `search_tools` tool, then submits one todo update per response, in one process/session per scenario. The endpoint supplies deterministic SSE tool calls and captures the next request's real tool results. No Grok model, paid inference, live Copilot, gateway, or production account is involved.

| Scenario | Todo calls | Removal-note counts by call | Process outcome |
| --- | ---: | --- | --- |
| Alternate casing, IDs omitted | 4 | 0, 1, 1, 1 | Success result, exit 0 |
| Alternate casing, stable explicit IDs | 4 | 0, 1, 1, 1 | Success result, exit 0 |
| Genuine removal, exact repeat, empty list | 4 | 0, 1, 0, 0 | Success result, exit 0 |
| Two distinct IDs, identical label; remove one | 2 | 0, 0 | Success result, subsequent Windows libuv abort |
| Rename and complete the same ID | 2 | 0, 1 | Success result, subsequent Windows libuv abort |

Total: five CLI processes, 16 todo calls, five discovery calls, 26 HTTP requests, eight removal notes. All final results are successful with `ISSUE_826_SCRIPT_COMPLETE`. Two processes subsequently exit `3221226505` with the Windows libuv closing-handle assertion. No timeout or blocked network attempt occurred. The endpoint does not choose its next action based on warning text: this proves repeatable harness output, not that a real model loops or that any proposed guidance change makes a model converge.

`todo_write` is withheld in headless mode unless enabled; use `--tools-enable todo_write`. It is also deferred: the fixture first obtains its full schema with `search_tools({query:"select:todo_write",max_results:1})`. The captured next request still lacks a top-level todo declaration, although the returned discovery schema supplies its parameters and the handler executes successfully. This is recorded as fixture context, not a new claim about provider strict-wire compatibility.

## Extracted-handler controls

`component-probe.mjs` hash-verifies the actual bundle and extracts its complete todo handler, validation, state helpers and result-text builder. Only the text/error result envelope wrappers are substituted; Map/Set state is supplied directly. The extraction wrapper terminates the surrounding minified variable declaration before name-registration calls. Product function bodies and the todo definition are unchanged. `source-excerpts.json` retains exact UTF-8 byte ranges and hashes.

Five primary sequences, ten additional controls and two diagnostic counterexamples pass their stated expectations. Controls include status-only completion, disappearance of already completed work, list reordering, genuine removal with unique explicit IDs, duplicate explicit IDs, invalid status, and manual deletion/completion state. Exact-label manual edits are honored; a recased submission bypasses those content-keyed sets even with the same explicit ID. The manual-edit state was injected directly, so this is not an interactive TUI reproduction.

The positional-ID and case-fold comparisons are deliberately naive test-only algorithms illustrating what a correction must avoid. They are not proposed source patches. This packet contains no production fix and makes no released/adopted claim.

## Suggested implementation acceptance

1. Give maintained todos stable identity independent of presentation text and array position. Distinguish caller-supplied and generated IDs; define uniqueness, missing-ID migration and duplicate-ID handling. Do not infer arbitrary semantic equivalence from fuzzy text.
2. A rename/reorder of a continuing item must not appear as dropped work. Preserve detection of genuinely removed unfinished items, including distinct items sharing a label. Completed/empty-list behavior should be an explicit product decision.
3. Keep manual user deletion/completion authoritative across supported renames. Match this against the same identity policy used by the warning, persistence and UI.
4. Make the saved-success result unambiguous: an intentional edit requires no resubmission; correction of an unintended removal should have one specific action. Consider bounded repeated-note guidance. If offering a previous list, avoid mandating restoration of work the user intentionally removed.
5. Run the supplied deterministic matrix before spending model calls. Then separately assess model convergence, TUI visibility, Linux, resume and concurrent sessions against a named implementation build. No recommendation here requires changing providers or testing real credentials.

## Setup failures retained

Before the final matrix, one component extraction attempt had a JavaScript wrapper syntax error; no handler tests executed. The wrapper was corrected without changing extracted product bodies.

Initial CLI attempt: enabled todo_write but skipped discovery. Four todo updates executed and reproduced the warning, then the fixture rejected its own incorrect assumption that every executable tool must be declared at top level; the process also had a post-success Windows abort. Five HTTP requests. This is excluded from the primary matrix.

Second attempt added discovery but accidentally removed `--tools-enable todo_write`. Discovery returned task_create, whose description merely mentions todo_write; four subsequent calls returned `No tool named "todo_write" exists`. The process exited 0 with the scripted marker, but the fixture correctly rejected the missing removal results. Six HTTP requests. The final harness restores the enabling flag and requires the actual `### todo_write` schema heading, not a loose substring.

Across setup and final runs: seven CLI processes, 37 HTTP requests; the five-run final matrix is reported separately. `setup-attempts.json` retains minimized results and raw-capture hashes. Full synthetic raw captures remain in private ignored scratch space; they are not required for portable saved-result verification.

## Limits

No live model convergence or indefinite loop was independently reproduced. The issue's Grok/Linux loop and turn consumption remain reporter evidence. Our script forces the documented state transitions, proving how the current tool responds. No interactive manual edit, resume, persistence across process restart, paid endpoint or team source implementation was tested. Windows shutdown outcomes are explicitly retained, not counted as clean exits. Estimated testing time saved is not measured.

## Publication review

REVIEW.md records the strengthened verifier, three failing mutation controls and a separate full portable rerun. Both primary cohorts are retained independently. The earlier artifact remains separately preserved.
