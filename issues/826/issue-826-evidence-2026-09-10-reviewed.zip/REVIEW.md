# Portable fixture verification, September 10, 2026

## Verification improvement

The original zero-warning controls only checked the absence of removal text. That could also occur if a tool call were rejected. The reviewed verifier now requires every todo reply to report successful execution, exact tool-call ID association, and exact submitted todo inputs captured from the final replay request. The actual CLI probe emits those inputs. Three mutation controls verify rejection of a failed zero-warning tool result, wrong submitted input, and mismatched call ID.

The original raw synthetic captures were hash-verified and re-minimized to include their actual sent todo arguments. All original findings pass the stronger verifier. No previously rejected call was mistaken for a successful primary control. The two earlier setup attempts remain excluded and documented.

## Fresh portable run

Extracted the original archive to a fresh scratch directory, verified every manifest entry, applied the two fixture validation improvements to this separate review copy, and used its unchanged lockfile with npm ci --ignore-scripts. No installed/global CLI or earlier runtime was reused. The exact 1.53.0 CLI and locked dependency hashes agree with provenance.json.

The copied component fixture passed all five sequences, ten controls and two identity counterexamples. The strengthened CLI fixture reran all five scenarios: 16 todo updates, five discovery calls, 26 localhost requests. Counts and input/result associations match the original matrix. Three processes exited 0; two emitted successful final results then hit the same Windows libuv assertion (3221226505). No watchdog timeout, blocked network attempt or model inference.

fresh-cli-results.json and fresh-component-results.json retain this separate cohort. Original primary CLI results remain in cli-results.json, augmented only with re-minimized sent arguments. The two primary cohorts together comprise ten processes, 32 todo updates and 52 requests, six clean exits and four qualified post-result aborts. Setup attempts remain separate: two processes/11 requests; they are not added to the primary matrix. No assertion that the scripted model loops or that a proposed guidance change improves real-model convergence.

## Revision contents

This revision contains the strengthened probe/verifier, both primary cohorts, documented setup failures, source anchors and unchanged lockfile. No application source correction was applied.
