import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import os from 'node:os';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {scenarios} from './scenarios.mjs';
const [packageArg,outputArg,only]=process.argv.slice(2);
if(!packageArg||!outputArg)throw Error('Usage: node cli-probe.mjs PACKAGE_DIR OUTPUT_DIR [SCENARIO]');
const root=path.dirname(fileURLToPath(import.meta.url)),packageRoot=fs.realpathSync(packageArg),runtimeRoot=path.dirname(packageRoot),outputRoot=path.resolve(outputArg);
const sha=x=>createHash('sha256').update(x).digest('hex'),bundleSha256=sha(fs.readFileSync(path.join(packageRoot,'dist/cli.mjs')));
assert.equal(bundleSha256,'b4f5398190f2912d90cecb3c558017f9e0c2c97d55ccf6b66848eed910642859');
if(only&&!scenarios.some(s=>s.name===only))throw Error('Unknown scenario');
const summary=[];
for(const scenario of scenarios.filter(s=>!only||only===s.name)){
 const runRoot=path.join(outputRoot,`${scenario.name}-${Date.now()}`),fixtureHome=path.join(runRoot,'home'),tmp=path.join(fixtureHome,'tmp');
 for(const p of [tmp,path.join(fixtureHome,'.commandcode'),path.join(fixtureHome,'AppData/Roaming'),path.join(fixtureHome,'AppData/Local')])fs.mkdirSync(p,{recursive:true});
 const provider='todo-fixture',model=`${provider}/model`,requests=[],sent=[],failures=[],startedAt=new Date().toISOString();
 const server=http.createServer((req,res)=>{
  let body='';req.on('data',b=>{body+=b;if(body.length>2_000_000)req.destroy();});
  req.on('end',()=>{
   if(req.method!=='POST'||req.url!=='/v1/chat/completions'){failures.push('Unexpected HTTP route');res.writeHead(404);res.end();return;}
   let payload;try{payload=JSON.parse(body);}catch{res.writeHead(400);res.end();return;}
   requests.push({bodySha256:sha(body),body:payload});
   if(requests.length>scenario.lists.length+2){failures.push('Request budget exceeded');res.writeHead(400);res.end('{}');return;}
   const replies=(payload.messages??[]).filter(m=>m.role==='tool'),step=replies.length-1;
   if(replies.length!==requests.length-1)failures.push(`Expected cumulative tool replies ${requests.length-1}; got ${replies.length}`);
   const declared=(payload.tools??[]).map(t=>t.function?.name);
   if(step<0&&!declared.includes('search_tools'))failures.push('search_tools was not declared');
   if(step>=0&&!String(replies[0]?.content).includes('### todo_write\n'))failures.push('Discovery did not return the todo_write schema');
   res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache'});
   const chunk=(delta,finish_reason=null)=>{const event={id:`fixture-${requests.length}`,object:'chat.completion.chunk',created:1,model:'model',choices:[{index:0,delta,finish_reason}]};sent.push(event);res.write(`data: ${JSON.stringify(event)}\n\n`);};
   if(step<0){chunk({role:'assistant',tool_calls:[{index:0,id:'call_discovery',type:'function',function:{name:'search_tools',arguments:JSON.stringify({query:'select:todo_write',max_results:1})}}]});chunk({},'tool_calls');}
   else if(step<scenario.lists.length){chunk({role:'assistant',tool_calls:[{index:0,id:`call_826_${step}`,type:'function',function:{name:'todo_write',arguments:JSON.stringify({todos:scenario.lists[step]})}}]});chunk({},'tool_calls');}
   else{chunk({role:'assistant',content:'ISSUE_826_SCRIPT_COMPLETE'});chunk({},'stop');}
   res.end('data: [DONE]\n\n');
  });
 });
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const port=server.address().port;
 fs.writeFileSync(path.join(fixtureHome,'.commandcode/providers.json'),JSON.stringify({provider:{[provider]:{api:'openai-completions',baseURL:`http://127.0.0.1:${port}/v1`,apiKey:'$FIXTURE_PROVIDER_KEY',models:{model:{contextWindow:200000,maxOutput:500,cost:{input:0,output:0}}}}}}));
 fs.writeFileSync(path.join(fixtureHome,'.commandcode/config.json'),JSON.stringify({model,provider,localOnly:true,telemetry:false,tasteLearning:false}));
 fs.writeFileSync(path.join(fixtureHome,'.commandcode/settings.json'),JSON.stringify({disableScratchpad:true,disableSkillShellExecution:true}));
 const env={};for(const k of ['SystemRoot','WINDIR','ComSpec','PATHEXT','PROCESSOR_ARCHITECTURE'])if(process.env[k])env[k]=process.env[k];
 env.PATH=[path.dirname(process.execPath),path.join(process.env.SystemRoot??'/','System32')].join(path.delimiter);
 Object.assign(env,{HOME:fixtureHome,USERPROFILE:fixtureHome,APPDATA:path.join(fixtureHome,'AppData/Roaming'),LOCALAPPDATA:path.join(fixtureHome,'AppData/Local'),TEMP:tmp,TMP:tmp,CMD_LOCAL_ONLY:'1',DO_NOT_TRACK:'1',OTEL_SDK_DISABLED:'true',COMMANDCODE_SKIP_UPDATES:'1',COMMANDCODE_DISABLE_CRON:'1',COMMANDCODE_DISABLE_DURABLE_CRON:'1',DOTENV_CONFIG_PATH:path.join(fixtureHome,'missing.env'),NO_COLOR:'1',FIXTURE_PORT:String(port),FIXTURE_PROVIDER_KEY:'synthetic-unused',COMMAND_CODE_API_KEY:'synthetic-unused'});
 const cliArgs=['--no-auto-update','--local-only','--skip-onboarding','--trust','--no-skills','--model',model,'--tools-enable','todo_write','--max-turns',String(scenario.lists.length+3),'--output-format','json','--print','Execute the synthetic todo_write fixture steps supplied by the local test endpoint.'];
 const nodeArgs=['--permission',`--allow-fs-read=${runtimeRoot}`,`--allow-fs-read=${root}`,`--allow-fs-read=${runRoot}`,`--allow-fs-write=${runRoot}`,'--require',path.join(root,'offline-guard.cjs'),path.join(packageRoot,'dist/index.mjs'),...cliArgs];
 let stdout='',stderr='',timedOut=false;
 const child=spawn(process.execPath,nodeArgs,{cwd:runRoot,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
 child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
 const timer=setTimeout(()=>{timedOut=true;child.kill();},45000);
 let exit;try{exit=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('close',(code,signal)=>resolve({code,signal}));});}finally{clearTimeout(timer);server.closeAllConnections();await new Promise(r=>server.close(r));}
 const finalPayload=requests.at(-1)?.body,allToolReplies=(finalPayload?.messages??[]).filter(m=>m.role==='tool'),toolReplies=allToolReplies.filter(m=>m.tool_call_id?.startsWith('call_826_'));
 const removed=toolReplies.map(m=>Number(JSON.stringify(m.content).match(/REMOVED (\d+)/)?.[1]??0));
 const events=stdout.split(/\r?\n/).flatMap(line=>{try{return[JSON.parse(line)]}catch{return[]}});
 const raw={scenario,startedAt,node:process.version,platform:process.platform,arch:process.arch,osRelease:os.release(),bundleSha256,cliArgs,exit,timedOut,stdout,stderr,requests,sent,failures};
 fs.writeFileSync(path.join(runRoot,'raw.json'),JSON.stringify(raw,null,2)+'\n');
 const result={name:scenario.name,startedAt,exit,timedOut,requests:requests.length,toolCalls:toolReplies.length,removed,expectedRemoved:scenario.removed,toolReplies,submittedTodos:(finalPayload?.messages??[]).flatMap(m=>m.tool_calls??[]).filter(c=>c.function?.name==='todo_write').map(c=>({id:c.id,input:JSON.parse(c.function.arguments)})),discoveryReply:allToolReplies[0],declaredAfterDiscovery:requests[1]?.body.tools?.some(t=>t.function?.name==='todo_write'),finalResult:events.filter(e=>e.type==='result'),guardReady:stderr.includes('offline-guard-ready'),blockedNetwork:stderr.includes('blocked-network'),stderr,rawSha256:sha(fs.readFileSync(path.join(runRoot,'raw.json'))),rawPath:path.relative(outputRoot,path.join(runRoot,'raw.json')),failures};
 summary.push(result);fs.writeFileSync(path.join(outputRoot,only?`cli-results-${only}.json`:'cli-results.json'),JSON.stringify({at:new Date().toISOString(),node:process.version,platform:process.platform,arch:process.arch,bundleSha256,method:'Actual unmodified CLI against a scripted owned localhost SSE endpoint; no model inference. Each scenario is one fresh process with multiple tool calls in the same session.',results:summary},null,2)+'\n');
 console.log(JSON.stringify({name:scenario.name,requests:result.requests,toolCalls:result.toolCalls,removed,exit,timedOut,failures}));
 assert.equal(result.blockedNetwork,false);assert.equal(result.guardReady,true);assert.equal(timedOut,false);assert.deepEqual(failures,[]);assert.deepEqual(removed,scenario.removed);assert.equal(toolReplies.length,scenario.lists.length);assert.ok(stdout.includes('ISSUE_826_SCRIPT_COMPLETE'));
 for(const [i,reply] of toolReplies.entries()){assert.equal(reply.tool_call_id,`call_826_${i}`);assert.ok(String(reply.content).startsWith('Todos have been modified successfully.'));}
 assert.deepEqual(result.submittedTodos.map(x=>x.input.todos),scenario.lists);
}
