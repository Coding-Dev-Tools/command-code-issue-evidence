export const todo=(content,status='pending',id)=>({content,status,...(id===undefined?{}:{id})});
const phase=(upper,id)=>[todo(upper?'Phase -1: Auto-Update Check':'Phase -1: Auto-update check','in_progress',id),todo('Run verification','pending',id===undefined?undefined:'verify')];
export const scenarios=[
 {name:'case-oscillation',lists:[phase(false),phase(true),phase(false),phase(true)],removed:[0,1,1,1]},
 {name:'stable-id-oscillation',lists:[phase(false,'phase'),phase(true,'phase'),phase(false,'phase'),phase(true,'phase')],removed:[0,1,1,1]},
 {name:'real-removal-noop-empty',lists:[[todo('A','in_progress'),todo('B')],[todo('B')],[todo('B')],[]],removed:[0,1,0,0]},
 {name:'distinct-ids-same-label',lists:[[todo('Run tests','in_progress','api'),todo('Run tests','pending','ui')],[todo('Run tests','in_progress','api')]],removed:[0,0]},
 {name:'renamed-completion',lists:[[todo('Run tests','in_progress','verify')],[todo('Run Tests','completed','verify')]],removed:[0,1]}
];
