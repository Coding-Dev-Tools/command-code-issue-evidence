# Reproduce issue 826 without model inference

Read REPORT.md, REVIEW.md and provenance.json first. Scripts require Node 24.15.0 for the recorded environment. The retained CLI run is Windows x64. The component fixture uses only Node built-ins; the CLI fixture needs the locked npm tree.

1. In a fresh scratch directory, copy `runtime-package.json` to `runtime/package.json` and `runtime-package-lock.json` to `runtime/package-lock.json`.
2. Acquire the exact dependencies with `npm ci --prefix runtime --ignore-scripts --no-audit --no-fund`. This accesses the npm registry; it makes no model calls. Do not use real provider credentials.
3. Run the component fixture:
   `node component-probe.mjs runtime/node_modules/command-code/dist/cli.mjs component-output`
4. Run the actual CLI matrix:
   `node cli-probe.mjs runtime/node_modules/command-code cli-output`
5. Check fresh outputs with:
   `node verify-results.mjs cli-output/cli-results.json component-output/component-results.json`

To check only the original preserved results, run `node verify-results.mjs` beside the evidence files. To verify the separate pre-publication rerun, use `node verify-results.mjs fresh-cli-results.json fresh-component-results.json`. That performs no fresh product execution or network calls.

All fixture filenames should stay together. Each runtime is hash-checked; the only supported CLI hash is the recorded 1.53.0 bundle. Output directories should be new scratch paths to preserve prior results. An optional third argument to cli-probe selects one scenario by name and writes a correspondingly named result file. Default execution runs all five sequences sequentially.

The CLI fixture uses an isolated synthetic HOME, environment allowlist, disabled updates/telemetry/cron/skills, a subprocess network guard restricted to its owned ephemeral localhost port, and Node filesystem permissions. It requests no child-process execution permission. The mock emits only search_tools and todo_write calls. Three final processes exited 0; two emitted success then hit the recorded Windows libuv shutdown assertion. The verifier requires successful final results and permits only these explicitly reported exit outcomes.

Files: scenarios.mjs contains stimuli and expected current removal counts; component-probe.mjs extracts the exact product handler; cli-probe.mjs runs the real CLI; cli-results.json and component-results.json retain observations; source-excerpts.json pins extraction; setup-attempts.json keeps the discarded setup attempts; provenance.json and package lock pin acquisition and dependencies.

The reviewed verifier requires successful tool output and exact captured input/call-ID association; zero removal notes alone cannot pass a control. verifier-negative-controls.json records three intentionally corrupted copies correctly rejected. Both preserved cohorts have three clean exits and two qualified post-result Windows aborts each.
