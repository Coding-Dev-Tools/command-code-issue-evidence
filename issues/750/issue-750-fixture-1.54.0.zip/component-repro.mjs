import {fs,fsp,path,assert,packageRuntime,save,expectedHash} from './common.mjs';
import {fileURLToPath} from 'node:url';import vm from 'node:vm';import {generate} from './generate.mjs';
const here=path.dirname(fileURLToPath(import.meta.url)),pkg=packageRuntime(process.argv[2]??path.join(here,'node_modules')),base=path.resolve(process.argv[3]??path.join(here,'runs'));
fs.mkdirSync(base,{recursive:true});const out=fs.mkdtempSync(path.join(base,'component750-')),project=process.argv[4]?path.resolve(process.argv[4]):path.join(out,'repo'),files=process.argv[4]?{shallow:'healthy750.txt',depth9:'a/b/c/d/e/f/g/h/boundary750.txt',depth10:'a/b/c/d/e/f/g/h/i/deepneedle750.txt',ignored:'ignored/ignore750.txt',dependency:'node_modules/pkg/dependency750.txt'}:generate(project,{bulk:100010}),source=pkg.source;
const start=source.indexOf('function loadGitignore('),end=source.indexOf('async function browseDirectory(',start),code=source.slice(start,end);
assert.ok(start>=0&&end>start);let now=Date.now(),reads=0;
const ctx=vm.createContext({n:path.join,i:path.relative,A:fs.existsSync,R:fs.readFileSync,we:pkg.req('ignore'),Date:{now:()=>now},$C:8,_C:1e5,FC:3e4,UC:50,jC:null,BC:128,WC:new Map(),HC:16,KC:7,qC:4,GC:3,VC:1,YC:2,JC:16,zC:8,QC:65,ZC:90,XC:97,eb:122,tb:48,nb:57,rb:new Set('/\\_-. :'.split('').map(x=>x.charCodeAt(0)))});
vm.runInContext(code+';var NC=({basePath})=>{const loader=loadGitignore(basePath);return {isIgnored:({path})=>loader.ignores(path)}};',ctx);
const runtime={fs:{readdirTypes:async({path:p})=>{reads++;return(await fsp.readdir(p,{withFileTypes:true})).map(x=>({name:x.name,isDirectory:x.isDirectory()}));}}};
const rows=[];async function search(name,query,target,expected){const before=reads,t=performance.now(),res=await ctx.searchFiles({runtime,basePath:project,searchTerm:query}),found=res.some(x=>x.path===path.join(project,target));const r={name,query,target,found,expected,enumerations:reads-before,elapsedMs:Number((performance.now()-t).toFixed(3)),resultNames:res.map(x=>x.name)};rows.push(r);assert.equal(found,expected,name);return r;}
let failure=null;
try{
 const first=await search('cold-shallow','healthy750.txt',files.shallow,true);
 const index=ctx.jC.entries;save(path.join(out,'index-summary.json'),{indexed:index.length,enumerations:reads,entryCap:100000,tail:index.slice(-3).map(x=>x.name)});assert.equal(index.length,100000);
 await search('cap-omission','entry100009.txt','bulk/entry100009.txt',false);
 await search('cap-direct-path','bulk/entry100009.txt','bulk/entry100009.txt',true);
 const warm=await search('warm-identical','healthy750.txt',files.shallow,true);assert.equal(warm.enumerations,0);
 const other=await search('warm-different','healthy750',files.shallow,true);assert.equal(other.enumerations,0);
 now+=31000;const expired=await search('expired-identical','healthy750.txt',files.shallow,true);assert.equal(expired.enumerations,0);
 const fresh=await search('expired-new-query','healthy750.tx',files.shallow,true);assert.ok(fresh.enumerations>0);
 ctx.invalidateFileIndex();const reopened=await search('invalidate-then-repeat','healthy750.txt',files.shallow,true);assert.ok(reopened.enumerations>0);
 // Use a small independent tree so the depth checks cannot be confounded by the entry cap.
 const small=path.join(out,'small');generate(small);ctx.invalidateFileIndex();
 for(const [name,query,target,expected]of [['depth9','boundary750.txt',files.depth9,true],['depth10','deepneedle750.txt',files.depth10,false],['depth10-path',files.depth10,files.depth10,true],['root-ignore','ignore750.txt',files.ignored,false],['node-modules','dependency750.txt',files.dependency,false],['absent','nonexistent750.txt','nonexistent750.txt',false]]){
  const before=reads,t=performance.now(),res=await ctx.searchFiles({runtime,basePath:small,searchTerm:query}),found=res.some(x=>x.path===path.join(small,target));rows.push({name,query,target,found,expected,enumerations:reads-before,elapsedMs:Number((performance.now()-t).toFixed(3)),resultNames:res.map(x=>x.name)});assert.equal(found,expected,name);
 }
}catch(e){failure={message:e.message,stack:e.stack};}
save(path.join(out,'results.json'),{version:'1.54.0',bundleSha256:expectedHash,node:process.version,platform:process.platform,scope:'Unmodified extracted search functions with actual filesystem enumeration and installed ignore dependency; simulated clock advancement for cache expiry. Component timings only. No terminal or reporter Linux latency inference.',extraction:{start,end,sha256:(await import('node:crypto')).createHash('sha256').update(code).digest('hex')},rows,failure});console.log(JSON.stringify({out,rows:rows.map(({resultNames,...x})=>x),failure}));if(failure)process.exitCode=1;
