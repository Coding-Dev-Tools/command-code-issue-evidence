import {fs,path,assert,packageRuntime,save,isolatedEnv,configure,sleep,expectedHash} from './common.mjs';
import {fileURLToPath} from 'node:url';import {generate} from './generate.mjs';import {execFileSync} from 'node:child_process';
const here=path.dirname(fileURLToPath(import.meta.url)),pkg=packageRuntime(process.argv[2]??path.join(here,'node_modules'));
const base=path.resolve(process.argv[3]??path.join(here,'runs'));fs.mkdirSync(base,{recursive:true});
const out=fs.mkdtempSync(path.join(base,'search750-')),project=process.argv[5]?path.resolve(process.argv[5]):path.join(out,'repo'),home=path.join(out,'home');
const large=!!process.argv[5]||Number(process.argv[4]??0)>0;
const files=process.argv[5]?{shallow:'healthy750.txt'}:generate(project,{bulk:Number(process.argv[4]??0)}),env=isolatedEnv(home,1);
await configure(home,project,pkg,1);
const {Terminal}=pkg.req('@xterm/headless'),pty=pkg.req('@lydell/node-pty');
const rows=[],sessions=[];let failure=null;
async function run(cwd,label){
 await configure(home,cwd,pkg,1);
 const term=new Terminal({cols:130,rows:42,allowProposedApi:true,scrollback:1000});let raw='',exit=null,child;
 function screen(){const b=term.buffer.active;return Array.from({length:b.length},(_,i)=>b.getLine(i)?.translateToString(true)??'').join('\n');}
 async function until(fn,ms=20000){const end=Date.now()+ms;while(Date.now()<end&&!fn()&&!exit)await sleep(30);return fn();}
 const nodeArgs=['--permission',`--allow-fs-read=${pkg.runtime}`,`--allow-fs-read=${here}`,`--allow-fs-read=${out}`,`--allow-fs-read=${project}`,`--allow-fs-write=${out}`,`--allow-fs-write=${project}`,'--require',path.join(here,'offline-guard.cjs'),pkg.cli,'--no-auto-update','--local-only','--skip-onboarding','--trust','--no-skills','--model','fixture/model'];
 try{
  child=pty.spawn(process.execPath,nodeArgs,{cols:130,rows:42,cwd,env,useConpty:true,windowsHide:true});
  term.onData(d=>child.write(d));child.onData(d=>{raw+=d;term.write(d)});child.onExit(e=>exit=e);
  assert.ok(await until(()=>screen().includes('Ask your question')),'CLI prompt must render');await sleep(250);
  for(const [name,query,target,present]of large?[
   ['shallow','healthy750.txt',files.shallow,true],['cap','entry100009.txt','bulk/entry100009.txt',false],['cap-path','bulk/entry100009.txt','bulk/entry100009.txt',true],['shallow-repeat','healthy750.txt',files.shallow,true]
  ]:[
   ['shallow','healthy750.txt',files.shallow,true],['depth9','boundary750.txt',files.depth9,true],
   ['depth10','deepneedle750.txt',files.depth10,false],['depth10-path',files.depth10,files.depth10,true],
   ['absent','nonexistent750.txt','nonexistent750.txt',false],['ignored','ignore750.txt',files.ignored,false],
   ['dependency','dependency750.txt',files.dependency,false],['shallow-repeat','healthy750.txt',files.shallow,true]
  ]){
   child.write('\x1b');await sleep(100);child.write('\x15');await sleep(100);
   // Type at a human-readable rate so the real input handler, not a paste mode, processes the query.
   const started=performance.now();for(const c of '@'+query){child.write(c);await sleep(12);}const typed=performance.now();
   await until(()=>screen().includes(`Searching for: "${query}"`));await sleep(large?5000:350);
   const view=screen(),lines=view.split('\n'),header=lines.findIndex(x=>x.includes(`Searching for: "${query}"`)),tail=lines.slice(header+1),end=tail.findIndex(x=>x.includes('navigate'));
   const resultLines=tail.slice(0,end<0?15:end),results=resultLines.join('\n'),found=resultLines.some(x=>[target.replaceAll('/',path.sep),target].includes(x.trim()));
   const r={label,name,query,target,expectedPresent:present,found,headerRendered:header>=0,observedAfterTypingMs:Math.round(performance.now()-typed),inputDurationMs:Math.round(typed-started),screen:view,resultRows:results};rows.push(r);save(path.join(out,`${label}-${name}.json`),r);
   assert.ok(r.headerRendered,`query header ${name}`);assert.equal(found,present,`${label}/${name}`);
  }
  child.write('\x1b');await sleep(100);child.write('\x15');await sleep(100);for(const c of '/exit'){child.write(c);await sleep(15);}child.write('\r');
  assert.ok(await until(()=>exit,8000),'CLI must exit');assert.equal(exit.exitCode,0);
 }finally{if(child&&!exit){child.kill();await until(()=>exit,2000);}sessions.push({label,exit,cwd:path.relative(out,cwd)});fs.writeFileSync(path.join(out,`${label}-terminal.raw`),raw);term.dispose();}
}
try{
 await run(project,'checkout');
 // Only this synthetic fixture is committed. No user repository or identity is used.
 if(!large){execFileSync('git',['init','-q'],{cwd:project});execFileSync('git',['add','.'],{cwd:project});
 execFileSync('git',['-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','-qm','Synthetic fixture'],{cwd:project});
 const worktree=path.join(out,'worktree');execFileSync('git',['worktree','add','--detach',worktree,'HEAD'],{cwd:project,stdio:'pipe'});
 await run(worktree,'worktree');}
}catch(e){failure={message:e.message,stack:e.stack};}
save(path.join(out,'results.json'),{version:'1.54.0',bundleSha256:expectedHash,node:process.version,platform:process.platform,scope:'Actual unchanged CLI in Windows ConPTY; generated on-disk files; parsed xterm terminal output. Observation time includes a settling wait, not a latency benchmark. No model requests are allowed.',rows,sessions,failure});
console.log(JSON.stringify({out,rows:rows.map(({name,label,found,expectedPresent})=>({name,label,found,expectedPresent})),sessions,failure}));setTimeout(()=>process.exit(failure?1:0),50);
