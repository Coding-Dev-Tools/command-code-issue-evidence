import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
export function generate(base,{bulk=0}={}){
 fs.mkdirSync(base,{recursive:true});
 const files={shallow:'healthy750.txt',depth9:'a/b/c/d/e/f/g/h/boundary750.txt',depth10:'a/b/c/d/e/f/g/h/i/deepneedle750.txt',ignored:'ignored/ignore750.txt',dependency:'node_modules/pkg/dependency750.txt'};
 for(const p of Object.values(files)){fs.mkdirSync(path.dirname(path.join(base,p)),{recursive:true});fs.writeFileSync(path.join(base,p),'Synthetic file-search fixture.\n');}
 fs.writeFileSync(path.join(base,'.gitignore'),'ignored/\n');
 if(bulk){const dir=path.join(base,'bulk');fs.mkdirSync(dir,{recursive:true});for(let i=0;i<bulk;i++)fs.writeFileSync(path.join(dir,`entry${String(i).padStart(6,'0')}.txt`),'');}
 return files;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){if(!process.argv[2])throw Error('Usage: node generate.mjs EMPTY_DIRECTORY [BULK_FILE_COUNT]');const base=path.resolve(process.argv[2]);if(fs.existsSync(base)&&fs.readdirSync(base).length)throw Error('Use an empty/new directory');console.log(JSON.stringify({base,files:generate(base,{bulk:Number(process.argv[3]??0)})}));}
