import fs from 'node:fs';import assert from 'node:assert/strict';import path from 'node:path';import {fileURLToPath} from 'node:url';
const dir=process.argv[2]?path.resolve(process.argv[2]):path.dirname(fileURLToPath(import.meta.url));
const read=n=>JSON.parse(fs.readFileSync(path.join(dir,n),'utf8'));
function verify({small,large,component,timing,index}){
 for(const x of [small,large,component,timing]){assert.equal(x.failure,null);assert.equal(x.bundleSha256,'0de512d28b0a66708fbb0e367443ad7f9f9d4e8eda62a76563f1493b997dd61d');}
 assert.equal(small.rows.length,16);assert.equal(large.rows.length,4);assert.equal(index.indexed,100000);
 for(const x of [small,large])for(const session of x.sessions)assert.equal(session.exit.exitCode,0);
 for(const r of [...small.rows,...large.rows]){
  assert.equal(r.headerRendered,true);
  const found=r.resultRows.split('\n').some(x=>x.trim().replaceAll('\\','/')===r.target);
  const expected=['shallow','depth9','depth10-path','shallow-repeat','cap-path'].includes(r.name);
  assert.equal(found,expected,r.label+'/'+r.name);assert.equal(r.found,found);
 }
 assert.equal(component.rows.length,14);
 const c=n=>component.rows.find(x=>x.name===n);for(const n of ['cold-shallow','cap-direct-path','depth9','depth10-path'])assert.equal(c(n).found,true);
 for(const n of ['cap-omission','depth10','root-ignore','node-modules','absent'])assert.equal(c(n).found,false);
 assert.equal(c('warm-identical').enumerations,0);assert.ok(c('invalidate-then-repeat').enumerations>0);
 assert.equal(timing.exit.exitCode,0);assert.ok(timing.rows.every(x=>x.rendered));assert.equal(timing.rows.find(x=>x.kind==='warm-edit').bulkEnumerationsStarted,0);assert.ok(timing.rows.find(x=>x.kind==='reopen').bulkEnumerationsStarted>0);
}
const data={small:read('terminal-small-results.json'),large:read('terminal-large-results.json'),component:read('component-results.json'),timing:read('terminal-timing-results.json'),index:read('index-summary.json')};verify(data);
const mutations=[x=>x.small.rows[0].resultRows='',x=>x.small.rows.find(r=>r.name==='depth10').resultRows='a/b/c/d/e/f/g/h/i/deepneedle750.txt',x=>x.large.rows.find(r=>r.name==='cap-path').resultRows='',x=>x.small.sessions[0].exit.exitCode=1,x=>x.index.indexed=99999,x=>x.timing.rows.find(r=>r.kind==='reopen').bulkEnumerationsStarted=0];
for(const mutate of mutations){const bad=structuredClone(data);mutate(bad);assert.throws(()=>verify(bad));}
const result={ok:true,negativeMutationsRejected:mutations.length,scope:'Retained evidence consistency and false-result rejection; no new product execution.'};fs.writeFileSync(path.join(dir,'verification.json'),JSON.stringify(result,null,2)+'\n');console.log(result);
