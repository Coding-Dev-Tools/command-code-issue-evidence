# Issue 750 fixture

Command Code 1.54.0, Node 24.15.0, Windows ConPTY. This packet separates actual terminal lookup, extracted search components and diagnostic terminal timing. The bundle hash is checked before every product run. No model request is allowed.

From this extracted directory:

```sh
npm ci --ignore-scripts --no-audit --no-fund
node terminal-repro.mjs
node component-repro.mjs
node latency-repro.mjs
node verify.mjs
```

The first command acquires the pinned runtime and terminal dependencies. The actual tests permit no external network. Terminal tests require Windows. The component and latency scripts each generate a directory with 100,010 empty bulk files plus small controls. Keep their fresh run directories until finished reviewing; creation and scanning can take time. To reuse a generated directory, pass runtime node_modules, an output directory, and the existing project as the fourth argument to component/latency scripts. `terminal-repro.mjs` supports `NODE_MODULES OUTPUT 0 EXISTING_LARGE_PROJECT` for the separate cap check.

For a quick manual reproduction, run `node generate.mjs NEW_DIRECTORY`, open Command Code 1.54.0 from that directory, and inspect the queries in the comment. No prompt submission is needed. The small automated terminal test checks ordinary-directory and generated-worktree behavior. The historical row label `checkout` means the initial directory before this harness initializes a standalone Git repository. No worktree-specific cause is established.

Selected results: 16 small-tree terminal queries across two clean CLI exits; four large-tree queries in one clean CLI exit; 14 component queries; one diagnostic terminal timing run with three observations and a clean exit. All target omissions are expected current product failures. Passing a verifier does not mean the bugs are fixed. `verify.mjs` checks the retained selected results and six deliberate corruptions, not a newly generated run. New runs assert their own expected outcomes and retain independent results under `runs/`.

The timing observer wraps fs.promises.readdir to log start/end and calls the original function. Its overhead, input pacing, OS caches and host load affect measurements. The warm-edit observation can reuse an already-visible result; do not use its display time as proof of completed search latency. The cold/reopened observations start a new picker but remain display observations, not proof of completed search latency. No sample reproduces the reporter's Linux 5-10 second delay. Source checks locate the mount invalidation and depth/entry limits, without claiming that they cause the reported slowness.

Privacy: only synthetic files, minimized results, test code and pinned dependency/provenance metadata are included. Original captures remain in the private lab. Read failure-accounting.json for excluded attempts. No application bundle, personal project, credential or public submission is included.
