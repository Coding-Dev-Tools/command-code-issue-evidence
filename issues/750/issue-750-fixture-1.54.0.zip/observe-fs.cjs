'use strict';
require('./offline-guard.cjs');
const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path');
const native=fsp.readdir;let seq=0;
fsp.readdir=async function(...args){
 const target=String(args[0]),traced=target===process.env.TRACE_PROJECT||target===path.join(process.env.TRACE_PROJECT,'bulk'),id=++seq;
 if(traced)fs.appendFileSync(process.env.TRACE_LOG,JSON.stringify({id,phase:'start',at:Date.now(),directory:path.relative(process.env.TRACE_PROJECT,target)||'.'})+'\n');
 try{return await native.apply(this,args);}finally{if(traced)fs.appendFileSync(process.env.TRACE_LOG,JSON.stringify({id,phase:'end',at:Date.now(),directory:path.relative(process.env.TRACE_PROJECT,target)||'.'})+'\n');}
};
require('node:module').syncBuiltinESMExports();
