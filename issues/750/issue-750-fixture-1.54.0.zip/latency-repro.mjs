import {fs,path,assert,packageRuntime,save,isolatedEnv,configure,sleep,expectedHash} from './common.mjs';import {fileURLToPath} from 'node:url';import {generate} from './generate.mjs';
const here=path.dirname(fileURLToPath(import.meta.url)),pkg=packageRuntime(process.argv[2]??path.join(here,'node_modules')),base=path.resolve(process.argv[3]??path.join(here,'runs'));fs.mkdirSync(base,{recursive:true});
const out=fs.mkdtempSync(path.join(base,'latency750-')),project=process.argv[4]?path.resolve(process.argv[4]):path.join(out,'repo');if(!process.argv[4])generate(project,{bulk:100010});const home=path.join(out,'home'),env=isolatedEnv(home,1);await configure(home,project,pkg,1);
Object.assign(env,{TRACE_PROJECT:project,TRACE_LOG:path.join(out,'fs.jsonl')});fs.writeFileSync(env.TRACE_LOG,'');
const pty=pkg.req('@lydell/node-pty'),{Terminal}=pkg.req('@xterm/headless'),term=new Terminal({cols:130,rows:42,allowProposedApi:true,scrollback:1000});let raw='',exit=null,failure=null,child;const rows=[];
const screen=()=>{const b=term.buffer.active;return Array.from({length:b.length},(_,i)=>b.getLine(i)?.translateToString(true)??'').join('\n');};
async function until(fn,ms=30000){const end=Date.now()+ms;while(Date.now()<end&&!fn()&&!exit)await sleep(20);return fn();}
function matched(query){const lines=screen().split('\n'),i=lines.findIndex(x=>x.includes(`Searching for: "${query}"`));return i>=0&&lines.slice(i+1).some(x=>x.trim()==='healthy750.txt');}
try{
 const args=['--permission',`--allow-fs-read=${pkg.runtime}`,`--allow-fs-read=${here}`,`--allow-fs-read=${out}`,`--allow-fs-read=${project}`,`--allow-fs-write=${out}`,`--allow-fs-write=${project}`,'--require',path.join(here,'observe-fs.cjs'),pkg.cli,'--no-auto-update','--local-only','--skip-onboarding','--trust','--no-skills','--model','fixture/model'];
 child=pty.spawn(process.execPath,args,{cwd:project,env,cols:130,rows:42,useConpty:true,windowsHide:true});term.onData(d=>child.write(d));child.onData(d=>{raw+=d;term.write(d)});child.onExit(e=>exit=e);assert.ok(await until(()=>screen().includes('Ask your question')));await sleep(300);
 for(const kind of ['cold','warm-edit','reopen']){
  if(kind==='reopen'){child.write('\x1b');await sleep(150);child.write('\x15');await sleep(150);}
  const query=kind==='warm-edit'?'healthy750.tx':'healthy750.txt',started=Date.now();
  if(kind==='warm-edit')child.write('\x7f');else for(const c of '@'+query){child.write(c);await sleep(20);}const lastKey=Date.now();
  const rendered=await until(()=>matched(query)),at=Date.now();await sleep(300);
  const trace=fs.readFileSync(env.TRACE_LOG,'utf8').trim().split('\n').filter(Boolean).map(x=>JSON.parse(x)).filter(x=>x.at>=started&&x.at<=at);
  const row={kind,query,rendered,inputStartToVisibleMs:at-started,lastKeyToVisibleMs:at-lastKey,rootEnumerationsStarted:trace.filter(x=>x.phase==='start'&&x.directory==='.').length,bulkEnumerationsStarted:trace.filter(x=>x.phase==='start'&&x.directory==='bulk').length,trace,screen:screen()};rows.push(row);assert.ok(rendered,kind);
 }
 child.write('\x1b');await sleep(150);child.write('\x15');await sleep(150);for(const c of '/exit'){child.write(c);await sleep(20);}await sleep(300);child.write('\r');assert.ok(await until(()=>exit,8000));assert.equal(exit.exitCode,0);
}catch(e){failure={message:e.message,stack:e.stack};}finally{if(child&&!exit){child.kill();await sleep(500);}term.dispose();}
fs.writeFileSync(path.join(out,'terminal.raw'),raw);save(path.join(out,'results.json'),{version:'1.54.0',bundleSha256:expectedHash,node:process.version,platform:process.platform,scope:'Unmodified CLI bundle in Windows ConPTY; fs.promises.readdir observer adds synchronous diagnostic logging. Parsed terminal observation uses 20ms polling; timings include fixture input pacing and are local samples, not reporter Linux benchmarks.',rows,exit,failure});console.log(JSON.stringify({out,rows:rows.map(({trace,screen,...x})=>x),exit,failure}));setTimeout(()=>process.exit(failure?1:0),50);
