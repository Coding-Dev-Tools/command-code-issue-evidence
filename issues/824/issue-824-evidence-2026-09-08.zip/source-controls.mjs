import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL, fileURLToPath } from 'node:url';
const [bundleArg,adapterArg,outputArg]=process.argv.slice(2);
if (!bundleArg || !adapterArg) throw Error('Usage: node source-controls.mjs CLI_BUNDLE ADAPTER_ENTRY [OUTPUT_JSON]');
const bundle=fs.realpathSync(bundleArg);
const adapterPath=fs.realpathSync(adapterArg);
const outputPath=outputArg ? path.resolve(outputArg) : path.join(path.dirname(fileURLToPath(import.meta.url)),'source-controls-results-new.json');
const sha256=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
if (sha256(bundle)!=='d408a372d5d6c8a8851610e2a9840f806929595584d1cd8d909d501928c0037c') throw Error('Expected pinned original Command Code 1.51.3 CLI bundle');
if (sha256(adapterPath)!=='d99610a3574365abb89c69d951e00ff6055b17dd3af6683f0c4f74fd43c6d5df') throw Error('Expected pinned @ai-sdk/openai-compatible 2.0.74 dist/index.mjs');
const source=fs.readFileSync(bundle,'utf8');
const extract=(start,end)=>source.slice(source.indexOf(`function ${start}(`),source.indexOf(`function ${end}(`));
const selected={toModelSpec:extract('toModelSpec','thinkingHook'),thinkingHook:extract('thinkingHook','isOpenAiHost'),moduleFor:extract('moduleFor','createDeclarativeProviderModules'),withBodyOptions:extract('withBodyOptions','keyFromAuth')};
const context=vm.createContext({__name:f=>f,resolveKnownModelId:({model})=>model==='gpt-6-astra'?'built-in-catalog-control':undefined,buildAiSdkTransport:()=>({stubbed:true}),declarativeWire:()=> 'openai-compatible'});
vm.runInContext(Object.values(selected).join('\n'),context);
const provider={id:'effcap',models:[{id:'gpt-6-astra',reasoningEfforts:['low','high']},{id:'org/model',reasoningEfforts:['low','high']}],baseURL:'http://127.0.0.1:1/v1',api:'openai-compatible'};
const module=context.moduleFor({provider,runtime:{}});
const hookCases=[['effcap/gpt-6-astra','high'],['effcap/gpt-6-astra','low'],['effcap/gpt-6-astra','off'],['effcap/gpt-6-astra','unsupported'],['effcap/org/model','high'],['org/model','low']].map(([model,effort])=>({model,effort,hookOutput:module.hooks.thinking({model,effort})??null}));
const {createOpenAICompatible}=await import(pathToFileURL(adapterPath).href);
const adapter=createOpenAICompatible({name:'effcap',baseURL:'http://127.0.0.1:1/v1'})('gpt-6-astra');
const adapterCases=[];
for (const [name,options] of [['snake-high',{effcap:{reasoning_effort:'high'}}],['camel-high',{effcap:{reasoningEffort:'high'}}],['camel-low',{effcap:{reasoningEffort:'low'}}],['absent',undefined],['conflict-camel-wins',{effcap:{reasoning_effort:'low',reasoningEffort:'high'}}]]) {
 const {args,warnings}=await adapter.getArgs({prompt:[{role:'user',content:[{type:'text',text:'synthetic fixture'}]}],providerOptions:options});
 const wire=JSON.parse(JSON.stringify(args));
 adapterCases.push({name,providerOptions:options??null,wireReasoningEffort:wire.reasoning_effort??null,hasOwnReasoningEffort:Object.hasOwn(wire,'reasoning_effort'),warnings});
}
const mergeCases=[];
for (const wire of [{model:'gpt-6-astra'},{model:'gpt-6-astra',reasoning_effort:'high'}]) {
 const wrapped=context.withBodyOptions({optionsFor:()=>({reasoning_effort:'low'}),base:async(_url,init)=>JSON.parse(init.body)});
 mergeCases.push({wireBefore:wire,wireAfter:await wrapped('http://127.0.0.1:1/v1',{body:JSON.stringify(wire)})});
}
const result={method:'Exact extracted moduleFor/thinkingHook/withBodyOptions plus actual pinned adapter getArgs; moduleFor catalog and transport dependencies stubbed, no CLI/network/provider inference',bundleSha256:createHash('sha256').update(fs.readFileSync(bundle)).digest('hex'),adapterVersion:'2.0.74',adapterSha256:createHash('sha256').update(fs.readFileSync(adapterPath)).digest('hex'),anchors:Object.fromEntries(Object.entries(selected).map(([name,body])=>[name,{utf8ByteOffset:Buffer.byteLength(source.slice(0,source.indexOf(body)),'utf8'),source:body}])),returnedSpecs:module.models,hookCases,adapterCases,mergeCases};
fs.writeFileSync(outputPath,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({returnedSpecs:module.models,hookCases,adapterCases,mergeCases},null,2));
