# #824: effort lost at the adapter option boundary

Recorded September 8, 2026 EDT (September 9 UTC). Original command-code **1.51.3**, Windows x64, Node **24.15.0**; actual localhost CLI calls plus separately labeled component controls. This packet is private and unpublished.

## Finding and correction

The reported missing `reasoning_effort` field is reproduced. The claimed universal model-ID mismatch is not supported for the tested current path. `moduleFor()` expands the model specs with qualified aliases and passes that expanded list to `thinkingHook()`. A current extracted caller control returns the snake-case option for `effcap/gpt-6-astra`.

The hook's OpenAI-compatible branch returns `providerOptions[providerId].reasoning_effort`. The pinned adapter 2.0.74 expects the option key `reasoningEffort`. It first spreads arbitrary extra options, then assigns `reasoning_effort: compatibleOptions.reasoningEffort`. The second assignment overwrites the supplied snake-case value with undefined; JSON serialization omits it.

A separate diagnostic bundle changes only that hook key to `reasoningEffort`. It restores high/low selections on the actual CLI without changing model-ID lookup, SDK code or dependencies. This isolates a sufficient correction for the tested path. The production source change and broader compatibility decision belong to the team.

## Actual CLI observations

| Mode | Released 1.51.3 | One-key diagnostic | Exit / HTTP |
| --- | --- | --- | --- |
| high | Field absent | `high` | Both 0; one request each |
| low | Field absent | `low` | Both 0; one request each |
| fixed `xhigh`, selected high | `xhigh` | `high` | Both 0; one request each |
| off | Unknown-effort rejection | Same rejection | Both 1; zero requests |

Eight independent CLI processes, six HTTP requests, six successful final results, two expected validation rejections. No timeouts, post-result shutdown assertions or blocked network attempts occurred in this #824 matrix. The `off` result is an input-validation control, not successful in-band suppression. All supported request cases sent the expected model ID.

The fixed-option control explains the workaround: `withBodyOptions()` applies model options after SDK serialization, merging static values first and serialized values last. The diagnostic selected value therefore wins over the static default. Intended precedence should be confirmed by the team and kept under regression coverage.

## Source and component evidence

See `source-controls-results.json` for exact extracted source and byte offsets in the pinned CLI: `moduleFor` 803136, `thinkingHook` 800906, `withBodyOptions` 801489. These are zero-based UTF-8 offsets, not line numbers. The pinned adapter's `dist/index.mjs` lines 533–541 show the option spread followed by `reasoning_effort: compatibleOptions.reasoningEffort`.

`source-controls.mjs` uses exact extracted functions and the actual adapter `getArgs()`. Catalog recognition and transport construction are explicit stubs in its `moduleFor()` control, so it is not an independent execution of the full provider registry. Its hook, namespace, negative and merge controls complement the actual CLI A/B; do not promote component-only ID cases to CLI claims.

## Reproduction and provenance

Follow `README.md`. `provenance.json` and the runtime lock pin the acquired bundle and installed dependency tree. Original CLI SHA256: `d408a372d5d6c8a8851610e2a9840f806929595584d1cd8d909d501928c0037c`. Diagnostic SHA256: `af21499e1d375a2f25367fd8489c4186a5005b396a10d566acd6c8a66017810c`.

Every process uses an isolated synthetic home/provider, fake keys, an ephemeral owned localhost endpoint, Node filesystem permissions without subprocess permission, disabled updates/telemetry and the retained network guard. `--trace` was enabled. The guard is a fixture control, not OS-level network isolation. The as-run harness was derived from the #788 fixture; its raw scope string incorrectly described every bundle as unmodified. Curated records explicitly identify original versus diagnostic by exact bundle hash. Raw observations are preserved privately; no raw logs are in this packet. The portable fixture removes unreachable retry code and corrects usage/scope wording; the exact as-run script is retained for provenance.

## Acceptance and limits

- Preserve supported low/high and other declared selections at the actual outgoing field.
- Keep provider-qualified IDs, namespaced IDs, duplicated bare IDs and case normalization under the existing registry contract; do not add an unnecessary prefix-strip fix based on this reproduction.
- Define and test static-default versus selected-effort precedence.
- Reject unsupported selections before requests; separately define/test no-effort and off behavior.
- Test interactive effort changes, persistence/resume and provider switching separately.
- Verify native OpenAI and Anthropic adapters independently; this matrix covers only the OpenAI-compatible BYOK path.

No macOS, real relay, production model behavior, older-version comparison, interactive switching, release adoption or team source implementation is established. Reporter claims about prior releases and external relays remain reporter evidence.
