import fs from 'node:fs';
import assert from 'node:assert/strict';
const data = JSON.parse(fs.readFileSync(new URL('./results.json', import.meta.url)));
assert.equal(data.runs.length, 8);
assert.equal(new Set(data.runs.map(r => `${r.variant}/${r.mode}`)).size, 8);
const original = 'd408a372d5d6c8a8851610e2a9840f806929595584d1cd8d909d501928c0037c';
const diagnostic = 'af21499e1d375a2f25367fd8489c4186a5005b396a10d566acd6c8a66017810c';
let requests = 0, successes = 0, rejections = 0;
for (const r of data.runs) {
  assert.ok(['original','diagnostic'].includes(r.variant));
  assert.ok(['high','low','off','fixed'].includes(r.mode));
  assert.equal(r.bundleSha256, r.variant === 'original' ? original : diagnostic);
  assert.equal(r.guardReady, true);
  assert.equal(r.timedOut, false);
  assert.equal(r.shutdownAssertion, false);
  assert.equal(r.blockedNetworkAttempts, 0);
  if (r.mode === 'off') {
    assert.equal(r.exit.code, 1); assert.equal(r.requests.length, 0);
    assert.match(r.validationError, /Unknown effort "off"/); rejections++;
    continue;
  }
  assert.equal(r.exit.code, 0); assert.equal(r.requests.length, 1);
  assert.equal(r.resultFrames.length, 1);
  assert.equal(r.resultFrames[0].subtype, 'success');
  assert.equal(r.resultFrames[0].finalText, 'ISSUE_824_FIXTURE_OK');
  const req = r.requests[0]; assert.equal(req.status, 200);
  assert.equal(req.path, '/v1/chat/completions');
  assert.equal(req.projectedBody.model, 'gpt-6-astra');
  const expected = r.variant === 'original' ? (r.mode === 'fixed' ? 'xhigh' : undefined) : (r.mode === 'fixed' ? 'high' : r.mode);
  assert.equal(req.reasoningEffortPresent, expected !== undefined);
  assert.equal(req.projectedBody.reasoning_effort, expected);
  requests++; successes++;
}
assert.deepEqual(data.totals, {cliInvocations:8,httpRequests:requests,successResults:successes,validationRejections:rejections,timeouts:0,shutdownAssertions:0,blockedNetworkAttempts:0});
console.log(JSON.stringify({verified:true, cliInvocations:8, httpRequests:requests, successes, validationRejections:rejections, applicationTestsRun:0}));
