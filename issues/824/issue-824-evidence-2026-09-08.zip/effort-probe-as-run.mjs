import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const root = path.dirname(fileURLToPath(import.meta.url));
const [packageArg, mode, expectedHash] = process.argv.slice(2);
const modes = ['high','low','off','fixed'];
if (!packageArg || !modes.includes(mode)) throw Error('Usage: node retry-probe.mjs PACKAGE_DIR MODE: ' + modes.join(', '));
const packageRoot = fs.realpathSync(packageArg);
const hash = p => createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const bundleSha256 = hash(path.join(packageRoot, 'dist/cli.mjs'));
if (bundleSha256 !== expectedHash) throw Error('Expected pinned command-code 1.51.3 bundle');
const runRoot = path.join(root, 'runs', `${mode}-${Date.now()}`);
const fixtureHome = path.join(runRoot, 'home'), tmp = path.join(fixtureHome, 'tmp');
for (const p of [tmp, path.join(fixtureHome, '.commandcode'), path.join(fixtureHome, 'AppData/Roaming'), path.join(fixtureHome, 'AppData/Local')]) fs.mkdirSync(p, {recursive:true});
const model = 'effcap/gpt-6-astra';
const requests = [], origin = performance.now(), startedAt = new Date().toISOString();
let child, cancelTimer, cancelRequestedAtMs = null, injection = null;
const now = () => Number((performance.now()-origin).toFixed(3));
const server = http.createServer((req,res) => {
  const receivedAtMs = now(); let body = '';
  req.on('data', b => { body += b; if (body.length > 2_000_000) req.destroy(); });
  req.on('end', () => {
    if (req.method !== 'POST' || req.url !== '/v1/chat/completions') { res.writeHead(404); res.end(); return; }
    const payload = JSON.parse(body);
    const record = {attempt:requests.length+1,path:req.url,method:req.method,receivedAtMs,model:payload.model,stream:payload.stream,body:payload,bodySha256:createHash('sha256').update(body).digest('hex')};
    requests.push(record);
    if (requests.length > 5) { record.status=400; res.writeHead(400,{'Content-Type':'application/json'}); res.end(JSON.stringify({error:{message:'Fixture request budget exceeded',type:'fixture_budget'}})); return; }
    const fail = false;
    if (fail) {
      const wall = Date.now();
      const header = ['seconds','repeated','cancel'].includes(mode) ? '8' : mode === 'http-date' ? new Date(wall + 8000).toUTCString() : mode === 'invalid' ? 'not-a-valid-delay' : null;
      record.status=429; record.responseAtMs=now(); record.responseWallMs=wall; record.retryAfter=header;
      record.requestedWaitMs = header === '8' ? 8000 : mode === 'http-date' ? Date.parse(header)-wall : null;
      res.writeHead(429, {'Content-Type':'application/json',...(header !== null ? {'Retry-After':header} : {})});
      res.end(JSON.stringify({error:{message:'ISSUE_824_SYNTHETIC_RATE_LIMIT',type:'rate_limit_error',code:'rate_limit_exceeded'}}));
      if (mode === 'cancel') cancelTimer=setTimeout(() => {cancelRequestedAtMs=now();child.send({fixtureAction:'inject-SIGINT'});},250);
      return;
    }
    record.status=200; record.responseAtMs=now();
    res.writeHead(200, {'Content-Type':'text/event-stream','Cache-Control':'no-cache'});
    const chunk = (delta,finish_reason=null) => `data: ${JSON.stringify({id:'fixture',object:'chat.completion.chunk',created:1,model:'model',choices:[{index:0,delta,finish_reason}]})}\n\n`;
    res.end(chunk({role:'assistant',content:'ISSUE_824_FIXTURE_OK'})+chunk({},'stop')+'data: [DONE]\n\n');
  });
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const port=server.address().port;
fs.writeFileSync(path.join(fixtureHome,'.commandcode/providers.json'),JSON.stringify({provider:{effcap:{api:'openai-completions',baseURL:`http://127.0.0.1:${port}/v1`,apiKey:'$FIXTURE_PROVIDER_KEY',models:{'gpt-6-astra':{contextWindow:200000,maxOutput:100,reasoningEfforts:['low','medium','high','xhigh'],...(mode==='fixed'?{options:{reasoning_effort:'xhigh'}}:{}),cost:{input:0,output:0}}}}}}));
fs.writeFileSync(path.join(fixtureHome,'.commandcode/config.json'),JSON.stringify({model,provider:'effcap',localOnly:true,telemetry:false,tasteLearning:false}));
fs.writeFileSync(path.join(fixtureHome,'.commandcode/settings.json'),JSON.stringify({disableScratchpad:true,disableSkillShellExecution:true}));
const env={};
for(const k of ['SystemRoot','WINDIR','ComSpec','PATHEXT','PROCESSOR_ARCHITECTURE']) if(process.env[k]) env[k]=process.env[k];
env.PATH=[path.dirname(process.execPath),path.join(process.env.SystemRoot??'/','System32')].join(path.delimiter);
Object.assign(env,{HOME:fixtureHome,USERPROFILE:fixtureHome,APPDATA:path.join(fixtureHome,'AppData/Roaming'),LOCALAPPDATA:path.join(fixtureHome,'AppData/Local'),TEMP:tmp,TMP:tmp,CMD_LOCAL_ONLY:'1',DO_NOT_TRACK:'1',OTEL_SDK_DISABLED:'true',COMMANDCODE_SKIP_UPDATES:'1',COMMANDCODE_DISABLE_CRON:'1',COMMANDCODE_DISABLE_DURABLE_CRON:'1',DOTENV_CONFIG_PATH:path.join(fixtureHome,'missing.env'),NO_COLOR:'1',FIXTURE_PORT:String(port),FIXTURE_PROVIDER_KEY:'synthetic-provider-key-not-real',COMMAND_CODE_API_KEY:'synthetic-command-key-not-real'});
const cliArgs=['--no-auto-update','--local-only','--skip-onboarding','--trust','--no-skills','--no-session','--model',model,'--effort',mode==='fixed'?'high':mode,'--max-turns','1','--output-format','json','--trace','--print','Reply with the synthetic fixture marker. Do not call any tools.'];
const nodeArgs=['--permission',`--allow-fs-read=${path.dirname(packageRoot)}`,`--allow-fs-read=${root}`,`--allow-fs-write=${runRoot}`,'--require',path.join(root,'offline-guard.cjs'),path.join(packageRoot,'dist/index.mjs'),...cliArgs];
child=spawn(process.execPath,nodeArgs,{cwd:runRoot,env,windowsHide:true,stdio:['ignore','pipe','pipe','ipc']});
let stdout='',stderr='',timedOut=false;
child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
child.on('message',m=>{injection={...m,receivedAtMs:now()};});
const watchdog=setTimeout(()=>{timedOut=true;child.kill();},35000);
const exit=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('close',(code,signal)=>resolve({code,signal}));});
const closedAtMs=now();clearTimeout(watchdog);clearTimeout(cancelTimer);server.closeAllConnections();await new Promise(r=>server.close(r));
const events=stdout.split(/\r?\n/).flatMap(line=>{try{return[JSON.parse(line)];}catch{return[];}});
const intervals=requests.slice(1).map((r,i)=>({afterAttempt:i+1,gapMs:Number((r.receivedAtMs-requests[i].responseAtMs).toFixed(3)),requestedWaitMs:requests[i].requestedWaitMs??null}));
const result={mode,startedAt,node:process.version,platform:process.platform,arch:process.arch,osRelease:os.release(),cliVersion:JSON.parse(fs.readFileSync(path.join(packageRoot,'package.json'))).version,bundleSha256,cliArgs,exit,timedOut,closedAtMs,requests,intervals,cancelRequestedAtMs,injection,stdout,stderr,eventTypes:events.map(e=>e.type),scope:'Unmodified CLI bundle; actual localhost BYOK HTTP; isolated synthetic home and allowlisted environment; filesystem permission restrictions; guarded Node fetch/net/tls; no provider credentials. Cancellation is a preload-injected process SIGINT event, not physical Ctrl+C.'};
fs.writeFileSync(path.join(runRoot,'raw.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify({mode,exit,timedOut,requests:requests.length,intervals,cancelRequestedAtMs,injection,closedAtMs,eventTypes:result.eventTypes,stdoutTail:stdout.slice(-600),stderrTail:stderr.slice(-300),raw:path.relative(root,path.join(runRoot,'raw.json'))}));
