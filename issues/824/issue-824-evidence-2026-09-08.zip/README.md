# Reproduce the #824 effort boundary

Read `REPORT.md`, `results.json`, `source-controls-results.json` and `provenance.json`. The package contains synthetic evidence and fixtures, not application bundles, credentials or raw prompts.

Verify the saved observations without network or application execution:

```text
node verify-results.mjs
```

Copy this directory to a fresh ignored scratch directory before generating new output. Use Node 24.15.0 / Windows x64 for the recorded environment. Copy `runtime-package.json` and `runtime-package-lock.json` into a new `runtime/` directory as `package.json` and `package-lock.json`, then run `npm ci --ignore-scripts --no-audit --no-fund` there. The supplied lock is the exact dependency resolution used; compare the bundle and dependency hashes in `provenance.json`. A fresh installation resolving only caret ranges is not equivalent.

Run the portable fixture with absolute paths; bypass installed shell wrappers:

```text
node effort-probe.mjs ORIGINAL_PACKAGE high d408a372d5d6c8a8851610e2a9840f806929595584d1cd8d909d501928c0037c
node effort-probe.mjs ORIGINAL_PACKAGE low d408a372d5d6c8a8851610e2a9840f806929595584d1cd8d909d501928c0037c
node effort-probe.mjs ORIGINAL_PACKAGE fixed d408a372d5d6c8a8851610e2a9840f806929595584d1cd8d909d501928c0037c
node effort-probe.mjs ORIGINAL_PACKAGE off d408a372d5d6c8a8851610e2a9840f806929595584d1cd8d909d501928c0037c
```

`ORIGINAL_PACKAGE` is the isolated `runtime/node_modules/command-code` directory. Each run writes a fresh `runs/MODE-TIMESTAMP/` directory; raw output includes synthetic home paths and must be minimized before sharing. The `fixed` mode sets static `reasoning_effort: xhigh` and selects high; off is rejected before HTTP. The watchdog is 35 seconds and the owned mock caps requests; recorded runs hit neither limit.

Create a new sibling package for the diagnostic, preserving the original:

```text
node build-diagnostic.mjs ORIGINAL_PACKAGE NEW_SIBLING_PACKAGE
node effort-probe.mjs NEW_SIBLING_PACKAGE high af21499e1d375a2f25367fd8489c4186a5005b396a10d566acd6c8a66017810c
```

Repeat diagnostic low/fixed/off only when reproducing the full matrix. This writes a derived bundle for a causal comparison; it is not an installed product update.

Run the separate offline component controls with the original CLI bundle and pinned adapter entry as explicit arguments:

```text
node source-controls.mjs ORIGINAL_PACKAGE/dist/cli.mjs RUNTIME_NODE_MODULES/@ai-sdk/openai-compatible/dist/index.mjs
```

These execute extracted functions with documented catalog/transport stubs and the actual adapter's request builder; no provider request is made. `effort-probe-as-run.mjs` retains the exact historical fixture, including unused retry code and its inherited scope label. Use the corrected portable entry point for new runs and preserve resulting differences explicitly.
