Follow-up to my earlier analysis: I compared the published **1.38.2 and 1.49.1** components, and the active-session paths have changed. My earlier description of request-time global-provider lookup should not be treated as the current 1.49.1 behavior.

I ran two separate Node processes sharing synthetic settings, with fake credentials and an actual localhost HTTP capture:

| Test | 1.38.2 | 1.49.1 |
|---|---|---|
| A's auth lane after B changes shared defaults | Changed in 6/6 scenarios | Stayed stable in 6/6 |
| Unpinned A model after settings reload | Changed in 3/3 | Stayed stable in 3/3 |
| Explicitly selected A model | Stayed stable, but auth still changed | Model and auth stayed stable |

Both processes picked up theme changes, confirming they observed the shared settings updates. Fresh harnesses adopted the new defaults. The comparison completed 12 scenarios, 398 assertions, and 84 local requests; the older version serves as the failing isolation control.

The current code captures `providerBinding` for transport headers, and `createConfigStore.reload()` excludes the active model/route. That looks like a fix for the specific active-session paths tested.

**Scope:** this is a Windows two-process probe of extracted, unmodified published functions. Config loaders, credentials, and the harness engine are substituted. The captured model comes from config-store getters. It does not verify full CLI inference, macOS behavior, or billing. Reproducer, hashes, and captures are in the attached evidence ZIP.

**Remaining check before closure:** please test rebuilding/resuming A after B changes the global provider. The inspected `createHarnessSession` restores saved `model`/`modelProvider` but reads the auth lane from current global settings. That is a lifecycle concern to validate, not a separately reproduced current defect. Preserve the session's provider/model pairing, or require explicit selection before sending if it cannot be restored.

Could you confirm the released fix version and verify active, rebuild, and resume isolation? The reporter can then retest that release. This comparison does not establish which release first introduced the protections.
