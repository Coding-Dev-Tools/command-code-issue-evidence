# Issue #777: active provider isolation regression

Tested September 6, 2026. Issue: https://github.com/CommandCodeAI/command-code/issues/777

**The active-session contamination paths described in the earlier comment behave differently in 1.49.1.** A controlled comparison reproduced provider drift in extracted 1.38.2 components and found that 1.49.1 preserves the active provider and configured model in the same scenarios. The next contribution should correct the older diagnosis, supply the regression evidence, and ask for full CLI resume/rebuild validation before closure.

## Measured results

| Observation | 1.38.2 | 1.49.1 |
|---|---|---|
| A's auth lane after B changes shared defaults | Changed in 6/6 scenarios | Preserved in 6/6 scenarios |
| Unpinned A model after config reload | Adopted B's model in 3/3 scenarios | Preserved A's model in 3/3 scenarios |
| Explicitly selected A model after config reload | Preserved in 3/3 scenarios, but auth still changed | Preserved in 3/3 scenarios with auth stable |
| A model route after config reload | Stayed at initial route, including when model changed | Stayed at initial route with model stable |
| Theme reload positive control | Observed both disk changes | Observed both disk changes |
| Unbound auth-resolver control | Followed latest global provider | Followed latest global provider |
| Fresh harness after another defaults change | Adopted new defaults | Adopted new defaults |

All **12 scenarios, 398 assertions, and 84 localhost HTTP requests passed their version-specific expectations**. The older version is an intentionally failing isolation control; its six drift cases are not six independent user incident reproductions. Each scenario uses two distinct Windows Node processes. Three repetitions per pinned/unpinned model condition were run for each version. Two repetitions supply the provider binding used by the current CLI wrapper; the third exercises the node factory's fallback behavior.

Environment: Windows, Node v24.15.0. The original report concerns macOS; this is not platform-matched end-to-end validation.

## Test method and boundaries

The test extracts unmodified function text from the published `dist/cli.mjs` bundles:

- `createConfigStore`
- `createNodeHarnessSession`
- `commandAuthHeaders`, `resolveCommandAuthHeaders`, `getConfiguredProvider`
- `normalizeCliEnvironment`, `buildCommandAuthHeaders`, `createNodeTransport`, and supporting transport functions

Each process executes its own extracted functions. Both read the same synthetic JSON file through replacement config loaders. Process B writes changed defaults; IPC acknowledgments determine ordering. A and B also send concurrent requests after the second change. The real extracted transport calls Node fetch and an owned HTTP server bound to 127.0.0.1. Generated OAuth headers are observed at that server.

The full `createHarness` model engine is replaced by an options-capture adapter. Request bodies are assembled by the probe from the real config store getters. Therefore the body proves the **configured model captured by the probe**, not an independently observed model inference request or backend route. Config parsing/discovery, runtime host, model canonicalization, OAuth credential retrieval, and telemetry dependencies are replaced with small synthetic adapters. Provider IDs use `command-code`, `codex`, and `anthropic`; models and model routes are deliberately synthetic.

No real auth files, provider credentials, accounts, billing APIs, or inference endpoints were used. The workers inherit an allowlisted environment, use isolated home directories, and restrict fetch to the test server. The product bundle is read without modification. The test script, results, and report are the deliverables; this is not a product patch.

## Why current behavior differs

In 1.38.2, the default node transport obtains its provider through the global lookup on every request. Config reload can also replace the unpinned model without replacing its route provider.

In 1.49.1, `createHarnessSession` captures the configured provider and passes `providerBinding`. `createNodeHarnessSession` reuses that binding in its header callback, or captures a fallback at construction. `resolveCommandAuthHeaders` uses the binding when present. `createConfigStore.reload` updates selected preferences, excluding model/modelProvider. This is consistent with the measured results.

This comparison does not establish the first fixed release. The binding preserves the provider selection; it does not freeze credentials. Same-lane token refresh should remain possible.

## Remaining validation for maintainers

The current `createHarnessSession` restores saved `model` and `modelProvider`, while it obtains the OAuth provider from current global user config when constructing the harness. This is a source-level lifecycle concern, **not a reproduced current resume defect**. The full product may have additional validation or lifecycle behavior outside this probe.

Recommended acceptance checks:

1. Keep A active while B changes its provider/model; verify actual outbound provider/model and displayed selection agree. Include unpinned, explicitly selected, explicit override, and null/default-lane cases.
2. Rebuild A without an intentional provider switch, including custom-provider configuration refresh. Preserve A's provider/model pairing.
3. Restart/resume A after B changes global defaults. Restore A's pairing or require an explicit selection before sending; do not silently inherit another session's lane.
4. Explicitly switch A, and verify B remains stable. Refresh or revoke credentials within a lane and verify visible failure instead of silent lane/model substitution.
5. Confirm the shipped fix version and ask the reporter to retest on that release before deciding whether to close #777.

If the resume/rebuild case fails, persist and restore the session's provider selection alongside its model/route, or require an explicit selection before sending. Do not solve selection isolation by preventing legitimate token refresh.

## Provenance and reproduction

The npm latest tag was refreshed during this investigation and returned 1.49.1. Both version tarballs were checked against npm's SHA-512 integrity values. The installed 1.49.1 bundle was byte-identical to the published bundle.

| Version | `dist/cli.mjs` SHA-256 |
|---|---|
| 1.38.2 | `1852550055b2a9c82a2b131a45ca57e86cbad7d9f3597783e6d4542a55a3cb79` |
| 1.49.1 | `10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05` |

Obtain the two published tarballs without installing dependencies or executing install scripts:

- https://registry.npmjs.org/command-code/-/command-code-1.38.2.tgz
- https://registry.npmjs.org/command-code/-/command-code-1.49.1.tgz

Extract them into separate directories. Run:

```text
node provider-isolation-test.mjs /path/to/1.38.2/package/dist/cli.mjs /path/to/1.49.1/package/dist/cli.mjs ./test-output
```

Use Node with built-in fetch support; the recorded run used v24.15.0. The script verifies both exact bundle hashes and fails if they differ. It needs no package installation. `results.json` includes exact source ranges in both UTF-16 offsets and UTF-8 bytes, extraction hashes, process IDs, synthetic request captures, controls, and counts. End offsets are exclusive.

Current wrapper static reference: `createHarnessSession` is at UTF-8 bytes 1,988,723–1,991,057, end exclusive, in the verified 1.49.1 bundle. Other tested ranges are machine-readable in the results.

## Separate CLI startup feasibility check

The unmodified installed 1.49.1 CLI completed isolated `--version` and `--help` runs with an offline guard, `CMD_LOCAL_ONLY=1`, and updates/telemetry disabled. Earlier 15-second startup timeouts were not consistently reproducible; their cause remains uncertain. These startup checks do not exercise #777. In particular, local-only mode bypasses the provider-header path, so successful startup in that mode cannot substitute for the component regression or a gateway-provider lifecycle test.

## Review and publication state

Four bounded internal reviewers checked provider binding, config/lifecycle behavior, CLI startup feasibility, and claim limits. The parent integrated the findings. No GitHub comments were posted, issue fields changed, commits created, or product files modified.
