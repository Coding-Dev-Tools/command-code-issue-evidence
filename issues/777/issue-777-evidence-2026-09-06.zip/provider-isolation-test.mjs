// Exact published-component regression. This does not launch the complete CLI.
// Run: node provider-isolation-test.mjs OLD_CLI_MJS NEW_CLI_MJS [OUTPUT_DIRECTORY]
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import http from 'node:http';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { fork } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const script = fileURLToPath(import.meta.url);
const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
const headers = {
  OAUTH_TOKEN: 'x-oauth-token', OAUTH_PROVIDER: 'x-oauth-provider',
  PROJECT_SLUG: 'x-project-slug', TASTE_LEARNING: 'x-taste-learning',
  CLI_ENVIRONMENT: 'x-cli-environment', CLI_VERSION: 'x-command-code-version',
  OSS_PRIMARY_PROVIDER: 'x-oss-primary-provider', SESSION_ID: 'x-session-id',
  CMD_ZDR: 'x-cmd-zdr', PROVIDER_DEEPSEEK_INTERNAL: 'x-cmd-provider-deepseek-internal',
};
const groups = [
  ['configStore', 'function createConfigStore(', 'function getModelCategory('],
  ['transport', 'function normalizeCliEnvironment(', 'function createFakeTransport('],
  ['auth', 'async function resolveCommandAuthHeaders(', 'async function hasBeenInstalled('],
  ['nodeHarnessFactory', 'async function createNodeHarnessSession(', 'function filterVisibleMessages('],
  ['globalProvider', 'async function getConfiguredProvider(', 'async function loadFeatureModels('],
];
function extract(bundle) {
  const source = fs.readFileSync(bundle, 'utf8');
  const ranges = groups.map(([name, first, next]) => {
    const start = source.indexOf(first), end = source.indexOf(next, start + first.length);
    assert(start >= 0 && end > start, `Missing exact source boundary: ${name}`);
    const code = source.slice(start, end);
    return { name, startUtf16: start, endUtf16: end,
      startByte: Buffer.byteLength(source.slice(0, start)),
      endByte: Buffer.byteLength(source.slice(0, end)), sha256: sha256(code), code };
  });
  return { sha256: sha256(Buffer.from(source)), ranges };
}

async function worker() {
  const [bundle, configFile, baseUrl, label] = process.argv.slice(3);
  const readConfig = async () => JSON.parse(fs.readFileSync(configFile, 'utf8'));
  const calls = [];
  const runtime = { env: () => ({}), cwd: () => path.dirname(configFile) };
  const sandbox = {
    // Config loaders are synthetic file adapters; the selected factory, auth,
    // headers, transport, global-provider helper, and config store are unedited.
    loadUserConfig: readConfig, loadCommandCodeConfig: readConfig,
    legacyUserConfigPath: () => configFile, getCommandConfigRuntime: () => runtime,
    getAuthFile: () => 'synthetic-auth-never-read',
    getOAuthCredentials: async ({ provider }) => {
      calls.push(provider);
      return provider && provider !== 'command-code'
        ? { token: `FAKE-NONFUNCTIONAL-${provider}`, oauthProvider: provider } : {};
    },
    validateOAuthToken: ({ token, provider }) => {
      if (provider && provider !== 'command-code') assert.equal(token, `FAKE-NONFUNCTIONAL-${provider}`);
    },
    isTasteLearningEnabled: async () => false,
    fP: async () => 'FAKE-NONFUNCTIONAL-API-KEY', FT: async () => 'FAKE-NONFUNCTIONAL-API-KEY',
    getTelemetryEnv: () => 'test', getCommandCurrentProjectDirName: () => 'synthetic-provider-test',
    getModelOverride: () => undefined, getModelOverrideProvider: () => undefined,
    canonicalizeModelId: ({ model }) => model, cr: 'synthetic-default',
    isBypassPermissionsDisabled: () => false,
    isLocalOnly: () => false, isTelemetryInitialized: () => false,
    createHarness: async options => options,
    __name: value => value, yy: headers, Uf: headers, Sy: 'cli', jf: 'cli',
    wy: 'TransportError', Bf: 'TransportError',
    fetch: (url, options) => {
      assert.equal(new URL(url).origin, baseUrl, 'Only the owned localhost server is allowed');
      return fetch(url, options);
    },
  };
  vm.createContext(sandbox);
  const extracted = extract(bundle);
  vm.runInContext(extracted.ranges.map(r => r.code).join('\n'), sandbox);
  let harness;
  process.on('message', async ({ id, command, data }) => {
    try {
      let value;
      if (command === 'write') {
        fs.writeFileSync(configFile, JSON.stringify(data)); value = await readConfig();
      } else if (command === 'create') {
        harness = await sandbox.createNodeHarnessSession({
          runtime, sessionId: label, cliVersion: data.version, baseUrl,
          interaction: {}, telemetrySink: {},
          ...(data.binding !== 'fallback' ? { providerBinding: { provider: data.binding } } : {}),
        });
        if (data.pinModel) harness.configStore.setSessionModel(data.pinModel);
        // Let the exact config store's initial asynchronous baseline read settle.
        await new Promise(resolve => setImmediate(resolve));
        value = { pid: process.pid, model: harness.configStore.getModel() };
      } else if (command === 'request') {
        const reload = data.reload ? await harness.configStore.reload() : null;
        const body = {
          stage: data.stage, model: harness.configStore.getModel(),
          modelProvider: harness.configStore.getModelProvider(),
          theme: harness.configStore.getTheme(), reload,
        };
        const before = calls.length;
        const captured = await harness.transport.post({ route: '/capture', body });
        value = { ...captured, credentialProvider: calls[before], pid: process.pid };
      } else if (command === 'unbound') {
        const before = calls.length;
        const resolved = await sandbox.resolveCommandAuthHeaders({ runtime, sessionId: label, cliVersion: data.version });
        value = { provider: calls[before], oauthProvider: resolved['x-oauth-provider'] ?? null };
      } else throw new Error(`Unknown command ${command}`);
      process.send({ id, value });
    } catch (error) { process.send({ id, error: error.stack }); }
  });
  process.send({ ready: true, pid: process.pid });
}

function startWorker(bundle, configFile, baseUrl, label, home) {
  fs.mkdirSync(home, { recursive: true });
  const env = Object.fromEntries(['SystemRoot', 'WINDIR', 'ComSpec', 'PATH', 'PATHEXT'].filter(k => process.env[k]).map(k => [k, process.env[k]]));
  Object.assign(env, { HOME: home, USERPROFILE: home, APPDATA: home, LOCALAPPDATA: home, TEMP: home, TMP: home });
  const child = fork(script, ['--worker', bundle, configFile, baseUrl, label], {
    env, cwd: home, silent: true, windowsHide: true,
  });
  const waiting = new Map(); let seq = 0, stderr = '';
  child.stderr.on('data', b => { stderr += b; });
  let readyResolve, readyReject;
  const ready = new Promise((resolve, reject) => { readyResolve = resolve; readyReject = reject; });
  const readyTimer = setTimeout(() => readyReject(new Error(`Worker startup timeout ${label}: ${stderr}`)), 10000);
  child.on('message', m => {
    if (m.ready) { clearTimeout(readyTimer); readyResolve(m); return; }
    const item = waiting.get(m.id); if (!item) return;
    waiting.delete(m.id); clearTimeout(item.timer);
    m.error ? item.reject(new Error(m.error)) : item.resolve(m.value);
  });
  const exited = new Promise(resolve => child.once('exit', (code, signal) => {
    clearTimeout(readyTimer); readyReject(new Error(`Worker exited ${label} ${code} ${signal}: ${stderr}`));
    for (const w of waiting.values()) { clearTimeout(w.timer); w.reject(new Error(`Worker exited: ${stderr}`)); }
    waiting.clear(); resolve({ code, signal });
  }));
  return { ready, pid: child.pid,
    ask: (command, data = {}) => new Promise((resolve, reject) => {
      const id = ++seq;
      const timer = setTimeout(() => { waiting.delete(id); reject(new Error(`Worker request timeout: ${command}`)); }, 10000);
      waiting.set(id, { resolve, reject, timer }); child.send({ id, command, data });
    }),
    stop: async () => { if (child.exitCode === null) child.kill(); await exited; },
  };
}

async function main() {
  const [oldArg, newArg, outArg] = process.argv.slice(2);
  assert(oldArg && newArg, 'Supply the published 1.38.2 and 1.49.1 cli.mjs paths');
  const out = path.resolve(outArg ?? path.join(path.dirname(script), 'test-output'));
  fs.mkdirSync(out, { recursive: true });
  let requestCount = 0, assertionCount = 0;
  const check = (actual, expected, why) => { assert.deepEqual(actual, expected, why); assertionCount++; };
  const server = http.createServer(async (req, res) => {
    let body = ''; for await (const chunk of req) body += chunk;
    requestCount++;
    res.writeHead(200, { 'content-type': 'application/json' });
    // Persist no full headers, just the relevant synthetic observations.
    res.end(JSON.stringify({
      sessionId: req.headers['x-session-id'], oauthProvider: req.headers['x-oauth-provider'] ?? null,
      oauthToken: req.headers['x-oauth-token'] ?? null,
      apiToken: req.headers.authorization ?? null, body: JSON.parse(body),
    }));
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const baseUrl = `http://127.0.0.1:${server.address().port}`;
  const results = { generatedAt: new Date().toISOString(), platform: process.platform, node: process.version,
    scope: 'Exact published-component tests in two real processes, synthetic shared config, actual localhost HTTP; not full CLI or model inference.',
    substitutions: ['JSON config file loaders', 'synthetic OAuth/API credentials', 'identity model canonicalizer', 'capture-only createHarness engine', 'runtime and telemetry adapters'],
    versions: [], cases: [],
  };
  try {
    for (const [version, bundleArg] of [['1.38.2', oldArg], ['1.49.1', newArg]]) {
      const bundle = path.resolve(bundleArg), current = version === '1.49.1', extracted = extract(bundle);
      const expectedHash = current ? '10348272545cc4440446d801e8a5bf31412e3d9acaf2aefee7c2ac914bb60b05' : '1852550055b2a9c82a2b131a45ca57e86cbad7d9f3597783e6d4542a55a3cb79';
      check(extracted.sha256, expectedHash, 'Published bundle identity');
      results.versions.push({ version, sha256: extracted.sha256, ranges: extracted.ranges.map(({ code, ...r }) => r) });
      for (const pin of [false, true]) for (let trial = 1; trial <= 3; trial++) {
        const id = `${version}-${pin ? 'pinned' : 'unpinned'}-${trial}`;
        const dir = path.join(out, id); fs.mkdirSync(dir, { recursive: true });
        const configFile = path.join(dir, 'synthetic-config.json');
        const cfgA = { provider: 'command-code', model: 'synthetic-model-A', modelProvider: 'synthetic-route-A', theme: 'dark' };
        const cfgB = { provider: 'codex', model: 'synthetic-model-B', modelProvider: 'synthetic-route-B', theme: 'light' };
        const cfgC = { provider: 'anthropic', model: 'synthetic-model-C', modelProvider: 'synthetic-route-C', theme: 'auto' };
        fs.writeFileSync(configFile, JSON.stringify(cfgA));
        const a = startWorker(bundle, configFile, baseUrl, `${id}-A`, path.join(dir, 'home-A'));
        const b = startWorker(bundle, configFile, baseUrl, `${id}-B`, path.join(dir, 'home-B'));
        try {
          const ready = await Promise.all([a.ready, b.ready]);
          check(ready[0].pid !== ready[1].pid, true, 'Distinct OS processes');
          // One trial also exercises the node factory's disk-snapshot fallback.
          const binding = trial === 3 ? 'fallback' : cfgA.provider;
          await a.ask('create', { version, binding, pinModel: pin ? { model: cfgA.model, provider: cfgA.modelProvider } : null });
          const before = await a.ask('request', { stage: 'A-before-B' });
          check(before.credentialProvider, cfgA.provider, 'Initial A auth lane');
          check(before.oauthProvider, null, 'Command lane emits no OAuth provider header');
          check(before.body.model, cfgA.model, 'Initial A model');
          await b.ask('write', cfgB);
          await b.ask('create', { version, binding: cfgB.provider });
          const bFirst = await b.ask('request', { stage: 'B-initial' });
          check([bFirst.credentialProvider, bFirst.body.model, bFirst.body.modelProvider], [cfgB.provider, cfgB.model, cfgB.modelProvider], 'New B uses new defaults');
          const aNoReload = await a.ask('request', { stage: 'A-after-B-before-reload' });
          check(aNoReload.credentialProvider, current ? cfgA.provider : cfgB.provider, 'Auth path independent of config reload');
          check(aNoReload.oauthProvider, current ? null : cfgB.provider, 'Observed HTTP OAuth provider');
          check(aNoReload.body.model, cfgA.model, 'Model before reload');
          const aReload = await a.ask('request', { stage: 'A-after-B-after-reload', reload: true });
          check(aReload.body.model, current || pin ? cfgA.model : cfgB.model, 'Model isolation after reload');
          check(aReload.body.modelProvider, cfgA.modelProvider, 'Route remains initial');
          check(aReload.body.theme, 'light', 'Positive control: disk theme reloaded');
          check(aReload.body.reload.includes('theme'), true, 'Reload reports theme change');
          await b.ask('write', cfgC);
          const [aConcurrent, bConcurrent] = await Promise.all([
            a.ask('request', { stage: 'A-concurrent-after-C', reload: true }),
            b.ask('request', { stage: 'B-concurrent-after-C', reload: true }),
          ]);
          check(aConcurrent.credentialProvider, current ? cfgA.provider : cfgC.provider, 'Concurrent A lane');
          check(bConcurrent.credentialProvider, current ? cfgB.provider : cfgC.provider, 'Concurrent B lane');
          check(aConcurrent.body.model, current || pin ? cfgA.model : cfgC.model, 'Concurrent A model');
          check(bConcurrent.body.model, current ? cfgB.model : cfgC.model, 'Concurrent B model');
          check([aConcurrent.body.theme, bConcurrent.body.theme], ['auto', 'auto'], 'Both processes observed second disk change');
          const unbound = await a.ask('unbound', { version });
          check(unbound.provider, cfgC.provider, 'Unbound resolver follows global provider as negative control');
          await b.ask('create', { version, binding: 'fallback' });
          const fresh = await b.ask('request', { stage: 'B-fresh-harness-after-C' });
          check([fresh.credentialProvider, fresh.body.model, fresh.body.modelProvider], [cfgC.provider, cfgC.model, cfgC.modelProvider], 'Fresh harness adopts new defaults');
          for (const capture of [before, bFirst, aNoReload, aReload, aConcurrent, bConcurrent, fresh]) {
            check(capture.apiToken, 'Bearer FAKE-NONFUNCTIONAL-API-KEY', 'Only fake API credentials');
            check(capture.oauthToken, capture.oauthProvider ? `Bearer FAKE-NONFUNCTIONAL-${capture.oauthProvider}` : null, 'Only fake OAuth credentials');
          }
          results.cases.push({ id, pinModel: pin, binding, processIds: ready.map(x => x.pid),
            before, bFirst, aNoReload, aReload, aConcurrent, bConcurrent, unbound, fresh, passed: true });
        } finally { await Promise.all([a.stop(), b.stop()]); }
      }
    }
    results.summary = { passed: true, cases: results.cases.length, assertions: assertionCount, localHttpRequests: requestCount,
      oldVersionCasesWithAuthDrift: results.cases.filter(c => c.id.startsWith('1.38.2') && c.aNoReload.credentialProvider !== 'command-code').length,
      currentVersionCasesRetainingActiveProviderAndModel: results.cases.filter(c => c.id.startsWith('1.49.1') && c.aConcurrent.credentialProvider === 'command-code' && c.aConcurrent.body.model === 'synthetic-model-A').length };
  } catch (error) { results.failure = error.stack; throw error; }
  finally {
    fs.writeFileSync(path.join(out, 'results.json'), JSON.stringify(results, null, 2));
    server.closeAllConnections(); await new Promise(resolve => server.close(resolve));
  }
  console.log(JSON.stringify(results.summary, null, 2));
}

if (process.argv[2] === '--worker') await worker(); else await main();
