import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

const runDir = process.argv[2] ? path.resolve(process.argv[2]) : null;
const negative = process.argv[3] ?? null;
if (!runDir) throw new Error('Usage: node verify-873.mjs <run-directory> [--negative marker|exit|request]');
const report = JSON.parse(fs.readFileSync(path.join(runDir, 'results.json'), 'utf8'));
const expected = ['malformed-bare', 'malformed-double-quoted', 'healthy-variable', 'healthy-single-quoted-literal', 'healthy-ordinary'];

function verify(candidate, writeSummary) {
  assert.deepEqual(candidate.scenarios.map(scenario => scenario.scenario), expected);
  assert.equal(candidate.package.name, 'command-code');
  assert.equal(candidate.package.version, '1.58.0');
  assert.equal(candidate.package.cliSha256, 'aab2bec800371953112d18472bb7383992ef264cca22558bdcda77e7d0dc0f14');
  for (const scenario of candidate.scenarios) {
    assert.ok(Array.isArray(scenario.requests), `${scenario.scenario}: request projection missing`);
    assert.ok(scenario.requests.length >= 1, `${scenario.scenario}: mock provider was not reached`);
    assert.ok(scenario.requests[0].toolNames.includes(scenario.selectedTool), `${scenario.scenario}: selected shell tool was not declared`);
    assert.ok(['shell_command', 'powershell', 'bash', 'shell', 'execute'].includes(scenario.selectedTool), `${scenario.scenario}: unexpected tool ${scenario.selectedTool}`);
    assert.equal(path.isAbsolute(scenario.rawFile), false, `${scenario.scenario}: raw path must be relative`);
    assert.ok(!scenario.rawFile.split(/[\\/]/).includes('..'), `${scenario.scenario}: raw path escapes run directory`);
    const rawPath = path.join(runDir, scenario.rawFile);
    assert.ok(fs.existsSync(rawPath), `${scenario.scenario}: raw capture missing`);
    const raw = fs.readFileSync(rawPath);
    assert.equal(createHash('sha256').update(raw).digest('hex'), scenario.rawSha256, `${scenario.scenario}: raw hash mismatch`);
    scenario.rawText = raw.toString('utf8').replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, '');
  }
  const healthy = candidate.scenarios.filter(scenario => scenario.expectedClass === 'healthy-control');
  assert.equal(healthy.length, 3, 'verifier-negative: healthy control set is incomplete');
  for (const scenario of healthy) {
    assert.equal(scenario.promptObserved, true, `${scenario.scenario}: permission prompt not observed`);
    assert.equal(scenario.processAliveAfterCancel, true, `${scenario.scenario}: process did not survive Escape`);
    assert.equal(scenario.followupPromptObserved, true, `${scenario.scenario}: follow-up prompt was not observed`);
    assert.equal(scenario.followupSubmitted, true, `${scenario.scenario}: follow-up turn was not submitted`);
    assert.equal(scenario.continuationRequestObserved, true, `${scenario.scenario}: continuation request was not observed`);
    assert.equal(scenario.continuationObserved, true, `${scenario.scenario}: continuation marker was not observed`);
    assert.equal(scenario.processAliveAfterContinuation, true, `${scenario.scenario}: process did not survive continuation`);
    assert.equal(scenario.exit?.code, 0, `${scenario.scenario}: CLI did not exit cleanly`);
    assert.equal(scenario.markerExistsAfter, false, `${scenario.scenario}: marker was created without approval`);
    assert.equal(scenario.requests.length, 2, `${scenario.scenario}: expected initial and continuation requests only`);
  }
  const malformed = candidate.scenarios.filter(scenario => scenario.expectedClass === 'reporter-malformed');
  assert.equal(malformed.length, 2, 'verifier-negative: malformed control set is incomplete');
  for (const scenario of malformed) {
    assert.equal(scenario.promptObserved, false, `${scenario.scenario}: malformed input unexpectedly reached a permission prompt`);
    assert.equal(scenario.exit?.code, 1, `${scenario.scenario}: malformed input did not exit with the observed failure`);
    assert.equal(scenario.requests.length, 1, `${scenario.scenario}: malformed input sent an unexpected follow-up request`);
    assert.match(scenario.rawText, /Bad substitution: \$\{\}/, `${scenario.scenario}: parse failure text missing`);
    assert.match(scenario.rawText, /Unhandled Promise Rejection/, `${scenario.scenario}: unhandled rejection text missing`);
  }
  const malformedOutcomes = malformed.map(scenario => ({ scenario: scenario.scenario, promptObserved: scenario.promptObserved, exit: scenario.exit, requests: scenario.requests.length }));
  const summary = {
    runId: candidate.runId,
    package: candidate.package,
    healthyControls: healthy.map(scenario => ({ scenario: scenario.scenario, promptObserved: scenario.promptObserved, processAliveAfterCancel: scenario.processAliveAfterCancel, followupSubmitted: scenario.followupSubmitted, continuationObserved: scenario.continuationObserved, processAliveAfterContinuation: scenario.processAliveAfterContinuation, exit: scenario.exit, markerExistsAfter: scenario.markerExistsAfter })),
    malformedOutcomes,
    interpretation: 'Both malformed commands reached the unmodified 1.58.0 CLI shell permission path, rendered Bad substitution and an unhandled rejection, and exited with code 1. Healthy mutating controls displayed the permission UI, survived Escape, completed a second user turn through the local mock, and left their markers absent.'
  };
  if (writeSummary) {
    for (const scenario of candidate.scenarios) delete scenario.rawText;
    fs.writeFileSync(path.join(runDir, 'verified-summary.json'), JSON.stringify(summary, null, 2) + '\n');
  }
  return summary;
}

if (negative) {
  assert.ok(['--negative', 'marker', 'exit', 'request', '--negative-marker', '--negative-exit', '--negative-request'].includes(negative), `unknown negative mode ${negative}`);
  const mode = negative.startsWith('--negative-') ? negative.slice('--negative-'.length) : negative === '--negative' ? (process.argv[4] ?? null) : negative;
  assert.ok(['marker', 'exit', 'request'].includes(mode), 'negative mode must be marker, exit or request');
  const altered = structuredClone(report);
  const healthy = altered.scenarios.find(scenario => scenario.expectedClass === 'healthy-control');
  assert.ok(healthy, 'negative control needs a healthy scenario');
  if (mode === 'marker') healthy.markerExistsAfter = true;
  if (mode === 'exit') healthy.exit = { code: 1, signal: null };
  if (mode === 'request') healthy.requests = healthy.requests.slice(0, 1);
  let rejected = false;
  try {
    verify(altered, false);
  } catch (error) {
    rejected = true;
    console.log(JSON.stringify({ negativeControl: mode, rejected: true, reason: error.message }));
  }
  if (!rejected) throw new Error(`negative verifier control unexpectedly passed: ${mode}`);
  process.exit(0);
}

console.log(JSON.stringify(verify(report, true)));
