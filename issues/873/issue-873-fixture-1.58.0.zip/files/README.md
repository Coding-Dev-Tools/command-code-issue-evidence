# Issue 873 portable CLI fixture

This packet exercises the unmodified Command Code 1.58.0 CLI on Windows with a native ConPTY and an owned localhost OpenAI-compatible SSE mock. It sends one synthetic `shell_command` call per scenario. No real provider, model, credential, personal configuration or paid inference is used. Product binaries are downloaded from npm and are not included in this packet.

The exact CLI bundle SHA-256 is `aab2bec800371953112d18472bb7383992ef264cca22558bdcda77e7d0dc0f14`. The pinned runtime is Node 24 or a compatible Node release, `@lydell/node-pty` 1.1.0 and `@xterm/headless` 6.0.0. The package files contain exactly three direct dependencies and a lockfile for the complete dependency graph.

## Windows PowerShell commands

Extract the ZIP into a directory whose name contains spaces. From the extracted packet root, run:

```powershell
Set-Location ".\files"
npm ci --ignore-scripts
Set-Location ..
node ".\files\repro-873.mjs" ".\files\node_modules" ".\files\runs"
$run = Get-ChildItem ".\files\runs" -Directory | Sort-Object LastWriteTime -Descending | Select-Object -First 1
node ".\files\verify-873.mjs" $run.FullName
node ".\files\verify-873.mjs" $run.FullName --negative marker
node ".\files\verify-873.mjs" $run.FullName --negative exit
```

The first command creates an exact clean install in the extracted `files` directory. The driver accepts the runtime directory and output directory as its first two arguments. It refuses to overwrite a run directory. The default locations are `files/node_modules` and `files/runs`.

The malformed controls are `echo ${}` and `echo "${}"`. A current 1.58.0 run is expected to reach the CLI permission path, render `Bad substitution: ${}` and `Unhandled Promise Rejection`, and exit with code 1 before a permission prompt. Healthy controls are `echo ${VAR} > issue-873-variable.txt`, `echo '$VAR' > issue-873-single-quoted.txt`, and `echo ISSUE_873_HEALTHY > issue-873-ordinary.txt`. Each should show the real shell permission UI, survive Escape without creating its marker, accept a subsequent harmless user turn through the mock, and exit through `/exit` with code 0.

The verifier checks the raw PTY hash, request count, prompt outcome, process survival, continuation response, marker absence and malformed error text. The `--negative marker` and `--negative exit` invocations alter an in-memory result and must be rejected by the same assertions. Raw PTY files stay in the run directory for local inspection and can contain temporary paths; they are not part of the ZIP.

This evidence covers the actual Windows CLI and local mock boundary. It does not establish real-provider behavior, macOS or Linux parity, a production gateway cause, or a source fix. `FAILURE-ACCOUNTING.json` records the earlier driver attempts retained in the private lab and explains why only the current matrix is bound to the public fixture.
