import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';

const filesDir = path.dirname(fileURLToPath(import.meta.url));
const packetRoot = path.resolve(filesDir, '..');
const runtimeArg = process.argv[2] && !process.argv[2].startsWith('-') ? process.argv[2] : null;
const outputArg = process.argv[3] ?? null;
const runtimeCandidate = path.resolve(runtimeArg ?? path.join(packetRoot, 'node_modules'));
const runtime = fs.existsSync(path.join(runtimeCandidate, 'command-code'))
  ? runtimeCandidate
  : path.join(runtimeCandidate, 'node_modules');
const outputRoot = path.resolve(outputArg ?? path.join(packetRoot, 'runs'));
const guard = path.join(filesDir, 'offline-guard.cjs');
const runId = process.env.ISSUE_873_RUN_ID ?? `${new Date().toISOString().replace(/[:.]/g, '')}-${process.pid}`;
const runDir = path.join(outputRoot, runId);
const runtimePackage = path.join(runtime, '..', 'package.json');
const req = createRequire(runtimePackage);
const pty = req('@lydell/node-pty');
const { Terminal } = req('@xterm/headless');
const cli = path.join(runtime, 'command-code/dist/index.mjs');
const cliBundle = path.join(runtime, 'command-code/dist/cli.mjs');
const cliSha256 = createHash('sha256').update(fs.readFileSync(cliBundle)).digest('hex');
const expectedCliSha256 = 'aab2bec800371953112d18472bb7383992ef264cca22558bdcda77e7d0dc0f14';
assert.equal(cliSha256, expectedCliSha256, 'unexpected CLI bundle');
if (fs.existsSync(runDir)) throw new Error('Refusing to overwrite an existing run directory');
fs.mkdirSync(runDir, { recursive: true });

const allScenarios = [
  { id: 'malformed-bare', command: 'echo ${}', expected: 'reporter-malformed' },
  { id: 'malformed-double-quoted', command: 'echo "${}"', expected: 'reporter-malformed' },
  { id: 'healthy-variable', command: 'echo ${VAR} > issue-873-variable.txt', expected: 'healthy-control', marker: 'issue-873-variable.txt' },
  { id: 'healthy-single-quoted-literal', command: "echo '$VAR' > issue-873-single-quoted.txt", expected: 'healthy-control', marker: 'issue-873-single-quoted.txt' },
  { id: 'healthy-ordinary', command: 'echo ISSUE_873_HEALTHY > issue-873-ordinary.txt', expected: 'healthy-control', marker: 'issue-873-ordinary.txt' }
];
const requestedScenarios = process.env.ISSUE_873_SCENARIOS?.split(',').map(value => value.trim()).filter(Boolean);
const scenarios = requestedScenarios?.length ? allScenarios.filter(scenario => requestedScenarios.includes(scenario.id)) : allScenarios;
if (requestedScenarios?.length && scenarios.length !== requestedScenarios.length) {
  throw new Error(`Unknown ISSUE_873_SCENARIOS value: ${requestedScenarios.join(',')}`);
}
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const sha = value => createHash('sha256').update(value).digest('hex');

function makeEnvironment(home, port) {
  for (const relative of ['tmp', 'AppData/Roaming', 'AppData/Local', '.commandcode']) {
    fs.mkdirSync(path.join(home, relative), { recursive: true });
  }
  const env = {};
  for (const key of ['SystemRoot', 'WINDIR', 'ComSpec', 'PATHEXT', 'PROCESSOR_ARCHITECTURE']) {
    if (process.env[key]) env[key] = process.env[key];
  }
  env.PATH = [path.dirname(process.execPath), ...(process.env.SystemRoot ? [path.join(process.env.SystemRoot, 'System32')] : ['/usr/bin', '/bin'])].join(path.delimiter);
  return Object.assign(env, {
    HOME: home,
    USERPROFILE: home,
    APPDATA: path.join(home, 'AppData/Roaming'),
    LOCALAPPDATA: path.join(home, 'AppData/Local'),
    TEMP: path.join(home, 'tmp'),
    TMP: path.join(home, 'tmp'),
    CMD_LOCAL_ONLY: '1',
    DO_NOT_TRACK: '1',
    OTEL_SDK_DISABLED: 'true',
    COMMANDCODE_SKIP_UPDATES: '1',
    COMMANDCODE_DISABLE_CRON: '1',
    COMMANDCODE_DISABLE_DURABLE_CRON: '1',
    DOTENV_CONFIG_PATH: path.join(home, 'absent.env'),
    TERM: 'xterm-256color',
    NO_COLOR: '1',
    FIXTURE_PORT: String(port),
    FIXTURE_PROVIDER_KEY: 'synthetic-provider-key-not-real',
    COMMAND_CODE_API_KEY: 'synthetic-command-key-not-real'
  });
}

function screenText(term) {
  const buffer = term.buffer.active;
  return Array.from({ length: buffer.length }, (_, index) => buffer.getLine(index)?.translateToString(true) ?? '').join('\n');
}

function stripAnsi(value) {
  return value
    .replace(/[\u001b\u009b]\[[0-?]*[ -/]*[@-~]/g, '')
    .replace(/[\u001b\u009b][\]PX^_].*?(?:\u0007|\u001b\\)/g, '')
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '');
}

function hasPermissionPrompt(raw, screen) {
  const value = stripAnsi(screen);
  return /\b(?:Tool Permission|Execute Shell Command|Allow once|Allow for this|Run this command|Permission denied|Your settings require confirmation)\b/i.test(value);
}

function hasIdlePrompt(screen) {
  const lines = stripAnsi(screen).split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  return lines.slice(-18).some(line => /Ask your question\.\.\./i.test(line));
}

function hasCancellationState(raw, screen) {
  return /Permission denied/i.test(stripAnsi(raw)) && /Ask your question\.\.\./i.test(stripAnsi(screen));
}

async function until(predicate, timeoutMs = 20000) {
  const end = Date.now() + timeoutMs;
  while (Date.now() < end && !predicate()) await sleep(100);
  return predicate();
}

async function typeText(child, value) {
  for (const character of value) {
    child.write(character);
    await sleep(12);
  }
}

function writeSse(res, payloads) {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache' });
  for (const payload of payloads) res.write(`data: ${JSON.stringify(payload)}\n\n`);
  res.end('data: [DONE]\n\n');
}

async function runScenario(scenario) {
  const scenarioDir = path.join(runDir, scenario.id);
  const command = scenario.command;
  const marker = scenario.marker ?? null;
  const home = path.join(scenarioDir, 'home');
  const project = path.join(scenarioDir, 'project');
  fs.mkdirSync(project, { recursive: true });
  const requests = [];
  let selectedTool = null;
  let server;
  server = http.createServer((req, res) => {
    let rawBody = '';
    req.on('data', chunk => {
      rawBody += chunk;
      if (rawBody.length > 4_000_000) req.destroy();
    });
    req.on('end', () => {
      if (!req.url?.endsWith('/chat/completions')) {
        res.writeHead(404);
        res.end('fixture endpoint not found');
        return;
      }
      let body;
      try {
        body = JSON.parse(rawBody);
      } catch {
        res.writeHead(400);
        res.end('invalid JSON');
        return;
      }
      const toolNames = (body.tools ?? []).map(tool => tool.function?.name ?? tool.name).filter(Boolean);
      const messageRoles = (body.messages ?? []).map(message => message.role);
      const toolMessages = (body.messages ?? [])
        .filter(message => message.role === 'tool')
        .map(message => String(message.content).slice(0, 400));
      const targetCandidates = ['shell_command', 'powershell', 'bash', 'shell', 'execute'];
      selectedTool ??= targetCandidates.find(name => toolNames.includes(name)) ?? null;
      const request = { index: requests.length + 1, path: req.url, toolNames, messageRoles, selectedTool, toolMessageCount: toolMessages.length };
      requests.push({ ...request, toolMessages });
      fs.writeFileSync(path.join(scenarioDir, 'mock-requests.json'), JSON.stringify(requests.map(({ toolMessages: _ignored, ...safe }) => safe), null, 2) + '\n');
      const base = { id: `issue-873-${scenario.id}-${requests.length}`, object: 'chat.completion.chunk', created: 1, model: 'fixture-model' };
      if (requests.length === 1 && selectedTool) {
        const toolInput = {
          command,
          description: `Issue 873 ${scenario.id} harmless permission fixture`,
          cwd: project,
          timeout: 1000
        };
        writeSse(res, [
          { ...base, choices: [{ index: 0, delta: { role: 'assistant', tool_calls: [{ index: 0, id: `call-873-${scenario.id}`, type: 'function', function: { name: selectedTool, arguments: JSON.stringify(toolInput) } }] }, finish_reason: null }] },
          { ...base, choices: [{ index: 0, delta: {}, finish_reason: 'tool_calls' }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } }
        ]);
        return;
      }
      const recovery = requests.length > 1 && toolMessages.length > 0;
      writeSse(res, [
        { ...base, choices: [{ index: 0, delta: { role: 'assistant', content: recovery ? 'ISSUE_873_CONTINUATION_OK' : 'ISSUE_873_NO_SHELL_TOOL' }, finish_reason: null }] },
        { ...base, choices: [{ index: 0, delta: {}, finish_reason: 'stop' }], usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 } }
      ]);
    });
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;
  const env = makeEnvironment(home, port);
  const model = 'fixture873/model';
  fs.writeFileSync(path.join(home, '.commandcode/providers.json'), JSON.stringify({ provider: { fixture873: { api: 'openai-completions', baseURL: `http://127.0.0.1:${port}/v1`, apiKey: '$FIXTURE_PROVIDER_KEY', models: { model: { contextWindow: 200000, maxOutput: 200, cost: { input: 0, output: 0 } } } } } }, null, 2));
  fs.writeFileSync(path.join(home, '.commandcode/config.json'), JSON.stringify({ model, provider: 'fixture873', localOnly: true, telemetry: false, tasteLearning: false }, null, 2));
  const permissions = { defaultMode: 'default' };
  if (process.env.ISSUE_873_FORCE_ASK !== '0') permissions.ask = ['Shell'];
  fs.writeFileSync(path.join(home, '.commandcode/settings.json'), JSON.stringify({ disableScratchpad: true, disableSkillShellExecution: true, permissions }, null, 2));
  const nodeArgs = [
    '--permission',
    '--allow-child-process',
    `--allow-fs-read=${runtime}`,
    `--allow-fs-read=${runDir}`,
    `--allow-fs-read=${filesDir}`,
    `--allow-fs-write=${runDir}`,
    '--require', guard,
    cli,
    '--no-auto-update', '--local-only', '--skip-onboarding', '--no-skills',
    '--model', model, '--permission-mode', 'default', '--max-turns', '3',
    'Run the synthetic permission check. Wait for the permission decision.'
  ];
  const term = new Terminal({ cols: 120, rows: 38, allowProposedApi: true, scrollback: 3000 });
  let raw = '';
  let exit = null;
  let child;
  const steps = [];
  const started = Date.now();
  const record = (name, extra = {}) => {
    const screen = screenText(term);
    const row = { name, at: new Date().toISOString(), screenTail: screen.length > 5000 ? screen.slice(-5000) : screen, rawTail: stripAnsi(raw).length > 5000 ? stripAnsi(raw).slice(-5000) : stripAnsi(raw), requestCount: requests.length, selectedTool, exit, ...extra };
    fs.writeFileSync(path.join(scenarioDir, `${name}.json`), JSON.stringify(row, null, 2) + '\n');
    const { screenTail: _screen, rawTail: _raw, ...safe } = row;
    steps.push(safe);
  };
  let promptObserved = false;
  let processAliveAfterCancel = false;
  let followupPromptObserved = false;
  let followupSubmitted = false;
  let continuationRequestObserved = false;
  let continuationObserved = false;
  let processAliveAfterContinuation = false;
  try {
    child = pty.spawn(process.execPath, nodeArgs, { name: 'xterm-256color', cols: 120, rows: 38, cwd: project, env, useConpty: process.platform === 'win32', windowsHide: true });
    child.onData(data => { raw += data; term.write(data); });
    child.onExit(event => { exit = { code: event.exitCode, signal: event.signal }; });
    const idlePromptObserved = await until(() => hasIdlePrompt(screenText(term)) || exit, 20000);
    record('startup', { idlePromptObserved });
    if (!exit && idlePromptObserved) {
      await typeText(child, 'Run the synthetic permission check.');
      child.write('\r');
      await sleep(500);
      record('user-turn-submitted', { userTurnSubmitted: true });
    }
    await until(() => requests.length > 0 || exit, 25000);
    record('after-provider-request', { providerRequestObserved: requests.length > 0 });
    await until(() => {
      if (hasPermissionPrompt(raw, screenText(term))) promptObserved = true;
      return promptObserved || Boolean(exit);
    }, 20000);
    record('permission-observation', { promptObserved });
    if (scenario.expected === 'reporter-malformed') {
      if (!exit) await until(() => exit, 8000);
      record('malformed-completion', { exitObserved: Boolean(exit) });
    } else if (promptObserved && !exit) {
      child.write('\u001b');
      const cancellationSettled = await until(() => hasCancellationState(raw, screenText(term)) || exit, 15000);
      processAliveAfterCancel = !exit;
      record('after-escape-cancel', { escapeSent: true, cancellationSettled, permissionDeniedObserved: hasCancellationState(raw, screenText(term)), processAliveAfterCancel });
      if (processAliveAfterCancel) {
        followupPromptObserved = await until(() => hasCancellationState(raw, screenText(term)), 5000);
        record('followup-ready', { followupPromptObserved });
        if (followupPromptObserved && !exit) {
          await typeText(child, 'Continue with the harmless follow-up check.');
          child.write('\r');
          followupSubmitted = true;
          record('followup-submitted', { followupSubmitted });
          continuationRequestObserved = await until(() => requests.length >= 2 || exit, 25000);
          continuationObserved = await until(() => screenText(term).includes('ISSUE_873_CONTINUATION_OK') || exit, 20000);
          processAliveAfterContinuation = !exit;
          record('continuation-observation', { continuationRequestObserved, continuationObserved, processAliveAfterContinuation });
        }
      }
      if (!exit) {
        child.write('/exit');
        child.write('\r');
        await until(() => exit, 10000);
      }
      record('after-exit', { cleanExitObserved: exit?.code === 0 });
    } else if (!exit) {
      child.write('\u0003');
      await until(() => exit, 5000);
      record('after-no-prompt-cancel', { escapeSent: false, ctrlCSent: true, processAliveAfterCancel: !exit });
    }
    if (!exit) {
      child.kill();
      await until(() => exit, 3000);
      record('forced-cleanup', { forcedCleanup: true });
    }
  } catch (error) {
    record('driver-error', { driverError: { message: error.message, name: error.name } });
    if (child && !exit) child.kill();
  } finally {
    if (child) {
      try { child.kill(); } catch {}
    }
    server.closeAllConnections();
    await new Promise(resolve => server.close(resolve));
    term.dispose();
  }
  const rawFile = path.join(scenarioDir, 'terminal.raw');
  fs.writeFileSync(rawFile, raw);
  const result = {
    scenario: scenario.id,
    command,
    expectedClass: scenario.expected,
    marker,
    node: process.version,
    cliVersion: '1.58.0',
    cliSha256,
    platform: process.platform,
    shell: process.platform === 'win32' ? 'Windows ConPTY' : 'POSIX PTY',
    elapsedMs: Date.now() - started,
    exit,
    requests: requests.map(({ toolMessages: _ignored, ...safe }) => safe),
    selectedTool,
    steps,
    promptObserved,
    processAliveAfterCancel,
    followupPromptObserved,
    followupSubmitted,
    continuationRequestObserved,
    continuationObserved,
    processAliveAfterContinuation,
    continuationToken: continuationObserved ? 'ISSUE_873_CONTINUATION_OK' : null,
    markerExistsAfter: marker ? fs.existsSync(path.join(project, marker)) : false,
    rawSha256: sha(raw),
    rawFile: path.relative(runDir, rawFile).replaceAll('\\', '/'),
    scope: 'Unmodified Command Code 1.58.0 CLI, isolated synthetic home, owned localhost OpenAI-compatible stream, guarded PTY. No real provider, model, credentials, user config, or approved shell command.'
  };
  fs.writeFileSync(path.join(scenarioDir, 'result.json'), JSON.stringify(result, null, 2) + '\n');
  return result;
}

const results = [];
for (const scenario of scenarios) {
  try {
    results.push(await runScenario(scenario));
  } catch (error) {
    results.push({ scenario: scenario.id, command: scenario.command, expectedClass: scenario.expected, driverError: { message: error.message, name: error.name } });
  }
}
const report = {
  runId,
  generatedAt: new Date().toISOString(),
  package: { name: 'command-code', version: '1.58.0', cliSha256, node: process.version, pty: '@lydell/node-pty@1.1.0', terminal: '@xterm/headless@6.0.0' },
  scenarios: results,
  limitations: [
    'The mock provider determines the tool call and final text; it does not establish behavior of a real model or provider gateway.',
    'Child-process permission is enabled only to reach the CLI shell-permission gate; the driver never sends approval, and each healthy marker file must remain absent after Escape.',
    'The test uses Windows ConPTY when run on Windows. It does not prove the reporter macOS shell behavior or the Linux #856 variant.',
    'Raw PTY captures remain local evidence. The JSON projections omit system prompts and absolute filesystem paths.'
  ]
};
fs.writeFileSync(path.join(runDir, 'results.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ runId, results: results.map(result => ({ scenario: result.scenario, exit: result.exit, promptObserved: result.promptObserved, processAliveAfterCancel: result.processAliveAfterCancel, followupSubmitted: result.followupSubmitted, continuationObserved: result.continuationObserved, requests: result.requests?.length ?? 0, driverError: result.driverError?.message ?? null })) }));





